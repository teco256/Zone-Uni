import * as h from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
const SKIN_TONES = [{ id: "porcelain", name: "Porcelain", hex: 16243140 }, { id: "fair", name: "Fair", hex: 15911336 }, { id: "light", name: "Light", hex: 15776154 }, { id: "honey", name: "Honey", hex: 14721911 }, { id: "tan", name: "Tan", hex: 14260844 }, { id: "caramel", name: "Caramel", hex: 12878671 }, { id: "olive", name: "Olive", hex: 12221519 }, { id: "brown", name: "Brown", hex: 9262372 }, { id: "umber", name: "Umber", hex: 7619357 }, { id: "deep", name: "Deep", hex: 6042391 }, { id: "ebony", name: "Ebony", hex: 3809040 }, { id: "mint", name: "Mint", hex: 10479044 }, { id: "lilac", name: "Lilac", hex: 12824304 }, { id: "sky", name: "Sky", hex: 9357552 }, { id: "coral", name: "Coral", hex: 15899284 }];
const SHIRT_COLORS = [{ id: "zoneblue", name: "Zone Blue", hex: 2981330 }, { id: "navy", name: "Navy", hex: 1784432 }, { id: "red", name: "Ember", hex: 14697790 }, { id: "green", name: "Turf", hex: 3515226 }, { id: "purple", name: "Grape", hex: 8146365 }, { id: "orange", name: "Sunset", hex: 15698996 }, { id: "pink", name: "Bubblegum", hex: 15695794 }, { id: "yellow", name: "Banana", hex: 15910724 }, { id: "white", name: "Chalk", hex: 15660026 }, { id: "black", name: "Midnight", hex: 2237998 }];
const ACCENT = 2981330;
function matte(R) {
  return new h.MeshLambertMaterial({ color: R });
}
function matteFront(R) {
  return new h.MeshLambertMaterial({ color: R, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
}
function basicFront(R) {
  return new h.MeshBasicMaterial({ ...R, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 });
}
function shadeOf(R, f) {
  const M = new h.Color(R);
  return M.multiplyScalar(f), M.getHex();
}
function shirtTrim(R) {
  const f = new h.Color(R), M = 0.2126 * f.r + 0.7152 * f.g + 0.0722 * f.b;
  return M > 0.62 ? 2237998 : 15922939;
}
const HEAD_TOP = 0.289, HEAD_FRONT = 0.25, EAR_Y = 0.077, EAR_X = 0.186, HEAD_POLAR_Y = [-0.21, -0.185, -0.16, -0.135, -0.11, -0.085, -0.06, -0.035, -0.01, 0.015, 0.04, 0.065, 0.09, 0.115, 0.14, 0.165, 0.19, 0.215, 0.24, 0.265], HEAD_POLAR = [[0.2195, 0.2212, 0.2165, 0.2025, 0.1651, 0.1341, 0.1102, 0.0944, 0.0812, 0.0684, 0.0621, 0.0548, 0.05, 0.0458, 0.0431, 0.0426], [0.2346, 0.2349, 0.2314, 0.2161, 0.1873, 0.1598, 0.1355, 0.1204, 0.105, 0.0945, 0.0899, 0.0866, 0.0866, 0.0846, 0.0826, 0.0789], [0.2415, 0.2411, 0.237, 0.2262, 0.2021, 0.1701, 0.1511, 0.1327, 0.122, 0.1157, 0.1139, 0.1154, 0.1153, 0.1125, 0.1111, 0.1075], [0.247, 0.2462, 0.2419, 0.2325, 0.2112, 0.1867, 0.1615, 0.1461, 0.1339, 0.129, 0.1296, 0.1318, 0.1337, 0.1343, 0.134, 0.1332], [0.2505, 0.2496, 0.2458, 0.2374, 0.2208, 0.1988, 0.1737, 0.1563, 0.143, 0.1379, 0.1404, 0.1465, 0.1486, 0.1519, 0.1532, 0.1533], [0.2525, 0.2514, 0.2486, 0.2415, 0.2258, 0.2065, 0.1841, 0.1671, 0.1525, 0.1458, 0.1492, 0.1562, 0.1599, 0.1646, 0.167, 0.1674], [0.2525, 0.2518, 0.2499, 0.2437, 0.2316, 0.214, 0.1951, 0.1737, 0.1609, 0.1521, 0.1559, 0.1636, 0.1701, 0.176, 0.1794, 0.1803], [0.2522, 0.2522, 0.2508, 0.2452, 0.2339, 0.2174, 0.1979, 0.1814, 0.1675, 0.158, 0.1612, 0.1697, 0.1766, 0.183, 0.187, 0.1882], [0.2514, 0.2515, 0.2509, 0.2466, 0.2363, 0.2223, 0.203, 0.1861, 0.1726, 0.163, 0.1666, 0.1754, 0.1827, 0.1893, 0.1938, 0.1951], [0.2502, 0.2509, 0.2509, 0.2466, 0.2372, 0.2229, 0.2061, 0.1885, 0.176, 0.1671, 0.1712, 0.1809, 0.1883, 0.1947, 0.1996, 0.2013], [0.2477, 0.2488, 0.2491, 0.2458, 0.2372, 0.2232, 0.2067, 0.1903, 0.1775, 0.1694, 0.1743, 0.1834, 0.1902, 0.1964, 0.2014, 0.2029], [0.2446, 0.246, 0.2469, 0.2441, 0.2365, 0.223, 0.2067, 0.1903, 0.1782, 0.1704, 0.1755, 0.1847, 0.1918, 0.1977, 0.2025, 0.2042], [0.2408, 0.2419, 0.2436, 0.2414, 0.2339, 0.2217, 0.2059, 0.1903, 0.1782, 0.1707, 0.1757, 0.1851, 0.1918, 0.1973, 0.2016, 0.2032], [0.2362, 0.2376, 0.2395, 0.2379, 0.2315, 0.2185, 0.2025, 0.1886, 0.1778, 0.1707, 0.1757, 0.1851, 0.1918, 0.1972, 0.2016, 0.2032], [0.2305, 0.2322, 0.2343, 0.233, 0.227, 0.2154, 0.2014, 0.1864, 0.176, 0.1695, 0.1746, 0.1828, 0.1886, 0.1937, 0.1984, 0.1998], [0.2226, 0.2246, 0.2274, 0.2267, 0.221, 0.2097, 0.1945, 0.1826, 0.1721, 0.167, 0.1721, 0.179, 0.1848, 0.1906, 0.194, 0.1952], [0.2138, 0.2142, 0.218, 0.2178, 0.2122, 0.201, 0.1886, 0.176, 0.1661, 0.163, 0.1675, 0.1745, 0.1799, 0.1841, 0.1869, 0.1877], [0.202, 0.2048, 0.2081, 0.2081, 0.204, 0.1904, 0.1777, 0.1665, 0.1581, 0.1559, 0.1615, 0.1674, 0.1723, 0.1757, 0.1775, 0.1776], [0.1902, 0.1926, 0.1962, 0.1965, 0.192, 0.1791, 0.1648, 0.1531, 0.1454, 0.1447, 0.1497, 0.156, 0.1596, 0.1614, 0.1642, 0.1634], [0.1728, 0.1748, 0.1789, 0.1777, 0.1724, 0.1576, 0.143, 0.1327, 0.1255, 0.1228, 0.1287, 0.1355, 0.138, 0.1391, 0.14, 0.1375]], POLAR_N = 16;
function headRadius(R, M) {
  const D = HEAD_POLAR_Y, g = D.length - 1;
  let J = 0;
  while (J < g && R > D[J + 1]) J++;
  const C = R <= D[0] ? 0 : R >= D[g] ? 1 : (R - D[J]) / (D[J + 1] - D[J]), Q = HEAD_POLAR[R <= D[0] ? 0 : J], W = HEAD_POLAR[R >= D[g] ? g : Math.min(J + 1, g)];
  let v = Math.abs((M % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2));
  if (v > Math.PI) v = Math.PI * 2 - v;
  const x = v / Math.PI * (POLAR_N - 1), O = Math.min(POLAR_N - 2, Math.floor(x)), L = x - O, p = Q[O] + (Q[O + 1] - Q[O]) * L, m = W[O] + (W[O + 1] - W[O]) * L;
  return p + (m - p) * C;
}
function headHalfWidth(R) {
  return headRadius(R, Math.PI / 2);
}
function headZ(R) {
  return (headRadius(R, 0) - headRadius(R, Math.PI)) / 2;
}
function headDepth(R) {
  return (headRadius(R, 0) + headRadius(R, Math.PI)) / 2 / headHalfWidth(R);
}
const HEAD_SEG = 32;
function headGeometry(R, { cap = false, floor = false } = {}) {
  const f = [], D = [], J = HEAD_SEG;
  for (const [W, Y] of R) {
    for (let v = 0; v < J; v++) {
      const x = v / J * Math.PI * 2, O = Math.max(15e-4, headRadius(W, x) + Y);
      f.push(Math.sin(x) * O, W, Math.cos(x) * O);
    }
  }
  for (let L = 0; L + 1 < R.length; L++) {
    for (let p = 0; p < J; p++) {
      const m = L * J + p, H = L * J + (p + 1) % J, V = m + J, s = H + J;
      D.push(m, H, V, H, s, V);
    }
  }
  const C = (N, K, P) => {
    const w = f.length / 3;
    f.push(0, K, 0);
    for (let z = 0; z < J; z++) {
      const T = N * J + z, o = N * J + (z + 1) % J;
      if (P) D.push(w, T, o);
      else D.push(w, o, T);
    }
  };
  if (cap) C(R.length - 1, R[R.length - 1][0], true);
  if (floor) C(0, R[0][0], false);
  const Q = new h.BufferGeometry();
  return Q.setAttribute("position", new h.Float32BufferAttribute(f, 3)), Q.setIndex(D), Q.computeVertexNormals(), Q;
}
function headRing(R, f, M, D, J = 1.04) {
  const C = headHalfWidth(R) * (J - 1) + 4e-3, k = headGeometry([[R - f / 2, C], [R + f / 2, C]], { cap: !M, floor: !M });
  return new h.Mesh(k, matte(D));
}
function headShell(R, f, M, D = 0.014, g = matte) {
  const J = HEAD_TOP - 0.035, C = headHalfWidth(J) + D, k = Math.max(1e-3, f - J), Q = [], W = 18;
  for (let v = 0; v <= W; v++) {
    const x = R + (f - R) * (v / W);
    if (x <= J) Q.push([x, D]);
    else {
      const O = Math.min(1, (x - J) / k), L = C * Math.cos(O * Math.PI * 0.5);
      Q.push([x, L - headRadius(x, Math.PI / 2)]);
    }
  }
  const Y = new h.Mesh(headGeometry(Q, { cap: true }), g(M));
  return Y;
}
function headDome(R, f, M, D = 1.045) {
  return headShell(R, f, M, headHalfWidth(R) * (D - 1) + 6e-3);
}
function headBrim(R, f, D, J = 0.026, C = 0, Q = 8e-3) {
  const W = HEAD_SEG, Y = [], v = [], x = [[R + J / 2, 1], [R - C + J / 2, f], [R - C - J / 2, f], [R - J / 2, 1]];
  for (const [L, p] of x) {
    for (let m = 0; m < W; m++) {
      const H = m / W * Math.PI * 2, V = (headRadius(R, H) + Q) * p;
      Y.push(Math.sin(H) * V, L, Math.cos(H) * V);
    }
  }
  for (let s = 0; s < x.length; s++) {
    const N = (s + 1) % x.length;
    for (let K = 0; K < W; K++) {
      const P = s * W + K, w = s * W + (K + 1) % W, z = N * W + K, T = N * W + (K + 1) % W;
      v.push(P, w, z, w, T, z);
    }
  }
  const O = new h.BufferGeometry();
  return O.setAttribute("position", new h.Float32BufferAttribute(Y, 3)), O.setIndex(v), O.computeVertexNormals(), new h.Mesh(O, matte(D));
}
function peak(R, f, M, D = 1, g = 0.24) {
  const J = headHalfWidth(R), C = new h.Mesh(new h.CylinderGeometry(J * D, J * D, 0.03, 30, 1, false, -0.62, 1.24), matteFront(M));
  return C.scale.z = headDepth(R) * f, C.position.set(0, R, headZ(R) + 0.02), C.rotation.x = g, C;
}
function makeCap(R) {
  const f = new h.Group(), M = 2981330, D = 1924254;
  f.add(headDome(0.1, 0.315, M)), f.add(headRing(0.108, 0.05, false, D, 1.055)), f.add(peak(0.142, 1.5, D, 1.04, 0.14));
  const J = new h.Mesh(new h.SphereGeometry(0.022, 10, 8), matte(D));
  J.position.y = 0.313, f.add(J);
  if (R) {
    const C = 0.2, k = 0.58, Q = 0.07, W = headHalfWidth(0.1) * 0.045 + 6e-3, Y = headRadius(C, k) + W, v = (headRadius(C + 0.01, k) - headRadius(C - 0.01, k)) / 0.02, x = Q / 2 * (Q / 2) / (2 * Y), O = Y + x + 6e-3, L = logoPatch(R, Q, Math.sin(k) * O, C, Math.cos(k) * O, 0);
    L.rotation.order = "YXZ", L.rotation.set(Math.atan(v), k, 0), f.add(L);
  }
  return f;
}
function makeBeanie(R) {
  const f = new h.Group(), M = 14173502, D = 12072239;
  f.add(headDome(0.105, 0.335, M, 1.055)), f.add(headRing(0.125, 0.075, false, D, 1.085));
  const J = new h.Mesh(new h.SphereGeometry(0.05, 14, 11), matte(15922939));
  return J.position.y = 0.352, f.add(J), f;
}
function makeBucket() {
  const R = new h.Group(), f = 4168802, M = 3112268, D = new h.Mesh(headGeometry([[0.122, 0.012], [0.2, 0.022], [0.265, 0.034], [0.305, 0.028]], { cap: true }), matte(f));
  return R.add(D), R.add(headRing(0.128, 0.045, false, M, 1.075)), R.add(headBrim(0.112, 1.62, f, 0.026, 0.022, 0.014)), R;
}
function makeTopHat() {
  const R = new h.Group(), f = 2237998;
  R.add(headBrim(0.235, 1.9, f, 0.026, 0.012, 0.012));
  const M = headHalfWidth(0.235) * 1.12, D = new h.Mesh(new h.CylinderGeometry(M * 1.02, M, 0.36, 30), matte(f));
  D.scale.z = headDepth(0.235), D.position.set(0, 0.425, headZ(0.235)), R.add(D);
  const J = new h.Mesh(new h.CylinderGeometry(M * 1.06, M * 1.06, 0.07, 30), matte(9252664));
  return J.scale.z = headDepth(0.235), J.position.set(0, 0.278, headZ(0.235)), R.add(J), R;
}
function makeCrown() {
  const R = new h.Group(), f = 15777856, M = 14263585, D = 0.185, J = headHalfWidth(D) * 1.06, C = headZ(D);
  R.add(headRing(D, 0.085, false, f, 1.06));
  const k = headRing(D - 0.045, 0.028, false, M, 1.075);
  R.add(k);
  for (let Q = 0; Q < 9; Q++) {
    const W = Q / 9 * Math.PI * 2, Y = Math.sin(W) * J * 0.94, v = Math.cos(W) * J * headDepth(D) * 0.94, x = new h.Mesh(new h.ConeGeometry(0.032, 0.105, 4), matte(f));
    x.position.set(Y, D + 0.09, C + v), x.rotation.y = W, R.add(x);
    const O = new h.Mesh(new h.SphereGeometry(0.019, 8, 6), matte(Q % 3 === 0 ? 14173502 : 4161496));
    O.position.set(Y * 1.03, D + 5e-3, C + v * 1.03), R.add(O);
  }
  return R;
}
function makeHeadphones() {
  const R = new h.Group(), f = 2566963, M = 2981330, D = EAR_X * 1.16, J = new h.Mesh(new h.TorusGeometry(D, 0.024, 10, 28, Math.PI), matte(f));
  J.position.set(0, EAR_Y + 0.03, headZ(EAR_Y + 0.03)), J.scale.y = 1.18, R.add(J);
  for (const C of [-1, 1]) {
    const k = new h.Mesh(new h.CylinderGeometry(0.072, 0.072, 0.055, 20), matte(f));
    k.rotation.z = Math.PI / 2, k.position.set(C * (EAR_X + 0.012), EAR_Y, headZ(EAR_Y)), R.add(k);
    const Q = new h.Mesh(new h.TorusGeometry(0.058, 0.021, 8, 20), matte(1382429));
    Q.rotation.y = Math.PI / 2, Q.position.set(C * (EAR_X - 0.012), EAR_Y, headZ(EAR_Y)), R.add(Q);
    const W = new h.Mesh(new h.CylinderGeometry(0.028, 0.028, 0.058, 16), matte(M));
    W.rotation.z = Math.PI / 2, W.position.set(C * (EAR_X + 0.016), EAR_Y, headZ(EAR_Y)), R.add(W);
  }
  return R;
}
function makePartyHat() {
  const R = new h.Group(), f = 0.235, M = headHalfWidth(f) * 1.15, D = headZ(f), J = new h.Mesh(new h.ConeGeometry(M, 0.34, 20), matte(15691688));
  J.scale.z = 1.12, J.position.set(0, f + 0.17, D), R.add(J);
  for (let k = 0; k < 3; k++) {
    const Q = (k + 1) / 4, W = new h.Mesh(new h.TorusGeometry(M * (1 - Q) + 0.012, 0.013, 6, 20), matte(16765514));
    W.rotation.x = Math.PI / 2, W.scale.y = 1.12, W.position.set(0, f + 0.34 * Q, D), R.add(W);
  }
  const C = new h.Mesh(new h.SphereGeometry(0.042, 12, 10), matte(15922939));
  return C.position.set(0, f + 0.35, D), R.add(C), R;
}
function makeHeadband() {
  const R = new h.Group();
  R.add(headRing(0.135, 0.062, false, 15660026, 1.07));
  const f = headRing(0.135, 0.02, false, 2981330, 1.078);
  return R.add(f), R;
}
function makeHalo() {
  const R = new h.Group(), f = new h.Mesh(new h.TorusGeometry(0.135, 0.022, 10, 30), new h.MeshBasicMaterial({ color: 16771466 }));
  return f.rotation.x = Math.PI / 2, f.position.set(0, 0.44, headZ(HEAD_TOP)), R.add(f), R.userData.spin = f, R;
}
const HAIR_COLORS = [{ id: "black", name: "Black", hex: 1840914 }, { id: "brown", name: "Brown", hex: 4861725 }, { id: "auburn", name: "Auburn", hex: 8009248 }, { id: "blonde", name: "Blonde", hex: 14267754 }, { id: "red", name: "Ginger", hex: 11555372 }, { id: "gray", name: "Gray", hex: 10132122 }, { id: "white", name: "Silver", hex: 15263978 }, { id: "blue", name: "Blue", hex: 4026320 }, { id: "pink", name: "Pink", hex: 15239360 }];
const HAIR_BASE = 0.145;
function hairDome(R, f, M, D = 1.05) {
  return headShell(R, f, M, headHalfWidth(R) * (D - 1) + 4e-3, matteFront);
}
function hairShard(R, f, M) {
  const D = new h.Mesh(new h.ConeGeometry(M, f, 5), matteFront(R));
  return D.scale.x = 0.62, D;
}
function makeHairShort(R) {
  const f = new h.Group();
  f.add(hairDome(HAIR_BASE, HEAD_TOP + 0.01, R, 1.045));
  const M = 0.05, D = -1.15;
  for (const [J, C] of [[-0.05, 0.22], [5e-3, 0.05], [0.06, -0.2]]) {
    const k = hairShard(R, M, 0.02);
    k.position.set(J, HAIR_BASE + 0.012 + M / 2 * Math.cos(D), HEAD_FRONT * 0.62 - M / 2 * Math.sin(D)), k.rotation.set(D, 0, C), f.add(k);
  }
  return f;
}
function makeHairBuzz(R) {
  return hairDome(HAIR_BASE + 0.01, HEAD_TOP + 1e-3, R, 1.02);
}
function makeHairFlattop(R) {
  const f = new h.Group(), M = 0.21, D = headHalfWidth(M) * 1.06, J = headHalfWidth(HAIR_BASE) * 1.05, C = new h.Mesh(new h.CylinderGeometry(D, J, M - HAIR_BASE, 22), matteFront(R));
  C.scale.z = headDepth(HAIR_BASE), C.position.set(0, (M + HAIR_BASE) / 2, headZ((M + HAIR_BASE) / 2)), f.add(C);
  const k = 0.09, Q = new h.Mesh(new h.CylinderGeometry(D * 0.95, D, k, 22), matteFront(R));
  Q.scale.z = headDepth(M) * 0.97, Q.position.set(0, M + k / 2, headZ(M)), f.add(Q);
  const W = new h.Mesh(new h.CylinderGeometry(D * 0.95, D * 0.95, 0.012, 22), matteFront(R));
  return W.scale.z = headDepth(M) * 0.97, W.position.set(0, M + k, headZ(M)), f.add(W), f;
}
function makeHairMessy(R) {
  const f = new h.Group();
  f.add(hairDome(HAIR_BASE, HEAD_TOP + 0.015, R, 1.05));
  const M = [[0.015, HEAD_TOP + 0.028, 0.02, -0.18, 0.1], [-0.06, HEAD_TOP + 0.015, -0.01, 0.22, -0.12], [0.065, HEAD_TOP + 0.01, 0.03, -0.28, 0.22], [-0.02, HEAD_TOP + 0.032, -0.06, 0.1, -0.2], [0.03, HEAD_TOP + 0.02, -0.08, -0.15, 0.15]], D = 0.036;
  for (const [J, C, k, Q, W] of M) {
    const Y = hairShard(R, D, 0.016);
    Y.position.set(J, C + D / 2 * Math.cos(Q), k - D / 2 * Math.sin(Q)), Y.rotation.set(Q, 0, W), f.add(Y);
  }
  return f;
}
function makeHairMohawk(R) {
  const f = new h.Group();
  f.add(hairDome(HAIR_BASE, HAIR_BASE + 6e-3, R, 1.01));
  for (let M = 0; M < 6; M++) {
    const D = M / 5, J = HEAD_TOP - 0.03 + D * 0.015, C = HEAD_FRONT * (1 - D * 1.7), k = 0.05 - D * 0.015, Q = -0.3 + D * 0.9, W = hairShard(R, k, 0.014);
    W.position.set(0, J + 0.03 + k / 2 * Math.cos(Q), C - k / 2 * Math.sin(Q)), W.rotation.x = Q, f.add(W);
  }
  return f;
}
function makeHairSpiky(R) {
  const f = new h.Group();
  f.add(hairDome(HAIR_BASE, HEAD_TOP + 0.015, R, 1.05));
  const M = [[-0.09, -0.02, 0.135, 0.032, -0.25, 0.55], [-0.04, -0.055, 0.155, 0.034, -0.15, 0.3], [0.02, -0.065, 0.16, 0.034, -0.1, -0.05], [0.07, -0.04, 0.14, 0.032, -0.15, -0.35], [0.1, 5e-3, 0.11, 0.028, -0.3, -0.6], [-0.13, 0.02, 0.1, 0.028, -0.35, 0.75]];
  for (const [D, J, C, k, Q, W] of M) {
    const Y = hairShard(R, C, k);
    Y.position.set(D, HEAD_TOP - 0.01 + C / 2 * Math.cos(Q), J - C / 2 * Math.sin(Q)), Y.rotation.set(Q, 0, W), f.add(Y);
  }
  for (const [v, O] of [[-0.09, 0.9], [-0.04, 0.75]]) {
    const L = 0.09, i = -0.55, p = hairShard(R, L, 0.022);
    p.position.set(v, HAIR_BASE + 0.03 + L / 2 * Math.cos(i), HEAD_FRONT * 0.55 - L / 2 * Math.sin(i)), p.rotation.set(i, 0, O), f.add(p);
  }
  return f;
}
function makeHairBun(R) {
  const f = new h.Group();
  f.add(hairDome(HAIR_BASE, HEAD_TOP - 0.01, R, 1.03));
  const M = new h.Mesh(new h.SphereGeometry(0.075, 16, 12), matteFront(R));
  return M.position.set(0, HEAD_TOP + 0.05, headZ(HEAD_TOP) - headHalfWidth(0.23) * headDepth(0.23) * 0.5), f.add(M), f;
}
const HAIR_DISABLED = true;
const HAIR = [{ id: "none", name: "Bald", build: null, icon: "\u{1F468}\u200D\u{1F9B2}" }, { id: "buzz", name: "Buzz Cut", build: makeHairBuzz, icon: "\u{1F487}" }, { id: "short", name: "Short", build: makeHairShort, icon: "\u{1F488}" }, { id: "spiky", name: "Spiky", build: makeHairSpiky, icon: "\u26A1" }, { id: "messy", name: "Messy", build: makeHairMessy, icon: "\u{1F64B}" }, { id: "flattop", name: "Flat Top", build: makeHairFlattop, icon: "\u{1F9D1}" }, { id: "mohawk", name: "Mohawk", build: makeHairMohawk, icon: "\u{1F3B8}" }, { id: "bun", name: "Bun", build: makeHairBun, icon: "\u{1F38E}" }], HAIR_HIDDEN_UNDER = /* @__PURE__ */ new Set(["cap", "beanie", "bucket", "tophat", "party"]), HATS = [{ id: "none", name: "None", build: null, icon: "\u20E0" }, { id: "cap", name: "Zone Cap", build: makeCap, logo: true, icon: "\u{1F9E2}" }, { id: "beanie", name: "Beanie", build: makeBeanie, icon: "\u{1F9E3}" }, { id: "bucket", name: "Bucket Hat", build: makeBucket, icon: "\u{1FAA3}" }, { id: "band", name: "Headband", build: makeHeadband, icon: "\u{1F3BD}" }, { id: "tophat", name: "Top Hat", build: makeTopHat, icon: "\u{1F3A9}" }, { id: "crown", name: "Crown", build: makeCrown, icon: "\u{1F451}" }, { id: "cans", name: "Headphones", build: makeHeadphones, icon: "\u{1F3A7}" }, { id: "party", name: "Party Hat", build: makePartyHat, icon: "\u{1F389}" }, { id: "halo", name: "Halo", build: makeHalo, icon: "\u{1F607}" }], FACE_SURFACE_X = [0, 0.025, 0.05, 0.075, 0.1, 0.125, 0.15, 0.175], FACE_SURFACE_Y = [-0.11, -0.08, -0.05, -0.02, 0.01, 0.04, 0.07, 0.1, 0.13, 0.16, 0.19], FACE_SURFACE = [[0.2499, 0.2499, 0.2478, 0.2416, 0.2319, 0.2185, 0.176, 0.1468], [0.2525, 0.2525, 0.2504, 0.2443, 0.2342, 0.2199, 0.2006, 0.1753], [0.2525, 0.2525, 0.2504, 0.2447, 0.2347, 0.22, 0.2006, 0.1753], [0.2522, 0.2522, 0.2504, 0.2447, 0.2347, 0.22, 0.1999, 0.1743], [0.2501, 0.2501, 0.2483, 0.2429, 0.2332, 0.2301, 0.2156, 0.1727], [0.2467, 0.2467, 0.245, 0.2397, 0.2301, 0.2301, 0.2156, 0.1706], [0.2424, 0.2424, 0.2406, 0.2353, 0.2258, 0.2258, 0.2116, 0.1681], [0.2362, 0.2362, 0.2344, 0.2291, 0.2199, 0.2199, 0.2062, 0.165], [0.2273, 0.2273, 0.2256, 0.2205, 0.2118, 0.1993, 0.1825, 0.1615], [0.2273, 0.2273, 0.2256, 0.2205, 0.2118, 0.1993, 0.1825, 0.1615], [0.2164, 0.2164, 0.2149, 0.2104, 0.2027, 0.1915, 0.1766, 0.1577]];
function gridSpan(R, f) {
  if (f <= R[0]) return [0, 0, 0];
  const M = R.length;
  if (f >= R[M - 1]) return [M - 1, M - 1, 0];
  let D = 1;
  while (D < M - 1 && f > R[D]) D++;
  return [D - 1, D, (f - R[D - 1]) / (R[D] - R[D - 1])];
}
function faceZ(R, f) {
  const [M, D, g] = gridSpan(FACE_SURFACE_X, Math.abs(R)), [J, C, k] = gridSpan(FACE_SURFACE_Y, f), Q = FACE_SURFACE[J][M] + (FACE_SURFACE[J][D] - FACE_SURFACE[J][M]) * g, W = FACE_SURFACE[C][M] + (FACE_SURFACE[C][D] - FACE_SURFACE[C][M]) * g;
  return Q + (W - Q) * k;
}
function faceYaw(R, f) {
  const M = Math.abs(R);
  if (M < 0.012) return 0;
  const D = 0.03, g = Math.max(0, M - D), J = (faceZ(M + D, f) - faceZ(g, f)) / (M + D - g);
  return -Math.atan(J) * (R < 0 ? -1 : 1);
}
function onFace(R, f, M, D = 4e-3, g = true) {
  const J = g ? faceYaw(f, M) : 0;
  R.position.set(f + Math.sin(J) * D, M, faceZ(f, M) + Math.cos(J) * D);
  if (g) R.rotation.y = J;
  return R;
}
const FACE_Z = HEAD_FRONT - 0.012, EYE_Y = 0.055, LENS_X = 0.07, ARM_FRONT = 0.52, ARM_BACK = 1.5;
function glassesArm(R, f, M = 9e-3, D = 0.011, g = EAR_Y) {
  const J = (x) => {
    const ri = X, O = headRadius(g, x) + M;
    return [R * Math.sin(x) * O, Math.cos(x) * O];
  }, [C, k] = J(ARM_FRONT), [Q, W] = J(ARM_BACK), Y = Math.hypot(Q - C, W - k), v = new h.Mesh(new h.BoxGeometry(Y, D, D), matteFront(f));
  return v.position.set((C + Q) / 2, g, (k + W) / 2), v.rotation.y = Math.atan2(-(W - k), Q - C), v;
}
function faceBar(R, f, M, D, J = 5e-3, C = 6) {
  const k = new h.Group(), Q = f * 2 / C;
  for (let W = 0; W < C; W++) {
    const Y = -f + Q * (W + 0.5), v = new h.Mesh(new h.BoxGeometry(Q * 1.25, D, D), matteFront(R));
    k.add(onFace(v, Y, M, J));
  }
  return k;
}
function glassesBridge(R, f, M, D = EYE_Y, g = 4e-3) {
  const J = new h.Mesh(new h.BoxGeometry(f, M, M), matteFront(R));
  return J.position.set(0, D, faceZ(0, D) + g), J;
}
function makeRoundGlasses() {
  const R = new h.Group(), f = 2830392, M = matteFront(f);
  for (const D of [-1, 1]) {
    const J = D * LENS_X, C = new h.Mesh(new h.TorusGeometry(0.05, 0.0105, 10, 24), M);
    R.add(onFace(C, J, EYE_Y, 5e-3));
    const k = new h.Mesh(new h.CircleGeometry(0.047, 20), basicFront({ color: 10471167, transparent: true, opacity: 0.26 }));
    R.add(onFace(k, J, EYE_Y, 3e-3)), R.add(glassesArm(D, f, 9e-3, 9e-3));
  }
  R.add(glassesBridge(f, 0.042, 95e-4));
  for (const Q of [-1, 1]) {
    const W = new h.Mesh(new h.BoxGeometry(9e-3, 0.016, 9e-3), matteFront(3883597));
    R.add(onFace(W, Q * 0.022, EYE_Y - 0.016, 2e-3));
  }
  return R;
}
function makeSunglasses() {
  const R = new h.Group(), f = 1448223;
  for (const M of [-1, 1]) {
    const D = M * 0.072, J = new h.Mesh(new h.BoxGeometry(0.112, 0.064, 0.013), matteFront(1911357));
    onFace(J, D, EYE_Y, 8e-3), J.rotation.z = M * -0.07, R.add(J);
    const C = new h.Mesh(new h.BoxGeometry(0.122, 0.074, 9e-3), matteFront(f));
    onFace(C, D, EYE_Y, 4e-3), C.rotation.z = M * -0.07, R.add(C);
    const k = new h.Mesh(new h.BoxGeometry(0.07, 9e-3, 5e-3), basicFront({ color: 7319791, transparent: true, opacity: 0.55 }));
    onFace(k, D + M * 4e-3, EYE_Y + 0.019, 0.016), k.rotation.z = M * -0.07, R.add(k), R.add(glassesArm(M, f, 0.011, 0.013));
  }
  return R.add(faceBar(f, 0.108, EYE_Y + 0.033, 0.012, 8e-3)), R.add(glassesBridge(f, 0.045, 0.013, EYE_Y + 8e-3, 8e-3)), R;
}
function makeNerdGlasses() {
  const R = new h.Group(), f = 1842204, M = matteFront(f), D = 0.011, J = 0.108, C = 0.086;
  for (const Q of [-1, 1]) {
    const W = Q * LENS_X, Y = new h.Mesh(new h.BoxGeometry(J - D, C - D, 8e-3), basicFront({ color: 9418984, transparent: true, opacity: 0.16 }));
    R.add(onFace(Y, W, EYE_Y, 4e-3));
    for (const [v, O, L, i] of [[0, C / 2, J, D], [0, -C / 2, J, D], [-J / 2, 0, D, C], [J / 2, 0, D, C]]) {
      const p = new h.Mesh(new h.BoxGeometry(L, i, 0.013), M);
      R.add(onFace(p, W + v, EYE_Y + O, 6e-3));
    }
    R.add(glassesArm(Q, f, 0.01, 0.013));
  }
  R.add(glassesBridge(f, 0.034, 0.013, EYE_Y + 4e-3, 6e-3));
  const k = new h.Mesh(new h.BoxGeometry(0.024, 0.03, 6e-3), matteFront(15262408));
  return k.position.set(0, EYE_Y + 4e-3, faceZ(0, EYE_Y) + 0.013), R.add(k), R;
}
function makeMonocle() {
  const R = new h.Group(), f = 13279562, M = matteFront(f), D = LENS_X, J = new h.Mesh(new h.TorusGeometry(0.048, 9e-3, 10, 24), M);
  R.add(onFace(J, D, EYE_Y, 5e-3));
  const C = new h.Mesh(new h.CircleGeometry(0.044, 20), basicFront({ color: 10471167, transparent: true, opacity: 0.22 }));
  R.add(onFace(C, D, EYE_Y, 3e-3));
  const k = new h.Mesh(new h.CapsuleGeometry(4e-3, 0.085, 4, 6), M);
  return k.position.set(D + 0.047, EYE_Y - 0.055, faceZ(D + 0.047, EYE_Y - 0.055) + 4e-3), k.rotation.z = 1, R.add(k), R;
}
function makeVisor() {
  const R = new h.Group();
  return R.add(headRing(0.125, 0.055, false, 2981330, 1.045)), R.add(headRing(0.125, 0.018, false, 15922939, 1.052)), R.add(peak(0.113, 1.5, 1924254, 1, 0.16)), R;
}
function makeEyepatch() {
  const R = new h.Group(), f = new h.Mesh(new h.CircleGeometry(0.055, 20), matteFront(1382429));
  onFace(f, -LENS_X, EYE_Y, 5e-3), f.scale.y = 1.1, R.add(f);
  const M = headRing(0.093, 0.014, false, 1382429, 1.03);
  return M.rotation.z = 0.09, R.add(M), R;
}
const FACES = [{ id: "none", name: "None", build: null, icon: "\u20E0" }, { id: "round", name: "Round Specs", build: makeRoundGlasses, icon: "\u{1F453}" }, { id: "shades", name: "Shades", build: makeSunglasses, icon: "\u{1F576}\uFE0F" }, { id: "visor", name: "Visor", build: makeVisor, icon: "\u{1F97D}" }, { id: "patch", name: "Eyepatch", build: makeEyepatch, icon: "\u{1F3F4}" }, { id: "nerd", name: "Nerd Glasses", build: makeNerdGlasses, icon: "\u{1F913}" }, { id: "monocle", name: "Monocle", build: makeMonocle, icon: "\u{1F9D0}" }];
function makeFace(R) {
  const f = new h.Group(), M = new h.MeshLambertMaterial({ color: 2304824, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }), D = 0.072, J = 0.013, C = (v, O, L, i = 1) => {
    const rz = rw, p = new h.Mesh(new h.SphereGeometry(1, 20, 16), M);
    return p.scale.set(0.031 * O, 0.031 * L, 0.024 * i), onFace(p, v, EYE_Y, -J);
  }, k = (v, O, L, i, p = 0) => {
    const rT = rw, H = new h.Mesh(new h.CapsuleGeometry(i, L, 4, 10), M);
    return H.scale.z = 0.55, onFace(H, v, O, -4e-3), H.rotation.z = Math.PI / 2 + p, H;
  }, Q = (v, O, L, i, p, H, V) => {
    const rd = rw, s = new h.Mesh(new h.TorusGeometry(L, i, 8, 22, H), M);
    return s.scale.z = 0.5, onFace(s, v, O, -4e-3), s.rotation.z = V ? p + Math.PI : p, s;
  }, W = (v, O = 1) => {
    const ro = rw, L = new h.Mesh(new h.SphereGeometry(82e-4 * O, 10, 8), new h.MeshBasicMaterial({ color: 16777215 }));
    return onFace(L, v + (v < 0 ? -0.011 : 0.011), EYE_Y + 0.015, 95e-4);
  }, Y = (v, O, L, i) => k(v, EYE_Y + O, L, 65e-4, i);
  if (R === "happy") f.add(Q(-D, EYE_Y - 6e-3, 0.032, 8e-3, Math.PI * 0.2, Math.PI * 0.6)), f.add(Q(D, EYE_Y - 6e-3, 0.032, 8e-3, Math.PI * 0.2, Math.PI * 0.6));
  else {
    if (R === "wink") f.add(C(-D, 1, 1.15), W(-D)), f.add(Q(D, EYE_Y - 6e-3, 0.032, 8e-3, Math.PI * 0.2, Math.PI * 0.6));
    else {
      if (R === "cool") f.add(k(-D, EYE_Y, 0.055, 9e-3), k(D, EYE_Y, 0.055, 9e-3)), f.add(Y(-D, 0.036, 0.042, 0.12), Y(D, 0.036, 0.042, -0.12));
      else {
        if (R === "wide") f.add(C(-D, 1.15, 1.35, 1.15), C(D, 1.15, 1.35, 1.15)), f.add(W(-D, 1.15), W(D, 1.15)), f.add(Y(-D, 0.064, 0.04, 0.1), Y(D, 0.064, 0.04, -0.1));
        else {
          if (R === "sleepy") f.add(Q(-D, EYE_Y + 4e-3, 0.032, 8e-3, Math.PI * 0.2, Math.PI * 0.6, true)), f.add(Q(D, EYE_Y + 4e-3, 0.032, 8e-3, Math.PI * 0.2, Math.PI * 0.6, true));
          else {
            if (R === "angry") f.add(C(-D, 0.85, 0.75), C(D, 0.85, 0.75)), f.add(W(-D, 0.8), W(D, 0.8)), f.add(Y(-D, 0.03, 0.045, 0.4), Y(D, 0.03, 0.045, -0.4));
            else R === "shocked" ? (f.add(C(-D, 1.3, 1.5, 1.3), C(D, 1.3, 1.5, 1.3)), f.add(W(-D, 1.2), W(D, 1.2)), f.add(Y(-D, 0.07, 0.038, 0.06), Y(D, 0.07, 0.038, -0.06))) : (f.add(C(-D, 1, 1.2), C(D, 1, 1.2)), f.add(W(-D), W(D)));
          }
        }
      }
    }
  }
  if (R === "happy" || R === "wink") f.add(Q(0, -0.03, 0.05, 9e-3, Math.PI * 1.15, Math.PI * 0.7));
  else {
    if (R === "angry") f.add(Q(0, -0.05, 0.045, 8e-3, Math.PI * 1.15, Math.PI * 0.7, true));
    else {
      if (R === "shocked") {
        const v = new h.Mesh(new h.TorusGeometry(0.024, 0.011, 8, 20), M);
        f.add(onFace(v, 0, -0.044, -4e-3));
      } else {
        if (R === "wide") {
          const x = new h.Mesh(new h.SphereGeometry(1, 16, 12), M);
          x.scale.set(0.022, 0.026, 0.014), f.add(onFace(x, 0, -0.04, -8e-3));
        } else {
          if (R === "sleepy") f.add(Q(0, -0.036, 0.03, 75e-4, Math.PI * 1.2, Math.PI * 0.6));
          else R === "cool" ? f.add(k(0, -0.038, 0.05, 75e-4)) : f.add(k(0, -0.038, 0.034, 75e-4));
        }
      }
    }
  }
  return f;
}
const EXPRESSIONS = [{ id: "default", name: "Default", icon: "\u{1F610}" }, { id: "happy", name: "Happy", icon: "\u{1F60A}" }, { id: "wink", name: "Wink", icon: "\u{1F609}" }, { id: "cool", name: "Deadpan", icon: "\u{1F611}" }, { id: "wide", name: "Surprised", icon: "\u{1F62E}" }, { id: "sleepy", name: "Sleepy", icon: "\u{1F634}" }, { id: "angry", name: "Angry", icon: "\u{1F620}" }, { id: "shocked", name: "Shocked", icon: "\u{1F631}" }];
function logoPatch(R, f, M, D, g, J) {
  const C = new h.Mesh(new h.PlaneGeometry(f, f), new h.MeshBasicMaterial({ map: R, transparent: true, alphaTest: 0.06, toneMapped: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }));
  C.position.set(M, D, g);
  if (J) C.rotation.y = J;
  return C;
}
function textBadge(R, f, M, D, g) {
  const J = 512, C = Math.round(512 * (M / f)), k = document.createElement("canvas");
  k.width = J, k.height = C;
  const Q = k.getContext("2d"), W = C * 0.18;
  Q.fillStyle = D, Q.beginPath(), Q.roundRect(0, 0, J, C, W), Q.fill(), Q.fillStyle = g, Q.textAlign = "center", Q.textBaseline = "middle";
  const Y = J * 0.1, v = C / (R.length + 0.7);
  R.forEach((L, p) => {
    let H = Math.round(v * 0.72);
    Q.font = "900 " + H + "px Arial, sans-serif";
    while (H > 8 && Q.measureText(L).width > J - Y * 2) {
      H -= 2, Q.font = "900 " + H + "px Arial, sans-serif";
    }
    Q.fillText(L, J / 2, v * (p + 0.85));
  });
  const x = new h.CanvasTexture(k);
  x.colorSpace = h.SRGBColorSpace, x.anisotropy = 4;
  const O = new h.Mesh(new h.PlaneGeometry(f, M), new h.MeshBasicMaterial({ map: x, transparent: true, toneMapped: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }));
  return O;
}
const SHIRTS = [{ id: "tee", name: "Zone Tee", icon: "\u{1F455}", logo: "chest" }, { id: "plain", name: "Plain Tee", icon: "\u{1F9F5}" }, { id: "stripe", name: "Striped Tee", icon: "\u{1F3BD}", stripe: true }, { id: "varsity", name: "Varsity", icon: "\u{1F9E5}", varsity: true }, { id: "staff", name: "Staff Jacket", icon: "\u{1F9BA}", jacket: true, logo: "staffbadge" }];
const CATALOG = { HATS, FACES, EXPRESSIONS, SHIRTS, SKIN_TONES, SHIRT_COLORS, HAIR, HAIR_COLORS, HAIR_DISABLED };
class Avatar {
  constructor(R, { interactive = false } = {}) {
    this.canvas = R, this.interactive = interactive, this.ready = false, this.disposed = false, this.t = 0, this.outfit = { skin: "light", shirtColor: "zoneblue", shirt: "tee", hat: "cap", face: "none", expression: "default", hair: HAIR_DISABLED ? "none" : "short", hairColor: "brown" }, this.scene = new h.Scene(), this.root = new h.Group(), this.scene.add(this.root), this.camera = new h.PerspectiveCamera(30, 1, 0.1, 50), this.camera.position.set(0, 1.15, 4.6), this.camera.lookAt(0, 1.02, 0), this.renderer = new h.WebGLRenderer({ canvas: R, antialias: true, alpha: true, powerPreference: "low-power" }), this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5)), this.renderer.shadowMap.enabled = false, this.renderer.localClippingEnabled = true, this.scene.add(new h.HemisphereLight(16777215, 4876953, 2.15));
    const f = new h.DirectionalLight(16777215, 0.85);
    f.position.set(2.5, 4, 4), this.scene.add(f);
    const M = new h.DirectionalLight(10471167, 0.35);
    M.position.set(-3, 2, -2.5), this.scene.add(M), this.groups = { head: new h.Group(), torso: new h.Group(), lhand: new h.Group(), rhand: new h.Group() };
    for (const D of Object.values(this.groups)) this.root.add(D);
    this.hairSlot = new h.Group(), this.hatSlot = new h.Group(), this.faceSlot = new h.Group(), this.exprSlot = new h.Group(), this.chestSlot = new h.Group(), this._onResize = () => this.resize(), window.addEventListener("resize", this._onResize);
    if (interactive) this._bindDrag();
  }
  async ["load"](R = "/models", f = "/img/logo.png") {
    const M = new GLTFLoader(), D = ["head", "torso", "lhand", "rhand"], g = await new Promise((Q, W) => M.load(R + "/player.glb", Q, void 0, W));
    this.meshes = {}, this.nodes = {};
    const J = /* @__PURE__ */ new Set(["lhand", "rhand"]), C = /* @__PURE__ */ new Set(), k = (Q) => {
      if (!Q || C.has(Q)) return;
      C.add(Q), Q.computeBoundingBox();
      const W = Q.boundingBox.getCenter(new h.Vector3());
      Q.translate(-W.x, -W.y, -W.z), Q.rotateY(Math.PI), Q.translate(W.x, W.y, W.z), Q.computeVertexNormals();
    };
    for (const Q of D) {
      const W = g.scene.getObjectByName(Q);
      if (!W) {
        console.warn("[avatar] missing part:", Q);
        continue;
      }
      W.traverse((Y) => {
        if (Y.isMesh) {
          Y.material = matte(16777215), Y.castShadow = Y.receiveShadow = false;
          if (!J.has(Q)) k(Y.geometry);
          if (!this.meshes[Q]) this.meshes[Q] = Y;
        }
      });
      if (J.has(Q)) this.groups[Q].rotation.y = Math.PI;
      this.nodes[Q] = W, this.groups[Q].add(W);
    }
    if (!this.meshes.head || !this.meshes.torso) throw new Error("player.glb is missing head or torso");
    return this.nodes.head.add(this.hairSlot, this.hatSlot, this.faceSlot, this.exprSlot), this.nodes.torso.add(this.chestSlot), this._profileTorso(), this.logoTex = await new Promise((Y) => {
      new h.TextureLoader().load(f, (v) => {
        v.colorSpace = h.SRGBColorSpace, Y(v);
      }, void 0, () => Y(null));
    }), this.ready = true, this.apply(this.outfit), this.frame(), this.resize(), this;
  }
  ["apply"](R = {}) {
    if (!this.ready) {
      Object.assign(this.outfit, R);
      return;
    }
    Object.assign(this.outfit, R);
    const M = this.outfit, D = (SKIN_TONES.find((x) => x.id === M.skin) || SKIN_TONES[1]).hex, g = (SHIRT_COLORS.find((x) => x.id === M.shirtColor) || SHIRT_COLORS[0]).hex;
    if (this.meshes.head) this.meshes.head.material.color.setHex(D);
    if (this.meshes.lhand) this.meshes.lhand.material.color.setHex(D);
    if (this.meshes.rhand) this.meshes.rhand.material.color.setHex(D);
    if (this.meshes.torso) this.meshes.torso.material.color.setHex(g);
    const J = (x) => {
      while (x.children.length) {
        const O = x.children.pop();
        disposeTree(O);
      }
    };
    J(this.hairSlot), J(this.hatSlot), J(this.faceSlot), J(this.exprSlot), J(this.chestSlot);
    const C = HATS.find((x) => x.id === M.hat);
    if (!HAIR_DISABLED && !HAIR_HIDDEN_UNDER.has(M.hat)) {
      const x = HAIR.find((L) => L.id === M.hair), O = (HAIR_COLORS.find((L) => L.id === M.hairColor) || HAIR_COLORS[1]).hex;
      if (x && x.build) this.hairSlot.add(x.build(O));
    }
    if (C && C.build) this.hatSlot.add(C.build(C.logo ? this.logoTex : null));
    const k = FACES.find((L) => L.id === M.face);
    if (k && k.build) this.faceSlot.add(k.build());
    const Q = M.face === "shades" || M.face === "round" || M.face === "nerd";
    if (!Q) this.exprSlot.add(makeFace(M.expression));
    const W = SHIRTS.find((L) => L.id === M.shirt) || SHIRTS[0], Y = shirtTrim(g), v = (L) => this.ty(L);
    W.stripe && (this.chestSlot.add(this._bodyBand(v(0.48), 0.12, Y)), this.chestSlot.add(this._bodyBand(v(0.66), 0.12, Y)));
    if (W.varsity) {
      this.chestSlot.add(this._bodyBand(v(0.93), 0.075, Y)), this.chestSlot.add(this._bodyBand(v(0.05), 0.075, Y));
      for (let L = 0; L < 4; L++) {
        const p = v(0.3 + L * 0.14), m = this.torsoFront(p), H = new h.Mesh(new h.CircleGeometry(0.022, 14), matte(Y));
        H.position.set(0, p, m.z + 6e-3), this.chestSlot.add(H);
      }
    }
    if (W.jacket) {
      const V = v(0.9), s = v(0.07), N = (V + s) / 2, K = this.torsoFront(N), P = new h.Mesh(new h.BoxGeometry(0.02, V - s, 0.012), matte(14212840));
      P.position.set(0, N, K.z + 6e-3), this.chestSlot.add(P), this.chestSlot.add(this._bodyBand(v(0.92), 0.085, 2237998)), this.chestSlot.add(this._bodyBand(v(0.05), 0.085, 2237998)), this.chestSlot.add(this._bodyBand(v(0.4), 0.1, 15910724));
    }
    if (W.logo === "chest" && this.logoTex) {
      const w = v(0.76), z = 0.4, d = 0.13, e = this.torsoFront(w, z), { r: A } = this.torsoAt(w), I = this.torsoFront(w, Math.max(0, z - d / 2 / A)), b = Math.max(8e-3, I.z - e.z + 6e-3), c = Math.atan2(e.x, e.z * 2.2);
      this.chestSlot.add(logoPatch(this.logoTex, d, e.x, w, e.z + b, c * 0.5));
    } else {
      if (W.logo === "staffbadge") {
        const a = v(0.8), E = 0.34, B = 0.13, l = 0.075, Z = this.torsoFront(a, E), { r: S } = this.torsoAt(a), j = this.torsoFront(a, E - B / 2 / S), u = Math.max(0.018, j.z - Z.z + 0.01), t = textBadge(["RECZONE", "STAFF"], B, l, "#12203a", "#eef3fa");
        t.position.set(Z.x, a, Z.z + u), this.chestSlot.add(t);
      }
    }
  }
  ["_profileTorso"]() {
    const R = this.meshes.torso;
    this._torsoProfile = null;
    if (!R || !R.geometry || !R.geometry.attributes.position) return;
    const f = R.geometry.attributes.position, M = 24;
    let D = Infinity, g = -Infinity;
    for (let Q = 0; Q < f.count; Q++) {
      const W = f.getY(Q);
      if (W < D) D = W;
      if (W > g) g = W;
    }
    const J = g - D || 1, C = new Array(M).fill(0), k = new Array(M).fill(0);
    for (let Y = 0; Y < f.count; Y++) {
      const v = Math.min(M - 1, Math.floor((f.getY(Y) - D) / J * M));
      C[v] = Math.max(C[v], Math.abs(f.getX(Y))), k[v] = Math.max(k[v], Math.abs(f.getZ(Y)));
    }
    for (let x = 0; x < M; x++) {
      if (C[x] > 0) continue;
      let O = x, L = x;
      while (O >= 0 && C[O] === 0) O--;
      while (L < M && C[L] === 0) L++;
      C[x] = C[O >= 0 ? O : L] || 0.3, k[x] = k[O >= 0 ? O : L] || 0.18;
    }
    this._torsoProfile = { minY: D, maxY: g, span: J, rx: C, rz: k, BINS: M };
  }
  ["torsoAt"](R) {
    const f = this._torsoProfile;
    if (!f) return { r: 0.33, squash: 0.57 };
    const M = Math.max(0, Math.min(f.BINS - 1, Math.floor((R - f.minY) / f.span * f.BINS))), D = f.rx[M] || 0.33;
    return { r: D, squash: (f.rz[M] || D * 0.57) / D };
  }
  ["ty"](R) {
    const M = this._torsoProfile;
    if (!M) return R * 1.374;
    return M.minY + R * M.span;
  }
  ["torsoFront"](R, f = 0) {
    const { r: M, squash: D } = this.torsoAt(R), g = Math.sqrt(Math.max(0, 1 - f * f));
    return { x: M * f, z: M * D * g };
  }
  ["_bodyBand"](R, f, M, D = 1.012) {
    const g = this.meshes.torso;
    if (!g) return new h.Group();
    const J = new h.Mesh(g.geometry, new h.MeshLambertMaterial({ color: M, side: h.DoubleSide, clippingPlanes: [new h.Plane(new h.Vector3(0, -1, 0), R + f / 2), new h.Plane(new h.Vector3(0, 1, 0), -(R - f / 2))] }));
    return J.scale.setScalar(D), J.userData.sharedGeometry = true, J;
  }
  ["randomise"]() {
    const R = (f) => f[Math.floor(Math.random() * f.length)];
    return this.apply({ skin: R(SKIN_TONES).id, shirtColor: R(SHIRT_COLORS).id, shirt: R(SHIRTS).id, hat: R(HATS).id, face: R(FACES).id, expression: R(EXPRESSIONS).id, hair: HAIR_DISABLED ? "none" : R(HAIR).id, hairColor: R(HAIR_COLORS).id }), this.outfit;
  }
  ["_bindDrag"]() {
    let R = false, f = 0;
    const M = this.canvas, D = (C) => {
      R = true, f = C.clientX, M.style.cursor = "grabbing";
      try {
        M.setPointerCapture(C.pointerId);
      } catch (k) {
      }
    }, g = (C) => {
      if (!R) return;
      this.spin = (this.spin || 0) + (C - f) * 0.011, f = C;
    }, J = (C) => {
      R = false, M.style.cursor = "grab";
      try {
        M.releasePointerCapture(C.pointerId);
      } catch (k) {
      }
    };
    M.style.cursor = "grab", M.addEventListener("pointerdown", D), M.addEventListener("pointermove", (C) => g(C.clientX)), M.addEventListener("pointerup", J), M.addEventListener("pointercancel", J), M.addEventListener("pointerleave", () => {
      if (!R) M.style.cursor = "grab";
    });
  }
  ["frame"]() {
    const R = new h.Box3().setFromObject(this.root);
    if (R.isEmpty()) return;
    const f = R.getSize(new h.Vector3()), M = R.getCenter(new h.Vector3());
    this._focus = M.y;
    const D = this.camera.fov * Math.PI / 180, g = Math.max(f.y, f.x * 1.25) / 2 / Math.tan(D / 2) * 1.28;
    this._dist = g, this.camera.position.set(0, M.y, g), this.camera.lookAt(0, M.y, 0);
  }
  ["resize"]() {
    const R = this.canvas.clientWidth || 1, f = this.canvas.clientHeight || 1;
    this.renderer.setSize(R, f, false), this.camera.aspect = R / f;
    if (this._dist) {
      const M = Math.max(1, 0.82 / this.camera.aspect);
      this.camera.position.set(0, this._focus, this._dist * M), this.camera.lookAt(0, this._focus, 0);
    }
    this.camera.updateProjectionMatrix();
  }
  ["update"](R) {
    if (!this.ready) return;
    this.t += R;
    const f = this.t;
    this.root.rotation.y = this.spin || 0;
    const M = this.hatSlot.children[0];
    if (M && M.userData.spin) M.userData.spin.rotation.z += R * 0.85;
  }
  ["render"]() {
    this.renderer.render(this.scene, this.camera);
  }
  ["start"]() {
    let R = performance.now();
    const f = (M) => {
      if (this.disposed) return;
      this._raf = requestAnimationFrame(f);
      const D = Math.min((M - R) / 1e3, 0.05);
      R = M, this.update(D), this.render();
    };
    this._raf = requestAnimationFrame(f);
  }
  ["dispose"]() {
    this.disposed = true;
    if (this._raf) cancelAnimationFrame(this._raf);
    window.removeEventListener("resize", this._onResize), disposeTree(this.scene), this.renderer.dispose();
  }
}
function disposeTree(R) {
  R.traverse?.((f) => {
    if (f.geometry && !f.userData.sharedGeometry) f.geometry.dispose();
    if (f.material) {
      const M = Array.isArray(f.material) ? f.material : [f.material];
      for (const D of M) D.dispose();
    }
  });
}
export {
  Avatar,
  CATALOG,
  HAIR_COLORS,
  HAIR_DISABLED,
  SHIRT_COLORS,
  SKIN_TONES
};
