import { a as c } from "./c-DJ4XDPT5.js";
import "./c-USQKEFSE.js";
import "three";
import { Avatar as l, CATALOG as k } from "/js/modules/avatar.js";
var t = (m, u, j) => {
  let S = document.createElement(m);
  return u && (S.className = u), j !== void 0 && (S.textContent = j), S;
}, tt = (m) => "#" + Number(m).toString(16).padStart(6, "0"), z = [{ id: "hat", field: "hat", label: "Hats", one: "Hat", list: () => k.HATS, shot: "hat" }, { id: "face", field: "face", label: "Faces", one: "Face", list: () => k.FACES, shot: "face" }, { id: "expression", field: "expression", label: "Expressions", one: "Expression", list: () => k.EXPRESSIONS, shot: "face" }, { id: "shirt", field: "shirt", label: "Shirts", one: "Shirt", list: () => k.SHIRTS, shot: "body" }, { id: "shirtColor", field: "shirtColor", label: "Colours", one: "Colour", list: () => k.SHIRT_COLORS, swatch: true }, { id: "skin", field: "skin", label: "Skin", one: "Skin", list: () => k.SKIN_TONES, swatch: true }], H = null;
async function et() {
  if (H) return H;
  try {
    let m = await fetch("/api/game/wallet", { credentials: "same-origin", headers: { Accept: "application/json" } });
    H = m.ok ? await m.json() : null;
  } catch {
    H = null;
  }
  return H || { balance: 0, owned: null, staff: false, buying: false };
}
var q = (m, u, j) => !m || !m.owned || !m.owned[u] || m.owned[u].includes(j), P = null;
async function nt(m) {
  if (P) return P;
  try {
    let u = await fetch("/api/game/outfits?names=" + encodeURIComponent(m && m.name ? m.name : ""), { credentials: "same-origin", headers: { Accept: "application/json" } }), j = u.ok ? await u.json() : {};
    P = { ...c, ...(j.outfits || {})[m && m.name] || {} };
  } catch {
    P = { ...c };
  }
  return P;
}
var W = 168, B = { hat: { y: 1.96, d: 2.05, at: 1.93 }, face: { y: 1.74, d: 1.05, at: 1.72 }, body: { y: 0.95, d: 2.6, at: 0.8 } }, U = null;
function ot() {
  return U || (U = (async () => {
    let m = document.createElement("canvas");
    m.width = m.height = W;
    let u = new l(m);
    return u.resize = () => {
    }, u.frame = () => {
    }, await u.load(), u.renderer.setPixelRatio(1), u.renderer.setSize(W, W, false), u.camera.aspect = 1, u.camera.updateProjectionMatrix(), { a: u, canvas: m, cache: /* @__PURE__ */ new Map() };
  })(), U.catch(() => {
    U = null;
  })), U;
}
async function st(m, u, j) {
  let S = await ot(), E = { ...j, [m.field]: u };
  m.id === "hat" && (E.face = "none", E.expression = "default"), m.id === "face" && (E.hat = "none"), m.id === "expression" && (E.hat = "none", E.face = "none");
  let A = m.id + ":" + u + ":" + E.skin + ":" + E.shirtColor;
  if (S.cache.has(A)) return S.cache.get(A);
  let g = B[m.shot] || B.face;
  S.a.outfit = { ...c }, S.a.apply(E), S.a.root.rotation.y = m.id === "face" ? -0.35 : -0.25, S.a.camera.position.set(0, g.y, g.d), S.a.camera.lookAt(0, g.at, 0), S.a.renderer.render(S.a.scene, S.a.camera);
  let J = S.canvas.toDataURL("image/png");
  return S.cache.set(A, J), J;
}
async function at(m, u, j, S) {
  for (let { img: E, id: A } of m) {
    if (!S()) return;
    try {
      E.src = await st(u, A, j), E.classList.add("is-in");
    } catch {
      return;
    }
    await new Promise((v) => requestAnimationFrame(v));
  }
}
var h = null, Z = 0;
function it(m) {
  if (Z++, m === "avatar" && h) {
    try {
      h.dispose();
    } catch {
    }
    h = null;
  }
}
async function pt(u, j, J = {}) {
  let M = ++Z, I = () => M === Z && j.page === "avatar" && u.isConnected, [d0, d1] = await Promise.all([nt(J.me), et()]);
  if (!I()) return;
  let d2 = { ...d0 }, d3 = { ...d0 }, d4 = z[0], d5 = t("div", "lk"), d6 = t("div", "lk-stage"), d7 = t("canvas", "lk-doll");
  d7.setAttribute("aria-label", "Your avatar");
  let d8 = t("div", "lk-name", J.me && J.me.name || "You"), d9 = t("div", "lk-tools"), dd = t("button", "wt-pill lk-tool", "Random"), dC = t("button", "wt-pill lk-tool", "Undo"), dc = t("button", "wt-send lk-save", "Save");
  dd.type = dC.type = dc.type = "button", d9.append(dC, dd, dc), d6.append(d7, d8, d9);
  let dl = t("div", "lk-side"), dF = t("div", "lk-tabs"), dk = t("div", "lk-grid"), dm = t("div", "lk-actions"), du = t("div", "lk-status", "Drag your avatar to turn it round"), dj = t("button", "wt-pill lk-reset", "Put back");
  dj.type = "button", dm.append(du, dj), dl.append(dF, dm, dk), d5.append(d6, dl), u.appendChild(d5), h = new l(d7, { interactive: true }), h.load().then(() => {
    if (!I()) {
      it("avatar");
      return;
    }
    h.apply(d3), h.resize(), h.start();
  }).catch(() => {
    du.textContent = "The preview could not load, but you can still pick and save.";
  });
  let dW = [], dS = () => JSON.stringify(d3) !== JSON.stringify(d2), dE = () => {
    dc.disabled = !dS(), dj.disabled = !dS(), dC.disabled = !dW.length, dS() && (du.textContent = "Not saved yet");
  }, dh = (dZ, dg) => {
    d3[dZ] !== dg && (dW.push({ ...d3 }), dW.length > 40 && dW.shift(), d3 = { ...d3, [dZ]: dg }, h && h.ready && h.apply(d3), dv(), dE());
  }, dA = () => {
    dF.textContent = "";
    for (let dZ of z) {
      let dg = t("button", "wt-chip lk-tab" + (dZ === d4 ? " is-on" : ""), dZ.label);
      dg.type = "button", dg.dataset.kind = dZ.id, dg.addEventListener("click", () => {
        d4 = dZ, dA(), dv();
      }), dF.appendChild(dg);
    }
  }, dv = () => {
    dk.textContent = "";
    let dZ = [];
    for (let db of d4.list() || []) {
      let de = q(d1, d4.field, db.id), dJ = d3[d4.field] === db.id, dO = t("button", "lk-item" + (dJ ? " is-on" : "") + (de ? "" : " is-locked"));
      dO.type = "button", dO.dataset.item = db.id, dO.title = de ? db.name : db.name + " (staff only)";
      let dM = t("span", "lk-art");
      if (d4.swatch) {
        let dT = t("span", "lk-swatch");
        dT.style.background = tt(db.hex), dM.appendChild(dT);
      } else {
        if (db.id === "none") dM.appendChild(t("span", "lk-none", "None"));
        else {
          let dD = t("img", "lk-pic");
          dD.alt = "", dD.draggable = false, dM.appendChild(dD), dZ.push({ img: dD, id: db.id });
        }
      }
      dJ && dM.appendChild(t("span", "lk-on", "On")), de || dM.appendChild(t("span", "lk-lock", "Staff")), dO.append(dM, t("span", "lk-itemname", db.name)), dO.disabled = !de, dO.addEventListener("click", () => dh(d4.field, db.id)), dk.appendChild(dO);
    }
    let dg = d4;
    at(dZ, d4, d3, () => I() && d4 === dg);
  };
  dC.addEventListener("click", () => {
    dW.length && (d3 = dW.pop(), h && h.ready && h.apply(d3), dv(), dE());
  }), dd.addEventListener("click", () => {
    dW.push({ ...d3 });
    let dZ = (dg, db) => {
      let de = (dg || []).filter((dJ) => q(d1, db, dJ.id));
      return de[Math.floor(Math.random() * de.length)].id;
    };
    d3 = { ...d3 };
    for (let dg of z) d3[dg.field] = dZ(dg.list(), dg.field);
    h && h.ready && h.apply(d3), dv(), dE();
  }), dj.addEventListener("click", () => {
    dW.push({ ...d3 }), d3 = { ...d2 }, h && h.ready && h.apply(d3), dv(), dE();
  }), dc.addEventListener("click", async () => {
    dc.disabled = true, du.textContent = "Saving\u2026";
    try {
      let dZ = await fetch("/api/game/outfit", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ outfit: d3 }) }), dg = await dZ.json().catch(() => ({}));
      if (!dZ.ok || !dg.ok) throw new Error("not saved");
      Object.assign(d2, dg.outfit || d3), P = { ...d2 };
      try {
        localStorage.setItem("reczone_outfit", JSON.stringify(d2));
      } catch {
      }
      du.textContent = "Saved. Everyone here sees your new look", J.onSaved?.(P);
    } catch {
      du.textContent = "Could not save. Try again in a moment";
    }
    dE(), dS() || (du.textContent = du.textContent);
  }), dA(), dv(), dE(), du.textContent = "Drag your avatar to turn it round";
}
function X(m) {
  let u = t("span", "st-coin"), j = Number(m);
  return u.append(t("i", "st-coin-mark", "RZ"), t("b", "", Number.isFinite(j) ? j.toLocaleString() : String(m))), u;
}
var Y = (m) => String(m).padStart(2, "0");
function Q(m) {
  let u = Math.max(0, Math.floor(m / 1e3)), j = Math.floor(u / 86400), S = Math.floor(u % 86400 / 3600), E = Math.floor(u % 3600 / 60), A = u % 60;
  return (j ? j + "d " : "") + Y(S) + ":" + Y(E) + ":" + Y(A);
}
function ct(u) {
  let j = t("section", "og"), E = t("div", "og-pic"), J = t("img");
  J.alt = "The OG Duck", J.draggable = false, J.src = new URL("img/og-duck.jpg", import.meta.url).href, E.append(J, t("span", "og-ribbon", "Release reward"));
  let O = t("div", "og-info"), M = t("div", "og-title");
  M.append(t("b", "", "OG Duck"), t("span", "og-free", "Free"));
  let T = t("p", "og-about", "For everyone who plays in the first 72 hours. OG on its side with your number: #1 is the first one claimed."), D = t("div", "og-clock"), G = t("span", "og-clocklabel"), R = t("b", "og-clocktime");
  D.append(G, R);
  let x = t("button", "og-claim", "Claim");
  x.type = "button";
  let f = t("div", "og-note");
  O.append(M, T, D, x, f), j.append(E, O);
  let i = null, I = 0, d0 = 0, d1 = () => Date.now() + I;
  function d2() {
    if (!i) return;
    let d4 = d1(), d5 = i.number > 0;
    j.classList.toggle("is-mine", d5), d5 ? (G.textContent = "Yours", R.textContent = "OG #" + i.number, x.hidden = true, f.textContent = "Press G in a dorm to hold it.") : d4 < i.opensAt ? (G.textContent = "Unlocks in", R.textContent = Q(i.opensAt - d4), x.hidden = false, x.disabled = true, x.textContent = "Locked", f.textContent = "Friday 13 November, 8:30 PM CST") : d4 < i.closesAt ? (G.textContent = "Claim within", R.textContent = Q(i.closesAt - d4), x.hidden = false, x.disabled = !i.signedIn || x.dataset.busy === "1", x.textContent = i.signedIn ? "Claim" : "Sign in to claim", f.textContent = i.claimed ? i.claimed.toLocaleString() + " claimed so far" : "Be the first to claim one") : (G.textContent = "Claiming has closed", R.textContent = "", x.hidden = true, f.textContent = "It was only for the first 72 hours.");
  }
  async function d3() {
    try {
      let d4 = await (await fetch("/api/game/og-duck", { credentials: "same-origin", headers: { Accept: "application/json" } })).json();
      if (!d4.ok) return;
      I = (d4.now || Date.now()) - Date.now(), i = d4, d2();
    } catch {
      f.textContent = "Could not reach the site.";
    }
  }
  return x.addEventListener("click", async () => {
    if (!x.disabled) {
      x.dataset.busy = "1", x.disabled = true, x.textContent = "Claiming\u2026";
      try {
        let d4 = await (await fetch("/api/game/og-duck/claim", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json" } })).json().catch(() => ({}));
        d4.ok ? (i = { ...i, number: d4.number }, j.classList.add("is-new"), window.dispatchEvent(new CustomEvent("rz:og-duck", { detail: { number: d4.number } }))) : f.textContent = d4.message || "That did not work. Try again.";
      } catch {
        f.textContent = "Could not reach the site.";
      }
      x.dataset.busy = "", d2();
    }
  }), d3(), d0 = setInterval(() => {
    if (!u() || !j.isConnected) {
      clearInterval(d0);
      return;
    }
    d2();
  }, 1e3), j;
}
async function ft(u, j, E = {}) {
  let J = ++Z, O = () => J === Z && j.page === "store" && u.isConnected, [M, T] = await Promise.all([et(), nt(E.me)]);
  if (!O()) return;
  let D = u.querySelector(".wt-title");
  if (D) {
    let d3 = t("div", "st-purse");
    d3.append(X(M.balance || 0)), d3.title = "RZ is the RECZONE currency. Earning it is coming soon.", D.appendChild(d3);
  }
  let G = "all", R = t("div", "st"), x = t("div", "st-banner"), f = t("div", "st-bannertext");
  f.append(t("b", "", "More items coming soon"), t("span", "", "New hats, faces and shirts are on the way, with RZ to spend on them. Everything here is already yours."));
  let i = t("div", "st-bannerbadge", "NEW");
  x.append(f, i);
  let I = t("div", "wt-chips st-filters"), d0 = () => {
    I.textContent = "";
    for (let [d4, d5] of [["all", "All"], ...z.map((d6) => [d6.id, d6.label])]) {
      let d6 = t("button", "wt-chip" + (G === d4 ? " is-on" : ""), d5);
      d6.type = "button", d6.dataset.filter = d4, d6.addEventListener("click", () => {
        G = d4, d0(), d2();
      }), I.appendChild(d6);
    }
  }, d1 = t("div", "st-shelves"), d2 = () => {
    d1.textContent = "";
    let d4 = [];
    for (let d5 of z) {
      if (G !== "all" && G !== d5.id) continue;
      let d6 = (d5.list() || []).filter((dC) => dC.id !== "none"), d7 = t("section", "st-shelf"), d8 = t("div", "st-shelftitle");
      d8.append(t("b", "", d5.label), t("span", "", d6.length + " items"));
      let d9 = t("div", "st-row"), dd = [];
      for (let dC of d6) {
        let dc = q(M, d5.field, dC.id), dl = T[d5.field] === dC.id, dF = t("div", "st-card" + (dc ? "" : " is-locked"));
        dF.dataset.item = d5.id + ":" + dC.id;
        let dk = t("div", "st-art");
        if (d5.swatch) {
          let dj = t("span", "lk-swatch st-swatch");
          dj.style.background = tt(dC.hex), dk.appendChild(dj);
        } else {
          let dW = t("img", "lk-pic");
          dW.alt = "", dW.draggable = false, dk.appendChild(dW), dd.push({ img: dW, id: dC.id });
        }
        dl && dk.appendChild(t("span", "st-wearing", "Wearing"));
        let dm = t("div", "st-foot");
        dm.append(t("b", "st-name", dC.name));
        let du = t("div", "st-price");
        dc ? du.append(t("span", "st-owned", "Owned")) : du.append(t("span", "st-staffonly", "Staff only")), dm.appendChild(du), dF.append(dk, dm), d9.appendChild(dF);
      }
      for (let dS = 0; dS < 2; dS++) {
        let dE = t("div", "st-card is-soon"), dh = t("div", "st-art");
        dh.appendChild(t("span", "st-mystery", "?"));
        let dA = t("div", "st-foot");
        dA.append(t("b", "st-name", "Coming soon"));
        let dv = t("div", "st-price");
        dv.append(X("???")), dA.appendChild(dv), dE.append(dh, dA), d9.appendChild(dE);
      }
      d7.append(d8, d9), d1.appendChild(d7), dd.length && d4.push(() => at(dd, d5, T, O));
    }
    (async () => {
      for (let dZ of d4) {
        if (!O()) return;
        await dZ();
      }
    })(), j._railSync?.();
  };
  R.append(ct(O), x, I, d1), u.appendChild(R), d0(), d2();
}
export {
  pt as drawAvatar,
  ft as drawStore,
  it as leave
};
