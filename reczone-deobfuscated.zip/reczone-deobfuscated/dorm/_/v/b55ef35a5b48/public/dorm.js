import { a as c, b as l, c as F, d as k, e as m, f as u, g as j, h as S, i as h, j as A } from "./c-7WVWS6WJ.js";
import { a as v, b } from "./c-ZGTNTUL7.js";
import { a as e, b as J, c as O, d as M, e as T, f as D, g as s } from "./c-H3C27IZN.js";
import { A as G, B as R, C as x, E as f, F as y, G as N, H as o, I as r, J as X, K as a, L as P, a as w, b as q, c as L, e as p, f as i, g as B, h as V, i as n, j as I, k as z, l as Y, m as t, n as K, p as Q, r as d0, s as d1, v as d2, w as d3, x as d4, y as d5, z as d6 } from "./c-USQKEFSE.js";
var ls = 3;
function Ei(d7, d8) {
  let d9 = [];
  for (let dd of d7.allNodes()) d8(dd.name || "") && d9.push(dd);
  return d9;
}
function ds(d7) {
  let d8 = d7.mesh && d7.mesh.positions, d9 = d7.mesh && d7.mesh.indices;
  if (!d8 || !d9) return null;
  let dd = d7.worldMatrix(), dC = new Set(d9), dc = [], dl = 1 / 0;
  for (let du of dC) {
    let dj = d8[du * 3], dW = d8[du * 3 + 1], dS = d8[du * 3 + 2], dE = [dd[0] * dj + dd[4] * dW + dd[8] * dS + dd[12], dd[1] * dj + dd[5] * dW + dd[9] * dS + dd[13], dd[2] * dj + dd[6] * dW + dd[10] * dS + dd[14]];
    dc.push(dE), dE[1] < dl && (dl = dE[1]);
  }
  let dF = [1 / 0, 1 / 0, 1 / 0], dk = [-1 / 0, -1 / 0, -1 / 0], dm = false;
  for (let dh of dc) if (!(dh[1] < dl + 0.7 || dh[1] > dl + 1.4)) {
    dm = true;
    for (let dA = 0; dA < 3; dA++) dh[dA] < dF[dA] && (dF[dA] = dh[dA]), dh[dA] > dk[dA] && (dk[dA] = dh[dA]);
  }
  if (!dm) return null;
  for (let dv = 0; dv < 3; dv++) dF[dv] -= 0.06, dk[dv] += 0.06;
  return { min: dF, max: dk, centre: [(dF[0] + dk[0]) / 2, (dF[1] + dk[1]) / 2, (dF[2] + dk[2]) / 2] };
}
function Li({ game: d7, world: d8, openDorms: d9 }) {
  let dd = null, dC = null;
  function dc() {
    let dW = Ei(d7.scene, (dE) => /^mirror:\d+$/.test(dE));
    for (let dE of dW) dE.mirror = true;
    d7.mirrorSelf = dW.length > 0;
    let dS = Ei(d7.scene, (dh) => /^inner door:\d+$/.test(dh));
    dd = dS.length ? dS[0].parent : null, dC = null;
    for (let dh of dS) {
      let dA = ds(dh);
      if (dA && (dA.max[0] - dA.min[0]) * (dA.max[2] - dA.min[2]) < 0.2 && dA.max[1] - dA.min[1] < 0.8) {
        dC = dA;
        break;
      }
    }
  }
  d8.doc.addEventListener("reset", () => setTimeout(dc, 0)), d8.doc.addEventListener("changed", () => setTimeout(dc, 0));
  let dl = 0, dF = setInterval(() => {
    dc(), (dd && dC || ++dl > 30) && clearInterval(dF);
  }, 1e3), dk = document.createElement("div");
  dk.className = "radio-hint", dk.hidden = true, document.body.appendChild(dk);
  let dm = () => document.pointerLockElement === d7.canvas, du = false;
  function dj() {
    if (!dd || !dC || !dm()) return false;
    let dW = d7.camera.position, dS = d7.camera.forward(), dE = d2(dd, dW, dS, ls);
    if (dE === null) return false;
    let dh = [dW[0] + dS[0] * dE, dW[1] + dS[1] * dE, dW[2] + dS[2] * dE];
    return dh[0] >= dC.min[0] && dh[0] <= dC.max[0] && dh[1] >= dC.min[1] && dh[1] <= dC.max[1] && dh[2] >= dC.min[2] && dh[2] <= dC.max[2];
  }
  return d7.addUpdater(() => {
    du = dj();
    let dW = du ? "Click the handle for dorms" : "";
    dk.textContent !== dW && (dk.textContent = dW), dk.hidden = !dW;
  }), d7.canvas.addEventListener("mousedown", (dW) => {
    dW.button !== 0 || !du || !dm() || d7.wielding && d7.wielding() || d9();
  }), { look: dc, get handle() {
    return dC;
  }, get door() {
    return dd;
  } };
}
var $ = { maxBuilt: 300, maxSize: 12, minSize: 0.05, reach: 60, minY: -5, maxY: 40, spawnRadius: 2.2, spawnHeight: 2.6, spawnDepth: 2.6, solidOpacity: 0.5, builtPrefix: "b_", maxStrokePoints: 6e3 }, zi = (d7) => d7.reduce((d8, d9) => d8 + (d9 && d9.kind === "stroke" && Array.isArray(d9.points) ? d9.points.length : 0), 0), vt = (d7) => !!d7 && typeof d7.id == "string" && d7.id.startsWith($.builtPrefix), Ft = (d7, d8, d9) => Math.min(Math.max(d7, d8), d9);
function Ht(d7) {
  if (!d7 || d7.kind === "model") return null;
  if (d7.kind === "stroke") {
    let dk = Array.isArray(d7.points) && d7.points.length ? d7.points : [[0, 0, 0]], dm = (d7.width || 0.03) / 2, du = [0, 1, 2].map((dW) => d7.position[dW] + Math.min(...dk.map((dS) => dS[dW])) - dm), dj = [0, 1, 2].map((dW) => d7.position[dW] + Math.max(...dk.map((dS) => dS[dW])) + dm);
    return { min: du, max: dj };
  }
  let d8 = [d7.scale[0] / 2, d7.kind === "plane" ? 0.02 : d7.scale[1] / 2, d7.scale[2] / 2], d9 = q.fromEuler([0, 0, 0, 1], (d7.rotation[0] || 0) * w, (d7.rotation[1] || 0) * w, (d7.rotation[2] || 0) * w), [dd, dC, dc, dl] = d9, dF = [[1 - 2 * (dC * dC + dc * dc), 2 * (dd * dC - dl * dc), 2 * (dd * dc + dl * dC)], [2 * (dd * dC + dl * dc), 1 - 2 * (dd * dd + dc * dc), 2 * (dC * dc - dl * dd)], [2 * (dd * dc - dl * dC), 2 * (dC * dc + dl * dd), 1 - 2 * (dd * dd + dC * dC)]].map((dW) => Math.abs(dW[0]) * d8[0] + Math.abs(dW[1]) * d8[1] + Math.abs(dW[2]) * d8[2]);
  return { min: [d7.position[0] - dF[0], d7.position[1] - dF[1], d7.position[2] - dF[2]], max: [d7.position[0] + dF[0], d7.position[1] + dF[1], d7.position[2] + dF[2]] };
}
function Ci(d7) {
  if (!d7 || d7.kind !== "box") return false;
  let d8 = d7.rotation || [0, 0, 0];
  if (Math.abs(d8[0] % 360) > 1e-6 || Math.abs(d8[2] % 360) > 1e-6) return false;
  let d9 = Math.abs(d7.scale[1]), dd = Math.min(Math.abs(d7.scale[0]), Math.abs(d7.scale[2]));
  return d9 <= 1.0001 && d9 * 8 <= dd;
}
function cs(d7, d8) {
  let d9 = d8[1] - $.spawnDepth, dd = d8[1] + $.spawnHeight;
  if (d7.max[1] < d9 || d7.min[1] > dd) return false;
  let dC = Ft(d8[0], d7.min[0], d7.max[0]), dc = Ft(d8[2], d7.min[2], d7.max[2]);
  return Math.hypot(dC - d8[0], dc - d8[2]) < $.spawnRadius;
}
function hs(d7, d8) {
  return d7.max[0] > d8[0] - 0.4 && d7.min[0] < d8[0] + 0.4 && d7.max[2] > d8[2] - 0.4 && d7.min[2] < d8[2] + 0.4 && d7.max[1] > d8[1] + 0.05 && d7.min[1] < d8[1] + 1.85;
}
function Ai(d7) {
  let d8 = String(d7 || "");
  return !d8 || d8.startsWith("rz:") ? true : d8.startsWith("/") && !d8.startsWith("//") && !/^\/+[a-z]+:/i.test(d8);
}
function Pe(d7, { spawns: d8 = [], people: d9 = [] } = {}) {
  let dd = d6(d7);
  if (!dd) return { refused: "That is not something that can be built." };
  let dC = [];
  if (dd.kind === "model" && !Ai(dd.src)) return { refused: "Only the game's own models can be placed in a dorm." };
  if (Ai(dd.src) || (dd.src = ""), vt(dd)) for (let dc = 0; dc < 3; dc++) {
    let dl = dd.scale[dc], dF = dl < 0 ? -1 : 1;
    dd.scale[dc] = dF * Ft(Math.abs(dl), $.minSize, $.maxSize);
  }
  if (dd.position[0] = Ft(dd.position[0], -$.reach, $.reach), dd.position[2] = Ft(dd.position[2], -$.reach, $.reach), dd.position[1] = Ft(dd.position[1], $.minY, $.maxY), dd.kind === "stroke" && dd.solid && (dd.solid = false), dd.kind === "stroke" && !dd.points.length) return { refused: "That line has nothing in it." };
  if (dd.solid) {
    let dk = Ht(dd);
    (dd.hidden || dd.opacity !== void 0 && dd.opacity < $.solidOpacity) && !Ci(dd) ? (dd.solid = false, dC.push("Invisible or see-through things cannot be solid.")) : Ci(dd) || (dk && d8.some((dm) => Array.isArray(dm) && cs(dk, dm)) ? (dd.solid = false, dC.push("Nothing solid can go where people arrive.")) : dk && d9.some((dm) => Array.isArray(dm) && hs(dk, dm)) && (dd.solid = false, dC.push("Nothing solid can go where somebody is standing.")));
  }
  return { object: dd, notes: dC };
}
function Pi(d7) {
  return (Array.isArray(d7) ? d7 : []).filter((d8) => !(d8 && typeof d8.name == "string" && /drag/i.test(d8.name))).map((d8) => d8 && Array.isArray(d8.position) ? d8.position : Array.isArray(d8) ? d8 : null).filter((d8) => d8 && d8.length === 3 && d8.every(Number.isFinite)).slice(0, 16);
}
var Oi = "rz.colours.saved.v1", ee = (d7) => Math.min(1, Math.max(0, d7));
function bt(d7) {
  return "#" + d7.slice(0, 3).map((d8) => Math.round(ee(d8) * 255).toString(16).padStart(2, "0")).join("");
}
function Ti(d7) {
  let d8 = String(d7 || "").trim().replace(/^#/, "");
  return /^[0-9a-f]{3}$/i.test(d8) && (d8 = d8.split("").map((d9) => d9 + d9).join("")), /^[0-9a-f]{6}$/i.test(d8) ? [0, 2, 4].map((d9) => Math.round(parseInt(d8.slice(d9, d9 + 2), 16) / 255 * 1e3) / 1e3) : null;
}
function Ri([d7, d8, d9]) {
  let dd = Math.max(d7, d8, d9), dC = Math.min(d7, d8, d9), dc = dd - dC, dl = 0;
  return dc > 1e-6 && (dd === d7 ? dl = (d8 - d9) / dc % 6 : dd === d8 ? dl = (d9 - d7) / dc + 2 : dl = (d7 - d8) / dc + 4, dl *= 60, dl < 0 && (dl += 360)), [dl, dd > 1e-6 ? dc / dd : 0, dd];
}
function Te([d7, d8, d9]) {
  let dd = d9 * d8, dC = dd * (1 - Math.abs(d7 / 60 % 2 - 1)), dc = d9 - dd, [dl, dF, dk] = d7 < 60 ? [dd, dC, 0] : d7 < 120 ? [dC, dd, 0] : d7 < 180 ? [0, dd, dC] : d7 < 240 ? [0, dC, dd] : d7 < 300 ? [dC, 0, dd] : [dd, 0, dC];
  return [dl + dc, dF + dc, dk + dc].map((dm) => Math.round(ee(dm) * 1e3) / 1e3);
}
function Re() {
  try {
    let d7 = JSON.parse(localStorage.getItem(Oi) || "[]");
    return Array.isArray(d7) ? d7.filter((d8) => Array.isArray(d8) && d8.length === 3 && d8.every(Number.isFinite)).slice(0, 16) : [];
  } catch {
    return [];
  }
}
function $i(d7) {
  try {
    localStorage.setItem(Oi, JSON.stringify(d7.slice(0, 16)));
  } catch {
  }
}
var tt = (d7, d8, d9) => {
  let dd = document.createElement(d7);
  return d8 && (dd.className = d8), d9 !== void 0 && (dd.textContent = d9), dd;
};
function Ii({ value: d7, presets: d8 = [], onInput: d9 = () => {
}, onChange: dd = () => {
} }) {
  let dC = (d7 || [1, 1, 1]).slice(0, 3), dc = Ri(dC), dl = tt("div", "cp"), dF = tt("div", "cp-top"), dk = tt("div", "cp-square"), dm = tt("i", "cp-knob");
  dk.appendChild(dm);
  let du = document.createElement("input");
  du.type = "range", du.min = "0", du.max = "360", du.step = "1", du.className = "cp-hue", du.setAttribute("aria-label", "Hue");
  let dj = tt("div", "cp-side"), dW = tt("div", "cp-now"), dS = document.createElement("input");
  dS.type = "text", dS.className = "cp-hex", dS.maxLength = 7, dS.spellcheck = false, dS.setAttribute("aria-label", "Hex colour");
  let dE = tt("button", "wt-chip cp-save", "Save colour");
  dE.type = "button", dj.append(dW, dS, dE), dF.append(dk, dj);
  let dh = tt("div", "cp-rgb"), dA = ["R", "G", "B"].map((dD, dG) => {
    let dR = tt("label", "cp-row"), dx = document.createElement("input");
    dx.type = "range", dx.min = "0", dx.max = "255", dx.step = "1", dx.className = "cp-ch cp-ch-" + dD.toLowerCase(), dx.setAttribute("aria-label", dD);
    let df = tt("b", "cp-val");
    return dR.append(tt("span", "", dD), dx, df), dh.appendChild(dR), dx.addEventListener("input", () => {
      let dy = dC.slice();
      dy[dG] = Math.round(Number(dx.value) / 255 * 1e3) / 1e3, dJ(dy, "rgb"), d9(dC);
    }), dx.addEventListener("change", () => dd(dC)), { input: dx, out: df };
  }), dv = (dD, dG, dR, dx) => {
    let df = tt("div", "cp-group");
    df.appendChild(tt("div", "cp-label", dR));
    let dy = tt("div", "bd-swatches " + dG);
    return dD.forEach((dN, dr) => {
      let dX = tt("button", "bd-sw");
      dX.type = "button", dX.style.background = bt(dN), dX.title = dx ? bt(dN) + " (Shift click to remove)" : bt(dN), dX.setAttribute("aria-label", bt(dN)), dX.addEventListener("click", (da) => {
        if (dx && da.shiftKey) {
          dx(dr);
          return;
        }
        dJ(dN.slice(), "all"), dd(dC);
      }), dy.appendChild(dX);
    }), df.appendChild(dy), df;
  }, dZ = dv(d8, "cp-presets", "Presets"), dg = tt("div"), db = () => {
    dg.replaceChildren();
    let dD = Re();
    if (!dD.length) {
      let dG = tt("div", "cp-group");
      dG.append(tt("div", "cp-label", "Saved"), tt("div", "cp-empty", "Colours you save show here.")), dg.appendChild(dG);
      return;
    }
    dg.appendChild(dv(dD, "cp-saved", "Saved", (dR) => {
      let dx = Re();
      dx.splice(dR, 1), $i(dx), db();
    }));
  };
  dE.addEventListener("click", () => {
    let dD = Re().filter((dG) => bt(dG) !== bt(dC));
    dD.unshift(dC.slice()), $i(dD), db();
  }), db(), dl.append(dF, du, dh, dZ, dg);
  function dJ(dD, dG) {
    if (dC = dD.map(ee), dG !== "hsv") {
      let dx = Ri(dC);
      dc = [dx[1] > 1e-3 ? dx[0] : dc[0], dx[1], dx[2]];
    }
    let dR = Te([dc[0], 1, 1]);
    dk.style.background = "linear-gradient(to top, #000, transparent), linear-gradient(to right, #fff, " + bt(dR) + ")", dm.style.left = dc[1] * 100 + "%", dm.style.top = (1 - dc[2]) * 100 + "%", dm.style.background = bt(dC), dG !== "hue" && (du.value = String(Math.round(dc[0]))), dW.style.background = bt(dC), dG !== "hex" && (dS.value = bt(dC)), dA.forEach((df, dy) => {
      dG !== "rgb" && (df.input.value = String(Math.round(dC[dy] * 255))), df.out.textContent = String(Math.round(dC[dy] * 255));
      let dN = dC.slice(), dr = dC.slice();
      dN[dy] = 0, dr[dy] = 1, df.input.style.setProperty("--cp-track", "linear-gradient(to right, " + bt(dN) + ", " + bt(dr) + ")");
    });
  }
  let dO = (dD) => {
    let dG = dk.getBoundingClientRect();
    dc = [dc[0], ee((dD.clientX - dG.left) / dG.width), 1 - ee((dD.clientY - dG.top) / dG.height)], dJ(Te(dc), "hsv"), d9(dC);
  };
  dk.addEventListener("pointerdown", (dD) => {
    dD.preventDefault(), dk.setPointerCapture(dD.pointerId), dl.dataset.dragging = "1", dO(dD);
  }), dk.addEventListener("pointermove", (dD) => {
    dl.dataset.dragging && dO(dD);
  });
  let dM = () => {
    dl.dataset.dragging && (delete dl.dataset.dragging, dd(dC));
  };
  dk.addEventListener("pointerup", dM), dk.addEventListener("pointercancel", dM), du.addEventListener("input", () => {
    dc = [Number(du.value), dc[1] || 1, dc[2] || 1], dJ(Te(dc), "hue"), d9(dC);
  }), du.addEventListener("change", () => dd(dC)), dS.addEventListener("input", () => {
    let dD = Ti(dS.value);
    if (!dD) {
      dS.classList.add("is-bad");
      return;
    }
    dS.classList.remove("is-bad"), dJ(dD, "hex"), d9(dC);
  });
  let dT = () => {
    Ti(dS.value) ? dd(dC) : (dS.classList.remove("is-bad"), dS.value = bt(dC));
  };
  return dS.addEventListener("change", dT), dS.addEventListener("keydown", (dD) => {
    dD.key === "Enter" && (dD.preventDefault(), dS.blur()), dD.stopPropagation();
  }), dJ(dC, "all"), dl.setColour = (dD) => {
    !dl.dataset.dragging && document.activeElement !== dS && dJ(dD.slice(0, 3), "all");
  }, dl;
}
var wt = [{ id: "off", label: "Off", hint: "Exactly where the pen is" }, { id: "grid", label: "Grid", hint: "Every point on the grid" }, { id: "surface", label: "Surface", hint: "On what you point at" }, { id: "free", label: "Free", hint: "Freehand, smoothed" }], ie = 5e-3, se = 0.15, us = (d7) => Math.min(0.06, Math.max(0.01, d7 * 0.6)), Kt = (d7, d8) => [d7[0] - d8[0], d7[1] - d8[1], d7[2] - d8[2]], fe = (d7, d8) => d7[0] * d8[0] + d7[1] * d8[1] + d7[2] * d8[2], ps = (d7) => Math.hypot(d7[0], d7[1], d7[2]), xt = (d7, d8) => Math.hypot(d7[0] - d8[0], d7[1] - d8[1], d7[2] - d8[2]), me = (d7) => {
  let d8 = ps(d7) || 1;
  return [d7[0] / d8, d7[1] / d8, d7[2] / d8];
}, ge = (d7, d8, d9) => [d7[0] + (d8[0] - d7[0]) * d9, d7[1] + (d8[1] - d7[1]) * d9, d7[2] + (d8[2] - d7[2]) * d9];
function pe(d7, d8, d9) {
  let dd = Kt(d9, d8), dC = fe(dd, dd), dc = dC < 1e-12 ? 0 : Math.max(0, Math.min(1, fe(Kt(d7, d8), dd) / dC)), dl = ge(d8, d9, dc);
  return { t: dc, point: dl, distance: xt(d7, dl) };
}
function Di(d7, d8 = 1e-3) {
  let d9 = [];
  for (let dd of d7) (!d9.length || xt(dd, d9[d9.length - 1]) > d8) && d9.push(dd);
  return d9;
}
function $e(d7, d8) {
  if (d7.length < 3) return d7.slice();
  let d9 = new Uint8Array(d7.length);
  d9[0] = d9[d7.length - 1] = 1;
  let dd = [[0, d7.length - 1]];
  for (; dd.length; ) {
    let [dC, dc] = dd.pop(), dl = -1, dF = -1;
    for (let dk = dC + 1; dk < dc; dk++) {
      let dm = pe(d7[dk], d7[dC], d7[dc]).distance;
      dm > dl && (dl = dm, dF = dk);
    }
    dl > d8 && (d9[dF] = 1, dd.push([dC, dF], [dF, dc]));
  }
  return d7.filter((du, dj) => d9[dj]);
}
function fs(d7, d8 = 2) {
  let d9 = d7;
  for (let dd = 0; dd < d8 && d9.length > 2; dd++) {
    let dC = [d9[0]];
    for (let dc = 0; dc < d9.length - 1; dc++) {
      let dl = d9[dc], dF = d9[dc + 1];
      dc > 0 && dC.push(ge(dl, dF, 0.25)), dc < d9.length - 2 && dC.push(ge(dl, dF, 0.75));
    }
    dC.push(d9[d9.length - 1]), d9 = dC;
  }
  return d9;
}
function Bi(d7, d8, d9) {
  let dd = me(Kt(d8, d7)), dC = me(Kt(d9, d8));
  return Math.acos(Math.max(-1, Math.min(1, fe(dd, dC))));
}
function ms(d7, d8 = 150 * Math.PI / 180) {
  let d9 = d7.slice(), dd = true;
  for (; dd && d9.length > 2; ) {
    dd = false;
    for (let dC = 1; dC < d9.length - 1; dC++) if (Bi(d9[dC - 1], d9[dC], d9[dC + 1]) > d8) {
      d9.splice(dC, 1), dd = true;
      break;
    }
  }
  return d9;
}
var gs = (d7, d8) => d7.map((d9) => Math.round(d9 / d8) * d8), ve = class {
  constructor({ width: d7 = 0.025, mode: d8 = "off", grid: d9 = 0.1, max: dd = 120 } = {}) {
    this.width = Math.min(se, Math.max(ie, d7)), this.mode = wt.some((dC) => dC.id === d8) ? d8 : "off", this.grid = d9 > 0 ? d9 : 0.1, this.max = Math.max(8, dd), this.points = [], this.done = [], this._brush = null, this._over = null, this._lifted = false;
  }
  get ["spacing"]() {
    return this.mode === "grid" ? this.grid * 0.5 : us(this.width);
  }
  get ["reach"]() {
    return Math.max(0.012, this.width * 0.9);
  }
  ["add"](d7) {
    let d8 = [];
    if (!d7 || d7.length !== 3 || !d7.every(Number.isFinite)) return this.points.length && (this._lifted = true), { changed: false, pieces: d8 };
    if (this.mode === "grid" && (d7 = gs(d7, this.grid)), this.mode === "free") {
      let dC = Math.max(0.03, this.width * 1.2);
      if (!this._brush) this._brush = d7.slice();
      else {
        let dc = xt(d7, this._brush);
        if (dc <= dC) return { changed: false, pieces: d8 };
        this._brush = ge(this._brush, d7, (dc - dC) / dc);
      }
      d7 = this._brush.slice();
    }
    this._lifted && (this._lifted = false, this._cut(d8));
    let d9 = this.points;
    if (!d9.length) return this.done.length && this._overOld(d7) ? { changed: false, pieces: d8 } : (d9.push(d7), { changed: true, pieces: d8 });
    let dd = d9[d9.length - 1];
    if (xt(d7, dd) < this.spacing) return { changed: false, pieces: d8 };
    if (!this._over && d9.length > 3 && xt(d7, d9[0]) < this.reach && this._length(d9) > Math.max(0.15, this.width * 8)) return d9.push(d9[0].slice()), this._lifted = true, { changed: true, pieces: d8 };
    if (!this._over && this._rewind(d7)) return { changed: true, pieces: d8 };
    if (this._overOld(d7)) return this._over || (this._over = { from: dd.slice() }), { changed: false, pieces: d8 };
    if (this._over) {
      let dl = xt(this._over.from, d7);
      if (this._over = null, dl > this.width * 3 + this.spacing * 2) return this._cut(d8), this.points.push(d7), { changed: true, pieces: d8 };
    }
    if (this.mode === "grid" && d9.length >= 2 && Bi(d9[d9.length - 2], dd, d7) < 1e-3 && d9.pop(), d9.push(d7), d9.length >= this.max) {
      let dF = d9[d9.length - 1].slice();
      this._cut(d8), this.points.push(dF);
    }
    return { changed: true, pieces: d8 };
  }
  ["finish"]() {
    let d7 = [];
    return this._cut(d7, true), this._brush = null, this._over = null, d7;
  }
  ["_cut"](d7, d8 = false) {
    let d9 = this.clean(this.points);
    (d9.length >= 2 || d9.length === 1 && d8 && !this.done.length && !d7.length) && (d7.push(d9), this.done.push(d9)), this.points = [];
  }
  ["clean"](d7) {
    let d8 = Di(d7.filter((d9) => d9.every(Number.isFinite)));
    return d8.length < 3 ? d8 : (this.mode === "free" ? (d8 = fs(d8, 2), d8 = $e(d8, Math.max(3e-3, this.width * 0.12))) : this.mode === "grid" ? d8 = $e(d8, 1e-4) : d8 = $e(d8, Math.max(2e-3, this.width * 0.08)), d8 = ms(d8), Di(d8, Math.min(9e-3, this.spacing * 0.5)));
  }
  ["_length"](d7) {
    let d8 = 0;
    for (let d9 = 1; d9 < d7.length; d9++) d8 += xt(d7[d9], d7[d9 - 1]);
    return d8;
  }
  ["_rewind"](d7) {
    let d8 = this.points;
    if (d8.length < 2) return false;
    let d9 = d8[d8.length - 1], dd = me(Kt(d7, d9)), dC = 0;
    for (let dc = d8.length - 2; dc >= 0; dc--) {
      let dl = d8[dc], dF = d8[dc + 1];
      if (dC += xt(dl, dF), dC > 2) break;
      let dk = pe(d7, dl, dF);
      if (!(dk.distance > this.reach || dk.t >= 0.999) && !(fe(dd, me(Kt(dF, dl))) > -0.5)) return d8.length = dc + 1, xt(dk.point, dl) > this.spacing * 0.5 && d8.push(dk.point), true;
    }
    return false;
  }
  ["_overOld"](d7) {
    let d8 = this.points, d9 = 0, dd = d8.length - 1;
    for (; dd > 0 && d9 < this.width * 3 + this.spacing * 2; ) d9 += xt(d8[dd], d8[dd - 1]), dd--;
    for (let dC = 0; dC < dd; dC++) if (pe(d7, d8[dC], d8[dC + 1]).distance < this.reach) return true;
    for (let dc of this.done) for (let dl = 0; dl < dc.length - 1; dl++) if (pe(d7, dc[dl], dc[dl + 1]).distance < this.reach) {
      if (dl === dc.length - 2 && d8.length && xt(d8[0], dc[dc.length - 1]) < 1e-6 && xt(d7, d8[0]) < this.width * 3 + this.spacing * 2) continue;
      return true;
    }
    return false;
  }
};
function Ni(d7, d8) {
  let d9 = [];
  for (let dd of d7) {
    let dC = dd.map((dl, dF) => Math.round((dl - d8[dF]) * 100) / 100), dc = d9[d9.length - 1];
    (!dc || dc[0] !== dC[0] || dc[1] !== dC[1] || dc[2] !== dC[2]) && d9.push(dC);
  }
  return d9;
}
var Gt = 14, Ut = [{ id: "create", label: "Create", hint: "Click to place \xB7 Wheel shape \xB7 R turn \xB7 Shift wheel size" }, { id: "draw", label: "Draw", hint: "Hold click to draw \xB7 R how it draws \xB7 Wheel nearer or further \xB7 Shift wheel thickness" }, { id: "select", label: "Select", hint: "Click to pick \xB7 Shift click to add \xB7 Hold and sweep to box select \xB7 Wheel: the one behind" }, { id: "move", label: "Move", hint: "Click to pick \xB7 Drag an arrow to move along it \xB7 Hold on it to carry" }, { id: "rotate", label: "Rotate", hint: "Click to pick \xB7 Drag a ring to turn round it \xB7 Wheel a little" }, { id: "scale", label: "Scale", hint: "Click to pick \xB7 Drag a handle to size along it \xB7 Wheel all ways" }, { id: "copy", label: "Copy", hint: "Click to copy and carry" }, { id: "paint", label: "Paint", hint: "Click a thing, furniture, the basket, a ball, or the walls" }, { id: "freeze", label: "Freeze", hint: "Click to freeze or unfreeze" }, { id: "delete", label: "Delete", hint: "Click to delete" }], Fi = [{ id: "walls", label: "Walls" }, { id: "ceiling", label: "Ceiling" }, { id: "trim", label: "Trim" }, { id: "accents", label: "Accents" }], Oe = [5e-3, 0.01, 0.025, 0.05, 0.075, 0.1, 0.15], Ki = "rz.draw.v1";
function bs() {
  try {
    let d7 = JSON.parse(localStorage.getItem(Ki) || "{}");
    return { mode: wt.some((d8) => d8.id === d7.mode) ? d7.mode : "free", width: Number.isFinite(d7.width) ? Math.min(se, Math.max(ie, d7.width)) : 0.025 };
  } catch {
    return { mode: "free", width: 0.025 };
  }
}
function Hi(d7, d8) {
  try {
    localStorage.setItem(Ki, JSON.stringify({ mode: d7, width: d8 }));
  } catch {
  }
}
var mt = [{ id: "block", label: "Block", kind: "box", size: [1, 1, 1] }, { id: "slab", label: "Floor", kind: "box", size: [2, 0.2, 2] }, { id: "wall", label: "Wall", kind: "box", size: [2, 2, 0.2] }, { id: "step", label: "Step", kind: "box", size: [1, 0.25, 0.5] }, { id: "beam", label: "Beam", kind: "box", size: [0.25, 0.25, 2] }, { id: "pillar", label: "Pillar", kind: "cylinder", size: [0.5, 2, 0.5] }, { id: "ball", label: "Ball", kind: "sphere", size: [0.8, 0.8, 0.8] }], Gi = [[0.16, 0.42, 0.98], [0.07, 0.16, 0.45], [0.3, 0.78, 1], [0.12, 0.7, 0.66], [0.2, 0.75, 0.32], [0.62, 0.86, 0.22], [1, 0.84, 0.22], [1, 0.55, 0.16], [0.92, 0.24, 0.24], [0.96, 0.42, 0.66], [0.6, 0.32, 0.92], [0.55, 0.36, 0.2], [0.96, 0.96, 0.97], [0.7, 0.72, 0.76], [0.36, 0.38, 0.43], [0.09, 0.09, 0.11]], oe = [{ id: "matte", label: "Matte", roughness: 0.85, metallic: 0 }, { id: "gloss", label: "Glossy", roughness: 0.18, metallic: 0 }, { id: "metal", label: "Metal", roughness: 0.3, metallic: 0.9 }, { id: "glow", label: "Glow", roughness: 0.5, metallic: 0, glow: true }], Ui = [0, 0.1, 0.25, 0.5, 1];
function Vi(d7) {
  return !!d7 && d7.kind === "model" && !d7.hidden && !/#(room|mirror)$/.test(d7.src || "");
}
function ws(d7) {
  let d8 = /#([^#]+)$/.exec(d7 && d7.src || "");
  try {
    return d8 ? decodeURIComponent(d8[1]) : d7 && d7.name || "that";
  } catch {
    return d7 && d7.name || "that";
  }
}
var ne = Math.PI / 180, ji = (d7) => q.fromEuler(q.create(), d7[0] * ne, d7[1] * ne, d7[2] * ne);
function ys(d7) {
  let d8 = L.fromRotationTranslationScale(L.create(), d7, [0, 0, 0], [1, 1, 1]), d9 = Math.max(-1, Math.min(1, -d8[9])), dd = Math.asin(d9), dC, dc;
  Math.abs(d9) < 0.9999 ? (dC = Math.atan2(d8[8], d8[10]), dc = Math.atan2(d8[1], d8[5])) : (dC = Math.atan2(-d8[2], d8[0]), dc = 0);
  let dl = (dF) => Math.round((dF / ne % 360 + 360) % 360 * 1e3) / 1e3;
  return [dl(dd), dl(dC), dl(dc)];
}
function ks(d7, d8, d9 = 0.018) {
  let dd = [], dC = [(d7[0] + d8[0]) / 2, (d7[1] + d8[1]) / 2, (d7[2] + d8[2]) / 2], dc = [d8[0] - d7[0], d8[1] - d7[1], d8[2] - d7[2]];
  for (let du = 0; du < 3; du++) {
    let dj = (du + 1) % 3, dW = (du + 2) % 3;
    for (let dS of [-1, 1]) for (let dE of [-1, 1]) {
      let dh = [d9, d9, d9];
      dh[du] = dc[du] + d9;
      let dA = dC.slice();
      dA[dj] += dS * dc[dj] / 2, dA[dW] += dE * dc[dW] / 2, dd.push({ geo: i(dh[0], dh[1], dh[2]), at: dA });
    }
  }
  let dl = [], dF = [], dk = [], dm = [];
  for (let { geo: dv, at: dZ } of dd) {
    let dg = dl.length / 3;
    for (let db = 0; db < dv.positions.length; db += 3) dl.push(dv.positions[db] + dZ[0], dv.positions[db + 1] + dZ[1], dv.positions[db + 2] + dZ[2]);
    for (let dJ of dv.normals) dF.push(dJ);
    for (let dO of dv.uvs) dk.push(dO);
    for (let dM of dv.indices) dm.push(dg + dM);
  }
  return { positions: new Float32Array(dl), normals: new Float32Array(dF), uvs: new Float32Array(dk), indices: dm };
}
function be(d7) {
  let d8 = (dC) => Math.round((Number(dC) || 0) * 1e3) / 1e3, d9 = (dC) => Math.round((Number(dC) || 0) * 100) / 100, dd = { id: d7.id, kind: d7.kind || "box", p: (d7.position || [0, 0, 0]).map(d8), r: (d7.rotation || [0, 0, 0]).map(d8), s: (d7.scale || [1, 1, 1]).map(d8), c: (d7.colour || [0.8, 0.8, 0.82]).slice(0, 3).map(d9), rough: d8(d7.roughness ?? 0.7), metal: d8(d7.metallic || 0) };
  return Array.isArray(d7.emissive) && d7.emissive.some(Boolean) && (dd.e = d7.emissive.map(d8)), d7.src && (dd.src = d7.src), d7.solid === false && (dd.solid = false), d7.hidden && (dd.hidden = true), d7.opacity !== void 0 && Number(d7.opacity) < 1 && (dd.op = d8(d7.opacity)), d7.locked && (dd.locked = true), d7.tag && (dd.tag = d7.tag), d7.kind === "stroke" && (dd.pts = (d7.points || []).map((dC) => dC.map(d9)), dd.w = d8(d7.width || 0.03)), d7.paint && Object.keys(d7.paint).length && (dd.paint = Object.keys(d7.paint).sort().map((dC) => [dC, d7.paint[dC].map(d8)])), Array.isArray(d7.tint) && (dd.tint = d7.tint.map(d8)), JSON.stringify(dd);
}
var Yi = (d7) => "#" + d7.map((d8) => Math.round(Math.min(1, Math.max(0, d8)) * 255).toString(16).padStart(2, "0")).join(""), Wi = (d7, d8) => d8 ? Math.round(d7 / d8) * d8 : d7, nt = (d7) => Math.round(d7 * 1e3) / 1e3;
function we(d7, d8) {
  let d9 = oe.find((dd) => dd.id === d8) || oe[0];
  return { colour: d7.slice(0, 3), roughness: d9.roughness, metallic: d9.metallic, emissive: d9.glow ? d7.map((dd) => nt(dd * 0.85)) : [0, 0, 0] };
}
var ye = class extends EventTarget {
  constructor({ game: d7, world: d8, net: d9, tools: dd, hud: dC = null, isMine: dc, save: dl = null, pickups: dF = null }) {
    super(), this.addEventListener("change", () => this._badge()), this.game = d7, this.world = d8, this.net = d9, this.tools = dd, this.hud = dC, this.isMine = dc, this.saver = dl, this.pickups = dF, this.active = false, this.tool = "create", this.shape = "block", this.ink = Gi[0].slice(), this.finish = "gloss", this.grid = 0.25, this.turn = 0, this.scaleBy = 1, this.selection = /* @__PURE__ */ new Set(), this.selected = null, this.grabbed = null, this.turnSnap = 15, this.gizmo = new a(), this.gizmo.root.noMirror = true, this._groupDrag = null, this._outlines = /* @__PURE__ */ new Map(), this._sweep = null, this.drawDist = 1.6;
    let dk = typeof localStorage > "u" ? { mode: "free", width: 0.025 } : bs();
    this.drawMode = dk.mode, this.lineWidth = dk.width, this.stroke = null, this.saveState = "saved", this.saved = null, this._savedObjects = [], this._aim = null, this.base = {}, this._buildMarks(), d8.overlay ? d8.overlay.add(this.gizmo.root) : d7.scene.add(this.gizmo.root), dd.penInkOf = (dm) => dm === "mine" ? this.ink : [0.25, 0.6, 1], d7.addUpdater((dm) => this.update(dm)), this._bind(), d8.addEventListener("changed", (dm) => {
      let du = dm.detail || {};
      du.k === d5.REMOVE && this.selection.has(du.id) && this.deselect(du.id), du.k === d5.REMOVE && this.grabbed && du.id === this.grabbed.id && (this.grabbed = null);
    }), d8.doc.addEventListener("reset", () => {
      this.select(null), this.grabbed = null, setTimeout(() => this.checkSaved(), 0);
    });
  }
  ["built"]() {
    return this.world.doc.list().filter(vt);
  }
  get ["count"]() {
    return this.built().length;
  }
  ["spawns"]() {
    let d7 = (this.world.spawns && this.world.spawns.length ? this.world.spawns : this.base.spawns) || [];
    return Pi(d7);
  }
  ["people"]() {
    let d7 = [];
    for (let d8 of this.game.remotes.values()) {
      let d9 = d8.root && d8.root.position;
      d9 && d7.push([d9[0], d9[1], d9[2]]);
    }
    return d7;
  }
  ["toggle"](d7) {
    let d8 = d7 === void 0 ? !this.active : !!d7;
    return d8 && !this.isMine() ? (this.say("You can build in your own dorm."), false) : (this.active = d8, this.game.player.wielding = d8 ? d4.builder : this.game.player.wielding === d4.builder ? 0 : this.game.player.wielding, d8 || (this._drop(), this.stroke && this.finishStroke(), this.select(null)), this._showMarks(), this._paintHint(), this.dispatchEvent(new CustomEvent("change")), !d8 && this.dirty && this.say("Your changes are not saved yet. Save them on the Builder page (Q) or with Ctrl S."), d8);
  }
  ["setTool"](d7) {
    Ut.some((d8) => d8.id === d7) && (this._groupDrag && this._endGroup(), this._drop(), this.stroke && this.finishStroke(), this.tool = d7, this._showMarks(), this._paintHint(), this.dispatchEvent(new CustomEvent("change")));
  }
  ["setShape"](d7) {
    mt.some((d8) => d8.id === d7) && (this.shape = d7, this.scaleBy = 1, this._ghostShape(), this._paintHint(), this.dispatchEvent(new CustomEvent("change")));
  }
  ["setInk"](d7, { quiet: d8 = false } = {}) {
    this.ink = d7.slice(0, 3).map((dd) => Math.min(1, Math.max(0, Number(dd) || 0)));
    let d9 = this.tools.pens.get("mine");
    d9 && d9.setInk(this.ink), this._marksInk(), this._paintHint(), d8 || this.dispatchEvent(new CustomEvent("change"));
  }
  ["setFinish"](d7) {
    oe.some((d8) => d8.id === d7) && (this.finish = d7), this._marksInk(), this.dispatchEvent(new CustomEvent("change"));
  }
  ["setGrid"](d7) {
    this.grid = Ui.includes(d7) ? d7 : 0.25, this.dispatchEvent(new CustomEvent("change"));
  }
  ["select"](d7, { add: d8 = false } = {}) {
    let d9 = d7 && this.world.doc.get(d7), dd = d9 && vt(d9);
    d8 || this.selection.clear(), dd && (d8 && this.selection.has(d7) ? this.selection.delete(d7) : this.selection.add(d7)), this.selected = this.selection.size ? [...this.selection][this.selection.size - 1] : null, this.dispatchEvent(new CustomEvent("change"));
  }
  ["deselect"](d7) {
    this.selection.delete(d7), this.selected = this.selection.size ? [...this.selection][this.selection.size - 1] : null, this.dispatchEvent(new CustomEvent("change"));
  }
  ["picked"]() {
    return [...this.selection].map((d7) => this.world.doc.get(d7)).filter(Boolean);
  }
  ["pivot"](d7 = this.picked()) {
    if (!d7.length) return null;
    let d8 = [1 / 0, 1 / 0, 1 / 0], d9 = [-1 / 0, -1 / 0, -1 / 0];
    for (let dd of d7) {
      let dC = Ht(dd) || { min: dd.position, max: dd.position };
      for (let dc = 0; dc < 3; dc++) d8[dc] = Math.min(d8[dc], dC.min[dc]), d9[dc] = Math.max(d9[dc], dC.max[dc]);
    }
    return [0, 1, 2].map((dl) => (d8[dl] + d9[dl]) / 2);
  }
  ["_commit"](d7, d8) {
    if (!this.isMine()) return null;
    if (d7 === d5.ADD && this.count >= $.maxBuilt) return this.say("Your dorm holds " + $.maxBuilt + " built things. Delete something to make room."), null;
    let d9 = Pe(d8, { spawns: this.spawns(), people: this.people() });
    if (d9.refused) return this.say(d9.refused), null;
    for (let dd of d9.notes) this.say(dd);
    return this.world._do({ k: d7, o: d9.object }), this._changed(), d9.object;
  }
  ["create"](d7 = this._aim) {
    let d8 = mt.find((dc) => dc.id === this.shape) || mt[0], d9 = this._placeFor(d7);
    if (!d9) return null;
    let dd = o(d8.kind, { id: N($.builtPrefix), name: d8.label, position: d9.position, rotation: [0, this.turn, 0], scale: d9.scale, solid: true, ...we(this.ink, this.finish) }), dC = this._commit(d5.ADD, dd);
    return dC && (this.select(dC.id), this.world.sealHistory()), dC;
  }
  ["removePicked"]() {
    let d7 = 0;
    for (let d8 of [...this.selection]) this.remove(d8) && d7++;
    return d7;
  }
  ["remove"](d7 = this.selected) {
    let d8 = d7 && this.world.doc.get(d7);
    return !d8 || !vt(d8) || !this.isMine() ? false : d8.locked ? (this.say("That is frozen. Unfreeze it on the Builder page first."), false) : (this.world._do({ k: d5.REMOVE, id: d7 }), this.world.sealHistory(), this.selection.has(d7) && this.deselect(d7), this._changed(), true);
  }
  ["paint"](d7) {
    let d8 = d7 && this.world.doc.get(d7);
    if (!d8 || !vt(d8)) return null;
    let d9 = { ...d8, ...we(this.ink, this.finish) };
    d9.emissive.some((dC) => dC > 0) || delete d9.emissive;
    let dd = this._commit(d5.MATERIAL, d9);
    return this.world.sealHistory(), dd;
  }
  ["paintModel"](d7, d8 = this.ink) {
    let d9 = d7 && this.world.doc.get(d7);
    if (!Vi(d9) || !this.isMine()) return null;
    let dd = { ...d9 };
    return d8 ? dd.tint = d8.slice(0, 3).map(nt) : delete dd.tint, this.world._do({ k: d5.MATERIAL, o: dd }), this.world.sealHistory(), this._changed(), dd;
  }
  ["paintGear"](d7, d8 = this.ink) {
    let d9 = this.furniture && this.furniture.gear ? this.furniture.gear().hoop : null;
    if (!d9 || !["basket", "balls"].includes(d7) || !this.isMine()) return null;
    let dd = { ...d9.paint || {} };
    d8 ? dd[d7] = d8.slice(0, 3).map(nt) : delete dd[d7];
    let dC = { ...d9, paint: dd };
    return Object.keys(dd).length || delete dC.paint, this.world._do({ k: d5.MATERIAL, o: dC }), this.world.sealHistory(), this._changed(), dC;
  }
  ["copy"](d7) {
    let d8 = d7 && this.world.doc.get(d7);
    if (!d8 || !vt(d8)) return null;
    let d9 = { ...d8, id: N($.builtPrefix), locked: void 0 };
    delete d9.locked;
    let dd = this._commit(d5.ADD, d9);
    return dd && this._grab(dd.id), dd;
  }
  ["change"](d7, d8) {
    let d9 = d7 && this.world.doc.get(d7);
    if (!d9 || !vt(d9)) return null;
    let dd = { ...d9, ...d8 };
    "locked" in d8 && !d8.locked && delete dd.locked, "opacity" in d8 && d8.opacity >= 1 && delete dd.opacity;
    let dC = "position" in d8 || "rotation" in d8 || "scale" in d8 ? d5.MOVE : d5.MATERIAL, dc = this._commit(dC, dd);
    return this.world.sealHistory(), dc;
  }
  ["undo"]() {
    this.isMine() && this.world.undo() && this._changed();
  }
  ["redo"]() {
    this.isMine() && this.world.redo() && this._changed();
  }
  ["clearAll"]() {
    if (!this.isMine()) return 0;
    let d7 = 0;
    for (let d8 of this.built()) this.world._do({ k: d5.REMOVE, id: d8.id }), d7++;
    return this.world.sealHistory(), this.select(null), d7 && this._changed(), d7;
  }
  ["turnObject"](d7, d8 = 45, d9 = 1) {
    let dd = d7 && this.world.doc.get(d7);
    if (!dd || !vt(dd)) return null;
    if (dd.locked) return this.say("That is frozen. Unfreeze it first."), null;
    let dC = dd.rotation.slice();
    return dC[d9] = ((dC[d9] + d8) % 360 + 360) % 360, this.change(d7, { rotation: dC });
  }
  ["resize"](d7, d8 = 1.25) {
    let d9 = d7 && this.world.doc.get(d7);
    if (!d9 || !vt(d9)) return null;
    if (d9.locked) return this.say("That is frozen. Unfreeze it first."), null;
    if (d9.kind === "stroke") return this.change(d7, { width: nt(Math.min(0.15, Math.max(5e-3, (d9.width || 0.03) * d8))) });
    let dd = d9.scale.map((dC) => nt(Math.sign(dC || 1) * Math.min($.maxSize, Math.max($.minSize, Math.abs(dC) * d8))));
    return this.change(d7, { scale: dd });
  }
  ["freeze"](d7) {
    let d8 = d7 && this.world.doc.get(d7);
    if (!d8 || !vt(d8)) return null;
    let d9 = this.change(d7, { locked: !d8.locked });
    return d9 && this.say(d8.locked ? "Unfrozen." : "Frozen where it is."), d9;
  }
  ["roomObject"]() {
    return this.world.doc.list().find((d7) => d7.kind === "model" && /#room$/.test(d7.src || "")) || null;
  }
  ["paintRoom"](d7, d8 = this.ink) {
    let d9 = this.roomObject();
    if (!d9 || !Fi.some((dc) => dc.id === d7) || !this.isMine()) return null;
    let dd = { ...d9.paint || {} };
    d8 ? dd[d7] = d8.slice(0, 3).map(nt) : delete dd[d7];
    let dC = { ...d9, paint: dd };
    return Object.keys(dd).length || delete dC.paint, this.world._do({ k: d5.MATERIAL, o: dC }), this.world.sealHistory(), this._changed(), dC;
  }
  ["setDrawMode"](d7) {
    wt.some((d8) => d8.id === d7) && (this.stroke && this.finishStroke(), this.drawMode = d7, Hi(this.drawMode, this.lineWidth), this._paintHint(), this.dispatchEvent(new CustomEvent("change")));
  }
  ["setLineWidth"](d7) {
    Number.isFinite(d7) && (this.lineWidth = Math.round(Math.min(se, Math.max(ie, d7)) * 1e3) / 1e3, Hi(this.drawMode, this.lineWidth), this._paintHint(), this.dispatchEvent(new CustomEvent("change")));
  }
  ["_drawPoint"](d7 = this._aim) {
    if (!d7) return null;
    if (this.drawMode === "surface") {
      if (!d7.hit) return null;
      let d9 = this.lineWidth / 2 + 7e-3;
      return [0, 1, 2].map((dd) => d7.point[dd] + d7.normal[dd] * d9);
    }
    let d8 = d7.hit && d7.distance < this.drawDist ? Math.max(0.3, d7.distance - 0.03 - this.lineWidth / 2) : this.drawDist;
    return [0, 1, 2].map((dd) => d7.eye[dd] + d7.dir[dd] * d8);
  }
  ["startStroke"]() {
    if (!this.isMine()) return;
    if (this.count >= $.maxBuilt) {
      this.say("Your dorm holds " + $.maxBuilt + " built things. Delete something to make room.");
      return;
    }
    if (zi(this.world.doc.list()) >= $.maxStrokePoints) {
      this.say("That is as much drawing as a dorm holds. Delete some lines to draw more.");
      return;
    }
    let d7 = new p("builder line");
    d7.material = new Q({ ...we(this.ink, this.finish), castShadow: false }), d7.visible = false, this.game.scene.add(d7);
    let d8 = new ve({ width: this.lineWidth, mode: this.drawMode, grid: this.grid || 0.1, max: G });
    this._aim = this.aim(), this.stroke = { pen: d8, preview: d7, dirty: true, made: 0 }, this.drawMode === "surface" && !(this._aim && this._aim.hit) && this.say("Point at something to draw on it."), this._extendStroke();
  }
  ["_extendStroke"]() {
    let d7 = this.stroke;
    if (!d7) return;
    let d8 = d7.pen.add(this._drawPoint());
    for (let d9 of d8.pieces) this._keepLine(d9);
    (d8.changed || d8.pieces.length) && (d7.dirty = true);
  }
  ["finishStroke"]() {
    let d7 = this.stroke;
    if (!d7) return null;
    this.stroke = null, d7.preview.dispose();
    let d8 = null;
    for (let d9 of d7.pen.finish()) d8 = this._keepLine(d9) || d8;
    return this.world.sealHistory(), d8;
  }
  ["_keepLine"](d7) {
    if (!d7 || !d7.length) return null;
    let d8 = d7[0].map((dC) => Math.round(dC * 1e3) / 1e3), d9 = o("stroke", { id: N($.builtPrefix), name: "Line", position: d8, points: Ni(d7, d8), width: this.lineWidth, solid: false, ...we(this.ink, this.finish) }), dd = this._commit(d5.ADD, d9);
    return dd && this.stroke && this.stroke.made++, dd;
  }
  ["_grab"](d7) {
    let d8 = this.world.doc.get(d7);
    if (!d8 || !vt(d8)) return;
    if (d8.locked) {
      this.say("That is frozen. Unfreeze it on the Builder page first.");
      return;
    }
    let d9 = this.game.camera.position, dd = this.game.camera.forward(), dC = Math.max(1.2, Math.min(Gt, Math.hypot(d8.position[0] - d9[0], d8.position[1] - d9[1], d8.position[2] - d9[2]))), dc = [d9[0] + dd[0] * dC, d9[1] + dd[1] * dC, d9[2] + dd[2] * dC];
    this.grabbed = { id: d7, dist: dC, offset: [0, 1, 2].map((dl) => d8.position[dl] - dc[dl]), sentAt: 0, last: d8.position.slice(), solid: d8.solid !== false }, this.selection.has(d7) || this.select(d7);
  }
  ["_carry"](d7) {
    let d8 = this.grabbed, d9 = this.world.doc.get(d8.id);
    if (!d9) {
      this.grabbed = null;
      return;
    }
    let dd = this.game.camera.position, dC = this.game.camera.forward(), dc = [0, 1, 2].map((dl) => Wi(dd[dl] + dC[dl] * d8.dist + d8.offset[dl], this.grid));
    dc.every((dl, dF) => Math.abs(dl - d8.last[dF]) < 1e-4) || d7 - d8.sentAt < 50 || (d8.sentAt = d7, d8.last = dc, this.world._do({ k: d5.MOVE, o: { ...d9, position: dc.map(nt), solid: d8.solid } }));
  }
  ["_drop"]() {
    if (!this.grabbed) return;
    let d7 = this.grabbed, d8 = this.world.doc.get(d7.id);
    this.grabbed = null, d8 && (this._commit(d5.MOVE, { ...d8, solid: d7.solid }), this.world.sealHistory());
  }
  ["rotate"](d7 = 15, d8 = 1) {
    let d9 = this.grabbed && this.grabbed.id || this.tool !== "create" && this.selected;
    if (d9) {
      let dd = this.world.doc.get(d9);
      if (!dd || dd.locked) return;
      let dC = dd.rotation.slice();
      dC[d8] = ((dC[d8] + d7) % 360 + 360) % 360, this.grabbed ? this.world._do({ k: d5.MOVE, o: { ...dd, rotation: dC } }) : this.change(d9, { rotation: dC });
      return;
    }
    this.turn = ((this.turn + d7) % 360 + 360) % 360;
  }
  ["_skip"]() {
    let d7 = new Set(this.game._cameraSkip ? this.game._cameraSkip() : []);
    for (let d8 of [this.ghost, this.beam, this.dot, this.halo]) d8 && d7.add(d8);
    for (let d9 of this.tools.pens.values()) d7.add(d9);
    if (this.pickups) {
      for (let dd of this.pickups.balls.values()) d7.add(dd.node);
    }
    if (this.grabbed) {
      let dC = this.world.nodes.get(this.grabbed.id);
      dC && d7.add(dC);
    }
    this.stroke && d7.add(this.stroke.preview);
    for (let dc of this._outlines.values()) d7.add(dc.node);
    return d7;
  }
  ["aim"]() {
    let d7 = this.game.camera.position.slice(), d8 = this.game.camera.forward(), d9 = {}, dd = d2(this.game.scene, d7, d8, Gt, this._skip(), d9), dC = null;
    if (dd !== null) {
      let dm = dd + 1e-3;
      for (let [du, dj] of this.world.nodes) {
        if (!du.startsWith($.builtPrefix) || !dj.visible) continue;
        let dW = d2(dj, d7, d8, dm);
        dW !== null && dW <= dm && (dm = dW, dC = du);
      }
    }
    if (!dC && this.tool !== "draw" && this.tool !== "create") {
      let dS = { origin: d7, dir: d8 }, dE = dd === null ? Gt : dd + 1e-3;
      for (let dh of this.world.doc.list()) {
        if (dh.kind !== "stroke" || !vt(dh) || !Array.isArray(dh.points)) continue;
        let dA = this.world.nodes.get(dh.id);
        if (!dA || !dA.visible) continue;
        let dv = dA.worldMatrix(), dZ = (dJ) => [0, 1, 2].map((dO) => dv[dO] * dJ[0] + dv[4 + dO] * dJ[1] + dv[8 + dO] * dJ[2] + dv[12 + dO]), dg = Math.max((dh.width || 0.03) / 2, 0.035), db = dh.points.length === 1 ? [dh.points[0], dh.points[0].map((dJ, dO) => dJ + (dO === 0 ? 1e-3 : 0))] : dh.points;
        for (let dJ = 0; dJ < db.length - 1; dJ++) {
          let dO = r(dS, dZ(db[dJ]), dZ(db[dJ + 1]));
          dO && dO.distance <= dg && dO.depth > 0 && dO.depth < dE && (dE = dO.depth, dC = dh.id);
        }
      }
    }
    let dc = null, dl = null;
    if (this.tool === "paint" && !dC) {
      let dM = (dd === null ? Gt : dd) + 1e-3;
      if (this.pickups) for (let dD of this.pickups.balls.values()) {
        let dG = d2(dD.node, d7, d8, dM);
        dG !== null && dG <= dM && (dM = dG, dl = "balls");
      }
      let dT = this.furniture && this.furniture.basket;
      if (dT) {
        let dR = d2(dT, d7, d8, dM);
        dR !== null && dR <= dM && (dM = dR, dl = "basket");
      }
      for (let dx of this.world.doc.list()) {
        if (!Vi(dx)) continue;
        let df = this.world.nodes.get(dx.id);
        if (!df || !df.visible) continue;
        let dy = d2(df, d7, d8, dM);
        dy !== null && dy <= dM && (dM = dy, dc = dx.id, dl = null);
      }
    }
    let dF = null;
    if (dd !== null && !dC && !dc && !dl) {
      let dN = this.roomObject(), dr = dN && this.world.nodes.get(dN.id), dX = dd + 1e-3;
      for (let da of dr && dr._paintParts || []) {
        let dP = d2(da, d7, d8, dX);
        dP !== null && dP <= dX && (dX = dP, dF = da._paintKey);
      }
    }
    let dk = dd === null ? 4 : dd;
    return { eye: d7, dir: d8, distance: dk, hit: dd !== null, id: dC, part: dF, model: dc, gear: dl, point: [d7[0] + d8[0] * dk, d7[1] + d8[1] * dk, d7[2] + d8[2] * dk], normal: dd !== null && d9.normal ? d9.normal : [-d8[0], -d8[1], -d8[2]] };
  }
  ["_placeFor"](d7) {
    if (!d7) return null;
    let d8 = mt.find((dk) => dk.id === this.shape) || mt[0], d9 = d8.size.map((dk) => nt(Math.min($.maxSize, Math.max($.minSize, dk * this.scaleBy)))), dd = { kind: d8.kind, position: [0, 0, 0], rotation: [0, this.turn, 0], scale: d9 }, dC = Ht(dd) || { min: d9.map((dk) => -dk / 2), max: d9.map((dk) => dk / 2) }, dc = d7.normal, dl = [0, 1, 2].reduce((dk, dm) => Math.abs(dc[dm]) > Math.abs(dc[dk]) ? dm : dk, 0), dF = [0, 0, 0];
    for (let dk = 0; dk < 3; dk++) if (dk === dl && d7.hit) {
      let dm = dc[dk] > 0 ? -dC.min[dk] : dC.max[dk];
      dF[dk] = nt(d7.point[dk] + Math.sign(dc[dk]) * dm);
    } else dF[dk] = nt(Wi(d7.point[dk], this.grid));
    return { position: dF, scale: d9 };
  }
  ["update"]() {
    if (this.active && !this.isMine() && this.toggle(false), this.active && this.game.player.wielding !== d4.builder && (this.active = false, this._drop(), this._showMarks(), this._paintHint()), !this.active) {
      this.gizmo.attach(null), this._drawOutlines();
      return;
    }
    let d7 = performance.now();
    if (this.grabbed && this._carry(d7), this._groupDrag && this._dragGroup(d7), this._aim = this.aim(), this._drawGizmo(), this._drawOutlines(), this._sweep && this._drawSweep(), this.stroke) {
      this._extendStroke();
      let d8 = this.stroke;
      if (d8 && d8.dirty) {
        let d9 = d8.pen.points;
        d8.preview.visible = d9.length > 0, d9.length && (d8.preview.mesh = Y(d9, this.lineWidth / 2, 8)), d8.dirty = false;
      }
    }
    this._drawMarks();
  }
  ["_gizmoTool"]() {
    return this.tool === "move" ? X.MOVE : this.tool === "rotate" ? X.ROTATE : this.tool === "scale" ? X.SCALE : null;
  }
  ["_drawGizmo"]() {
    let d7 = this._gizmoTool(), d8 = this.picked().filter((dC) => !dC.locked);
    if (!d7 || !d8.length || this.grabbed || this.stroke) {
      this.gizmo.attach(null), this._handle = -1;
      return;
    }
    this.gizmo.setTool(d7), this.gizmo.snap = { move: this.grid || 0, rotate: this.turnSnap || 0, scale: 0.05 }, this._groupDrag || (this._proxy = { position: this.pivot(d8), rotation: [0, 0, 0], scale: [1, 1, 1] }, this.gizmo.attach(this._proxy));
    let d9 = this.game.camera, dd = this.game.canvas.clientWidth / Math.max(1, this.game.canvas.clientHeight) || 16 / 9;
    this.gizmo.update(d9, dd), this._handle = this._groupDrag ? this._groupDrag.axis : this.gizmo.pick(d9, 0, 0), this.gizmo.setHover(this._handle);
  }
  ["_beginGroup"](d7) {
    let d8 = this.picked().filter((d9) => !d9.locked);
    return !d8.length || !this.gizmo.begin(this.game.camera, 0, 0, d7) ? false : (this._groupDrag = { axis: d7, tool: this.gizmo.tool, pivot: this._proxy.position.slice(), sentAt: 0, start: d8.map((d9) => ({ id: d9.id, position: d9.position.slice(), rotation: d9.rotation.slice(), scale: d9.scale.slice(), solid: d9.solid !== false, width: d9.width })) }, true);
  }
  ["_dragGroup"](d7) {
    let d8 = this._groupDrag, d9 = this.gizmo.move(this.game.camera, 0, 0);
    if (!d9 || d7 - d8.sentAt < 50) return;
    d8.sentAt = d7;
    let dd = this._groupResult(d8, d9);
    for (let dC of dd) this.world._do({ k: d5.MOVE, o: dC });
  }
  ["_groupResult"](d7, d8) {
    let d9 = [], dd = [[1, 0, 0], [0, 1, 0], [0, 0, 1]][d7.axis];
    for (let dC of d7.start) {
      let dc = this.world.doc.get(dC.id);
      if (!dc) continue;
      let dl = { ...dc, solid: dC.solid };
      if (d7.tool === X.MOVE && d8.position) {
        let dF = d8.position[d7.axis] - d7.pivot[d7.axis];
        dl.position = dC.position.slice(), dl.position[d7.axis] = nt(dC.position[d7.axis] + dF);
      } else {
        if (d7.tool === X.ROTATE && d8.rotation) {
          let dk = d8.rotation[d7.axis], dm = q.setAxisAngle(q.create(), dd, dk * ne), du = [0, 1, 2].map((dS) => dC.position[dS] - d7.pivot[dS]), dj = L.fromRotationTranslationScale(L.create(), dm, [0, 0, 0], [1, 1, 1]), dW = [0, 1, 2].map((dS) => dj[dS] * du[0] + dj[4 + dS] * du[1] + dj[8 + dS] * du[2]);
          dl.position = [0, 1, 2].map((dS) => nt(d7.pivot[dS] + dW[dS])), dl.rotation = ys(q.multiply(q.create(), dm, ji(dC.rotation)));
        } else {
          if (d7.tool === X.SCALE && d8.scale) {
            let dS = Math.max(0.05, d8.scale[d7.axis]);
            if (dc.kind === "stroke") dl.width = nt(Math.min(0.15, Math.max(5e-3, (dC.width || 0.03) * dS)));
            else {
              let dE = ji(dC.rotation), dh = L.fromRotationTranslationScale(L.create(), dE, [0, 0, 0], [1, 1, 1]), dA = 0, dv = -1;
              for (let dZ = 0; dZ < 3; dZ++) {
                let dg = Math.abs(dh[dZ * 4 + d7.axis]);
                dg > dv && (dv = dg, dA = dZ);
              }
              dl.scale = dC.scale.slice(), dl.scale[dA] = nt(Math.sign(dC.scale[dA] || 1) * Math.min($.maxSize, Math.max($.minSize, Math.abs(dC.scale[dA]) * dS)));
            }
            d7.start.length > 1 && (dl.position = dC.position.slice(), dl.position[d7.axis] = nt(d7.pivot[d7.axis] + (dC.position[d7.axis] - d7.pivot[d7.axis]) * dS));
          }
        }
      }
      d9.push(dl);
    }
    return d9;
  }
  ["_endGroup"]() {
    let d7 = this._groupDrag;
    if (!d7) return;
    let d8 = this.gizmo.move(this.game.camera, 0, 0);
    this.gizmo.end(), this._groupDrag = null;
    let d9 = d8 ? this._groupResult(d7, d8) : [];
    for (let dd of d9) this._commit(d5.MOVE, dd);
    if (!d9.length) for (let dC of d7.start) {
      let dc = this.world.doc.get(dC.id);
      dc && this._commit(d5.MOVE, { ...dc, solid: dC.solid });
    }
    this.world.sealHistory();
  }
  ["_drawOutlines"]() {
    let d7 = this.active ? this.selection : /* @__PURE__ */ new Set();
    for (let [d8, d9] of this._outlines) d7.has(d8) || (d9.node.dispose(), this._outlines.delete(d8));
    for (let dd of d7) {
      let dC = this.world.doc.get(dd), dc = dC && Ht(dC);
      if (!dc) continue;
      let dl = this._outlines.get(dd);
      if (!dl) {
        let dS = new p("builder outline");
        dS.material = new Q({ colour: [1, 1, 1], emissive: [1, 1, 1], roughness: 0.5, castShadow: false }), dS.noMirror = true, this.game.scene.add(dS), dl = { node: dS, key: "" }, this._outlines.set(dd, dl);
      }
      let dF = 0.03, dk = dc.min.map((dE) => dE - dF), dm = dc.max.map((dE) => dE + dF), du = [...dk, ...dm].map((dE) => dE.toFixed(3)).join(",");
      du !== dl.key && (dl.node.mesh = ks(dk, dm, 0.02), dl.key = du);
      let dj = dd === this.selected, dW = dC.locked ? [0.55, 0.85, 1] : dj ? [1, 0.86, 0.3] : [0.45, 0.8, 1];
      dl.node.material.colour = dW, dl.node.material.emissive = dW.map((dE) => dE * (dj ? 1.2 : 0.9));
    }
  }
  ["_beginSweep"](d7, d8) {
    let d9 = d7.hit ? d7.point.slice() : [0, 1, 2].map((dd) => d7.eye[dd] + d7.dir[dd] * 6);
    this._sweep = { from: d9, add: d8, moved: false }, typeof document < "u" && (this._sweepBox = this._sweepBox || document.body.appendChild(Object.assign(document.createElement("div"), { className: "bd-sweep" })), this._sweepBox.hidden = true);
  }
  ["_toScreen"](d7) {
    let d8 = this.game.camera.viewProjection, d9 = d8[0] * d7[0] + d8[4] * d7[1] + d8[8] * d7[2] + d8[12], dd = d8[1] * d7[0] + d8[5] * d7[1] + d8[9] * d7[2] + d8[13], dC = d8[3] * d7[0] + d8[7] * d7[1] + d8[11] * d7[2] + d8[15];
    return dC <= 1e-4 ? null : [d9 / dC, dd / dC];
  }
  ["_sweepRect"](d7 = this._sweep) {
    let d8 = this._toScreen(d7.from) || [0, 0];
    return { x0: Math.min(d8[0], 0), x1: Math.max(d8[0], 0), y0: Math.min(d8[1], 0), y1: Math.max(d8[1], 0) };
  }
  ["_drawSweep"]() {
    let d7 = this._sweepRect();
    (d7.x1 - d7.x0 > 0.02 || d7.y1 - d7.y0 > 0.02) && (this._sweep.moved = true);
    let d8 = this._sweepBox;
    if (!d8) return;
    d8.hidden = !this._sweep.moved;
    let d9 = this.game.canvas.clientWidth, dd = this.game.canvas.clientHeight, dC = this.game.canvas.getBoundingClientRect();
    d8.style.left = dC.left + (d7.x0 + 1) / 2 * d9 + "px", d8.style.top = dC.top + (1 - d7.y1) / 2 * dd + "px", d8.style.width = (d7.x1 - d7.x0) / 2 * d9 + "px", d8.style.height = (d7.y1 - d7.y0) / 2 * dd + "px";
  }
  ["_endSweep"]() {
    let d7 = this._sweep;
    if (this._sweep = null, this._sweepBox && (this._sweepBox.hidden = true), !d7) return 0;
    if (!d7.moved) return d7.add || this.select(null), 0;
    let d8 = this._sweepRect(d7);
    d7.add || this.selection.clear();
    let d9 = 0;
    for (let dd of this.built()) {
      let dC = Ht(dd), dc = dC ? [0, 1, 2].map((dF) => (dC.min[dF] + dC.max[dF]) / 2) : dd.position, dl = this._toScreen(dc);
      dl && dl[0] >= d8.x0 && dl[0] <= d8.x1 && dl[1] >= d8.y0 && dl[1] <= d8.y1 && (this.selection.add(dd.id), d9++);
    }
    return this.selected = this.selection.size ? [...this.selection][this.selection.size - 1] : null, this.say(d9 ? "Picked " + d9 + " thing" + (d9 === 1 ? "" : "s") + "." : "Nothing you built was in the box."), this.dispatchEvent(new CustomEvent("change")), d9;
  }
  ["_alongAim"]() {
    let d7 = this.game.camera.position.slice(), d8 = this.game.camera.forward(), d9 = [];
    for (let [dd, dC] of this.world.nodes) {
      if (!dd.startsWith($.builtPrefix) || !dC.visible) continue;
      let dc = d2(dC, d7, d8, Gt);
      dc !== null && d9.push({ id: dd, t: dc });
    }
    return d9.sort((dl, dF) => dl.t - dF.t).map((dl) => dl.id);
  }
  ["_buildMarks"]() {
    let d7 = (d8) => new Q({ colour: this.ink, emissive: this.ink, alpha: d8, roughness: 0.4, castShadow: false });
    this._ghostMat = new Q({ colour: this.ink, alpha: 0.42, roughness: 0.3, castShadow: false }), this.ghost = new p("builder ghost"), this._ghostShape(), this.beam = new p("builder beam"), this.beam.mesh = i(1, 1, 1), this.beam.material = d7(0.55), this.dot = new p("builder dot"), this.dot.mesh = V(0.035, 14, 10), this.dot.material = d7(0.95), this.halo = new p("builder pick"), this.halo.mesh = i(1, 1, 1), this.halo.material = new Q({ colour: [0.4, 0.75, 1], emissive: [0.15, 0.35, 0.8], alpha: 0.2, roughness: 0.5, castShadow: false });
    for (let d8 of [this.ghost, this.beam, this.dot, this.halo]) d8.visible = false, this.game.scene.add(d8);
  }
  ["_ghostShape"]() {
    if (!this.ghost) return;
    let d7 = mt.find((d8) => d8.id === this.shape) || mt[0];
    this.ghost.mesh = d7.kind === "sphere" ? V(0.5, 24, 16) : d7.kind === "cylinder" ? n(0.5, 1, 24) : i(1, 1, 1), this.ghost.material = this._ghostMat;
  }
  ["_marksInk"]() {
    let d7 = this.ink;
    this._ghostMat.colour = d7, this._ghostMat.emissive = oe.find((d8) => d8.id === this.finish)?.glow ? d7.map((d8) => d8 * 0.6) : [0, 0, 0], this.beam.material.colour = d7, this.beam.material.emissive = d7, this.dot.material.colour = d7, this.dot.material.emissive = d7;
  }
  ["_showMarks"]() {
    for (let d7 of [this.ghost, this.beam, this.dot, this.halo]) d7.visible = false;
  }
  ["_drawMarks"]() {
    let d7 = this._aim, d8 = this.tools.pens.get("mine"), d9 = null;
    if (d8 && d8.tipLocal) {
      let dk = d8.worldMatrix(), dm = d8.tipLocal;
      d9 = [0, 1, 2].map((du) => dk[du] * dm[0] + dk[4 + du] * dm[1] + dk[8 + du] * dm[2] + dk[12 + du]);
    }
    let dd = d7.point;
    if (d9 && d7.hit) {
      let du = [dd[0] - d9[0], dd[1] - d9[1], dd[2] - d9[2]], dj = Math.hypot(du[0], du[1], du[2]);
      dj > 0.05 ? (this.beam.visible = true, this.beam.setPosition((d9[0] + dd[0]) / 2, (d9[1] + dd[1]) / 2, (d9[2] + dd[2]) / 2), this.beam.setEuler(Math.asin(Math.max(-1, Math.min(1, du[1] / dj))), Math.atan2(-du[0], -du[2]), 0), this.beam.setScale(6e-3, 6e-3, dj)) : this.beam.visible = false;
    } else this.beam.visible = false;
    if (this.tool === "draw") {
      let dW = this._drawPoint(d7);
      if (this.dot.visible = !!dW, dW && this.dot.setPosition(dW[0], dW[1], dW[2]), dW && d9) {
        let dS = [dW[0] - d9[0], dW[1] - d9[1], dW[2] - d9[2]], dE = Math.hypot(dS[0], dS[1], dS[2]);
        this.beam.visible = dE > 0.05, this.beam.setPosition((d9[0] + dW[0]) / 2, (d9[1] + dW[1]) / 2, (d9[2] + dW[2]) / 2), this.beam.setEuler(Math.asin(Math.max(-1, Math.min(1, dS[1] / (dE || 1)))), Math.atan2(-dS[0], -dS[2]), 0), this.beam.setScale(6e-3, 6e-3, dE);
      }
    } else this.dot.visible = d7.hit, d7.hit && this.dot.setPosition(dd[0], dd[1], dd[2]);
    let dC = this.tool === "create" && !this.grabbed ? this._placeFor(d7) : null;
    if (this.ghost.visible = !!dC && this.count < $.maxBuilt, dC) {
      this.ghost.setPosition(...dC.position), this.ghost.setEuler(0, this.turn * Math.PI / 180, 0), this.ghost.setScale(...dC.scale);
      let dh = Pe({ kind: mt.find((dA) => dA.id === this.shape).kind, id: "b_ghost", position: dC.position, rotation: [0, this.turn, 0], scale: dC.scale, solid: true }, { spawns: this.spawns(), people: this.people() });
      this._ghostMat.alpha = dh.object && !dh.object.solid ? 0.18 : 0.42, this._ghostNote = dh.object && !dh.object.solid ? dh.notes[0] : "";
    } else this._ghostNote = "";
    let dc = this.grabbed ? null : this.tool !== "create" && d7.id && !this.selection.has(d7.id) ? d7.id : null, dl = dc && this.world.doc.get(dc), dF = dl && Ht(dl);
    this.halo.visible = !!dF, dF && (this.halo.setPosition((dF.min[0] + dF.max[0]) / 2, (dF.min[1] + dF.max[1]) / 2, (dF.min[2] + dF.max[2]) / 2), this.halo.setScale(dF.max[0] - dF.min[0] + 0.05, dF.max[1] - dF.min[1] + 0.05, dF.max[2] - dF.min[2] + 0.05), this.halo.material.colour = this.tool === "delete" && !this.grabbed ? [1, 0.3, 0.3] : this.tool === "freeze" ? [0.55, 0.85, 1] : [0.4, 0.75, 1]), this._partNote = this.tool !== "paint" || d7.id ? "" : d7.gear === "balls" ? "Paint the basketballs" : d7.gear === "basket" ? "Paint the ball basket" : d7.model ? "Paint the " + ws(this.world.doc.get(d7.model)) : d7.part ? "Paint the " + d7.part : "", this._paintHint();
  }
  ["_paintHint"]() {
    if (typeof document > "u" || (this.hint || (this.hint = document.createElement("div"), this.hint.className = "bd-hint", this.hint.hidden = true, document.body.appendChild(this.hint)), this.hint.hidden = !this.active, !this.active)) return;
    let d7 = Ut.find((dF) => dF.id === this.tool), d8 = mt.find((dF) => dF.id === this.shape), d9 = this.tool === "create" ? d7.label + " \xB7 " + d8.label : this.tool === "draw" ? d7.label + " \xB7 " + (wt.find((dF) => dF.id === this.drawMode) || wt[0]).label + " \xB7 " + Math.round(this.lineWidth * 1e3) / 10 + " cm" : d7.label, dd = this.grabbed ? "Let go to drop \xB7 Wheel nearer or further \xB7 R turn" : this.stroke ? "Let go to finish the line" : d7.hint, dC = this._ghostNote || this._partNote, dc = dC ? '<div class="bd-note">' + dC + "</div>" : "", dl = '<div class="bd-strip"><span class="bd-swatch" style="background:' + Yi(this.ink) + '"></span><b>' + d9 + '</b><span class="bd-keys">' + dd + '</span><span class="bd-more">Right click next tool \xB7 Q menu \xB7 B put away</span><span class="bd-count">' + this.count + "/" + $.maxBuilt + "</span>" + (this.dirty ? '<span class="bd-unsaved">Unsaved \xB7 Ctrl S</span>' : "") + ("</div>" + dc);
    dl !== this._hintHtml && (this.hint.innerHTML = dl, this._hintHtml = dl);
  }
  ["_badge"]() {
    if (typeof document > "u") return;
    this.badge || (this.badge = document.createElement("button"), this.badge.type = "button", this.badge.className = "bd-badge", this.badge.hidden = true, this.badge.addEventListener("click", () => this.save()), document.body.appendChild(this.badge));
    let d7 = this.isMine() && this.dirty && !this.active;
    this.badge.hidden = !d7, d7 && (this.badge.textContent = this.saveState === "error" ? "Not saved \xB7 click to try again" : "Unsaved build changes \xB7 Save (Ctrl S)");
  }
  ["say"](d7) {
    this.hud && typeof this.hud.say == "function" && this.hud.say(d7, "info"), this.dispatchEvent(new CustomEvent("note", { detail: { text: d7 } }));
  }
  ["_changed"]() {
    if (this.saved && this.saveState !== "saving" && this.saveState !== "discarding") {
      this.checkSaved();
      return;
    }
    this.saveState = "unsaved", this.dispatchEvent(new CustomEvent("change"));
  }
  get ["dirty"]() {
    return this.saveState === "unsaved" || this.saveState === "error";
  }
  ["setSaved"](d7) {
    this._savedObjects = (d7 || []).map((d8) => ({ ...d8 })), this.saved = new Map(this._savedObjects.map((d8) => [d8.id, be(d8)])), this.checkSaved();
  }
  ["checkSaved"]() {
    if (!this.saved || this.saveState === "saving" || this.saveState === "discarding") return this.saveState === "saved";
    let d7 = this.world.doc.list(), d8 = d7.length === this.saved.size && d7.every((dd) => this.saved.get(dd.id) === be(dd)), d9 = d8 ? "saved" : "unsaved";
    return d9 !== this.saveState && (this.saveState = d9, this.dispatchEvent(new CustomEvent("change"))), d8;
  }
  ["sceneNow"]() {
    let d7 = this.world.spawns && this.world.spawns.length ? this.world.spawns : this.base.spawns || [];
    return { ...this.base, spawns: d7, objects: this.world.doc.list() };
  }
  async ["save"]() {
    if (!this.saver || !this.isMine() || this.saveState === "saving" || this.saveState === "discarding") return false;
    let d7 = this.sceneNow();
    this.saveState = "saving", this.dispatchEvent(new CustomEvent("change"));
    let d8 = false;
    try {
      let d9 = await this.saver(d7);
      d8 = !!(d9 && d9.ok), d9 && !d9.ok && d9.message && this.say(d9.message);
    } catch {
      d8 = false;
    }
    return d8 ? (this.saveState = "saved", this.setSaved(d7.objects), this.say("Saved.")) : (this.saveState = "error", this.say("Could not save your dorm. Your changes are still here: try Save again.")), this.dispatchEvent(new CustomEvent("change")), d8;
  }
  async ["discard"]() {
    if (!this.isMine() || !this.saved || this.saveState === "saving" || this.saveState === "discarding") return 0;
    this._drop(), this.stroke && (this.stroke.preview.dispose(), this.stroke = null);
    let d7 = new Map(this._savedObjects.map((dd) => [dd.id, dd])), d8 = [];
    for (let dd of this.world.doc.list()) d7.has(dd.id) || d8.push({ k: d5.REMOVE, id: dd.id });
    for (let [dC, dc] of d7) {
      let dl = this.world.doc.get(dC);
      dl ? be(dl) !== be(dc) && d8.push({ k: d5.MATERIAL, o: { ...dc } }) : d8.push({ k: d5.ADD, o: { ...dc } });
    }
    if (!d8.length) return this.checkSaved(), 0;
    this.saveState = "discarding", this.select(null), this.dispatchEvent(new CustomEvent("change"));
    let d9 = 40;
    for (let dF = 0; dF < d8.length; dF += d9) {
      dF && await new Promise((dk) => setTimeout(dk, 1100));
      for (let dk of d8.slice(dF, dF + d9)) this.world._do(dk);
    }
    return this.world.sealHistory(), this.saveState = "saved", this.checkSaved(), this.say("Changes discarded. Your dorm is as you last saved it."), this.dispatchEvent(new CustomEvent("change")), d8.length;
  }
  ["_bind"]() {
    if (typeof window > "u") return;
    let d7 = this.game.canvas, d8 = () => document.pointerLockElement === d7, d9 = (dd) => dd && (/^(INPUT|TEXTAREA|SELECT)$/.test(dd.tagName) || dd.isContentEditable);
    window.addEventListener("keydown", (dd) => {
      if (!(d9(dd.target) || dd.altKey)) {
        if ((dd.ctrlKey || dd.metaKey) && dd.code === "KeyS" && this.isMine()) {
          dd.preventDefault(), this.save();
          return;
        }
        if ((dd.ctrlKey || dd.metaKey) && this.active) {
          dd.code === "KeyZ" && !dd.shiftKey ? (dd.preventDefault(), this.undo()) : (dd.code === "KeyY" || dd.code === "KeyZ" && dd.shiftKey) && (dd.preventDefault(), this.redo());
          return;
        }
        if (!(dd.ctrlKey || dd.metaKey || dd.repeat)) {
          if (dd.code === "KeyB" && (d8() || this.active)) {
            if (!this.isMine()) {
              this.say("You can build in your own dorm.");
              return;
            }
            this.toggle();
            return;
          }
          if (this.active) {
            if (dd.code === "KeyQ") dd.preventDefault(), this.dispatchEvent(new CustomEvent("menu"));
            else {
              if (dd.code === "KeyR" && this.tool === "draw") {
                let dC = wt.findIndex((dl) => dl.id === this.drawMode), dc = wt[(dC + (dd.shiftKey ? -1 : 1) + wt.length) % wt.length];
                this.setDrawMode(dc.id), this.say("Drawing: " + dc.label + ". " + dc.hint + ".");
              } else dd.code === "KeyR" ? this.rotate(dd.shiftKey ? -15 : 15, 1) : (dd.code === "Delete" || dd.code === "Backspace") && this.removePicked();
            }
          }
        }
      }
    }), d7.addEventListener("mousedown", (dd) => {
      if (!this.active || !d8()) return;
      if (dd.button === 2) {
        let dc = Ut.findIndex((dl) => dl.id === this.tool);
        this.setTool(Ut[(dc + 1) % Ut.length].id);
        return;
      }
      if (dd.button !== 0) return;
      let dC = this._aim || this.aim();
      if (!(this._gizmoTool() && this._handle >= 0 && this._beginGroup(this._handle))) switch (this.tool) {
        case "create":
          this.create(dC);
          break;
        case "draw":
          this.startStroke();
          break;
        case "select":
          dC.id ? this.select(dC.id, { add: dd.shiftKey }) : this._beginSweep(dC, dd.shiftKey);
          break;
        case "move":
        case "rotate":
        case "scale":
          if (!dC.id) {
            dd.shiftKey || this.select(null);
            break;
          }
          if (dd.shiftKey || !this.selection.has(dC.id)) {
            this.select(dC.id, { add: dd.shiftKey });
            break;
          }
          this.tool === "move" ? this._grab(dC.id) : this.tool === "rotate" ? this.turnObject(dC.id, 45, 1) : this.resize(dC.id, 1.25);
          break;
        case "paint": {
          let dl = dd.shiftKey ? null : this.ink;
          dC.id ? dd.shiftKey || this.paint(dC.id) : dC.gear ? this.paintGear(dC.gear, dl) : dC.model ? this.paintModel(dC.model, dl) : dC.part ? this.paintRoom(dC.part, dl) : dC.hit && this.say("The floor and the windows keep their look. Walls, ceiling, trim, accents, furniture, the basket and the balls take paint.");
          break;
        }
        case "copy":
          dC.id && this.copy(dC.id);
          break;
        case "freeze":
          dC.id && this.freeze(dC.id);
          break;
        case "delete":
          dC.id && this.remove(dC.id);
          break;
      }
    }), window.addEventListener("mouseup", (dd) => {
      dd.button === 0 && (this._groupDrag && this._endGroup(), this._sweep && this._endSweep(), this.grabbed && this._drop(), this.stroke && this.finishStroke());
    }), d7.addEventListener("contextmenu", (dd) => {
      this.active && dd.preventDefault();
    }), window.addEventListener("wheel", (dd) => {
      if (!this.active || !d8()) return;
      dd.stopPropagation(), dd.preventDefault();
      let dC = dd.deltaY < 0;
      if (this.grabbed) {
        dd.shiftKey ? this._resizeGrabbed(dC ? 1.1 : 1 / 1.1) : this.grabbed.dist = Math.max(1, Math.min(Gt, this.grabbed.dist + (dC ? 0.25 : -0.25)));
        return;
      }
      let dc = this._aim && this._aim.id;
      if (this.tool === "select") {
        let dF = this._alongAim();
        if (!dF.length) return;
        let dk = dF.indexOf(this.selected), dm = dF[((dk < 0 ? -1 : dk) + (dC ? -1 : 1) + dF.length) % dF.length];
        this.select(dm, { add: false });
        return;
      }
      if (this.tool === "draw") {
        if (dd.shiftKey) {
          let du = dC ? Oe.find((dj) => dj > this.lineWidth + 1e-6) : [...Oe].reverse().find((dj) => dj < this.lineWidth - 1e-6);
          du !== void 0 && this.setLineWidth(du);
        } else this.drawDist = Math.max(0.5, Math.min(6, this.drawDist + (dC ? 0.2 : -0.2)));
        this.dispatchEvent(new CustomEvent("change"));
        return;
      }
      if (this.tool === "rotate" && dc) {
        this.turnObject(dc, dC ? 15 : -15, 1);
        return;
      }
      if (this.tool === "scale" && dc) {
        this.resize(dc, dC ? 1.1 : 1 / 1.1);
        return;
      }
      if (this.tool !== "create") return;
      if (dd.shiftKey) {
        this.scaleBy = Math.max(0.25, Math.min(4, this.scaleBy * (dC ? 1.1 : 1 / 1.1)));
        return;
      }
      let dl = mt.findIndex((dj) => dj.id === this.shape);
      this.setShape(mt[(dl + (dC ? -1 : 1) + mt.length) % mt.length].id);
    }, { capture: true, passive: false }), window.addEventListener("beforeunload", (dd) => {
      !this.isMine() || !this.dirty || this.leaving || (dd.preventDefault(), dd.returnValue = "");
    });
  }
  ["_resizeGrabbed"](d7) {
    let d8 = this.world.doc.get(this.grabbed.id);
    if (!d8) return;
    let d9 = d8.scale.map((dd) => nt(Math.sign(dd || 1) * Math.min($.maxSize, Math.max($.minSize, Math.abs(dd) * d7))));
    this.world._do({ k: d5.MOVE, o: { ...d8, scale: d9 } });
  }
}, g = (d7, d8, d9) => {
  let dd = document.createElement(d7);
  return d8 && (dd.className = d8), d9 !== void 0 && (dd.textContent = d9), dd;
}, xs = { create: '<svg viewBox="0 0 24 24"><path d="M11 4h2v7h7v2h-7v7h-2v-7H4v-2h7z"/></svg>', select: '<svg viewBox="0 0 24 24"><path d="M6 3l12 9-5.2 1 3 6.2-2.4 1.1-3-6.2L6 18z"/></svg>', move: '<svg viewBox="0 0 24 24"><path d="M12 2l3.5 3.5h-2.3V11h5.3V8.7L22 12l-3.5 3.5v-2.3h-5.3v5.3h2.3L12 22l-3.5-3.5h2.3v-5.3H5.5v2.3L2 12l3.5-3.5v2.3h5.3V5.5H8.5z"/></svg>', paint: '<svg viewBox="0 0 24 24"><path d="M19 3a2 2 0 012 2v3a2 2 0 01-2 2h-6v2.2a2 2 0 011 1.8v6a2 2 0 01-4 0v-6a2 2 0 011-1.8V9a1 1 0 011-1h7V5H5v2H3V5a2 2 0 012-2z"/></svg>', copy: '<svg viewBox="0 0 24 24"><path d="M8 3h11a2 2 0 012 2v11h-2V5H8zM3 8a2 2 0 012-2h10a2 2 0 012 2v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/></svg>', delete: '<svg viewBox="0 0 24 24"><path d="M9 3h6l1 2h4v2H4V5h4zm-3 6h12l-1 11a2 2 0 01-2 2H9a2 2 0 01-2-2z"/></svg>', draw: '<svg viewBox="0 0 24 24"><path d="M3 17c3-6 6 2 9-3s4-8 7-6l-1.4 1.4c-1.5-.7-2.4 1-3.9 3.8C12 17 9.7 18.3 7.6 15.6 6.4 14 5.4 15 4.8 18z"/><circle cx="20" cy="5" r="2"/></svg>', rotate: '<svg viewBox="0 0 24 24"><path d="M12 4a8 8 0 017.4 5H22l-3.5 4L15 9h2.2A6 6 0 106 12H4a8 8 0 018-8zm-8 11l3.5-4L11 15H8.8A6 6 0 0018 12h2a8 8 0 01-15.4 3z"/></svg>', scale: '<svg viewBox="0 0 24 24"><path d="M3 3h8v2H6.4l4.3 4.3-1.4 1.4L5 6.4V11H3zm18 18h-8v-2h4.6l-4.3-4.3 1.4-1.4 4.3 4.3V13h2z"/><rect x="13" y="3" width="8" height="8" rx="1.5" opacity=".55"/><rect x="3" y="13" width="8" height="8" rx="1.5" opacity=".55"/></svg>', freeze: '<svg viewBox="0 0 24 24"><path d="M11 2h2v4.2l2.6-2.6 1.4 1.4-4 4V11h2.4l4-4 1.4 1.4-2.6 2.6H22v2h-4.2l2.6 2.6-1.4 1.4-4-4H13v2.4l4 4-1.4 1.4-2.6-2.6V22h-2v-4.2l-2.6 2.6L7 19l4-4V13H8.6l-4 4-1.4-1.4L5.8 13H2v-2h3.8L3.2 8.4 4.6 7l4 4H11V8.6l-4-4L8.4 3.2 11 5.8z"/></svg>' };
function Zi(d7) {
  let d8 = null, d9 = () => {
    d8 && d8.open && d8.page === "build" && d8.show("build");
  };
  return d7.addEventListener("change", () => {
    document.activeElement && document.activeElement.type === "range" || document.querySelector(".cp[data-dragging]") || document.activeElement && document.activeElement.classList.contains("cp-hex") || d9();
  }), { id: "build", label: "Builder", title: "Builder", dock: false, visible: () => d7.isMine(), draw(dd, dC) {
    d8 = dC;
    let dc = d7, dl = g("div", "bd-top"), dF = g("button", "bd-pen" + (dc.active ? " is-on" : ""), dc.active ? "Put the pen away" : "Take out the pen");
    dF.type = "button", dF.addEventListener("click", () => {
      dc.toggle(), dc.active && dC.toggle(false);
    });
    let dk = g("div", "bd-meter"), dm = g("i");
    dm.style.width = Math.min(100, dc.count / $.maxBuilt * 100) + "%";
    let du = g("div", "bd-bar");
    du.appendChild(dm), dk.append(g("span", "", "Built"), du, g("b", "", dc.count + " of " + $.maxBuilt)), dl.append(dF, dk), dd.appendChild(dl);
    let dj = g("div", "bd-saving is-" + dc.saveState), dW = { saved: "All saved", saving: "Saving\u2026", unsaved: "Unsaved changes", error: "Not saved: try again", discarding: "Putting it back\u2026" }[dc.saveState], dS = g("i", "bd-light"), dE = g("span", "bd-savetext", dW), dh = g("button", "wt-chip bd-savebtn" + (dc.dirty ? " is-on" : ""), "Save"), dA = g("button", "wt-chip bd-danger", "Discard changes");
    dh.type = dA.type = "button", dh.disabled = !dc.dirty, dA.disabled = !dc.dirty || !dc.saved, dh.addEventListener("click", () => dc.save()), dA.addEventListener("click", () => {
      if (!dA.dataset.sure) {
        dA.dataset.sure = "1", dA.textContent = "Click again to discard", setTimeout(() => {
          dA.isConnected && (delete dA.dataset.sure, dA.textContent = "Discard changes");
        }, 3500);
        return;
      }
      dc.discard();
    }), dj.append(dS, dE, dh, dA), dd.appendChild(dj), dd.appendChild(g("div", "bd-rules", "Your dorm is only saved when you press Save (or Ctrl S). Leave without saving and it is as you last saved it; Discard puts it back to that now."));
    let dv = g("div", "bd-tools");
    for (let dK of Ut) {
      let dH = g("button", "bd-tool bd-tool-" + dK.id + (dc.tool === dK.id ? " is-on" : ""));
      dH.type = "button", dH.innerHTML = xs[dK.id] + "<span>" + dK.label + "</span>", dH.addEventListener("click", () => {
        dc.setTool(dK.id), dc.active || dc.toggle(true);
      }), dv.appendChild(dH);
    }
    dd.appendChild(dv);
    let dZ = g("div", "wt-field wt-field-wide bd-field"), dg = g("div", "wt-fieldtop");
    dg.append(g("span", "", "Shape"), g("b", "wt-val", "wheel to change"));
    let db = g("div", "wt-chips");
    for (let dQ of mt) {
      let C0 = g("button", "wt-chip" + (dc.shape === dQ.id ? " is-on" : ""), dQ.label);
      C0.type = "button", C0.addEventListener("click", () => {
        dc.setShape(dQ.id), dc.setTool("create");
      }), db.appendChild(C0);
    }
    dZ.append(dg, db), dd.appendChild(dZ);
    let dJ = g("div", "wt-field wt-field-wide bd-field"), dO = g("div", "wt-fieldtop");
    dO.append(g("span", "", "Colour"), g("b", "wt-val", "Paint tool: click anything \xB7 Shift click: back to how it was"));
    let dM = Ii({ value: dc.ink, presets: Gi, onInput: (C1) => dc.setInk(C1, { quiet: true }), onChange: (C1) => dc.setInk(C1) }), dT = g("div", "wt-chips bd-finishes");
    for (let C1 of oe) {
      let C2 = g("button", "wt-chip" + (dc.finish === C1.id ? " is-on" : ""), C1.label);
      C2.type = "button", C2.addEventListener("click", () => dc.setFinish(C1.id)), dT.appendChild(C2);
    }
    let dD = g("button", "wt-chip", "Paint with it");
    dD.type = "button", dD.addEventListener("click", () => {
      dc.setTool("paint"), dc.active || dc.toggle(true), dC.toggle(false);
    }), dT.appendChild(dD), dJ.append(dO, dM, g("div", "cp-label", "Finish (things you build)"), dT), dd.appendChild(dJ);
    let dG = g("div", "wt-field wt-field-wide bd-field"), dR = g("div", "wt-fieldtop"), dx = wt.find((C3) => C3.id === dc.drawMode) || wt[0];
    dR.append(g("span", "", "Drawing"), g("b", "wt-val", dx.hint + " \xB7 R changes it"));
    let df = g("div", "wt-chips");
    for (let C3 of wt) {
      let C4 = g("button", "wt-chip" + (dc.drawMode === C3.id ? " is-on" : ""), C3.label);
      C4.type = "button", C4.title = C3.hint, C4.addEventListener("click", () => {
        dc.setDrawMode(C3.id), dc.setTool("draw");
      }), df.appendChild(C4);
    }
    let dy = (C5) => Math.round(C5 * 1e3) / 10 + " cm", dN = g("div", "wt-fieldtop"), dr = g("b", "wt-val", dy(dc.lineWidth) + " \xB7 " + Math.round(dc.drawDist * 10) / 10 + " m in front");
    dN.append(g("span", "", "Thickness"), dr);
    let dX = document.createElement("input");
    dX.type = "range", dX.min = String(ie * 1e3), dX.max = String(se * 1e3), dX.step = "1", dX.value = String(Math.round(dc.lineWidth * 1e3)), dX.setAttribute("aria-label", "Line thickness"), dX.addEventListener("input", () => {
      dr.textContent = dy(Number(dX.value) / 1e3) + " \xB7 " + Math.round(dc.drawDist * 10) / 10 + " m in front";
    }), dX.addEventListener("change", () => dc.setLineWidth(Number(dX.value) / 1e3));
    let da = g("div", "wt-chips");
    for (let C5 of Oe) {
      let C6 = g("button", "wt-chip" + (Math.abs(dc.lineWidth - C5) < 1e-6 ? " is-on" : ""), dy(C5));
      C6.type = "button", C6.addEventListener("click", () => {
        dc.setLineWidth(C5), dc.setTool("draw");
      }), da.appendChild(C6);
    }
    dG.append(dR, df, dN, dX, da), dd.appendChild(dG);
    let dP = dc.roomObject();
    if (dP) {
      let C7 = g("div", "wt-field wt-field-wide bd-field"), C8 = g("div", "wt-fieldtop");
      C8.append(g("span", "", "Room colours"), g("b", "wt-val", "Paint tool, or here"));
      let C9 = g("div", "bd-parts");
      for (let Cd of Fi) {
        let CC = dP.paint && dP.paint[Cd.id], Cc = g("div", "bd-part"), Cl = g("span", "bd-partsw");
        Cl.style.background = CC ? Yi(CC) : "repeating-linear-gradient(45deg, #8aa1d8 0 6px, #5f79bb 6px 12px)";
        let CF = g("button", "wt-chip", "Use my colour"), Ck = g("button", "wt-chip", "Original");
        CF.type = Ck.type = "button", CF.addEventListener("click", () => dc.paintRoom(Cd.id, dc.ink)), Ck.addEventListener("click", () => dc.paintRoom(Cd.id, null)), Ck.disabled = !CC, Cc.append(Cl, g("b", "", Cd.label), CF, Ck), C9.appendChild(Cc);
      }
      C7.append(C8, C9, g("div", "bd-rules", "The floor, the doors and the windows keep their look.")), dd.appendChild(C7);
    }
    if (dc.selection.size > 1) {
      let Cm = g("div", "wt-field wt-field-wide bd-field"), Cu = g("div", "wt-fieldtop");
      Cu.append(g("span", "", "Picked: " + dc.selection.size + " things"), g("b", "wt-val", "Move, Rotate and Scale handles move them together")), Cm.appendChild(Cu);
      let Cj = g("div", "wt-chips"), CW = (CS, CE, Ch = "") => {
        let CA = g("button", "wt-chip " + Ch, CS);
        CA.type = "button", CA.addEventListener("click", CE), Cj.appendChild(CA);
      };
      CW("Paint them", () => {
        for (let CS of [...dc.selection]) dc.paint(CS);
      }), CW("Freeze them", () => {
        for (let CS of [...dc.selection]) dc.change(CS, { locked: true });
      }), CW("Unfreeze them", () => {
        for (let CS of [...dc.selection]) dc.change(CS, { locked: false });
      }), CW("Pick nothing", () => dc.select(null)), CW("Delete them", () => {
        let CS = dc.removePicked();
        dc.say("Deleted " + CS + ".");
      }, "bd-danger"), Cm.appendChild(Cj), dd.appendChild(Cm);
    }
    let dw = dc.selection.size <= 1 && dc.selected && dc.world.doc.get(dc.selected), dq = g("div", "wt-field wt-field-wide bd-field"), dL = g("div", "wt-fieldtop");
    if (dL.append(g("span", "", dw ? "Picked: " + (dw.name || "thing") : "Picked"), g("b", "wt-val", dw ? "" : "Select a thing with the pen")), dq.appendChild(dL), dw) {
      let CS = g("div", "bd-sizes");
      ["Width", "Height", "Depth"].forEach((CA, Cv) => {
        let CZ = g("div", "bd-size"), Cg = g("button", "wt-chip", "\u2212"), Cb = g("button", "wt-chip", "+");
        Cg.type = Cb.type = "button";
        let CJ = (CO) => {
          let CM = dw.scale.slice();
          CM[Cv] = nt(Math.min($.maxSize, Math.max($.minSize, Math.abs(CM[Cv]) + CO))), dc.change(dw.id, { scale: CM });
        };
        Cg.addEventListener("click", () => CJ(-(dc.grid || 0.1))), Cb.addEventListener("click", () => CJ(dc.grid || 0.1)), CZ.append(g("span", "", CA), Cg, g("b", "", Math.abs(dw.scale[Cv]).toFixed(2) + " m"), Cb), CS.appendChild(CZ);
      }), dq.appendChild(CS);
      let CE = g("div", "wt-chips"), Ch = (CA, Cv, CZ, Cg = "") => {
        let Cb = g("button", "wt-chip" + (Cv ? " is-on" : "") + " " + Cg, CA);
        Cb.type = "button", Cb.addEventListener("click", CZ), CE.appendChild(Cb);
      };
      Ch("Turn left", false, () => dc.change(dw.id, { rotation: [dw.rotation[0], (dw.rotation[1] + 345) % 360, dw.rotation[2]] })), Ch("Turn right", false, () => dc.change(dw.id, { rotation: [dw.rotation[0], (dw.rotation[1] + 15) % 360, dw.rotation[2]] })), Ch("Tip over", false, () => dc.change(dw.id, { rotation: [(dw.rotation[0] + 90) % 360, dw.rotation[1], dw.rotation[2]] })), Ch("Solid", dw.solid !== false, () => dc.change(dw.id, { solid: dw.solid === false })), Ch("See-through", (dw.opacity ?? 1) < 1, () => dc.change(dw.id, { opacity: (dw.opacity ?? 1) < 1 ? 1 : 0.45, ...(dw.opacity ?? 1) < 1 ? {} : { solid: false } })), Ch("Freeze", !!dw.locked, () => dc.change(dw.id, { locked: !dw.locked })), Ch("Paint it", false, () => dc.paint(dw.id)), Ch("Delete", false, () => dc.remove(dw.id), "bd-danger"), dq.appendChild(CE);
    }
    dd.appendChild(dq);
    let dp = g("div", "wt-field wt-field-wide bd-field"), dB = g("div", "wt-fieldtop");
    dB.append(g("span", "", "Grid"), g("b", "wt-val", dc.grid ? dc.grid + " m" : "off"));
    let dV = g("div", "wt-chips");
    for (let CA of Ui) {
      let Cv = g("button", "wt-chip" + (dc.grid === CA ? " is-on" : ""), CA ? CA + " m" : "Off");
      Cv.type = "button", Cv.addEventListener("click", () => dc.setGrid(CA)), dV.appendChild(Cv);
    }
    let dn = g("div", "wt-chips");
    for (let CZ of [0, 5, 15, 45, 90]) {
      let Cg = g("button", "wt-chip" + (dc.turnSnap === CZ ? " is-on" : ""), CZ ? "Turn " + CZ + "\xB0" : "Turn free");
      Cg.type = "button", Cg.addEventListener("click", () => {
        dc.turnSnap = CZ, dc.dispatchEvent(new CustomEvent("change"));
      }), dn.appendChild(Cg);
    }
    let dI = g("div", "wt-chips bd-history"), dz = g("button", "wt-chip", "Undo"), dY = g("button", "wt-chip", "Redo"), dU = g("button", "wt-chip bd-danger", "Clear what I built");
    dz.type = dY.type = dU.type = "button", dz.addEventListener("click", () => dc.undo()), dY.addEventListener("click", () => dc.redo()), dU.addEventListener("click", () => {
      if (dU.dataset.sure) {
        let Cb = dc.clearAll();
        dc.say(Cb ? "Cleared " + Cb + " things you built." : "Nothing built yet.");
        return;
      }
      dU.dataset.sure = "1", dU.textContent = "Click again to clear it all", setTimeout(() => {
        dU.isConnected && (delete dU.dataset.sure, dU.textContent = "Clear what I built");
      }, 3500);
    }), dI.append(dz, dY, dU), dp.append(dB, dV, dn, dI), dd.appendChild(dp), dd.appendChild(g("div", "bd-rules", "Your dorm, your rules, mostly: anything see-through, anything where people arrive, and anything built on top of somebody is never solid, so nobody visiting can be trapped. Only you can build here."));
  } };
}
var Pt = (d7, d8, d9) => {
  let dd = document.createElement(d7);
  return d8 && (dd.className = d8), d9 !== void 0 && (dd.textContent = d9), dd;
}, Ms = [["builds", "Something inappropriate built"], ["drawing", "An offensive drawing or words"], ["trap", "Built to trap or grief visitors"], ["other", "Something else"]];
function qi({ room: d7, canReport: d8 }) {
  return { id: "report", label: "Report", title: "Report this dorm", dock: false, visible: () => d8(), draw(d9, dd) {
    let dC = "builds";
    d9.appendChild(Pt("div", "st-note", "Tell staff what is wrong here. They are told straight away and come and check. The owner is not told who reported it."));
    let dc = Pt("div", "wt-field wt-field-wide"), dl = Pt("div", "wt-fieldtop");
    dl.append(Pt("span", "", "What is wrong"));
    let dF = Pt("div", "wt-chips");
    for (let [dj, dW] of Ms) {
      let dS = Pt("button", "wt-chip" + (dj === dC ? " is-on" : ""), dW);
      dS.type = "button", dS.addEventListener("click", () => {
        dC = dj;
        for (let dE of dF.children) dE.classList.toggle("is-on", dE === dS);
      }), dF.appendChild(dS);
    }
    let dk = Pt("textarea", "rp-details");
    dk.maxLength = 500, dk.rows = 3, dk.placeholder = "Anything that helps staff find it (optional)";
    let dm = Pt("button", "wt-pill rp-send", "Send report");
    dm.type = "button";
    let du = Pt("div", "rp-said");
    dm.addEventListener("click", async () => {
      dm.disabled = true, du.textContent = "Sending\u2026";
      try {
        let dE = await fetch("/api/dorms/report", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ room: d7(), reason: dC, details: dk.value }) }), dh = await dE.json().catch(() => ({}));
        du.textContent = dh.message || (dE.ok ? "Sent." : "Could not send that. Try again in a little while."), dE.ok ? setTimeout(() => {
          dd.open && dd.page === "report" && dd.show("dorms");
        }, 2200) : dm.disabled = false;
      } catch {
        du.textContent = "The site did not answer. Try again in a moment.", dm.disabled = false;
      }
    }), dc.append(dl, dF, dk), d9.append(dc, dm, du);
  } };
}
var ae = 0.62, Yt = 0.3, De = 0.18, Me = 0.022, Ot = Me + Yt, Ct = Me + Yt / 2, Be = De / 2, U = { x0: -0.15, x1: 0.15, y: Ot + 6e-3, z: 0.022 }, It = { x: 0.088, screenY: 0.252, deckY: 0.16, keysY: 0.084 }, Zt = { x0: -It.x, x1: It.x, y0: It.keysY - 0.02, y1: It.screenY + 0.036, z: Be + 0.01 }, Tt = [Math.PI / 2, 0, 0], Ss = 0.188, ke = null;
function Vt(d7, d8, d9) {
  if (typeof document > "u") return null;
  let dd = document.createElement("canvas");
  return dd.width = d7, dd.height = d8, d9(dd.getContext("2d"), d7, d8), dd;
}
var Xi = 11, $t = () => (Xi = Xi * 16807 % 2147483647) / 2147483647;
function Ie(d7, d8, d9) {
  d7.save(), d7.translate(d8, 0), d7.scale(-1, 1), d9(), d7.restore();
}
function _s() {
  if (ke) return ke;
  let d7 = Vt(512, 512, (dF, dk, dm) => {
    let du = dk / 2, dj = dm / 2, dW = dF.createRadialGradient(du - 60, dj - 70, 20, du, dj, dk / 2);
    dW.addColorStop(0, "#6a707b"), dW.addColorStop(0.6, "#454a54"), dW.addColorStop(1, "#2c3037"), dF.fillStyle = dW, dF.beginPath(), dF.arc(du, dj, dk / 2, 0, Math.PI * 2), dF.fill();
    let dS = 7.4;
    for (let dE = 1, dh = 26; dh < dk / 2 - 14; dE++, dh += 19) {
      let dA = Math.floor(Math.PI * 2 * dh / 19);
      for (let dv = 0; dv < dA; dv++) {
        let dZ = dv / dA * Math.PI * 2 + dE % 2 * (Math.PI / dA), dg = du + Math.cos(dZ) * dh, db = dj + Math.sin(dZ) * dh;
        dF.fillStyle = "rgba(255,255,255,0.28)", dF.beginPath(), dF.arc(dg, db - 1.6, dS, 0, Math.PI * 2), dF.fill(), dF.save(), dF.globalCompositeOperation = "destination-out", dF.beginPath(), dF.arc(dg, db, dS, 0, Math.PI * 2), dF.fill(), dF.restore();
      }
    }
    dF.fillStyle = dW, dF.beginPath(), dF.arc(du, dj, 20, 0, Math.PI * 2), dF.fill();
  }), d8 = Vt(256, 64, (dF, dk, dm) => {
    let du = dF.createLinearGradient(0, 0, 0, dm);
    du.addColorStop(0, "#1d2433"), du.addColorStop(1, "#3a4459"), dF.fillStyle = du, dF.fillRect(0, 0, dk, dm);
    for (let dj = 4; dj < dm; dj += 8) dF.fillStyle = "rgba(255,255,255,0.07)", dF.fillRect(0, dj, dk, 2);
  }), d9 = Vt(512, 256, (dF, dk, dm) => {
    dF.fillStyle = "#d9dce2", dF.fillRect(0, 0, dk, dm);
    for (let du = 0; du < 1400; du++) {
      let dj = $t() * dm, dW = 40 + $t() * 260, dS = $t() * dk, dE = 190 + Math.round($t() * 60);
      dF.fillStyle = "rgba(" + dE + "," + (dE + 2) + "," + (dE + 6) + "," + (0.18 + $t() * 0.3) + ")", dF.fillRect(dS, dj, dW, 1);
    }
  }), dd = Vt(256, 256, (dF, dk, dm) => {
    dF.fillStyle = "#f4f4f4", dF.fillRect(0, 0, dk, dm);
    for (let du = 0; du < 9e3; du++) {
      let dj = 214 + Math.round($t() * 41);
      dF.fillStyle = "rgb(" + dj + "," + dj + "," + dj + ")", dF.fillRect($t() * dk, $t() * dm, 1.5, 1.5);
    }
  }), dC = Vt(512, 320, (dF, dk, dm) => {
    dF.fillStyle = "#1c2230", dF.fillRect(0, 0, dk, dm), dF.strokeStyle = "rgba(255,255,255,0.12)", dF.lineWidth = 6, dF.strokeRect(10, 10, dk - 20, dm - 20);
    for (let [du, dj] of [[26, 26], [dk - 26, 26], [26, dm - 26], [dk - 26, dm - 26], [dk / 2, dm - 26]]) dF.fillStyle = "#5b6578", dF.beginPath(), dF.arc(du, dj, 8, 0, Math.PI * 2), dF.fill();
    dF.fillStyle = "#f2ead7", dF.fillRect(40, 34, dk - 80, dm - 120), dF.fillStyle = "#2e6be6", dF.fillRect(40, 34, dk - 80, 26), dF.fillStyle = "#ffd248", dF.fillRect(40, 60, dk - 80, 10), Ie(dF, dk, () => {
      dF.fillStyle = "#ffffff", dF.font = "900 20px system-ui, sans-serif", dF.textBaseline = "middle", dF.fillText("RZ RADIO", 56, 48), dF.textAlign = "right", dF.fillText("C-60", dk - 56, 48), dF.textAlign = "left", dF.fillStyle = "#23305a", dF.font = "800 22px system-ui, sans-serif", dF.fillText("A", 56, 210), dF.textAlign = "right", dF.fillText("RZ MIX", dk - 56, 210);
    }), dF.fillStyle = "#0b0e15", dF.beginPath(), dF.roundRect(118, 96, dk - 236, 94, 40), dF.fill(), dF.fillStyle = "#3b2616", dF.fillRect(150, 178, dk - 300, 6), dF.fillStyle = "#10141d", dF.fillRect(150, dm - 70, dk - 300, 44);
  }), dc = ["back", "play", "forward", "stop"].map((dF) => Vt(64, 48, (dk, dm, du) => {
    dk.fillStyle = "#ffffff", Ie(dk, dm, () => {
      let dj = (dW, dS) => {
        dk.beginPath(), dk.moveTo(dW, 12), dk.lineTo(dW + 14 * dS, 24), dk.lineTo(dW, 36), dk.closePath(), dk.fill();
      };
      dF === "back" && (dj(32, -1), dj(46, -1)), dF === "play" && dj(24, 1), dF === "forward" && (dj(18, 1), dj(32, 1)), dF === "stop" && dk.fillRect(21, 13, 22, 22);
    });
  })), dl = (dF, dk) => Vt(256, 48, (dm, du, dj) => {
    dm.fillStyle = "#0d1630", dm.fillRect(0, 0, du, dj), Ie(dm, du, () => {
      dm.fillStyle = dk, dm.font = "900 30px system-ui, sans-serif", dm.textAlign = "center", dm.textBaseline = "middle", dm.fillText(dF, du / 2, dj / 2 + 1);
    });
  });
  return ke = { grille: d7, cone: d8, brushed: d9, grain: dd, tape: dC, marks: dc, rzBadge: dl("RZ RADIO", "#ffd248"), bassBadge: dl("BASS BOOST", "#8fc3ff") }, ke;
}
var ct = (d7, d8 = {}) => new Q({ colour: d7, roughness: 0.5, ...d8 }), Ne = class {
  constructor() {
    this.lots = /* @__PURE__ */ new Map(), this.place = new p("radio bake");
  }
  ["add"](d7, d8, d9, dd = null, dC = null, dc = null) {
    let dl = this.place;
    dl.position.set([0, 0, 0]), dl.rotation.set([0, 0, 0, 1]), dl.scale.set([1, 1, 1]), dl.setPosition(d9[0], d9[1], d9[2]), dd && dl.setEuler(dd[0], dd[1], dd[2]), dC && dl.setScale(dC[0], dC[1], dC[2]), dl.markDirty();
    let dF = dl.worldMatrix();
    dc && (dF = Es(dc, dF)), this.lots.has(d8) || this.lots.set(d8, []), this.lots.get(d8).push(Ls(d7, dF));
  }
  ["into"](d7) {
    for (let [d8, d9] of this.lots) {
      let dd = new p("radio body");
      dd.mesh = K(d9), dd.material = d8, d7.add(dd);
    }
    this.lots.clear();
  }
};
function Es(d7, d8) {
  let d9 = new Float32Array(16);
  for (let dd = 0; dd < 4; dd++) for (let dC = 0; dC < 4; dC++) d9[dd * 4 + dC] = d7[dC] * d8[dd * 4] + d7[4 + dC] * d8[dd * 4 + 1] + d7[8 + dC] * d8[dd * 4 + 2] + d7[12 + dC] * d8[dd * 4 + 3];
  return d9;
}
function Ls(d7, d8) {
  let d9 = d7.positions, dd = d7.normals, dC = new Float32Array(d9.length), dc = new Float32Array(dd.length), dl = d8[0], dF = d8[1], dk = d8[2], dm = d8[4], du = d8[5], dj = d8[6], dW = d8[8], dS = d8[9], dE = d8[10], dh = du * dE - dj * dS, dA = -(dm * dE - dj * dW), dv = dm * dS - du * dW, dZ = dl * dh + dF * dA + dk * dv || 1, dg = [dh / dZ, (dk * dS - dF * dE) / dZ, (dF * dj - dk * du) / dZ, dA / dZ, (dl * dE - dk * dW) / dZ, (dk * dm - dl * dj) / dZ, dv / dZ, (dF * dW - dl * dS) / dZ, (dl * du - dF * dm) / dZ];
  for (let db = 0; db < d9.length; db += 3) {
    let dJ = d9[db], dO = d9[db + 1], dM = d9[db + 2];
    dC[db] = d8[0] * dJ + d8[4] * dO + d8[8] * dM + d8[12], dC[db + 1] = d8[1] * dJ + d8[5] * dO + d8[9] * dM + d8[13], dC[db + 2] = d8[2] * dJ + d8[6] * dO + d8[10] * dM + d8[14];
    let dT = dd[db], dD = dd[db + 1], dG = dd[db + 2], dR = dg[0] * dT + dg[1] * dD + dg[2] * dG, dx = dg[3] * dT + dg[4] * dD + dg[5] * dG, df = dg[6] * dT + dg[7] * dD + dg[8] * dG, dy = Math.hypot(dR, dx, df) || 1;
    dc[db] = dR / dy, dc[db + 1] = dx / dy, dc[db + 2] = df / dy;
  }
  return { positions: dC, normals: dc, uvs: d7.uvs, indices: d7.indices };
}
function Cs(d7, d8, d9, dd = 48) {
  let dC = [], dc = [], dl = [], dF = [], dk = d7 - d8, dm = Math.hypot(d9, dk) || 1;
  for (let du = 0; du <= dd; du++) {
    let dj = du / dd, dW = dj * Math.PI * 2, dS = Math.cos(dW), dE = Math.sin(dW), dh = [-dS * d9 / dm, -dE * d9 / dm, dk / dm];
    dC.push(dS * d7, dE * d7, d9 / 2), dc.push(...dh), dl.push(dj, 0), dC.push(dS * d8, dE * d8, -d9 / 2), dc.push(...dh), dl.push(dj, 1);
  }
  for (let dA = 0; dA < dd; dA++) {
    let dv = dA * 2;
    dF.push(dv, dv + 2, dv + 1, dv + 2, dv + 3, dv + 1);
  }
  return { positions: new Float32Array(dC), normals: new Float32Array(dc), uvs: new Float32Array(dl), indices: dF };
}
var Rt = (d7, d8, d9, dd = null, dC = null, dc = "radio part") => {
  let dl = new p(dc);
  return dl.mesh = d7, dl.material = d8, dl.setPosition(d9[0], d9[1], d9[2]), dd && dl.setEuler(dd[0], dd[1], dd[2]), dC && dl.setScale(dC[0], dC[1], dC[2]), dl;
};
function xe(d7, d8, d9, dd, dC = "radio screen") {
  let dc = new p(dC);
  dc.setPosition(dd[0], dd[1], dd[2]);
  let dl = new p(dC + " tilt");
  return dl.setEuler(Math.PI / 2, 0, 0), dc.add(dl), dl.add(Rt(B(d8, d9), d7, [0, 0, 0], [0, Math.PI, 0])), dc;
}
function Ji(d7, d8, d9, dd, dC = 6) {
  let dc = [], dl = [[d7 / 2 - d9, d8 / 2 - d9, 0], [-d7 / 2 + d9, d8 / 2 - d9, Math.PI / 2], [-d7 / 2 + d9, -d8 / 2 + d9, Math.PI], [d7 / 2 - d9, -d8 / 2 + d9, Math.PI * 1.5]];
  for (let [dF, dk, dm] of dl) for (let du = 0; du <= dC; du++) {
    let dj = dm + du / dC * (Math.PI / 2);
    dc.push([dF + Math.cos(dj) * d9, dk + Math.sin(dj) * d9, dd]);
  }
  return dc.push(dc[0].slice()), dc;
}
var Se = class {
  constructor() {
    let d7 = _s(), d8 = ct([0.06, 0.25, 0.82], { roughness: 0.62, map: d7.grain }), d9 = ct([0.03, 0.12, 0.42], { roughness: 0.6, map: d7.grain }), dd = ct([0.86, 0.88, 0.92], { roughness: 0.32, metallic: 0.65, map: d7.brushed }), dC = ct([0.86, 0.88, 0.92], { roughness: 0.4, metallic: 0.75, map: d7.grille, alphaCutoff: 0.5, doubleSided: true }), dc = ct([1, 1, 1], { roughness: 0.85, map: d7.cone, doubleSided: true }), dl = ct([0.9, 0.92, 0.95], { roughness: 0.12, metallic: 1 }), dF = ct([0.2, 0.22, 0.26], { roughness: 0.3, metallic: 0.85 }), dk = ct([0.05, 0.055, 0.065], { roughness: 0.92 }), dm = ct([0.02, 0.025, 0.035], { roughness: 0.18 }), du = ct([0.78, 0.8, 0.84], { roughness: 0.55 }), dj = ct([0.16, 0.18, 0.24], { roughness: 0.4, metallic: 0.3 }), dW = new Q({ colour: [1, 1, 1], roughness: 0.45, map: d7.tape }), dS = ct([0.95, 0.95, 0.97], { roughness: 0.35 }), dE = ct([0.24, 0.15, 0.09], { roughness: 0.6 });
    this.glow = ct([0.35, 0.7, 1], { emissive: [0.3, 0.62, 1.15], roughness: 0.3, castShadow: false }), this.slider = U;
    let dh = new p("radio");
    this.root = dh;
    let dA = new Ne(), dv = (dL, dp, dB, dV, dn) => dA.add(dL, dp, dB, dV, dn), dZ = (...dL) => {
      let dp = Rt(...dL);
      return dh.add(dp), dp;
    };
    dv(z(ae, Yt, De, 0.055, 5), d8, [0, Ct, 0]), dv(z(ae + 4e-3, Yt + 4e-3, 0.035, 0.05, 4), d9, [0, Ct, -De / 2 + 0.03]), dv(z(ae - 0.05, Yt - 0.052, 0.016, 0.03, 4), dd, [0, Ct, Be - 3e-3]);
    let dg = Be + 5e-3;
    dv(Y(Ji(ae - 0.05, Yt - 0.052, 0.03, 0), 35e-4, 8), dl, [0, Ct, dg]), this.cones = [];
    for (let dL of [-1, 1]) {
      let dp = dL * Ss, dB = Ct - 0.02;
      dv(I(0.094, 56, 4), dm, [dp, dB, dg + 6e-4], Tt), dv(t(0.081, 85e-4, 56, 12), dk, [dp, dB, dg + 2e-3], Tt), dv(t(0.094, 52e-4, 56, 10), dl, [dp, dB, dg + 6e-3], Tt), dv(I(0.089, 72, 6), dC, [dp, dB, dg + 0.012], Tt), dv(n(0.012, 4e-3, 24), dl, [dp, dB, dg + 0.0135], Tt);
      let dV = new p("radio cone");
      dV.setPosition(dp, dB, dg - 4e-3), dV.add(Rt(Cs(0.075, 0.022, 0.022), dc, [0, 0, 0])), dV.add(Rt(V(0.024, 24, 14), dl, [0, 0, -9e-3], null, [1, 1, 0.5])), dh.add(dV), this.cones.push(dV);
      let dn = dL * 0.25, dI = Ct + 0.09;
      dv(I(0.026, 32, 2), dm, [dn, dI, dg + 1e-3], Tt), dv(t(0.022, 4e-3, 32, 8), dl, [dn, dI, dg + 4e-3], Tt), dv(V(0.015, 20, 12), du, [dn, dI, dg + 2e-3], null, [1, 1, 0.55]);
      for (let dz of [Math.PI / 4, 3 * Math.PI / 4, 5 * Math.PI / 4, 7 * Math.PI / 4]) dv(V(5e-3, 10, 8), dl, [dp + Math.cos(dz) * 0.106, dB + Math.sin(dz) * 0.104, dg + 2e-3], null, [1, 1, 0.5]);
    }
    this.canvas = typeof document < "u" ? document.createElement("canvas") : null, this.canvas && (this.canvas.width = 600, this.canvas.height = 232), this.screen = new Q({ colour: [1.35, 1.35, 1.35], roughness: 0.3, map: this.canvas, castShadow: false }), this.screen.mapVersion = 0;
    let db = It.screenY;
    dv(z(0.168, 0.072, 0.012, 0.01, 3), dm, [0, db, dg + 2e-3]), dh.add(xe(this.screen, 0.152, 0.0588, [0, db, dg + 85e-4]));
    let dJ = new Q({ colour: [0.9, 0.95, 1], alpha: 0.14, roughness: 0.04, metallic: 0.1, castShadow: false });
    dZ(z(0.158, 0.064, 2e-3, 6e-3, 2), dJ, [0, db, dg + 95e-4]);
    let dO = It.deckY;
    dv(z(0.172, 0.096, 6e-3, 0.012, 3), dm, [0, dO, dg + 1e-3]), dv(Y(Ji(0.172, 0.096, 0.012, 0), 26e-4, 6), dl, [0, dO, dg + 55e-4]);
    let dM = 0.142, dT = 0.08875;
    dh.add(xe(dW, dM, dT, [0, dO, dg + 45e-4], "radio tape"));
    let dD = dO + (0.5 - 143 / 320) * dT, dG = (347 / 512 - 0.5) * dM;
    this.reels = [];
    for (let [dY, dU] of [[-1, 0.0128], [1, 92e-4]]) {
      let dK = new p("radio reel");
      dK.setPosition(dY * dG, dD, dg + 52e-4), dK.add(Rt(n(dU, 12e-4, 40), dE, [0, 0, -8e-4], Tt)), dK.add(Rt(n(64e-4, 2e-3, 28), dS, [0, 0, 6e-4], Tt));
      for (let dH = 0; dH < 6; dH++) {
        let dQ = dH / 6 * Math.PI * 2;
        dK.add(Rt(i(16e-4, 3e-3, 22e-4), dm, [Math.cos(dQ) * 39e-4, Math.sin(dQ) * 39e-4, 16e-4], [0, 0, dQ]));
      }
      dh.add(dK), this.reels.push(dK);
    }
    let dR = new Q({ colour: [0.08, 0.1, 0.16], alpha: 0.3, roughness: 0.05, metallic: 0.2, castShadow: false });
    dZ(z(0.162, 0.086, 2e-3, 8e-3, 2), dR, [0, dO, dg + 95e-4]), dZ(z(0.15, 35e-4, 4e-3, 15e-4, 2), this.glow, [0, dO - 0.055, dg + 2e-3]), ["back", "play", "forward", "stop"].forEach((C0, C1) => {
      let C2 = -0.06 + C1 * 0.04;
      dv(z(0.034, 0.02, 0.012, 4e-3, 2), dj, [C2, It.keysY, dg + 4e-3]);
      let C3 = new Q({ colour: [1, 1, 1], emissive: [0.25, 0.25, 0.28], roughness: 0.4, map: d7.marks[C1], castShadow: false });
      dh.add(xe(C3, 0.024, 0.018, [C2, It.keysY, dg + 0.0112], "radio key " + C0));
    }), this.led = dZ(V(42e-4, 12, 8), ct([0.3, 1, 0.5], { emissive: [0.2, 0.9, 0.4] }), [0.262, Ct + 0.05, dg + 4e-3]);
    let dx = [[-0.168, d7.rzBadge], [0.152, d7.bassBadge]];
    for (let [C0, C1] of dx) {
      dv(z(0.106, 0.024, 6e-3, 5e-3, 2), dF, [C0, Ct + 0.09, dg + 2e-3]);
      let C2 = new Q({ colour: [1, 1, 1], emissive: [0.22, 0.22, 0.22], roughness: 0.3, glowMap: true, map: C1, castShadow: false });
      dh.add(xe(C2, 0.098, 0.0184, [C0, Ct + 0.09, dg + 62e-4], "radio badge"));
    }
    for (let C3 of [-1, 1]) for (let C4 = 0; C4 < 5; C4++) dv(z(6e-3, 0.01, 0.1, 4e-3, 2), dm, [C3 * (ae / 2 + 1e-3), Ct - 0.06 + C4 * 0.03, -0.01]);
    this.slot = dZ(z(U.x1 - U.x0 + 0.036, 8e-3, 0.036, 6e-3, 3), dm, [0, Ot + 2e-3, U.z], null, null, "radio slot"), this.fill = dZ(i(1, 4e-3, 0.014), this.glow, [0, U.y, U.z]);
    for (let C5 = 0; C5 <= 10; C5++) {
      let C6 = U.x0 + (U.x1 - U.x0) * (C5 / 10);
      dv(i(28e-4, 3e-3, C5 % 5 === 0 ? 0.016 : 9e-3), dl, [C6, Ot + 2e-3, U.z + 0.03]);
    }
    this.knob = new p("radio knob"), this.knob.add(Rt(z(0.032, 0.026, 0.05, 9e-3, 3), dl, [0, 0.013, 0], null, null, "radio knob part"));
    for (let C7 of [-0.012, 0, 0.012]) this.knob.add(Rt(i(0.026, 3e-3, 3e-3), dF, [0, 0.0265, C7], null, null, "radio knob part"));
    dh.add(this.knob);
    let df = -0.045, dy = 0.215, dN = 0.11, dr = [];
    for (let C8 = 0; C8 <= 28; C8++) {
      let C9 = Math.PI - C8 / 28 * Math.PI, Cd = Math.cos(C9), CC = Math.sin(C9);
      dr.push([dy * Math.sign(Cd) * Math.abs(Cd) ** 0.4, Ot + 0.016 + dN * Math.abs(CC) ** 0.45, df]);
    }
    dv(Y(dr, 0.0145, 14), dk, [0, 0, 0]);
    for (let Cc of [-1, 1]) dv(n(0.024, 0.02, 28), dl, [Cc * dy, Ot + 8e-3, df]), dv(V(0.018, 20, 12), dl, [Cc * dy, Ot + 0.02, df]);
    let dX = 0.268, da = -0.06, dP = -0.36;
    dv(V(0.014, 18, 12), dl, [dX, Ot + 6e-3, da]);
    let dw = [dX, Ot + 0.012, da], dq = [Math.sin(-dP), Math.cos(dP), 0];
    for (let [Cl, CF] of [[6e-3, 0.15], [47e-4, 0.14], [35e-4, 0.13]]) {
      let Ck = dw.map((Cm, Cu) => Cm + dq[Cu] * CF / 2);
      dv(n(Cl, CF, 14), dl, Ck, [0, 0, dP]), dw = dw.map((Cm, Cu) => Cm + dq[Cu] * CF), dv(n(Cl + 12e-4, 6e-3, 14), dF, dw, [0, 0, dP]);
    }
    dv(V(75e-4, 14, 10), dl, dw);
    for (let Cm of [-1, 1]) for (let Cu of [-1, 1]) dv(z(0.07, Me + 0.01, 0.04, 8e-3, 2), dk, [Cm * 0.22, (Me + 0.01) / 2, Cu * 0.055]);
    dA.into(dh), this.grips = [this.knob, this.slot], this._reelAngle = 0, this._reelAt = null, this.setVolume(60), this.show({ title: "", artist: "" });
  }
  ["setVolume"](d7) {
    let d8 = Math.min(100, Math.max(0, d7)) / 100, d9 = U.x0 + (U.x1 - U.x0) * d8;
    this.knob.setPosition(d9, U.y - 4e-3, U.z);
    let dd = Math.max(1e-3, d9 - U.x0);
    this.fill.setPosition(U.x0 + dd / 2, U.y, U.z), this.fill.setScale(dd, 1, 1), this.volume = Math.round(d8 * 100), this._dirty = true;
  }
  ["show"](d7) {
    let d8 = this.now || {};
    this.now = d7 || {}, (d8.title !== this.now.title || d8.artist !== this.now.artist || d8.note !== this.now.note || d8.tag !== this.now.tag) && (this._dirty = true);
  }
  ["draw"](d7, d8 = false, d9 = true) {
    let dd = d8 ? this.volume / 100 : 0, dC = Math.max(0, Math.sin(d7 * 8.6)) ** 3 * 0.7 + Math.max(0, Math.sin(d7 * 4.3 + 1.1)) ** 4 * 0.3;
    for (let dA of this.cones) dA.setScale(1, 1, 1 + dC * dd * 1.4);
    this.led && (this.led.material.emissive = d8 ? [0.2, 0.9, 0.4] : [0.05, 0.2, 0.08]);
    let dc = this._reelAt === null ? 0 : Math.min(0.25, Math.max(0, d7 - this._reelAt));
    if (this._reelAt = d7, d8 && (this._reelAngle -= dc * 2.6), this.reels && (this.reels[0].setEuler(0, 0, this._reelAngle * 0.7), this.reels[1].setEuler(0, 0, this._reelAngle)), !this.canvas || !this._dirty && (!d9 || d7 - (this._drawnAt || 0) < 1 / 15)) return;
    this._dirty = false, this._drawnAt = d7;
    let dl = this.canvas, dF = dl.getContext("2d");
    dF.save(), dF.translate(dl.width, 0), dF.scale(-1, 1);
    let dk = this.now.tag === "ALERT", dm = dk && Math.floor(d7 * 2) % 2 === 0, du = dF.createLinearGradient(0, 0, 0, dl.height);
    dk ? (du.addColorStop(0, dm ? "#6b2cff" : "#3b1ca8"), du.addColorStop(1, "#0d0630")) : (du.addColorStop(0, "#0a2156"), du.addColorStop(1, "#030b22")), dF.fillStyle = du, dF.fillRect(0, 0, dl.width, dl.height), dF.fillStyle = dk ? "rgba(200,160,255,0.08)" : "rgba(80,160,255,0.06)";
    for (let dv = 0; dv < dl.height; dv += 4) dF.fillRect(0, dv, dl.width, 1);
    if (dF.font = "800 24px system-ui, sans-serif", dF.fillStyle = "#ffd248", dF.textBaseline = "top", dF.fillText("RZ RADIO", 24, 16), dF.textAlign = "right", dF.fillStyle = "#8fc3ff", dF.fillText("VOL " + this.volume, dl.width - 24, 16), this.now.tag) {
      let dZ = { LIVE: "#ff4f6a", PICKED: "#3fd28a", LOOP: "#b678ff", PAUSED: "#ffb347", ALERT: "#ffe14a" };
      dF.font = "900 20px system-ui, sans-serif";
      let dg = this.now.tag === "LIVE" ? "\u25CF LIVE" : dk ? "\u2605 RZ ALERT" : this.now.tag, db = dF.measureText(dg).width, dJ = dl.width / 2 - db / 2 - 14;
      dF.fillStyle = dZ[this.now.tag] || "#8fc3ff", dF.globalAlpha = 0.22, dF.fillRect(dJ, 12, db + 28, 30), dF.globalAlpha = 1, dF.strokeStyle = dF.fillStyle, dF.lineWidth = 2, dF.strokeRect(dJ, 12, db + 28, 30), dF.textAlign = "center", dF.fillText(dg, dl.width / 2, 18);
    }
    dF.textAlign = "left";
    let dj = this.now.title || this.now.note || "No songs yet";
    dF.font = "900 54px system-ui, sans-serif", dF.fillStyle = "#ffffff";
    let dW = dF.measureText(dj).width, dS = dl.width - 48, dE = 24;
    if (dW > dS) {
      let dO = dW - dS, dM = 2 + dO / 60 + 2, dT = d7 % (dM * 2) / dM, dD = dT < 1 ? Math.min(1, Math.max(0, (dT * dM - 2) / (dO / 60))) : Math.min(1, Math.max(0, 1 - ((dT - 1) * dM - 2) / (dO / 60)));
      dE = 24 - dO * dD;
    }
    dF.save(), dF.beginPath(), dF.rect(24, 48, dS, 68), dF.clip(), dF.shadowColor = dk ? "rgba(255,60,60,0.9)" : "rgba(90,170,255,0.9)", dF.shadowBlur = 14, dF.fillText(dj, dE, 52), dF.restore(), dF.font = "700 28px system-ui, sans-serif", dF.fillStyle = dk ? "#ffc2c2" : "#9fc6ff", dF.fillText(this.now.artist || (this.now.title ? "" : "An EDR adds music on the website"), 24, 118, dS);
    let dh = 30;
    for (let dG = 0; dG < dh; dG++) {
      let dR = d8 ? 8 + 30 * Math.abs(Math.sin(d7 * (2.1 + dG % 5 * 0.37) + dG * 1.3)) * (0.4 + this.volume / 170) : 4;
      dF.fillStyle = dG / dh < this.volume / 100 ? "#3f8cff" : "#1b3566", dF.fillRect(24 + dG * 18.4, dl.height - 18 - dR, 12, dR);
    }
    dF.restore(), this.screen.mapVersion = (this.screen.mapVersion || 0) + 1;
  }
}, As = 3.2;
function zs(d7) {
  let d8 = [1 / 0, 1 / 0, 1 / 0], d9 = [-1 / 0, -1 / 0, -1 / 0];
  for (let dd of d7.allNodes()) {
    if (!dd.mesh || !dd.mesh.positions) continue;
    let dC = dd.worldMatrix(), dc = dd.mesh.positions;
    for (let dl = 0; dl < dc.length; dl += 3) for (let dF = 0; dF < 3; dF++) {
      let dk = dC[dF] * dc[dl] + dC[4 + dF] * dc[dl + 1] + dC[8 + dF] * dc[dl + 2] + dC[12 + dF];
      dk < d8[dF] && (d8[dF] = dk), dk > d9[dF] && (d9[dF] = dk);
    }
  }
  return Number.isFinite(d8[0]) ? { min: d8, max: d9 } : null;
}
function Qi({ game: d7, world: d8, library: d9, builder: dd = null, openPlayer: dC = null }) {
  let dc = new Se();
  dc.root.visible = false, d7.scene.add(dc.root);
  let dl = new S({ game: d7, library: d9, model: dc }), dF = "";
  function dk() {
    let db = d8.doc.list(), dJ = db.find((dG) => dG.tag === "radio"), dO = db.find((dG) => /#table$/.test(dG.src || "")), dM = dJ ? "tag:" + dJ.position : dO ? "table:" + dO.position + "|" + dO.scale : "";
    if (!dM) {
      dc.root.visible = false, dl.setOn(false), dF = "";
      return;
    }
    if (dM === dF) return;
    let dT, dD;
    if (dJ) {
      let dG = d8.nodes.get(dJ.id);
      dG && (dG.visible = false), dT = dJ.position.slice(), dD = (dJ.rotation[1] || 0) * Math.PI / 180;
    } else {
      let dR = d8.nodes.get(dO.id), dx = dR && zs(dR);
      if (!dx) return;
      let df = (dx.min[0] + dx.max[0]) / 2, dy = (dx.min[2] + dx.max[2]) / 2, dN = [df, dx.max[1] + 0.5, dy], dr = d2(dR, dN, [0, -1, 0], 3);
      dT = [df, dr === null ? dx.max[1] : dN[1] - dr, dy];
      let dX = Math.atan2(-df, -dy);
      dD = Math.round(dX / (Math.PI / 2)) * (Math.PI / 2);
    }
    dc.root.setPosition(dT[0], dT[1], dT[2]), dc.root.setEuler(0, dD, 0), dc.root.visible = true, dl.setOn(true), dF = dM;
  }
  d8.doc.addEventListener("reset", () => {
    dF = "", setTimeout(dk, 0);
  }), d8.doc.addEventListener("changed", () => setTimeout(dk, 0));
  let dm = d7.canvas, du = () => document.pointerLockElement === dm, dj = false, dW = false, dS = false, dE = false, dh = document.createElement("div");
  dh.className = "radio-hint", dh.hidden = true, document.body.appendChild(dh);
  let dA = () => ({ eye: d7.camera.position, dir: d7.camera.forward() });
  function dv() {
    if (!dc.root.visible) return { grip: false, radio: false, screen: false };
    let { eye: db, dir: dJ } = dA(), dO = d2(dc.root, db, dJ, As);
    if (dO === null) return { grip: false, radio: false, screen: false };
    let dM = false;
    for (let dT of dc.grips) d2(dT, db, dJ, dO + 0.05) !== null && (dM = true);
    return { grip: dM, radio: true, screen: !dM && !!dC && dZ(dO) };
  }
  function dZ(db) {
    let dJ = dc.root.worldMatrix(), { eye: dO, dir: dM } = dA(), dT = [dO[0] - dJ[12], dO[1] - dJ[13], dO[2] - dJ[14]], dD = (dN) => [0, 1, 2].map((dr) => dJ[4 * dr] * dN[0] + dJ[4 * dr + 1] * dN[1] + dJ[4 * dr + 2] * dN[2]), dG = dD(dT), dR = dD(dM);
    if (dR[2] >= -1e-4) return false;
    let dx = (Zt.z - dG[2]) / dR[2];
    if (dx < 0 || dx > db + 0.03) return false;
    let df = dG[0] + dR[0] * dx, dy = dG[1] + dR[1] * dx;
    return df >= Zt.x0 && df <= Zt.x1 && dy >= Zt.y0 && dy <= Zt.y1;
  }
  function dg() {
    let db = dc.root.worldMatrix(), dJ = (dw) => [0, 1, 2].map((dq) => db[dq] * dw[0] + db[4 + dq] * dw[1] + db[8 + dq] * dw[2] + db[12 + dq]), dO = dJ([U.x0, U.y, U.z]), dM = dJ([U.x1, U.y, U.z]), { eye: dT, dir: dD } = dA(), dG = [dM[0] - dO[0], dM[1] - dO[1], dM[2] - dO[2]], dR = [dO[0] - dT[0], dO[1] - dT[1], dO[2] - dT[2]], dx = (dw, dq) => dw[0] * dq[0] + dw[1] * dq[1] + dw[2] * dq[2], df = dx(dG, dG), dy = dx(dG, dD), dN = dx(dD, dD), dr = dx(dG, dR), dX = dx(dD, dR), da = df * dN - dy * dy, dP = da > 1e-9 ? (dy * dX - dN * dr) / da : 0;
    return Math.min(1, Math.max(0, dP));
  }
  return dm.addEventListener("mousedown", (db) => {
    if (!(db.button !== 0 || !du() || !(dj || dS)) && !(dd && dd.active) && !(d7.wielding && d7.wielding())) {
      if (dS && !dj) {
        dC();
        return;
      }
      if (dl.readOnly || dl.locked) {
        dl.setVolume(dl.volume + 1);
        return;
      }
      dE = true, dl.setVolume(dg() * 100);
    }
  }), window.addEventListener("mouseup", (db) => {
    db.button !== 0 || !dE || (dl.setVolume(dg() * 100), dE = false);
  }), window.addEventListener("wheel", (db) => {
    !dW || !du() || dd && dd.active || dl.readOnly || dl.locked || (db.stopPropagation(), db.preventDefault(), dl.setVolume(dl.volume + (db.deltaY < 0 ? 5 : -5)));
  }, { capture: true, passive: false }), d7.addUpdater(() => {
    dF || dk();
    let db = performance.now() / 1e3;
    dl.update(db);
    let dJ = du() && !dE ? dv() : { grip: dE, radio: dE, screen: false };
    dj = dJ.grip, dW = dJ.radio, dS = dJ.screen, dE && dl.setVolume(dg() * 100);
    let dO = dl.readOnly ? (dl.owner || "The owner") + "'s radio" : "", dM = dl.locked && (dj || dW || dS) ? "RecZone Alert \xB7 the radio is locked" : dE ? "Volume " + dl.volume : dj ? dO ? dO + " \xB7 Volume " + dl.volume : "Hold click and slide \xB7 Volume " + dl.volume : dS ? "Click the screen to open the radio" : dW ? dO ? dO + " \xB7 Volume " + dl.volume : "Scroll for volume \xB7 " + dl.volume : "";
    dh.hidden = !dM, dM && dh.textContent !== dM && (dh.textContent = dM);
  }), { model: dc, player: dl, place: dk };
}
var E = (d7, d8, d9) => {
  let dd = document.createElement(d7);
  return d8 && (dd.className = d8), d9 !== void 0 && (dd.textContent = d9), dd;
}, He = (d7) => (d7 = Math.max(0, Math.floor(d7 || 0)), Math.floor(d7 / 60) + ":" + String(d7 % 60).padStart(2, "0")), qt = { prev: '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="3" y="4" width="2.4" height="12" rx="0.8"/><path d="M16.2 4.9v10.2c0 .7-.8 1.1-1.4.7L7.4 10.7a.85.85 0 0 1 0-1.4l7.4-5.1c.6-.4 1.4 0 1.4.7z"/></svg>', next: '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="14.6" y="4" width="2.4" height="12" rx="0.8"/><path d="M3.8 4.9v10.2c0 .7.8 1.1 1.4.7l7.4-5.1a.85.85 0 0 0 0-1.4L5.2 4.2c-.6-.4-1.4 0-1.4.7z"/></svg>', play: '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6 4.3v11.4c0 .8.9 1.3 1.5.8l8.6-5.7a.95.95 0 0 0 0-1.6L7.5 3.5C6.9 3 6 3.5 6 4.3z"/></svg>', pause: '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="5" y="4" width="3.6" height="12" rx="1"/><rect x="11.4" y="4" width="3.6" height="12" rx="1"/></svg>', loop: '<svg viewBox="0 0 20 20" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9V8a3 3 0 0 1 3-3h8"/><path d="M12.5 2.6 15 5l-2.5 2.4"/><path d="M16 11v1a3 3 0 0 1-3 3H5"/><path d="M7.5 17.4 5 15l2.5-2.4"/></svg>' };
function Ps() {
  let d7 = E("div", "rd-tape");
  return d7.innerHTML = '\n    <svg viewBox="0 0 120 76" aria-hidden="true">\n      <rect x="3" y="3" width="114" height="70" rx="7" class="rd-tape-shell"/>\n      <rect x="14" y="10" width="92" height="22" rx="3" class="rd-tape-label"/>\n      <rect x="14" y="10" width="92" height="5" class="rd-tape-stripe"/>\n      <rect x="30" y="36" width="60" height="20" rx="10" class="rd-tape-window"/>\n      <g class="rd-reel rd-reel-l" transform="translate(42 46)"><circle r="8.5" class="rd-reel-hub"/><path d="M0-8.5v4M7.4 4.3l-3.5-2M-7.4 4.3l3.5-2" class="rd-reel-teeth"/></g>\n      <g class="rd-reel rd-reel-r" transform="translate(78 46)"><circle r="8.5" class="rd-reel-hub"/><path d="M0-8.5v4M7.4 4.3l-3.5-2M-7.4 4.3l3.5-2" class="rd-reel-teeth"/></g>\n      <path d="M26 73l6-9h56l6 9" class="rd-tape-foot"/>\n    </svg>', d7;
}
function Ts(d7) {
  let d8 = E("div", "rd-takeover"), d9 = E("div", "rd-tohead");
  d9.append(E("b", "", "RecZone Alert"), E("span", "rd-toedr", "EDR"));
  let dd = E("div", "rd-tofrom", "Sent as the RecZone Management Team"), dC = E("div", "rd-tolive");
  dC.hidden = true;
  let dc = E("span"), dl = E("button", "wt-pill rd-toend", "End it now");
  dl.type = "button", dC.append(E("i"), dc, dl);
  let dF = E("select", "rd-toin");
  dF.setAttribute("aria-label", "Type of alert");
  let dk = E("select", "rd-toin");
  dk.setAttribute("aria-label", "Clip"), dk.appendChild(new Option("No clip, the alert and the message only", ""));
  let dm = E("input", "rd-toin");
  dm.type = "text", dm.maxLength = 160, dm.placeholder = "Message on everybody's screen";
  let du = E("select", "rd-toin");
  du.append(new Option("Every dorm radio", "radios"), new Option("Everybody in the game (announcement)", "everyone"));
  let dj = E("div", "rd-volume rd-tovol"), dW = E("input", "rd-range");
  dW.type = "range", dW.min = "5", dW.max = "100", dW.step = "1", dW.value = "80", dW.setAttribute("aria-label", "Takeover volume");
  let dS = E("span", "rd-volval", "80"), dE = () => {
    dS.textContent = dW.value, dW.style.setProperty("--fill", dW.value + "%");
  };
  dW.addEventListener("input", dE), dE(), dj.append(E("span", "rd-vollabel", "VOL"), dW, dS);
  let dh = E("button", "rd-togo", "Take over now");
  dh.type = "button";
  let dA = E("div", "rd-tosaid");
  d8.append(d9, dd, dC, dF, dk, dm, du, dj, dh, dA);
  let dv = (dg) => {
    dC.hidden = !dg, dg && (dc.textContent = "On now: " + (dg.label || "Alert") + " \xB7 " + (dg.clip ? dg.clip.title : "the alert") + (dg.message ? ' \xB7 "' + dg.message + '"' : "") + " \xB7 " + (dg.scope === "everyone" ? "everybody" : "every radio") + " \xB7 volume " + dg.volume);
  };
  d7.clips().then((dg) => {
    if (!dg) {
      dA.textContent = "Could not get the music library.";
      return;
    }
    for (let [db, dJ] of Object.entries(dg.kinds || { announcement: "Announcement" })) dF.appendChild(new Option(dJ, db));
    for (let dO of dg.clips) dk.appendChild(new Option("" + dO.title + (dO.kind === "clip" ? " (voice line)" : ""), String(dO.id)));
    dv(dg.takeover);
  }).catch(() => {
    dA.textContent = "Could not get the music library.";
  });
  let dZ = (dg) => dv(dg.detail);
  return d7.addEventListener("takeover", dZ), dh.addEventListener("click", async () => {
    dh.disabled = true, dA.textContent = "";
    let dg = await d7.startTakeover({ kind: dF.value, clipId: dk.value, message: dm.value, volume: Number(dW.value), scope: du.value }).catch(() => ({ ok: false, message: "The website did not answer." }));
    dh.disabled = false, dA.textContent = dg.ok ? "Taking over in three seconds." : dg.message || "That did not work.", dg.ok && dv(dg.takeover);
  }), dl.addEventListener("click", async () => {
    await d7.stopTakeover(), dv(null), dA.textContent = "Ended. The radios are back.";
  }), { node: d8, off: () => d7.removeEventListener("takeover", dZ) };
}
function ts(d7, { sync: d8 = null, edr: d9 = false } = {}) {
  let dd = 0, dC = [];
  return { id: "radio", label: "Radio", title: "RZ Radio", dock: false, visible: () => !!d7 && d7.model.root.visible, leave() {
    clearInterval(dd);
    for (let dc of dC) dc();
    dC = [];
  }, draw(dc) {
    let dl = d7.player, dF = (dY, dU) => {
      dl.addEventListener(dY, dU), dC.push(() => dl.removeEventListener(dY, dU));
    }, dk = E("div", "rd-deck"), dm = Ps(), du = E("div", "rd-lcd"), dj = E("div", "rd-lcdtop"), dW = E("span", "rd-brand", "RZ RADIO"), dS = E("span", "rd-lamps"), dE = (dY) => {
      let dU = E("span", "rd-lamp", dY);
      return dS.appendChild(dU), dU;
    }, dh = dE("LIVE"), dA = dE("LOOP"), dv = dE("PAUSE");
    dj.append(dW, dS);
    let dZ = E("div", "rd-title"), dg = E("div", "rd-artist"), db = E("div", "rd-meter"), dJ = [];
    for (let dY = 0; dY < 32; dY++) dJ.push(db.appendChild(E("i")));
    let dO = E("div", "rd-times"), dM = E("span"), dT = E("span");
    dO.append(dM, dT), du.append(dj, dZ, dg, db, dO), dk.append(dm, du);
    let dD = E("div", "rd-keys"), dG = (dU, dK, dH, dQ) => {
      let C0 = E("button", "rd-key " + dU);
      return C0.type = "button", C0.innerHTML = '<span class="rd-keycap">' + dK + "</span>", C0.setAttribute("aria-label", dH), C0.title = dH, C0.addEventListener("click", dQ), dD.appendChild(C0), C0;
    }, dR = dG("rd-prev", qt.prev, "The one before", () => dl.previous()), dx = dG("rd-play", qt.pause, "Pause", () => dl.togglePause()), df = dG("rd-next", qt.next, "Next song", () => dl.next()), dy = dG("rd-loop", qt.loop, "Loop this song", () => dl.setLoop(!dl.loop)), dN = dG("rd-live", "<b>LIVE</b>", "Back to the live radio, the same as everybody", () => dl.goLive()), dr = E("div", "rd-volume"), dX = E("span", "rd-vollabel", "VOL"), da = E("input", "rd-range");
    da.type = "range", da.min = "0", da.max = "100", da.step = "1", da.setAttribute("aria-label", "Volume"), da.addEventListener("input", () => dl.setVolume(Number(da.value)));
    let dP = E("span", "rd-volval");
    dr.append(dX, da, dP);
    let dw = E("div", "rd-card"), dq = E("div", "rd-cardhead");
    dq.append(E("b", "", "RZ Radio"), E("span", "rd-cardcount"));
    let dL = E("ol", "rd-list");
    dw.append(dq, dL);
    let dp = E("div", "rd-note");
    if (dp.hidden = true, dc.append(dp, dk, dD, dr, dw), d9 && d8) {
      let dU = Ts(d8);
      dc.appendChild(dU.node), dC.push(dU.off);
    }
    let dB = "";
    function dV() {
      let dK = dl.songs(), dH = dK.map((C0) => C0.url).join("|");
      dH !== dB && (dB = dH, dL.textContent = "", dq.querySelector(".rd-cardcount").textContent = dK.length ? dK.length + " " + (dK.length === 1 ? "song" : "songs") : "", dK.length || dL.appendChild(E("li", "rd-empty", "No songs yet")), dK.forEach((C0, C1) => {
        let C2 = E("li"), C3 = E("button", "rd-song");
        C3.type = "button", C3.disabled = dl.readOnly || !!dl.locked, C3.dataset.i = String(C1);
        let C4 = C1 < 6 ? "A" : C1 < 12 ? "B" : "";
        C3.append(E("span", "rd-num", C4 ? "" + C4 + (C1 % 6 + 1) : String(C1 + 1)), E("span", "rd-name", C0.title), E("span", "rd-by", C0.artist || ""), E("span", "rd-len", He(C0.duration))), C3.addEventListener("click", () => dl.pick(C1)), C2.appendChild(C3), dL.appendChild(C2);
      }));
      let dQ = dl.song();
      for (let C0 of dL.querySelectorAll(".rd-song")) {
        let C1 = dK[Number(C0.dataset.i)];
        C0.classList.toggle("is-on", !!dQ && !!C1 && C1.url === dQ.url);
      }
    }
    function dn() {
      let dK = dl.song();
      dZ.textContent = dK ? dK.title : "No songs yet", dg.textContent = dK && dK.artist || "";
      let dH = dl.playing && !dl.paused;
      dm.classList.toggle("is-turning", dH), dh.classList.toggle("is-on", !!dK && dl.mode === "live" && !dl.paused), dA.classList.toggle("is-on", !!dK && dl.loop), dv.classList.toggle("is-on", !!dK && dl.paused), dx.querySelector(".rd-keycap").innerHTML = dl.paused ? qt.play : qt.pause, dx.setAttribute("aria-label", dl.paused ? "Play" : "Pause"), dx.title = dl.paused ? "Play" : "Pause", dx.classList.toggle("is-down", !dl.paused && !!dK), dy.classList.toggle("is-down", dl.loop), dN.classList.toggle("is-down", dl.mode === "live" && !dl.paused);
      let dQ = dl.readOnly || !!dl.locked;
      for (let C0 of [dR, dx, df, dy, dN]) C0.disabled = !dK || dQ;
      da.disabled = dQ;
      for (let C1 of dL.querySelectorAll(".rd-song")) C1.disabled = dQ;
      dp.hidden = !dQ, dp.classList.toggle("is-alert", !!dl.locked), dp.textContent = dl.locked ? "RecZone Alert. The radio is locked until it ends." : dl.readOnly ? "This is " + (dl.owner || "the owner") + "'s radio. You hear what they play, at their volume." : "", dV();
    }
    function dI() {
      da.value = String(dl.volume), dP.textContent = String(dl.volume), da.style.setProperty("--fill", dl.volume + "%");
    }
    function dz() {
      let dK = dl.progress();
      dM.textContent = He(dK.at), dT.textContent = He(dK.length);
      let dH = dK.length ? Math.round(dK.at / dK.length * dJ.length) : 0;
      dJ.forEach((dQ, C0) => dQ.classList.toggle("is-lit", C0 < dH)), dn();
    }
    dF("changed", dn), dF("song", dn), dF("volume", dI), dn(), dI(), dz(), clearInterval(dd), dd = setInterval(dz, 250);
  } };
}
O(M);
var ut = globalThis.RZ || {}, ns = document.getElementById("view");
d1(new URL(".", import.meta.url).pathname);
var Qt = { el: document.getElementById("boot"), bar: document.getElementById("bootBar"), what: document.getElementById("bootWhat"), step(d7, d8) {
  this.bar && (this.bar.style.width = d7 + "%"), d8 && this.what && (this.what.textContent = d8);
}, done() {
  this.step(100, "ready"), setTimeout(() => this.el && this.el.classList.add("gone"), 240), setTimeout(() => this.el && this.el.remove(), 760);
} };
Qt.step(14, "starting the engine");
var H = new d3(ns, { sky: "golden", fov: 60, gpu: await d0() });
H.showHands(), Qt.step(30, "getting ready");
var Xt = ut.room || "LOBBY", _e = ut.roomName || "a dorm";
Qt.step(48, "knocking");
var W = new R({ url: J(ut), name: ut.me && ut.me.name || "Guest", room: Xt, ticket: ut.relayUrl ? e(() => W.room) : async () => {
  let d7 = await fetch("/api/dorms/ticket", { method: "POST", credentials: "same-origin", headers: { Accept: "application/json" } });
  return d7.ok && (await d7.json()).ticket || null;
} }), at = new P(H, { net: W });
at.groundPlane = false, W.source(() => H.player.snapshot()), W.addEventListener("state", (d7) => H.applySnapshot(d7.detail.id, d7.detail.state, d7.detail.time)), W.addEventListener("left", (d7) => H.removeRemote(d7.detail.id)), W.connect();
var Ee = [];
function te() {
  let d7 = Ee.filter((dl) => /spawn/i.test(dl.name) && !/drag/i.test(dl.name)), d8 = d7.length ? d7 : Ee;
  if (!d8.length) return H.spawn(0, 1, 6);
  let d9 = d8[Math.floor(Math.random() * d8.length)].position, dd = [d9[0], d9[1] + 0.5, d9[2]], dC = H.collision.raycast(dd, [0, -1, 0], 6), dc = dC ? dd[1] - dC.distance + 0.02 : d9[1] + 0.2;
  return Ve = [d9[0], dc, d9[2]], H.spawn(d9[0], dc, d9[2]);
}
var Ve = null;
function je(d7, d8) {
  if (!(!d7 || d7 === Xt) && !(ot.isMine() && ot.dirty && !confirm("You have building changes you have not saved. Leave without saving them?"))) {
    Xt = d7, _e = d8 || "a dorm", Ce("Going to " + _e), ot.toggle(false), ot.saved = null, ot.saveState = "saved", ot.base = {};
    for (let d9 of [...H.remotes.keys()]) H.removeRemote(d9);
    at.doc.replaceAll([]), Ee = [], W.room = d7, W.disconnect(), setTimeout(() => W.connect(), 120), os(d7), ht.room = d7, rt.redraw();
  }
}
function jt() {
  return !!(ut.me && W.room === "DORM-" + ut.me.id);
}
async function os(d7) {
  try {
    let d8 = await fetch("/api/dorms/scene/" + encodeURIComponent(d7), { credentials: "same-origin", headers: { Accept: "application/json" } });
    if (!d8.ok) return;
    let { scene: d9 } = await d8.json();
    if (d9 && jt()) {
      let { objects: dC, ...dc } = d9;
      ot.base = dc, ot.setSaved(dC || []);
    }
    let dd = d9 && Array.isArray(d9.spawns) && d9.spawns.length ? d9.spawns : null;
    dd && (Ee = dd, at.spawns = dd), d9 && Array.isArray(d9.objects) && d9.objects.length && at.doc.size === 0 && (at.doc.replaceAll(d9.objects), dd && te(), jt() && W.connected && W.sendScene(at.doc.list(), at.spawns));
  } catch {
  }
}
var ht = null, as = null, re = new y({ game: H, net: W, respawn: () => te() }), ot = new ye({ game: H, world: at, net: W, tools: re, isMine: jt, save: async (d7) => {
  let d8 = await fetch("/api/dorms/scene", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ scene: d7 }) }), d9 = await d8.json().catch(() => ({}));
  return { ok: d8.ok && d9.ok !== false, message: d9.message || "", notes: d9.notes || [] };
} });
globalThis.rzBuilder = ot;
var gt = new T({ mount: document.body, me: ut.me && ut.me.name || "You", room: () => _e, players: () => [...new Set([...W.players.values()].map((d7) => d7.name))].filter((d7) => d7 !== W.name), onRespawn: te, onCamera: () => s(H, "reczone-dorm"), rooms: () => c({ current: Xt, enter: (d7, d8) => je(d7, d8), knock: () => ht.toggle(true) }), pages: [l({ canReport: () => /^DORM-\d+$/.test(W.room || "") && !jt() }), ...m({ me: ut.me, onSaved: (d7) => as?.refreshMe(d7) }), b({ net: W, tools: re, site: true, goTo: (d7, d8) => je(d7, d8) }), Zi(ot), qi({ room: () => W.room, canReport: () => /^DORM-\d+$/.test(W.room || "") && !jt() })], customize: () => gt.show("avatar"), invite: async () => (ht.mine || await ht.refresh(), ht.mine && ht.mine.code ? { text: ht.mine.code, note: "Code " + ht.mine.code + " copied" } : { text: location.href, note: "Link copied" }) });
globalThis.rzWatch = gt, ot.addEventListener("menu", () => {
  gt.toggle(true), gt.show("build");
}), ht = F(gt, Xt), ht.addEventListener("enter", (d7) => je(d7.detail.room, d7.detail.label)), window.addEventListener("keydown", (d7) => {
  d7.code !== "Tab" || /^(INPUT|TEXTAREA)$/.test(d7.target.tagName) || (d7.preventDefault(), gt.open && gt.page === "dorms" ? gt.toggle(false) : ht.toggle(true));
}), W.addEventListener("refused", (d7) => {
  d7.detail && d7.detail.code === "paused" || W.connected || ht.toggle(true);
});
var rt = new D({ game: H, net: W, canvas: ns, watch: gt, roomName: () => _e });
globalThis.rzHud = rt, re.hud = rt, u({ game: H, net: W, tools: re, hud: rt });
var Fe = new f({ game: H, net: W, hud: rt }).connect();
ot.hud = rt, ot.pickups = Fe;
var Le = new j();
Le.load();
var Rs = new h({ library: Le, hud: rt }), Jt = Qi({ game: H, world: at, library: Le, builder: ot, openPlayer: () => {
  gt.toggle(true), gt.show("radio");
} }), Ke = new A({ net: W, player: Jt.player, radioModel: Jt.model }).start();
H.addUpdater(() => Ke.update()), gt.extraPages.push(ts(Jt, { sync: Ke, edr: !!(ut.me && ut.me.role === "edr") })), rt.addEventListener("play", () => Jt.player.begin());
var es = 0;
Jt.player.addEventListener("refused", (d7) => {
  performance.now() - es < 2500 || (es = performance.now(), Ce(d7.detail));
}), globalThis.rzRadio = Jt, globalThis.rzRadioSync = Ke, globalThis.rzDormExtras = Li({ game: H, world: at, openDorms: () => ht.toggle(true) }), globalThis.rzMusic = { library: Le, menuMusic: Rs };
var is = 0;
H.addUpdater(() => {
  if (H.player.position[1] >= -12 || at.doc.size === 0) return;
  te();
  let d7 = performance.now();
  d7 - is > 5e3 && Ce("Back to the start: you fell out of the dorm."), is = d7;
});
var $s = v({ pickups: Fe, world: at, game: H });
ot.furniture = $s, globalThis.rzPickups = Fe, globalThis.rzStaff = re;
var Ge = new x({ net: W, game: H });
rt.attachVoice(Ge), gt.attachVoice(Ge), globalThis.rzVoice = Ge;
function Ce(d7) {
  rt.say(d7, "info");
}
k(ht, gt, rt), Qt.step(72, "furnishing"), os(Xt).then(() => {
  Qt.step(90, "nearly");
});
var We = false, ss = 0, Os = performance.now();
rt.setLoading(0.05, "Loading the dorm"), H.addUpdater(() => {
  if (We) return;
  let d7 = at.doc.list().filter((dl) => dl.kind === "model"), d8 = d7.filter((dl) => {
    let dF = at.nodes.get(dl.id);
    return dF && (dF.children.length || dF.mesh);
  }).length, d9 = performance.now() - Os, dd = at.doc.size === 0 && d9 > 6e3, dC = d7.length > 0 && d8 === d7.length, dc = dC ? 0.97 : d7.length ? 0.15 + 0.8 * (d8 / d7.length) : Math.min(0.15, 0.05 + d9 / 4e4);
  if (H.player.velocity[0] = H.player.velocity[1] = H.player.velocity[2] = 0, Ve && H.player.position.set(Ve), (dC || dd) && ss++, ss < 3) {
    rt.setLoading(dc, d7.length ? "Loading the dorm (" + d8 + " of " + d7.length + ")" : "Loading the dorm");
    return;
  }
  We = true, te(), rt.setLoading(1), rt.redraw(), jt() && setTimeout(() => Ce("Your dorm. Press B to take out the Builder pen, Q for its menu."), 1200), jt() && new URLSearchParams(location.search).get("build") === "1" && setTimeout(() => ot.toggle(true), 1500);
}), globalThis.rzGame = H, globalThis.rzReady = () => We, globalThis.rzNet = W, globalThis.rzWorld = at, globalThis.rzDorms = ht, te(), import("./c-32QMBSR3.js").then((d7) => {
  as = d7.dressPlayers({ game: H, net: W, myName: ut.me && ut.me.name || "" });
}).catch((d7) => console.warn("[wardrobe] outfits are off:", d7.message)), H.start(), rt.redraw(), requestAnimationFrame(() => Qt.done());
