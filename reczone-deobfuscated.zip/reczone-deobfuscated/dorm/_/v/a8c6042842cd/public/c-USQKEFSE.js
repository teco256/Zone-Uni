var bo = Object.defineProperty, Eo = (c, l) => {
  for (var F in l) bo(c, F, { get: l[F], enumerable: true });
}, ht = {};
Eo(ht, { bounds: () => To, box: () => B, boxTiled: () => qe, cylinder: () => V, disc: () => bt, merge: () => Pt, plane: () => Yt, room: () => Mo, roundedBox: () => Z, sphere: () => U, taper: () => ct, torus: () => W, tube: () => Ke });
function B(F = 1, m = 1, u = 1) {
  let S = F / 2, E = m / 2, A = u / 2, v = [{ n: [0, 0, 1], v: [[-S, -E, A], [S, -E, A], [S, E, A], [-S, E, A]] }, { n: [0, 0, -1], v: [[S, -E, -A], [-S, -E, -A], [-S, E, -A], [S, E, -A]] }, { n: [1, 0, 0], v: [[S, -E, A], [S, -E, -A], [S, E, -A], [S, E, A]] }, { n: [-1, 0, 0], v: [[-S, -E, -A], [-S, -E, A], [-S, E, A], [-S, E, -A]] }, { n: [0, 1, 0], v: [[-S, E, A], [S, E, A], [S, E, -A], [-S, E, -A]] }, { n: [0, -1, 0], v: [[-S, -E, -A], [S, -E, -A], [S, -E, A], [-S, -E, A]] }], g = [], b = [], O = [], M = [];
  return v.forEach((T, x) => {
    for (let w of T.v) g.push(...w), b.push(...T.n);
    O.push(0, 0, 1, 0, 1, 1, 0, 1);
    let y = x * 4;
    M.push(y, y + 1, y + 2, y, y + 2, y + 3);
  }), pt(g, b, O, M);
}
function qe(F = [1, 1, 1], m = 1) {
  let u = B(1, 1, 1), S = Math.max(0.05, m), E = Math.abs(F[0]) / S, A = Math.abs(F[1]) / S, v = Math.abs(F[2]) / S, g = [[E, A], [E, A], [v, A], [v, A], [E, v], [E, v]];
  for (let b = 0; b < 6; b++) for (let O = 0; O < 4; O++) {
    let M = (b * 4 + O) * 2;
    u.uvs[M] *= g[b][0], u.uvs[M + 1] *= g[b][1];
  }
  return u;
}
function Yt(F = 1, m = 1, S = 1) {
  let E = [], A = [], v = [], g = [];
  for (let O = 0; O <= S; O++) for (let M = 0; M <= S; M++) {
    let T = M / S, x = O / S;
    E.push((T - 0.5) * F, 0, (x - 0.5) * m), A.push(0, 1, 0), v.push(T, x);
  }
  let b = S + 1;
  for (let y = 0; y < S; y++) for (let w = 0; w < S; w++) {
    let q = y * b + w, L = q + 1, p = q + b, I = p + 1;
    g.push(q, p, L, L, p, I);
  }
  return pt(E, A, v, g);
}
function U(F = 0.5, S = 24, E = 16) {
  let A = [], v = [], b = [], O = [];
  for (let T = 0; T <= E; T++) {
    let x = T / E * Math.PI, y = Math.sin(x), w = Math.cos(x);
    for (let q = 0; q <= S; q++) {
      let L = q / S * Math.PI * 2, I = y * Math.cos(L), z = w, K = y * Math.sin(L);
      A.push(I * F, z * F, K * F), v.push(I, z, K), b.push(q / S, T / E);
    }
  }
  let M = S + 1;
  for (let H = 0; H < E; H++) for (let d0 = 0; d0 < S; d0++) {
    let d1 = H * M + d0, d2 = d1 + M;
    O.push(d1, d1 + 1, d2, d1 + 1, d2 + 1, d2);
  }
  return pt(A, v, b, O);
}
function V(F = 0.5, m = 1, S = 20, E = true) {
  let A = [], v = [], g = [], b = [], O = m / 2;
  for (let M = 0; M <= S; M++) {
    let T = M / S, x = T * Math.PI * 2, y = Math.cos(x), w = Math.sin(x);
    A.push(y * F, -O, w * F), v.push(y, 0, w), g.push(T, 0), A.push(y * F, O, w * F), v.push(y, 0, w), g.push(T, 1);
  }
  for (let q = 0; q < S; q++) {
    let L = q * 2;
    b.push(L, L + 1, L + 2, L + 1, L + 3, L + 2);
  }
  if (E) for (let [p, I] of [[O, 1], [-O, -1]]) {
    let z = A.length / 3;
    A.push(0, p, 0), v.push(0, I, 0), g.push(0.5, 0.5);
    for (let K = 0; K <= S; K++) {
      let H = K / S * Math.PI * 2;
      A.push(Math.cos(H) * F, p, Math.sin(H) * F), v.push(0, I, 0), g.push(0.5 + Math.cos(H) * 0.5, 0.5 + Math.sin(H) * 0.5);
    }
    for (let d0 = 0; d0 < S; d0++) I > 0 ? b.push(z, z + d0 + 2, z + d0 + 1) : b.push(z, z + d0 + 1, z + d0 + 2);
  }
  return pt(A, v, g, b);
}
function bt(F = 0.5, S = 48, E = 6) {
  let A = [0, 0, 0], v = [0, 1, 0], g = [0.5, 0.5], b = [];
  for (let M = 1; M <= E; M++) {
    let T = M / E * F;
    for (let x = 0; x <= S; x++) {
      let y = x / S * Math.PI * 2, w = Math.cos(y) * T, q = Math.sin(y) * T;
      A.push(w, 0, q), v.push(0, 1, 0), g.push(0.5 + w / (2 * F), 0.5 + q / (2 * F));
    }
  }
  let O = S + 1;
  for (let L = 0; L < S; L++) b.push(0, 1 + L + 1, 1 + L);
  for (let I = 1; I < E; I++) {
    let z = 1 + (I - 1) * O, K = 1 + I * O;
    for (let H = 0; H < S; H++) {
      let d0 = z + H, d1 = z + H + 1, d2 = K + H, d3 = K + H + 1;
      b.push(d0, d1, d3, d0, d3, d2);
    }
  }
  return pt(A, v, g, b);
}
function Z(O = 1, q = 1, L = 1, I = 0.1, z = 4) {
  let K = [O / 2, q / 2, L / 2], H = Math.max(0, Math.min(I, ...K)), d0 = K.map((d7) => d7 - H), d1 = (d7) => {
    let d8 = [];
    for (let d9 = z; d9 >= 1; d9--) d8.push(-(d0[d7] + H * Math.tan(d9 / z * Math.PI / 4)));
    d8.push(-d0[d7], d0[d7]);
    for (let dd = 1; dd <= z; dd++) d8.push(d0[d7] + H * Math.tan(dd / z * Math.PI / 4));
    return d8;
  }, d2 = [], d3 = [], d4 = [], d5 = [], d6 = [[2, 1, 0, 1], [2, -1, 1, 0], [0, 1, 1, 2], [0, -1, 2, 1], [1, 1, 2, 0], [1, -1, 0, 2]];
  for (let [d7, d8, d9, dd] of d6) {
    let dC = d1(d9), dc = d1(dd), dl = d2.length / 3;
    for (let dk = 0; dk < dc.length; dk++) for (let dm = 0; dm < dC.length; dm++) {
      let du = [0, 0, 0];
      du[d7] = d8 * K[d7], du[d9] = dC[dm], du[dd] = dc[dk];
      let dj = du.map((dE, dh) => Math.min(d0[dh], Math.max(-d0[dh], dE))), dW = [du[0] - dj[0], du[1] - dj[1], du[2] - dj[2]], dS = Math.hypot(dW[0], dW[1], dW[2]);
      dS < 1e-9 ? (dW = [0, 0, 0], dW[d7] = d8) : dW = dW.map((dE) => dE / dS), d2.push(dj[0] + dW[0] * H, dj[1] + dW[1] * H, dj[2] + dW[2] * H), d3.push(dW[0], dW[1], dW[2]), d4.push((dC[dm] + K[d9]) / (2 * K[d9]), (dc[dk] + K[dd]) / (2 * K[dd]));
    }
    let dF = dC.length;
    for (let dE = 0; dE < dc.length - 1; dE++) for (let dh = 0; dh < dF - 1; dh++) {
      let dA = dl + dE * dF + dh, dv = dA + 1, dZ = dA + dF, dg = dZ + 1;
      d5.push(dA, dv, dg, dA, dg, dZ);
    }
  }
  return pt(d2, d3, d4, d5);
}
function Ke(O, q = 0.015, L = 8) {
  let I = [], z = [], K = [], H = [], d0 = (O || []).filter((d7, d8, d9) => d8 === 0 || Math.hypot(d7[0] - d9[d8 - 1][0], d7[1] - d9[d8 - 1][1], d7[2] - d9[d8 - 1][2]) > 1e-4);
  if (d0.length === 1) return U(q, L, Math.max(4, L >> 1));
  if (!d0.length) return pt([], [], [], []);
  let d1 = (d7) => {
    let d8 = Math.hypot(d7[0], d7[1], d7[2]) || 1;
    return [d7[0] / d8, d7[1] / d8, d7[2] / d8];
  }, d2 = (d7, d8) => [d7[1] * d8[2] - d7[2] * d8[1], d7[2] * d8[0] - d7[0] * d8[2], d7[0] * d8[1] - d7[1] * d8[0]], d3 = (d7, d8) => d7[0] * d8[0] + d7[1] * d8[1] + d7[2] * d8[2], d4 = null, d5 = [];
  for (let d7 = 0; d7 < d0.length; d7++) {
    let d8 = d0[Math.max(0, d7 - 1)], d9 = d0[Math.min(d0.length - 1, d7 + 1)], dd = d7 > 0 ? d1([d0[d7][0] - d8[0], d0[d7][1] - d8[1], d0[d7][2] - d8[2]]) : null, dC = d7 < d0.length - 1 ? d1([d9[0] - d0[d7][0], d9[1] - d0[d7][1], d9[2] - d0[d7][2]]) : null, dc = dd && dC ? d1([dd[0] + dC[0], dd[1] + dC[1], dd[2] + dC[2]]) : dd || dC;
    if (!d4) d4 = d1(d2(dc, Math.abs(dc[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0]));
    else {
      let dm = d3(d4, dc);
      d4 = d1([d4[0] - dc[0] * dm, d4[1] - dc[1] * dm, d4[2] - dc[2] * dm]);
    }
    let dl = d2(dc, d4), dF = null, dk = 1;
    if (dd && dC) {
      let du = d3(dc, dd);
      du < 0.999 && (dF = d1([dC[0] - dd[0], dC[1] - dd[1], dC[2] - dd[2]]), dk = Math.min(2.5, 1 / Math.max(du, 1e-3)));
    }
    d5.push({ p: d0[d7], n: d4, b: dl, t: dc, bend: dF, stretch: dk });
  }
  for (let dj = 0; dj < d5.length; dj++) {
    let dW = d5[dj];
    for (let dS = 0; dS <= L; dS++) {
      let dE = dS / L * Math.PI * 2, dh = [0, 1, 2].map((dZ) => dW.n[dZ] * Math.cos(dE) + dW.b[dZ] * Math.sin(dE)), dA = dW.bend ? d3(dh, dW.bend) * (dW.stretch - 1) : 0, dv = dW.bend ? [0, 1, 2].map((dZ) => dh[dZ] + dW.bend[dZ] * dA) : dh;
      I.push(dW.p[0] + dv[0] * q, dW.p[1] + dv[1] * q, dW.p[2] + dv[2] * q), z.push(dh[0], dh[1], dh[2]), K.push(dS / L, dj / (d5.length - 1));
    }
  }
  let d6 = L + 1;
  for (let dZ = 0; dZ < d5.length - 1; dZ++) for (let dg = 0; dg < L; dg++) {
    let db = dZ * d6 + dg, dJ = db + d6;
    H.push(db, db + 1, dJ, db + 1, dJ + 1, dJ);
  }
  for (let [dO, dM] of [[d5[0], -1], [d5[d5.length - 1], 1]]) {
    let dT = I.length / 3;
    for (let dG = 1; dG <= 3; dG++) {
      let dR = dG / 3 * (Math.PI / 2), dx = Math.cos(dR) * q, df = Math.sin(dR) * q * dM;
      for (let dy = 0; dy <= L; dy++) {
        let dN = dy / L * Math.PI * 2, dX = [0, 1, 2].map((dw) => dO.n[dw] * Math.cos(dN) + dO.b[dw] * Math.sin(dN)), dP = d1([0, 1, 2].map((dw) => dX[dw] * Math.cos(dR) + dO.t[dw] * Math.sin(dR) * dM));
        I.push(dO.p[0] + dX[0] * dx + dO.t[0] * df, dO.p[1] + dX[1] * dx + dO.t[1] * df, dO.p[2] + dX[2] * dx + dO.t[2] * df), z.push(dP[0], dP[1], dP[2]), K.push(dy / L, dM > 0 ? 1 : 0);
      }
    }
    let dD = dM < 0 ? 0 : (d5.length - 1) * d6;
    for (let dw = 0; dw < 3; dw++) {
      let dq = dT + dw * d6;
      for (let dL = 0; dL < L; dL++) {
        let dp = dD + dL, dB = dq + dL;
        dM > 0 ? H.push(dp, dp + 1, dB, dp + 1, dB + 1, dB) : H.push(dp, dB, dp + 1, dp + 1, dB, dB + 1);
      }
      dD = dq;
    }
  }
  return pt(I, z, K, H);
}
function ct(F = 0.5, S = 0.2, E = 1, A = 20) {
  let b = [], O = [], M = [], T = [], x = E / 2, y = (F - S) / E, w = y / Math.hypot(1, y), q = 1 / Math.hypot(1, y);
  for (let L = 0; L <= A; L++) {
    let I = L / A, z = I * Math.PI * 2, K = Math.cos(z), H = Math.sin(z);
    b.push(K * F, -x, H * F), O.push(K * q, w, H * q), M.push(I, 0), b.push(K * S, x, H * S), O.push(K * q, w, H * q), M.push(I, 1);
  }
  for (let d0 = 0; d0 < A; d0++) {
    let d1 = d0 * 2;
    T.push(d1, d1 + 1, d1 + 2, d1 + 1, d1 + 3, d1 + 2);
  }
  for (let [d2, d3, d4] of [[x, S, 1], [-x, F, -1]]) {
    if (d3 <= 1e-5) continue;
    let d5 = b.length / 3;
    b.push(0, d2, 0), O.push(0, d4, 0), M.push(0.5, 0.5);
    for (let d6 = 0; d6 <= A; d6++) {
      let d7 = d6 / A * Math.PI * 2;
      b.push(Math.cos(d7) * d3, d2, Math.sin(d7) * d3), O.push(0, d4, 0), M.push(0.5 + Math.cos(d7) * 0.5, 0.5 + Math.sin(d7) * 0.5);
    }
    for (let d8 = 0; d8 < A; d8++) d4 > 0 ? T.push(d5, d5 + d8 + 2, d5 + d8 + 1) : T.push(d5, d5 + d8 + 1, d5 + d8 + 2);
  }
  return pt(b, O, M, T);
}
function W(F = 0.5, S = 0.05, E = 32, A = 10) {
  let b = [], O = [], M = [], T = [];
  for (let y = 0; y <= E; y++) {
    let w = y / E * Math.PI * 2, q = Math.cos(w), L = Math.sin(w);
    for (let I = 0; I <= A; I++) {
      let z = I / A * Math.PI * 2, K = Math.cos(z), H = Math.sin(z), d0 = [K * q, H, K * L];
      b.push(q * F + d0[0] * S, d0[1] * S, L * F + d0[2] * S), O.push(d0[0], d0[1], d0[2]), M.push(y / E, I / A);
    }
  }
  let x = A + 1;
  for (let d1 = 0; d1 < E; d1++) for (let d2 = 0; d2 < A; d2++) {
    let d3 = d1 * x + d2, d4 = d3 + 1, d5 = d3 + x, d6 = d5 + 1;
    T.push(d3, d4, d5, d4, d6, d5);
  }
  return pt(b, O, M, T);
}
function Mo(c = 10, l = 3, F = 10, m = 0.2) {
  let u = [], S = (E, A, v, g) => {
    let b = E.positions;
    for (let O = 0; O < b.length; O += 3) b[O] += A, b[O + 1] += v, b[O + 2] += g;
    u.push(E);
  };
  return S(B(c, m, F), 0, -m / 2, 0), S(B(c, m, F), 0, l + m / 2, 0), S(B(c, l, m), 0, l / 2, -F / 2 - m / 2), S(B(c, l, m), 0, l / 2, F / 2 + m / 2), S(B(m, l, F), -c / 2 - m / 2, l / 2, 0), S(B(m, l, F), c / 2 + m / 2, l / 2, 0), Pt(u);
}
function Pt(c) {
  let l = [], F = [], m = [], u = [], S = 0;
  for (let E of c) {
    l.push(...E.positions), F.push(...E.normals), m.push(...E.uvs);
    for (let h of E.indices) u.push(h + S);
    S += E.positions.length / 3;
  }
  return pt(l, F, m, u);
}
function pt(c, l, F, m) {
  return { positions: new Float32Array(c), normals: new Float32Array(l), uvs: new Float32Array(F), indices: m };
}
function To(c) {
  let l = c.positions;
  if (!l.length) return { min: [0, 0, 0], max: [0, 0, 0] };
  let F = [1 / 0, 1 / 0, 1 / 0], m = [-1 / 0, -1 / 0, -1 / 0];
  for (let u = 0; u < l.length; u += 3) for (let S = 0; S < 3; S++) l[u + S] < F[S] && (F[S] = l[u + S]), l[u + S] > m[S] && (m[S] = l[u + S]);
  return { min: F, max: m };
}
var Ee = Math.PI / 180, _ = { create: (c = 0, l = 0, F = 0) => new Float32Array([c, l, F]), set: (c, l, F, m) => (c[0] = l, c[1] = F, c[2] = m, c), copy: (c, l) => (c[0] = l[0], c[1] = l[1], c[2] = l[2], c), add: (c, l, F) => (c[0] = l[0] + F[0], c[1] = l[1] + F[1], c[2] = l[2] + F[2], c), sub: (c, l, F) => (c[0] = l[0] - F[0], c[1] = l[1] - F[1], c[2] = l[2] - F[2], c), mul: (c, l, F) => (c[0] = l[0] * F[0], c[1] = l[1] * F[1], c[2] = l[2] * F[2], c), scale: (c, l, F) => (c[0] = l[0] * F, c[1] = l[1] * F, c[2] = l[2] * F, c), scaleAndAdd: (c, l, F, m) => (c[0] = l[0] + F[0] * m, c[1] = l[1] + F[1] * m, c[2] = l[2] + F[2] * m, c), dot: (c, l) => c[0] * l[0] + c[1] * l[1] + c[2] * l[2], cross: (l, F, m) => {
  let u = F[0], S = F[1], E = F[2], h = m[0], A = m[1], v = m[2];
  return l[0] = S * v - E * A, l[1] = E * h - u * v, l[2] = u * A - S * h, l;
}, lengthSq: (c) => c[0] * c[0] + c[1] * c[1] + c[2] * c[2], length: (c) => Math.hypot(c[0], c[1], c[2]), distance: (c, l) => Math.hypot(c[0] - l[0], c[1] - l[1], c[2] - l[2]), normalize: (c, l) => {
  let F = Math.hypot(l[0], l[1], l[2]);
  return F < 1e-6 ? _.set(c, 0, 0, 0) : _.scale(c, l, 1 / F);
}, lerp: (c, l, F, m) => (c[0] = l[0] + (F[0] - l[0]) * m, c[1] = l[1] + (F[1] - l[1]) * m, c[2] = l[2] + (F[2] - l[2]) * m, c), transformMat4: (c, l, F) => {
  let m = l[0], u = l[1], S = l[2];
  return c[0] = F[0] * m + F[4] * u + F[8] * S + F[12], c[1] = F[1] * m + F[5] * u + F[9] * S + F[13], c[2] = F[2] * m + F[6] * u + F[10] * S + F[14], c;
}, transformDir: (c, l, F) => {
  let m = l[0], u = l[1], S = l[2];
  return c[0] = F[0] * m + F[4] * u + F[8] * S, c[1] = F[1] * m + F[5] * u + F[9] * S, c[2] = F[2] * m + F[6] * u + F[10] * S, c;
}, transformQuat: (F, m, S) => {
  let E = m[0], A = m[1], v = m[2], g = S[0], b = S[1], O = S[2], M = S[3], T = 2 * (b * v - O * A), x = 2 * (O * E - g * v), y = 2 * (g * A - b * E);
  return F[0] = E + M * T + b * y - O * x, F[1] = A + M * x + O * T - g * y, F[2] = v + M * y + g * x - b * T, F;
} }, X = { create: () => new Float32Array([0, 0, 0, 1]), identity: (c) => (c[0] = 0, c[1] = 0, c[2] = 0, c[3] = 1, c), copy: (c, l) => (c.set(l), c), setAxisAngle: (c, l, F) => {
  let m = F * 0.5, u = Math.sin(m);
  return c[0] = l[0] * u, c[1] = l[1] * u, c[2] = l[2] * u, c[3] = Math.cos(m), c;
}, fromEuler: (F, m, S, E) => {
  let A = m * 0.5, v = S * 0.5, g = E * 0.5, b = Math.sin(A), O = Math.cos(A), M = Math.sin(v), T = Math.cos(v), x = Math.sin(g), y = Math.cos(g);
  return F[0] = b * T * y + O * M * x, F[1] = O * M * y - b * T * x, F[2] = O * T * x - b * M * y, F[3] = O * T * y + b * M * x, F;
}, multiply: (F, m, u) => {
  let S = m[0], E = m[1], A = m[2], v = m[3], g = u[0], b = u[1], O = u[2], M = u[3];
  return F[0] = S * M + v * g + E * O - A * b, F[1] = E * M + v * b + A * g - S * O, F[2] = A * M + v * O + S * b - E * g, F[3] = v * M - S * g - E * b - A * O, F;
}, normalize: (c, l) => {
  let F = Math.hypot(l[0], l[1], l[2], l[3]);
  return F < 1e-6 ? X.identity(c) : (c[0] = l[0] / F, c[1] = l[1] / F, c[2] = l[2] / F, c[3] = l[3] / F, c);
}, slerp: (F, m, S, E) => {
  let A = S[0], v = S[1], g = S[2], b = S[3], O = m[0] * A + m[1] * v + m[2] * g + m[3] * b;
  O < 0 && (O = -O, A = -A, v = -v, g = -g, b = -b);
  let M, T;
  if (1 - O > 1e-6) {
    let x = Math.acos(O), y = Math.sin(x);
    M = Math.sin((1 - E) * x) / y, T = Math.sin(E * x) / y;
  } else M = 1 - E, T = E;
  return F[0] = M * m[0] + T * A, F[1] = M * m[1] + T * v, F[2] = M * m[2] + T * g, F[3] = M * m[3] + T * b, F;
} }, P = { create: () => {
  let c = new Float32Array(16);
  return c[0] = 1, c[5] = 1, c[10] = 1, c[15] = 1, c;
}, identity: (c) => (c.fill(0), c[0] = 1, c[5] = 1, c[10] = 1, c[15] = 1, c), copy: (c, l) => (c.set(l), c), multiply: (F, S, A) => {
  let O = S[0], T = S[1], q = S[2], L = S[3], I = S[4], z = S[5], K = S[6], H = S[7], d0 = S[8], d1 = S[9], d2 = S[10], d3 = S[11], d4 = S[12], d5 = S[13], d6 = S[14], d7 = S[15];
  for (let d8 = 0; d8 < 4; d8++) {
    let d9 = A[d8 * 4], dd = A[d8 * 4 + 1], dC = A[d8 * 4 + 2], dc = A[d8 * 4 + 3];
    F[d8 * 4] = d9 * O + dd * I + dC * d0 + dc * d4, F[d8 * 4 + 1] = d9 * T + dd * z + dC * d1 + dc * d5, F[d8 * 4 + 2] = d9 * q + dd * K + dC * d2 + dc * d6, F[d8 * 4 + 3] = d9 * L + dd * H + dC * d3 + dc * d7;
  }
  return F;
}, fromRotationTranslationScale: (F, S, A, O) => {
  let T = S[0], x = S[1], q = S[2], L = S[3], I = T + T, z = x + x, K = q + q, H = T * I, d0 = T * z, d1 = T * K, d2 = x * z, d3 = x * K, d4 = q * K, d5 = L * I, d6 = L * z, d7 = L * K, d8 = O[0], d9 = O[1], dd = O[2];
  return F[0] = (1 - (d2 + d4)) * d8, F[1] = (d0 + d7) * d8, F[2] = (d1 - d6) * d8, F[3] = 0, F[4] = (d0 - d7) * d9, F[5] = (1 - (H + d4)) * d9, F[6] = (d3 + d5) * d9, F[7] = 0, F[8] = (d1 + d6) * dd, F[9] = (d3 - d5) * dd, F[10] = (1 - (H + d2)) * dd, F[11] = 0, F[12] = A[0], F[13] = A[1], F[14] = A[2], F[15] = 1, F;
}, perspective: (c, l, F, m, u) => {
  let S = 1 / Math.tan(l / 2);
  if (c.fill(0), c[0] = S / F, c[5] = S, c[11] = -1, u !== 1 / 0) {
    let E = 1 / (m - u);
    c[10] = (u + m) * E, c[14] = 2 * u * m * E;
  } else c[10] = -1, c[14] = -2 * m;
  return c;
}, ortho: (F, m, u, S, E, h, A) => {
  let v = 1 / (m - u), g = 1 / (S - E), b = 1 / (h - A);
  return F.fill(0), F[0] = -2 * v, F[5] = -2 * g, F[10] = 2 * b, F[15] = 1, F[12] = (m + u) * v, F[13] = (E + S) * g, F[14] = (A + h) * b, F;
}, lookAt: (c, l, F, m) => {
  let u = _.normalize(_.create(), _.sub(_.create(), l, F)), S = _.normalize(_.create(), _.cross(_.create(), m, u)), E = _.cross(_.create(), u, S);
  return c[0] = S[0], c[1] = E[0], c[2] = u[0], c[3] = 0, c[4] = S[1], c[5] = E[1], c[6] = u[1], c[7] = 0, c[8] = S[2], c[9] = E[2], c[10] = u[2], c[11] = 0, c[12] = -_.dot(S, l), c[13] = -_.dot(E, l), c[14] = -_.dot(u, l), c[15] = 1, c;
}, invert: (q, L) => {
  let z = L[0], K = L[1], H = L[2], d0 = L[3], d1 = L[4], d2 = L[5], d3 = L[6], d4 = L[7], d5 = L[8], d6 = L[9], d7 = L[10], d8 = L[11], d9 = L[12], dd = L[13], dC = L[14], dc = L[15], dl = z * d2 - K * d1, dF = z * d3 - H * d1, dk = z * d4 - d0 * d1, dm = K * d3 - H * d2, du = K * d4 - d0 * d2, dj = H * d4 - d0 * d3, dW = d5 * dd - d6 * d9, dS = d5 * dC - d7 * d9, dE = d5 * dc - d8 * d9, dh = d6 * dC - d7 * dd, dA = d6 * dc - d8 * dd, dv = d7 * dc - d8 * dC, dZ = dl * dv - dF * dA + dk * dh + dm * dE - du * dS + dj * dW;
  return dZ ? (dZ = 1 / dZ, q[0] = (d2 * dv - d3 * dA + d4 * dh) * dZ, q[1] = (H * dA - K * dv - d0 * dh) * dZ, q[2] = (dd * dj - dC * du + dc * dm) * dZ, q[3] = (d7 * du - d6 * dj - d8 * dm) * dZ, q[4] = (d3 * dE - d1 * dv - d4 * dS) * dZ, q[5] = (z * dv - H * dE + d0 * dS) * dZ, q[6] = (dC * dk - d9 * dj - dc * dF) * dZ, q[7] = (d5 * dj - d7 * dk + d8 * dF) * dZ, q[8] = (d1 * dA - d2 * dE + d4 * dW) * dZ, q[9] = (K * dE - z * dA - d0 * dW) * dZ, q[10] = (d9 * du - dd * dk + dc * dl) * dZ, q[11] = (d6 * dk - d5 * du - d8 * dl) * dZ, q[12] = (d2 * dS - d1 * dh - d3 * dW) * dZ, q[13] = (z * dh - K * dS + H * dW) * dZ, q[14] = (dd * dF - d9 * dm - dC * dl) * dZ, q[15] = (d5 * dm - d6 * dF + d7 * dl) * dZ, q) : null;
}, normalFromMat4: (c, l) => {
  let F = P.invert(P.create(), l);
  return F ? (c[0] = F[0], c[1] = F[4], c[2] = F[8], c[3] = F[1], c[4] = F[5], c[5] = F[9], c[6] = F[2], c[7] = F[6], c[8] = F[10], c) : null;
}, getTranslation: (c, l) => _.set(c, l[12], l[13], l[14]) }, wi = { create: () => new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]) }, mt = (c, l, F) => c < l ? l : c > F ? F : c, So = (c, l, F) => c + (l - c) * F, Je = (c, l, F, m) => So(c, l, 1 - Math.exp(-F * m)), N = class {
  constructor(c = {}) {
    this.colour = c.colour || [0.8, 0.8, 0.82], this.alpha = c.alpha ?? 1, this.roughness = c.roughness ?? 0.7, this.metallic = c.metallic ?? 0, this.emissive = c.emissive || [0, 0, 0], this.glowMap = !!c.glowMap, this.grid = c.grid || 0, this.map = c.map || null, this.alphaCutoff = c.alphaCutoff ?? 1e-3, this.doubleSided = !!c.doubleSided, this.castShadow = c.castShadow !== false, this._texture = null;
  }
}, Zt = 8, Et = new N(), Qt = P.create();
function yi(c, l) {
  let F = c.worldPosition(), m = F[0] - l[0], u = F[1] - l[1], S = F[2] - l[2];
  return m * m + u * u + S * S;
}
var zt = class {
  constructor() {
    this._normalMatrix = wi.create(), this.stats = { draws: 0, triangles: 0, culled: 0, shadowDrawn: false, shadowReused: 0 }, this._shadowSig = new Float32Array(0), this._shadowSigNext = new Float32Array(256), this._shadowMeshes = [], this._shadowPending = null, this.shadowEvery = 3, this.culling = true, this._planes = new Float32Array(24), this._spheres = /* @__PURE__ */ new WeakMap(), this.postLevel = 0, this.reflections = 1, this.mirrorSlots = 1, this.post = null, this.lighting = 1, this.shadowTaps = 4, this.anisotropy = 8, this.fogDensity = 4e-3, this.samples = 0;
  }
  ["samplesFor"](c, l) {
    let F = c * l, m = this.samples;
    return F > 42e5 ? m = Math.min(m, 2) : F > 24e5 && (m = Math.min(m, 4)), m;
  }
  ["_gather"](c) {
    let l = [], F = [], m = [];
    for (let u of c.visibleNodes()) u.mesh && !u.batched && l.push(u), u.light && F.push(u), u.mirror && u.mesh && m.push(u);
    return { drawables: l, lights: F, mirrors: m };
  }
  ["_reflected"](c) {
    if (!this.mirrorExtras) return c;
    let l = c.slice();
    for (let F of this.mirrorExtras) if (!(!F || F.visible)) {
      for (let m of F.allNodes()) m.mesh && !m.batched && l.push(m);
    }
    return l;
  }
  ["_sorted"](c, l, F) {
    let m = this.culling ? this._cull(c, l.viewProjection) : c, u = [], S = [];
    for (let E of m) F && F(E) || ((E.material || Et).alpha < 1 ? S : u).push(E);
    if (S.length) {
      let h = l.position;
      S.sort((A, v) => yi(v, h) - yi(A, h));
    }
    return { opaque: u, blended: S };
  }
  ["_cull"](F, S) {
    let A = this._planes, O = (K) => [S[K], S[K + 4], S[K + 8], S[K + 12]], [M, T, x, q] = [O(0), O(1), O(2), O(3)], L = [Ut(q, M), Bt(q, M), Ut(q, T), Bt(q, T), Ut(q, x), Bt(q, x)];
    for (let K = 0; K < 6; K++) {
      let [H, d0, d1, d2] = L[K], d3 = Math.hypot(H, d0, d1) || 1;
      A[K * 4] = H / d3, A[K * 4 + 1] = d0 / d3, A[K * 4 + 2] = d1 / d3, A[K * 4 + 3] = d2 / d3;
    }
    let I = [], z = 0;
    for (let d4 of F) {
      if (d4.skin || d4.noCull) {
        I.push(d4);
        continue;
      }
      let d5 = this._sphereOf(d4.mesh);
      if (!d5) {
        I.push(d4);
        continue;
      }
      let d6 = d4.worldMatrix(), d7 = d6[0] * d5[0] + d6[4] * d5[1] + d6[8] * d5[2] + d6[12], d8 = d6[1] * d5[0] + d6[5] * d5[1] + d6[9] * d5[2] + d6[13], d9 = d6[2] * d5[0] + d6[6] * d5[1] + d6[10] * d5[2] + d6[14], dd = Math.max(Math.hypot(d6[0], d6[1], d6[2]), Math.hypot(d6[4], d6[5], d6[6]), Math.hypot(d6[8], d6[9], d6[10])), dC = d5[3] * dd, dc = true;
      for (let dl = 0; dl < 24; dl += 4) if (A[dl] * d7 + A[dl + 1] * d8 + A[dl + 2] * d9 + A[dl + 3] < -dC) {
        dc = false;
        break;
      }
      dc ? I.push(d4) : z++;
    }
    return this.stats.culled = z, I;
  }
  ["_sphereOf"](l) {
    if (!l || !l.positions || !l.positions.length) return null;
    let F = this._spheres.get(l);
    if (F) return F;
    let m = l.positions, u = [1 / 0, 1 / 0, 1 / 0], S = [-1 / 0, -1 / 0, -1 / 0];
    for (let h = 0; h < m.length; h += 3) for (let A = 0; A < 3; A++) m[h + A] < u[A] && (u[A] = m[h + A]), m[h + A] > S[A] && (S[A] = m[h + A]);
    let E = [(u[0] + S[0]) / 2, (u[1] + S[1]) / 2, (u[2] + S[2]) / 2];
    return F = [E[0], E[1], E[2], Math.hypot(S[0] - E[0], S[1] - E[1], S[2] - E[2])], this._spheres.set(l, F), F;
  }
  ["_mirrorStrips"](c) {
    return this.reflections === 0 ? 0 : Math.max(0, Math.min(this.mirrorSlots | 0, c.length));
  }
  ["_mirrorsInView"](l, F, m = 1) {
    if (!l.length || this.reflections === 0 || m <= 0) return [];
    let u = [], S = this._frustum(F.viewProjection, this._mirrorPlanes || (this._mirrorPlanes = new Float32Array(24)));
    for (let E of l) {
      let A = this._mirrorPlane(E);
      if (!A) continue;
      let v = F.position;
      if (A.n[0] * v[0] + A.n[1] * v[1] + A.n[2] * v[2] - A.d <= 0.05) continue;
      let g = Math.hypot(A.p[0] - v[0], A.p[1] - v[1], A.p[2] - v[2]);
      g > 14 || g > 1.5 && !this._sphereInView(E, S) || u.push({ node: E, plane: A, dist: g });
    }
    return u.sort((b, O) => b.dist - O.dist), u.slice(0, m);
  }
  ["_nearestMirror"](c, l) {
    return this._mirrorsInView(c, l, 1)[0] || null;
  }
  ["_frustum"](F, m) {
    let S = (O) => [F[O], F[O + 4], F[O + 8], F[O + 12]], [E, A, v, g] = [S(0), S(1), S(2), S(3)], b = [Ut(g, E), Bt(g, E), Ut(g, A), Bt(g, A), Ut(g, v), Bt(g, v)];
    for (let O = 0; O < 6; O++) {
      let [M, T, x, y] = b[O], w = Math.hypot(M, T, x) || 1;
      m[O * 4] = M / w, m[O * 4 + 1] = T / w, m[O * 4 + 2] = x / w, m[O * 4 + 3] = y / w;
    }
    return m;
  }
  ["_sphereInView"](F, m) {
    let u = this._sphereOf(F.mesh);
    if (!u) return true;
    let S = F.worldMatrix(), E = S[0] * u[0] + S[4] * u[1] + S[8] * u[2] + S[12], A = S[1] * u[0] + S[5] * u[1] + S[9] * u[2] + S[13], v = S[2] * u[0] + S[6] * u[1] + S[10] * u[2] + S[14], g = Math.max(Math.hypot(S[0], S[1], S[2]), Math.hypot(S[4], S[5], S[6]), Math.hypot(S[8], S[9], S[10])), b = u[3] * g;
    for (let O = 0; O < 24; O += 4) if (m[O] * E + m[O + 1] * A + m[O + 2] * v + m[O + 3] < -b) return false;
    return true;
  }
  ["_mirrorPlane"](F) {
    let S = F.mesh;
    if (!S.positions || !S.normals || !S.positions.length) return null;
    let E = F.worldMatrix(), A = S.positions, b = S.normals, O = 0, M = 0, T = 0, x = A.length / 3;
    for (let H = 0; H < A.length; H += 3) O += A[H], M += A[H + 1], T += A[H + 2];
    O /= x, M /= x, T /= x;
    let y = [E[0] * O + E[4] * M + E[8] * T + E[12], E[1] * O + E[5] * M + E[9] * T + E[13], E[2] * O + E[6] * M + E[10] * T + E[14]];
    P.normalFromMat4(this._normalMatrix, E);
    let w = b[0], q = b[1], L = b[2], I = this._normalMatrix, z = [I[0] * w + I[3] * q + I[6] * L, I[1] * w + I[4] * q + I[7] * L, I[2] * w + I[5] * q + I[8] * L], K = Math.hypot(z[0], z[1], z[2]) || 1;
    return z[0] /= K, z[1] /= K, z[2] /= K, { p: y, n: z, d: z[0] * y[0] + z[1] * y[1] + z[2] * y[2] };
  }
  ["_mirrorView"](F, S, A = 0, O = 1) {
    let { n: T, d: q } = F.plane, L = (dd, dC) => {
      let dc = 2 * (T[0] * dd[0] + T[1] * dd[1] + T[2] * dd[2] - (dC ? q : 0));
      return [dd[0] - dc * T[0], dd[1] - dc * T[1], dd[2] - dc * T[2]];
    }, I = L(S.position, true), z = S.forward(), K = L([S.position[0] + z[0], S.position[1] + z[1], S.position[2] + z[2]], true), H = L([0, 1, 0], false);
    this._mirrorCams ??= [];
    let d0 = this._mirrorCams[A] || (this._mirrorCams[A] = { position: _.create(), view: P.create(), projection: P.create(), viewProjection: P.create(), inverseViewProjection: P.create(), textureMatrix: P.create(), near: 0.05, far: 100, forward() {
      return this._fwd;
    }, _fwd: [0, 0, -1], update() {
      return this;
    } });
    _.set(d0.position, I[0], I[1], I[2]), P.lookAt(d0.view, I, K, H), d0._fwd = [K[0] - I[0], K[1] - I[1], K[2] - I[2]], d0.near = S.near, d0.far = S.far, P.copy(d0.projection, S.projection);
    let d1 = d0.view, d2 = [d1[0] * T[0] + d1[4] * T[1] + d1[8] * T[2], d1[1] * T[0] + d1[5] * T[1] + d1[9] * T[2], d1[2] * T[0] + d1[6] * T[1] + d1[10] * T[2]], d3 = F.plane.p, d4 = [d1[0] * d3[0] + d1[4] * d3[1] + d1[8] * d3[2] + d1[12], d1[1] * d3[0] + d1[5] * d3[1] + d1[9] * d3[2] + d1[13], d1[2] * d3[0] + d1[6] * d3[1] + d1[10] * d3[2] + d1[14]], d5 = [d2[0], d2[1], d2[2], -(d2[0] * d4[0] + d2[1] * d4[1] + d2[2] * d4[2])], d6 = d0.projection, d7 = [(Math.sign(d5[0]) + d6[8]) / d6[0], (Math.sign(d5[1]) + d6[9]) / d6[5], -1, (1 + d6[10]) / d6[14]], d8 = d5[0] * d7[0] + d5[1] * d7[1] + d5[2] * d7[2] + d5[3] * d7[3];
    if (Math.abs(d8) > 1e-9) {
      let dd = 2 / d8;
      d6[2] = d5[0] * dd, d6[6] = d5[1] * dd, d6[10] = d5[2] * dd + 1 - 3e-3, d6[14] = d5[3] * dd;
    }
    P.multiply(d0.viewProjection, d0.projection, d0.view), P.invert(d0.inverseViewProjection, d0.viewProjection);
    let d9 = this._bias || (this._bias = new Float32Array([0.5, 0, 0, 0, 0, 0.5, 0, 0, 0, 0, 0.5, 0, 0.5, 0.5, 0.5, 1]));
    if (P.multiply(d0.textureMatrix, d9, P.multiply(this._tmpMat || (this._tmpMat = P.create()), S.projection, d0.view)), O > 1) {
      let dC = d0.textureMatrix;
      for (let dc = 0; dc < 16; dc += 4) dC[dc] = dC[dc] / O + dC[dc + 3] * A / O;
    }
    return d0;
  }
  ["_noMirror"](c) {
    for (let l = c; l; l = l.parent) if (l.noMirror) return true;
    return false;
  }
  ["_shadowFrame"](F, m, u) {
    let S = u.direction(), E = this.shadows.extent, h = _.scaleAndAdd(_.create(), m.position, m.forward(), E * 0.35), A = Math.max(E / 4, 0.5);
    h[0] = Math.round(h[0] / A) * A, h[1] = 0, h[2] = Math.round(h[2] / A) * A;
    let v = this._shadowsStale(F, h, S, E);
    if (this._shadowAge = (this._shadowAge || 0) + 1, !v || v === "moving" && this._shadowAge < this.shadowEvery) return this.stats.shadowReused++, false;
    this._shadowSig = this._shadowPending.sig, this._shadowMeshes = this._shadowPending.meshes, this._shadowAge = 0, this.stats.shadowDrawn = true;
    let g = _.scaleAndAdd(_.create(), h, S, E * 1.5);
    return P.lookAt(this.shadows.view, g, h, Math.abs(S[1]) > 0.99 ? [0, 0, 1] : [0, 1, 0]), P.ortho(this.shadows.projection, -E, E, -E, E, 0.1, E * 4), P.multiply(this.shadows.matrix, this.shadows.projection, this.shadows.view), true;
  }
  ["_shadowsStale"](F, S, E, A) {
    let v = 0, b = this._shadowSigNext, O = [], M = (w) => {
      if (v >= b.length) {
        let q = new Float32Array(b.length * 2);
        q.set(b), b = this._shadowSigNext = q;
      }
      b[v++] = w;
    };
    M(S[0]), M(S[2]), M(E[0]), M(E[1]), M(E[2]), M(A), M(this.shadows.size), M(this.shadows.generation);
    let T = v;
    for (let w of F) {
      let q = w.material || Et;
      if (!q.castShadow || q.alpha < 1) continue;
      O.push(w.mesh);
      let L = w.skin && w.skin.matrices ? w.skin : null, I = L && L.root ? L.root.worldMatrix() : w.worldMatrix();
      for (let z = 0; z < 16; z++) M(I[z]);
      if (L) {
        for (let K = 0; K < L.matrices.length; K++) M(L.matrices[K]);
      }
    }
    let x = this._shadowSig, y = false;
    (x.length !== v || this._shadowMeshes.length !== O.length) && (y = "changed");
    for (let H = 0; !y && H < O.length; H++) this._shadowMeshes[H] !== O[H] && (y = "changed");
    for (let d0 = 0; !y && d0 < T; d0++) x[d0] !== b[d0] && (y = "changed");
    for (let d1 = T; !y && d1 < v; d1++) x[d1] !== b[d1] && (y = "moving");
    return y && (this._shadowPending = { sig: b.slice(0, v), meshes: O }), y;
  }
  ["_pickLights"](F, m) {
    let S = F;
    if (S.length > Zt) {
      let b = m.position, O = (M) => {
        let T = M.worldPosition();
        return Math.hypot(T[0] - b[0], T[1] - b[1], T[2] - b[2]) - (M.light.range || 8);
      };
      S = S.map((M) => [O(M), M]).sort((M, T) => M[0] - T[0]).slice(0, Zt).map((M) => M[1]);
    }
    let E = this._lightPos || (this._lightPos = new Float32Array(Zt * 4)), A = this._lightCol || (this._lightCol = new Float32Array(Zt * 3)), v = this.lightScale ?? 1, g = 0;
    for (let M of S) {
      let T = M.light, x = M.worldPosition(), y = T.colour || [1, 1, 1], w = (T.intensity ?? 4) * v;
      w <= 0 || (E.set([x[0], x[1], x[2], T.range || 8], g * 4), A.set([y[0] * w, y[1] * w, y[2] * w], g * 3), g++);
    }
    return g;
  }
}, Ut = (c, l) => [c[0] + l[0], c[1] + l[1], c[2] + l[2], c[3] + l[3]], Bt = (c, l) => [c[0] - l[0], c[1] - l[1], c[2] - l[2], c[3] - l[3]];
function Ye(c, l = {}) {
  let F = c.getContext("webgl2", { antialias: !!l.antialias, alpha: false, depth: true, stencil: false, preserveDrawingBuffer: !!l.preserveDrawingBuffer, powerPreference: l.powerPreference || "high-performance" });
  if (!F) throw new Error("This browser has no WebGL2. The engine needs it \u2014 WebGL1 cannot do what the renderer relies on.");
  return F.enable(F.DEPTH_TEST), F.depthFunc(F.LEQUAL), F.enable(F.CULL_FACE), F.cullFace(F.BACK), F;
}
function ut(F, m, S, E = "shader") {
  let A = _i(F, F.VERTEX_SHADER, m, E + " (vertex)"), v = _i(F, F.FRAGMENT_SHADER, S, E + " (fragment)"), g = F.createProgram();
  if (F.attachShader(g, A), F.attachShader(g, v), F.linkProgram(g), F.deleteShader(A), F.deleteShader(v), !F.getProgramParameter(g, F.LINK_STATUS)) {
    let x = F.getProgramInfoLog(g);
    throw F.deleteProgram(g), new Error("Could not link " + E + ":\n" + x);
  }
  let b = {}, O = F.getProgramParameter(g, F.ACTIVE_UNIFORMS);
  for (let y = 0; y < O; y++) {
    let w = F.getActiveUniform(g, y), q = w.name.replace(/\[0\]$/, "");
    b[q] = F.getUniformLocation(g, w.name);
  }
  let M = {}, T = F.getProgramParameter(g, F.ACTIVE_ATTRIBUTES);
  for (let L = 0; L < T; L++) {
    let p = F.getActiveAttrib(g, L);
    M[p.name] = F.getAttribLocation(g, p.name);
  }
  return { program: g, uniforms: b, attribs: M, name: E };
}
function _i(F, m, u, S) {
  let E = F.createShader(m);
  if (F.shaderSource(E, u), F.compileShader(E), F.getShaderParameter(E, F.COMPILE_STATUS)) return E;
  let A = F.getShaderInfoLog(E) || "";
  F.deleteShader(E);
  let v = Number((A.match(/\d+:(\d+)/) || [])[1]), g = "";
  if (v) {
    let b = u.split("\n"), O = Math.max(0, v - 4), M = Math.min(b.length, v + 3);
    g = "\n" + b.slice(O, M).map((T, x) => (O + x + 1 === v ? " >> " : "    ") + (O + x + 1) + "  " + T).join("\n");
  }
  throw new Error("Could not compile " + S + ":\n" + A + g);
}
function Ze(F, { positions: S, normals: E, uvs: A, indices: v, colors: b, joints: O, weights: M }) {
  let T = F.createVertexArray();
  F.bindVertexArray(T);
  let x = [], y = (z, K, H) => {
    if (!z) return;
    let d0 = F.createBuffer();
    F.bindBuffer(F.ARRAY_BUFFER, d0), F.bufferData(F.ARRAY_BUFFER, z, F.STATIC_DRAW), F.enableVertexAttribArray(K), F.vertexAttribPointer(K, H, F.FLOAT, false, 0, 0), x.push(d0);
  };
  y(S, 0, 3), y(E, 1, 3), y(A, 2, 2), y(b, 3, 3), y(O, 4, 4), y(M, 5, 4);
  let w = !!(O && M), q = null, L = S.length / 3, I = 0;
  if (v) {
    q = F.createBuffer(), F.bindBuffer(F.ELEMENT_ARRAY_BUFFER, q);
    let z = S.length / 3 > 65535, K = z ? new Uint32Array(v) : new Uint16Array(v);
    F.bufferData(F.ELEMENT_ARRAY_BUFFER, K, F.STATIC_DRAW), L = v.length, I = z ? F.UNSIGNED_INT : F.UNSIGNED_SHORT, x.push(q);
  }
  return F.bindVertexArray(null), { vao: T, count: L, indexType: I, indexed: !!v, buffers: x, skinned: w, dispose() {
    F.deleteVertexArray(T);
    for (let H of x) F.deleteBuffer(H);
  } };
}
function Me(c, l) {
  c.bindVertexArray(l.vao), l.indexed ? c.drawElements(c.TRIANGLES, l.count, l.indexType, 0) : c.drawArrays(c.TRIANGLES, 0, l.count);
}
var Gt = "#version 300 es\nprecision highp float;\nout vec2 vUv;\nvoid main() {\n  vec2 pos = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);\n  vUv = pos;\n  gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);\n}", Ao = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uDepth;\nuniform mat4 uInvProj;\nuniform vec2 uTexel;\nuniform float uRadius;\nuniform float uIntensity;\nuniform float uProjScale;\nuniform int uSamples;\nout vec4 fragColour;\n\n// A point of the picture, back in the camera's space, worked out at the\n// middle of the depth pixel its depth came from. This pass is half size,\n// and a depth from one place put back at another tilts a floor seen at a\n// low angle a little differently every few rows, which came out as soft\n// dark bands across it at some window sizes.\nvec3 viewPos(vec2 uv) {\n  vec2 size = vec2(textureSize(uDepth, 0));\n  vec2 px = clamp(floor(uv * size), vec2(0.0), size - 1.0);\n  float d = texelFetch(uDepth, ivec2(px), 0).r;\n  vec2 c = (px + 0.5) / size;\n  vec4 p = uInvProj * vec4(c * 2.0 - 1.0, d * 2.0 - 1.0, 1.0);\n  return p.xyz / p.w;\n}\n\nvoid main() {\n  float d = texelFetch(uDepth, ivec2(clamp(floor(vUv * vec2(textureSize(uDepth, 0))), vec2(0.0), vec2(textureSize(uDepth, 0)) - 1.0)), 0).r;\n  if (d >= 0.99999) { fragColour = vec4(1.0); return; }\n  vec3 P = viewPos(vUv);\n  // The surface's facing from its neighbours, taking whichever side is\n  // nearer so an edge does not tilt it.\n  vec3 pr = viewPos(vUv + vec2(uTexel.x, 0.0)) - P, pl = P - viewPos(vUv - vec2(uTexel.x, 0.0));\n  vec3 pu = viewPos(vUv + vec2(0.0, uTexel.y)) - P, pd = P - viewPos(vUv - vec2(0.0, uTexel.y));\n  vec3 dx = abs(pr.z) < abs(pl.z) ? pr : pl;\n  vec3 dy = abs(pu.z) < abs(pd.z) ? pu : pd;\n  vec3 N = normalize(cross(dx, dy));\n\n  // How big the radius is on screen here.\n  float screenR = uRadius * uProjScale / max(-P.z, 0.1);\n  if (screenR < uTexel.x * 1.5) { fragColour = vec4(1.0); return; }\n  float spin = 6.2831853 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));\n  float r2 = uRadius * uRadius;\n  float sum = 0.0;\n  for (int i = 0; i < 24; i++) {\n    if (i >= uSamples) break;\n    float t = (float(i) + 0.5) / float(uSamples);\n    float a = spin + float(i) * 2.39996323;\n    vec2 off = vec2(cos(a), sin(a)) * screenR * sqrt(t);\n    vec3 v = viewPos(vUv + off) - P;\n    float vv = dot(v, v);\n    float vn = dot(v, N);\n    // Further than the radius counts for less, and not at all well past it.\n    float fall = max(0.0, 1.0 - vv / (r2 * 1.6));\n    sum += max(0.0, vn + P.z * 0.0015) / (vv + 0.0005) * fall;\n  }\n  float ao = max(0.0, 1.0 - 2.0 * uIntensity * sum / float(uSamples) * uRadius * 0.6);\n  fragColour = vec4(ao, ao, ao, 1.0);\n}", Ro = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uAo;\nuniform sampler2D uDepth;\nuniform vec2 uTexel;     // of the occlusion texture\nuniform vec2 uNearFar;\nout vec4 fragColour;\n\nfloat linear(float d) {\n  float z = d * 2.0 - 1.0;\n  return 2.0 * uNearFar.x * uNearFar.y / (uNearFar.y + uNearFar.x - z * (uNearFar.y - uNearFar.x));\n}\n\nvoid main() {\n  float centre = linear(texture(uDepth, vUv).r);\n  float sum = 0.0, weight = 0.0;\n  for (int y = -2; y <= 1; y++) {\n    for (int x = -2; x <= 1; x++) {\n      vec2 uv = vUv + (vec2(float(x), float(y)) + 0.5) * uTexel;\n      float z = linear(texture(uDepth, uv).r);\n      float w = 1.0 / (1.0 + abs(z - centre) * 8.0 / max(centre, 0.5));\n      sum += texture(uAo, uv).r * w;\n      weight += w;\n    }\n  }\n  float ao = sum / max(weight, 1e-4);\n  fragColour = vec4(ao, ao, ao, 1.0);\n}", Po = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uSource;\nuniform vec2 uTexel;\nuniform float uThreshold;\nout vec4 fragColour;\nvoid main() {\n  vec3 c = 0.25 * (\n    texture(uSource, vUv + uTexel * vec2(-1.0, -1.0)).rgb + texture(uSource, vUv + uTexel * vec2(1.0, -1.0)).rgb +\n    texture(uSource, vUv + uTexel * vec2(-1.0, 1.0)).rgb + texture(uSource, vUv + uTexel * vec2(1.0, 1.0)).rgb);\n  float bright = max(c.r, max(c.g, c.b));\n  // A soft knee rather than a hard cut, so things fade into glowing.\n  float knee = uThreshold * 0.5;\n  float soft = clamp(bright - uThreshold + knee, 0.0, 2.0 * knee);\n  soft = soft * soft / (4.0 * knee + 1e-4);\n  float keep = max(soft, bright - uThreshold) / max(bright, 1e-4);\n  fragColour = vec4(min(c * keep, vec3(32.0)), 1.0);\n}", Fo = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uSource;\nuniform vec2 uTexel;     // of the source\nout vec4 fragColour;\nvoid main() {\n  vec3 c = texture(uSource, vUv).rgb * 4.0;\n  c += texture(uSource, vUv + uTexel * vec2(-1.0, -1.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(1.0, -1.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(-1.0, 1.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(1.0, 1.0)).rgb;\n  fragColour = vec4(c / 8.0, 1.0);\n}", ko = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uSource;\nuniform vec2 uTexel;     // of the source\nout vec4 fragColour;\nvoid main() {\n  vec3 c = vec3(0.0);\n  c += texture(uSource, vUv + uTexel * vec2(-2.0, 0.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(2.0, 0.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(0.0, -2.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(0.0, 2.0)).rgb;\n  c += texture(uSource, vUv + uTexel * vec2(-1.0, -1.0)).rgb * 2.0;\n  c += texture(uSource, vUv + uTexel * vec2(1.0, -1.0)).rgb * 2.0;\n  c += texture(uSource, vUv + uTexel * vec2(-1.0, 1.0)).rgb * 2.0;\n  c += texture(uSource, vUv + uTexel * vec2(1.0, 1.0)).rgb * 2.0;\n  fragColour = vec4(c / 12.0, 1.0);\n}", Co = "#version 300 es\nprecision highp float;\nin vec2 vUv;\nuniform sampler2D uColour;\nuniform sampler2D uAo;\nuniform sampler2D uBloom;\nuniform bool uHdr;\nuniform bool uUseAo;\nuniform bool uUseBloom;\nuniform float uExposure;\nuniform float uAoStrength;\nuniform float uBloomStrength;\nuniform float uSaturation;\nuniform float uContrast;\nuniform float uVignette;\nuniform vec3 uTint;\nuniform int uDebug;\nout vec4 fragColour;\n\nvec3 aces(vec3 x) {\n  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);\n}\n\nvoid main() {\n  if (uDebug == 1) { fragColour = vec4(texture(uAo, vUv).rrr, 1.0); return; }\n  vec3 c = texture(uColour, vUv).rgb;\n  if (uUseAo) {\n    float ao = texture(uAo, vUv).r;\n    c *= mix(1.0, ao, uAoStrength);\n  }\n  if (uUseBloom) c += texture(uBloom, vUv).rgb * uBloomStrength;\n  if (uHdr) c = pow(aces(c * uExposure), vec3(1.0 / 2.2));\n  c = clamp(c, 0.0, 1.0);\n  // The grade: a gentle S of contrast, saturation round the luminance, a tint.\n  float l = dot(c, vec3(0.2126, 0.7152, 0.0722));\n  c = mix(vec3(l), c, uSaturation);\n  c = clamp((c - 0.5) * uContrast + 0.5, 0.0, 1.0);\n  c *= uTint;\n  vec2 q = vUv - 0.5;\n  c *= 1.0 - uVignette * smoothstep(0.25, 0.85, dot(q, q) * 2.2);\n  // Dither: a fraction of a step of noise so smooth dark gradients do not band.\n  float n = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));\n  c += (n - 0.5) / 255.0;\n  fragColour = vec4(c, 1.0);\n}";
function Qe(F, m, u, S, E, h, A) {
  let v = F.createTexture();
  F.bindTexture(F.TEXTURE_2D, v), F.texImage2D(F.TEXTURE_2D, 0, S, m, u, 0, E, h, null), F.texParameteri(F.TEXTURE_2D, F.TEXTURE_MIN_FILTER, A), F.texParameteri(F.TEXTURE_2D, F.TEXTURE_MAG_FILTER, A), F.texParameteri(F.TEXTURE_2D, F.TEXTURE_WRAP_S, F.CLAMP_TO_EDGE), F.texParameteri(F.TEXTURE_2D, F.TEXTURE_WRAP_T, F.CLAMP_TO_EDGE);
  let g = F.createFramebuffer();
  F.bindFramebuffer(F.FRAMEBUFFER, g), F.framebufferTexture2D(F.FRAMEBUFFER, F.COLOR_ATTACHMENT0, F.TEXTURE_2D, v, 0);
  let b = F.checkFramebufferStatus(F.FRAMEBUFFER) === F.FRAMEBUFFER_COMPLETE;
  return F.bindFramebuffer(F.FRAMEBUFFER, null), { tex: v, fb: g, w: m, h: u, ok: b };
}
var te = { 1: { aoSamples: 10, aoRadius: 0.6, aoIntensity: 1.5, aoStrength: 0.9, bloom: 4, bloomStrength: 0.5, threshold: 0.95 }, 2: { aoSamples: 16, aoRadius: 0.8, aoIntensity: 1.7, aoStrength: 1, bloom: 5, bloomStrength: 0.6, threshold: 0.9 } }, Te = class {
  constructor(c) {
    this.gl = c, this.failed = false, this.hdr = !!(c.getExtension("EXT_color_buffer_float") || c.getExtension("EXT_color_buffer_half_float")), this.programs = null, this.size = null, this.vao = c.createVertexArray(), this.grade = { exposure: 1, saturation: 0.97, contrast: 1.05, vignette: 0.26, tint: [1, 1, 1] }, this.debug = "";
  }
  ["_programs"]() {
    if (this.programs) return this.programs;
    let c = this.gl;
    return this.programs = { ao: ut(c, Gt, Ao, "post ao"), blur: ut(c, Gt, Ro, "post blur"), bright: ut(c, Gt, Po, "post bright"), down: ut(c, Gt, Fo, "post down"), up: ut(c, Gt, ko, "post up"), composite: ut(c, Gt, Co, "post composite") }, this.programs;
  }
  ["begin"](c, l, F) {
    if (this.failed) return null;
    let m = this.size;
    if (m && m.width === c && m.height === l && m.samples === F) return m.sceneFb;
    this.dispose();
    try {
      return this._programs(), this._make(c, l, F), this.size.sceneFb;
    } catch (u) {
      return console.warn("[render] post effects are off:", u.message), this.dispose(), this.failed = true, null;
    }
  }
  ["_make"](F, S, E) {
    let A = this.gl, O = this.hdr ? A.RGBA16F : A.RGBA8, M = A.createFramebuffer(), T = A.createRenderbuffer(), x = A.createRenderbuffer();
    if (A.bindRenderbuffer(A.RENDERBUFFER, T), E ? A.renderbufferStorageMultisample(A.RENDERBUFFER, E, O, F, S) : A.renderbufferStorage(A.RENDERBUFFER, O, F, S), A.bindRenderbuffer(A.RENDERBUFFER, x), E ? A.renderbufferStorageMultisample(A.RENDERBUFFER, E, A.DEPTH_COMPONENT24, F, S) : A.renderbufferStorage(A.RENDERBUFFER, A.DEPTH_COMPONENT24, F, S), A.bindFramebuffer(A.FRAMEBUFFER, M), A.framebufferRenderbuffer(A.FRAMEBUFFER, A.COLOR_ATTACHMENT0, A.RENDERBUFFER, T), A.framebufferRenderbuffer(A.FRAMEBUFFER, A.DEPTH_ATTACHMENT, A.RENDERBUFFER, x), A.checkFramebufferStatus(A.FRAMEBUFFER) !== A.FRAMEBUFFER_COMPLETE) throw new Error("scene buffer incomplete");
    let q = A.createTexture();
    A.bindTexture(A.TEXTURE_2D, q), A.texImage2D(A.TEXTURE_2D, 0, O, F, S, 0, A.RGBA, this.hdr ? A.HALF_FLOAT : A.UNSIGNED_BYTE, null);
    for (let [d4, d5] of [[A.TEXTURE_MIN_FILTER, A.LINEAR], [A.TEXTURE_MAG_FILTER, A.LINEAR], [A.TEXTURE_WRAP_S, A.CLAMP_TO_EDGE], [A.TEXTURE_WRAP_T, A.CLAMP_TO_EDGE]]) A.texParameteri(A.TEXTURE_2D, d4, d5);
    let L = A.createTexture();
    A.bindTexture(A.TEXTURE_2D, L), A.texImage2D(A.TEXTURE_2D, 0, A.DEPTH_COMPONENT24, F, S, 0, A.DEPTH_COMPONENT, A.UNSIGNED_INT, null);
    for (let [d6, d7] of [[A.TEXTURE_MIN_FILTER, A.NEAREST], [A.TEXTURE_MAG_FILTER, A.NEAREST], [A.TEXTURE_WRAP_S, A.CLAMP_TO_EDGE], [A.TEXTURE_WRAP_T, A.CLAMP_TO_EDGE]]) A.texParameteri(A.TEXTURE_2D, d6, d7);
    let I = A.createFramebuffer();
    if (A.bindFramebuffer(A.FRAMEBUFFER, I), A.framebufferTexture2D(A.FRAMEBUFFER, A.COLOR_ATTACHMENT0, A.TEXTURE_2D, q, 0), A.framebufferTexture2D(A.FRAMEBUFFER, A.DEPTH_ATTACHMENT, A.TEXTURE_2D, L, 0), A.checkFramebufferStatus(A.FRAMEBUFFER) !== A.FRAMEBUFFER_COMPLETE) throw new Error("resolve buffer incomplete");
    A.bindFramebuffer(A.FRAMEBUFFER, null);
    let z = Math.max(1, F >> 1), K = Math.max(1, S >> 1), H = Qe(A, z, K, A.RGBA8, A.RGBA, A.UNSIGNED_BYTE, A.LINEAR), d0 = Qe(A, z, K, A.RGBA8, A.RGBA, A.UNSIGNED_BYTE, A.LINEAR), d1 = [], d2 = z, d3 = K;
    for (let d8 = 0; d8 < 6; d8++) d1.push(Qe(A, d2, d3, O, A.RGBA, this.hdr ? A.HALF_FLOAT : A.UNSIGNED_BYTE, A.LINEAR)), d2 = Math.max(1, d2 >> 1), d3 = Math.max(1, d3 >> 1);
    if (![H, d0, ...d1].every((d9) => d9.ok)) throw new Error("effect buffers incomplete");
    this.size = { width: F, height: S, samples: E, sceneFb: M, sceneColour: T, sceneDepth: x, resolveFb: I, colourTex: q, depthTex: L, ao: H, aoBlur: d0, chain: d1 };
  }
  ["dispose"]() {
    let c = this.size;
    if (!c) return;
    let l = this.gl;
    l.deleteFramebuffer(c.sceneFb), l.deleteRenderbuffer(c.sceneColour), l.deleteRenderbuffer(c.sceneDepth), l.deleteFramebuffer(c.resolveFb), l.deleteTexture(c.colourTex), l.deleteTexture(c.depthTex);
    for (let F of [c.ao, c.aoBlur, ...c.chain]) l.deleteFramebuffer(F.fb), l.deleteTexture(F.tex);
    this.size = null;
  }
  ["keepDepth"]() {
    let c = this.gl, l = this.size;
    c.bindFramebuffer(c.READ_FRAMEBUFFER, l.sceneFb), c.bindFramebuffer(c.DRAW_FRAMEBUFFER, l.resolveFb), c.blitFramebuffer(0, 0, l.width, l.height, 0, 0, l.width, l.height, c.DEPTH_BUFFER_BIT, c.NEAREST), c.bindFramebuffer(c.FRAMEBUFFER, l.sceneFb);
  }
  ["_pass"](c, l, F, m, u) {
    let S = this.gl;
    S.bindFramebuffer(S.FRAMEBUFFER, l), S.viewport(0, 0, F, m), S.useProgram(c.program), u(c.uniforms), S.drawArrays(S.TRIANGLES, 0, 3);
  }
  ["_bind"](c, l, F) {
    let m = this.gl;
    m.activeTexture(m.TEXTURE0 + c), m.bindTexture(m.TEXTURE_2D, l), m.uniform1i(F, c);
  }
  ["finish"](F, m) {
    let S = this.gl, E = this.size, A = this.programs, v = te[m] || te[1];
    S.bindFramebuffer(S.READ_FRAMEBUFFER, E.sceneFb), S.bindFramebuffer(S.DRAW_FRAMEBUFFER, E.resolveFb), S.blitFramebuffer(0, 0, E.width, E.height, 0, 0, E.width, E.height, S.COLOR_BUFFER_BIT, S.NEAREST), S.disable(S.DEPTH_TEST), S.disable(S.CULL_FACE), S.disable(S.BLEND), S.depthMask(false), S.bindVertexArray(this.vao);
    let g = F.projection, b = F.inverseProjection || (F.inverseProjection = new Float32Array(16));
    Io(b, g), this._pass(A.ao, E.ao.fb, E.ao.w, E.ao.h, (T) => {
      this._bind(0, E.depthTex, T.uDepth), S.uniformMatrix4fv(T.uInvProj, false, b), S.uniform2f(T.uTexel, 1 / E.ao.w, 1 / E.ao.h), S.uniform1f(T.uRadius, v.aoRadius), S.uniform1f(T.uIntensity, v.aoIntensity), S.uniform1f(T.uProjScale, g[5] * 0.5), S.uniform1i(T.uSamples, v.aoSamples);
    }), this._pass(A.blur, E.aoBlur.fb, E.aoBlur.w, E.aoBlur.h, (T) => {
      this._bind(0, E.ao.tex, T.uAo), this._bind(1, E.depthTex, T.uDepth), S.uniform2f(T.uTexel, 1 / E.ao.w, 1 / E.ao.h), S.uniform2f(T.uNearFar, F.near, F.far);
    });
    let O = Math.min(v.bloom, E.chain.length);
    this._pass(A.bright, E.chain[0].fb, E.chain[0].w, E.chain[0].h, (T) => {
      this._bind(0, E.colourTex, T.uSource), S.uniform2f(T.uTexel, 1 / E.width, 1 / E.height), S.uniform1f(T.uThreshold, this.hdr ? v.threshold : 0.82);
    });
    for (let T = 1; T < O; T++) {
      let x = E.chain[T - 1], y = E.chain[T];
      this._pass(A.down, y.fb, y.w, y.h, (w) => {
        this._bind(0, x.tex, w.uSource), S.uniform2f(w.uTexel, 1 / x.w, 1 / x.h);
      });
    }
    S.enable(S.BLEND), S.blendFunc(S.ONE, S.ONE);
    for (let w = O - 1; w > 0; w--) {
      let q = E.chain[w], L = E.chain[w - 1];
      this._pass(A.up, L.fb, L.w, L.h, (I) => {
        this._bind(0, q.tex, I.uSource), S.uniform2f(I.uTexel, 1 / q.w, 1 / q.h);
      });
    }
    S.disable(S.BLEND);
    let M = this.grade;
    this._pass(A.composite, null, E.width, E.height, (p) => {
      this._bind(0, E.colourTex, p.uColour), this._bind(1, E.aoBlur.tex, p.uAo), this._bind(2, E.chain[0].tex, p.uBloom), S.uniform1i(p.uHdr, this.hdr ? 1 : 0), S.uniform1i(p.uUseAo, 1), S.uniform1i(p.uUseBloom, O > 0 ? 1 : 0), S.uniform1f(p.uExposure, M.exposure), S.uniform1f(p.uAoStrength, v.aoStrength), S.uniform1f(p.uBloomStrength, v.bloomStrength / Math.max(1, O - 1)), S.uniform1f(p.uSaturation, M.saturation), S.uniform1f(p.uContrast, M.contrast), S.uniform1f(p.uVignette, M.vignette), S.uniform3fv(p.uTint, M.tint), S.uniform1i(p.uDebug, this.debug === "ao" ? 1 : 0);
    }), S.enable(S.DEPTH_TEST), S.enable(S.CULL_FACE), S.depthMask(true), S.bindVertexArray(null), S.activeTexture(S.TEXTURE0);
  }
};
function Io(q, L) {
  let z = L[0], K = L[1], H = L[2], d0 = L[3], d1 = L[4], d2 = L[5], d3 = L[6], d4 = L[7], d5 = L[8], d6 = L[9], d7 = L[10], d8 = L[11], d9 = L[12], dd = L[13], dC = L[14], dc = L[15], dl = z * d2 - K * d1, dF = z * d3 - H * d1, dk = z * d4 - d0 * d1, dm = K * d3 - H * d2, du = K * d4 - d0 * d2, dj = H * d4 - d0 * d3, dW = d5 * dd - d6 * d9, dS = d5 * dC - d7 * d9, dE = d5 * dc - d8 * d9, dh = d6 * dC - d7 * dd, dA = d6 * dc - d8 * dd, dv = d7 * dc - d8 * dC, dZ = dl * dv - dF * dA + dk * dh + dm * dE - du * dS + dj * dW;
  return dZ && (dZ = 1 / dZ, q[0] = (d2 * dv - d3 * dA + d4 * dh) * dZ, q[1] = (H * dA - K * dv - d0 * dh) * dZ, q[2] = (dd * dj - dC * du + dc * dm) * dZ, q[3] = (d7 * du - d6 * dj - d8 * dm) * dZ, q[4] = (d3 * dE - d1 * dv - d4 * dS) * dZ, q[5] = (z * dv - H * dE + d0 * dS) * dZ, q[6] = (dC * dk - d9 * dj - dc * dF) * dZ, q[7] = (d5 * dj - d7 * dk + d8 * dF) * dZ, q[8] = (d1 * dA - d2 * dE + d4 * dW) * dZ, q[9] = (K * dE - z * dA - d0 * dW) * dZ, q[10] = (d9 * du - dd * dk + dc * dl) * dZ, q[11] = (d6 * dk - d5 * du - d8 * dl) * dZ, q[12] = (d2 * dS - d1 * dh - d3 * dW) * dZ, q[13] = (z * dh - K * dS + H * dW) * dZ, q[14] = (dd * dF - d9 * dm - dC * dl) * dZ, q[15] = (d5 * dm - d6 * dF + d7 * dl) * dZ), q;
}
var xi = "#version 300 es\nprecision highp float;\n\nlayout(location = 0) in vec3 aPosition;\nlayout(location = 1) in vec3 aNormal;\nlayout(location = 2) in vec2 aUv;\nlayout(location = 4) in vec4 aJoints;\nlayout(location = 5) in vec4 aWeights;\n\nuniform mat4 uModel;\nuniform mat4 uViewProjection;\nuniform mat4 uLightViewProjection;\nuniform mat3 uNormalMatrix;\n\n// Skinning. uJoints holds one matrix per bone, already multiplied by\n// that bone's inverse bind matrix, so the shader does nothing but mix\n// them. MAX_JOINTS is what fits in the guaranteed vertex uniform\n// budget with room left for everything else.\nconst int MAX_JOINTS = 48;\nuniform bool uSkinned;\nuniform mat4 uJoints[MAX_JOINTS];\n\nout vec3 vWorldPos;\nout vec3 vNormal;\nout vec2 vUv;\nout vec4 vLightSpace;\n\nmat4 skinMatrix() {\n  // Weights are normalised by the exporter, but not always exactly, so\n  // a vertex whose weights sum to 0.98 would quietly shrink. Summing\n  // and dividing costs nothing and removes the whole class of bug.\n  mat4 m = uJoints[int(aJoints.x)] * aWeights.x\n         + uJoints[int(aJoints.y)] * aWeights.y\n         + uJoints[int(aJoints.z)] * aWeights.z\n         + uJoints[int(aJoints.w)] * aWeights.w;\n  float total = aWeights.x + aWeights.y + aWeights.z + aWeights.w;\n  return total > 0.0001 ? m / total : mat4(1.0);\n}\n\nvoid main() {\n  vec3 position = aPosition;\n  vec3 normal = aNormal;\n  if (uSkinned) {\n    mat4 skin = skinMatrix();\n    position = (skin * vec4(aPosition, 1.0)).xyz;\n    normal = mat3(skin) * aNormal;\n  }\n\n  vec4 world = uModel * vec4(position, 1.0);\n  vWorldPos = world.xyz;\n  // The inverse-transpose, so non-uniform scale does not skew the normal.\n  vNormal = normalize(uNormalMatrix * normal);\n  vUv = aUv;\n  vLightSpace = uLightViewProjection * world;\n  gl_Position = uViewProjection * world;\n}", bi = "#version 300 es\nprecision highp float;\n\nin vec3 vWorldPos;\nin vec3 vNormal;\nin vec2 vUv;\nin vec4 vLightSpace;\n\nuniform vec3 uColour;\nuniform float uAlpha;\nuniform vec3 uCameraPos;\nuniform vec3 uSunDirection;\nuniform vec3 uSunColour;\nuniform vec3 uSkyColour;\nuniform vec3 uGroundColour;\nuniform float uRoughness;\nuniform float uMetallic;\nuniform vec3 uEmissive;\nuniform float uGridScale;\nuniform float uAlphaCutoff;\n\nuniform sampler2D uBaseColourMap;\nuniform highp sampler2DShadow uShadowMap;\nuniform bool uHasBaseColour;\n/** The glow takes its colour from the map (a sign's words). */\nuniform bool uGlowMap;\nuniform bool uShadows;\nuniform vec2 uShadowTexel;\n// 1 a hard edge, 4 a soft one, 12 a wide soft penumbra. Set by the\n// graphics tier (render/quality.js).\nuniform int uShadowTaps;\n// 0 plain diffuse, 1 the full material model, 2 plus sky reflections,\n// 3 plus a rim of sky light and a little air in the distance.\nuniform int uLighting;\nuniform vec3 uZenithColour;\nuniform float uFogDensity;\n// When the frame goes on to the effects pass (High, Ultra) it is left in\n// linear light above 1.0 and toned there; otherwise it is toned here.\nuniform bool uLinearOut;\nuniform float uExposure;\n// A mirror: the world reflected in it, drawn into uReflection, and where\n// each point of the glass lands in that picture.\nuniform bool uReflect;\nuniform mat4 uReflectMatrix;\nuniform sampler2D uReflection;\n// How much light the sky and the ground give the shadows: 1 for open air,\n// less indoors, where the light is the sun coming in.\nuniform float uAmbientScale;\n// Point lights: lamps, neon, blacklights. Only the few nearest the camera\n// are given each frame (see Renderer._lights), xyz where and w how far it\n// reaches, with its colour already times how bright.\n#define MAX_POINT_LIGHTS 8\nuniform int uPointCount;\nuniform vec4 uPointPos[MAX_POINT_LIGHTS];\nuniform vec3 uPointColour[MAX_POINT_LIGHTS];\n\nout vec4 fragColour;\n\nconst float PI = 3.14159265359;\n\n// Hemisphere ambient: sky from above, bounced ground light from below.\n// Two colours rather than one flat term is most of what stops an\n// untextured scene looking like cardboard, and it costs nothing.\nvec3 ambient(vec3 n) {\n  return mix(uGroundColour, uSkyColour, n.y * 0.5 + 0.5) * uAmbientScale;\n}\n\n// A filmic curve (the ACES fit): rich mid tones, highlights that roll off\n// instead of clipping, the look of a render rather than a flat game.\nvec3 aces(vec3 x) {\n  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);\n}\nvec3 toScreen(vec3 c) {\n  if (uLinearOut) return c;\n  return pow(aces(c * uExposure), vec3(1.0 / 2.2));\n}\n\nfloat grid(vec2 p, float scale) {\n  vec2 coord = p * scale;\n  vec2 d = fwidth(coord);\n  vec2 g = abs(fract(coord - 0.5) - 0.5) / d;\n  return 1.0 - min(min(g.x, g.y), 1.0);\n}\n\n// \u2500\u2500 microfacet terms \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\n// Real GGX rather than Blinn-Phong. The difference shows on exactly the\n// thing people import: a metal or a smooth plastic, where Blinn-Phong's\n// highlight is the wrong shape and metals read as grey plastic.\nfloat distributionGGX(float ndoth, float roughness) {\n  float a = roughness * roughness;\n  float a2 = a * a;\n  float d = ndoth * ndoth * (a2 - 1.0) + 1.0;\n  return a2 / max(PI * d * d, 1e-5);\n}\n\nfloat geometrySmith(float ndotv, float ndotl, float roughness) {\n  float r = roughness + 1.0;\n  float k = (r * r) / 8.0;\n  float gv = ndotv / (ndotv * (1.0 - k) + k);\n  float gl = ndotl / (ndotl * (1.0 - k) + k);\n  return gv * gl;\n}\n\nvec3 fresnelSchlick(float cosTheta, vec3 f0) {\n  return f0 + (1.0 - f0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);\n}\n\n// \u2500\u2500 shadows \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\nconst vec2 POISSON[12] = vec2[12](\n  vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696,  0.457), vec2(-0.203,  0.621),\n  vec2( 0.962, -0.195), vec2( 0.473, -0.480), vec2( 0.519,  0.767), vec2( 0.185, -0.893),\n  vec2( 0.507,  0.064), vec2( 0.896,  0.412), vec2(-0.322, -0.933), vec2(-0.792, -0.598));\n\nfloat shadowAt(vec4 lightSpace, float ndotl) {\n  if (!uShadows) return 1.0;\n  vec3 proj = lightSpace.xyz / lightSpace.w;\n  proj = proj * 0.5 + 0.5;\n  // Outside the map is LIT, not dark. Treating it as shadowed draws a\n  // hard black edge across the world where the map runs out.\n  if (proj.z > 1.0 || proj.x < 0.0 || proj.x > 1.0 || proj.y < 0.0 || proj.y > 1.0) return 1.0;\n\n  // Slope-scaled bias. A constant one either stripes every surface with\n  // its own shadow, or detaches the shadow from whatever cast it.\n  float bias = max(0.0015 * (1.0 - ndotl), 0.0004);\n\n  // The GPU does the comparing: a shadow sampler with linear filtering\n  // compares against the four nearest texels and blends the answers in\n  // one fetch. One fetch is already soft at the edge; four, half a texel\n  // apart, are softer than the nine-fetch filter this replaced and cost\n  // under half as much, which on a big screen is a lot of pixels.\n  float ref = proj.z - bias;\n  if (uShadowTaps <= 1) return texture(uShadowMap, vec3(proj.xy, ref));\n  if (uShadowTaps <= 4) {\n    vec2 o = uShadowTexel * 0.5;\n    return 0.25 * (\n      texture(uShadowMap, vec3(proj.xy + vec2(-o.x, -o.y), ref)) +\n      texture(uShadowMap, vec3(proj.xy + vec2( o.x, -o.y), ref)) +\n      texture(uShadowMap, vec3(proj.xy + vec2(-o.x,  o.y), ref)) +\n      texture(uShadowMap, vec3(proj.xy + vec2( o.x,  o.y), ref)));\n  }\n  // Wide and soft: a dozen taps on a disc a few texels across, the disc\n  // turned a different way at every pixel so the pattern breaks up into\n  // fine grain instead of showing as rings. A little more bias, since the\n  // taps reach further across a sloped surface.\n  float turn = 6.2831853 * fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));\n  float c = cos(turn), s = sin(turn);\n  mat2 spin = mat2(c, -s, s, c);\n  vec2 radius = uShadowTexel * 2.4;\n  float wide = proj.z - bias * 1.6;\n  float sum = 0.0;\n  for (int i = 0; i < 12; i++) {\n    sum += texture(uShadowMap, vec3(proj.xy + spin * POISSON[i] * radius, wide));\n  }\n  return sum / 12.0;\n}\n\n// What the point lights add: diffuse, and (above the lowest tier) their\n// highlight. Each fades to nothing at the edge of its reach, smoothly, so a\n// light never ends in a hard circle on the floor.\nvec3 pointLights(vec3 n, vec3 v, vec3 albedo, vec3 f0, float rough, float metal, bool shiny) {\n  vec3 sum = vec3(0.0);\n  for (int i = 0; i < MAX_POINT_LIGHTS; i++) {\n    if (i >= uPointCount) break;\n    vec3 toLight = uPointPos[i].xyz - vWorldPos;\n    float d = length(toLight);\n    float range = uPointPos[i].w;\n    if (d >= range) continue;\n    vec3 l = toLight / max(d, 1e-4);\n    float ndotl = max(dot(n, l), 0.0);\n    if (ndotl <= 0.0) continue;\n    float x = d / range;\n    float window = clamp(1.0 - x * x * x * x, 0.0, 1.0);\n    vec3 radiance = uPointColour[i] * (window * window / (1.0 + d * d));\n    vec3 diffuse = (1.0 - metal) * albedo / PI;\n    vec3 spec = vec3(0.0);\n    if (shiny) {\n      vec3 h = normalize(v + l);\n      float ndotv = max(dot(n, v), 1e-4);\n      vec3 f = fresnelSchlick(max(dot(h, v), 0.0), f0);\n      spec = (distributionGGX(max(dot(n, h), 0.0), rough) * geometrySmith(ndotv, ndotl, rough) * f) / max(4.0 * ndotv * ndotl, 1e-4);\n      diffuse *= vec3(1.0) - f;\n    }\n    sum += (diffuse + spec) * radiance * ndotl;\n  }\n  return sum;\n}\n\nvoid main() {\n  // A mirror shows what is in front of it, already lit (and toned, when\n  // this pass tones), with a touch of the glass's own tint and sheen.\n  if (uReflect) {\n    vec4 at = uReflectMatrix * vec4(vWorldPos, 1.0);\n    vec3 seen = texture(uReflection, at.xy / at.w).rgb;\n    fragColour = vec4(seen * vec3(0.94, 0.96, 0.98), 1.0);\n    return;\n  }\n  vec3 n = normalize(vNormal);\n  vec3 v = normalize(uCameraPos - vWorldPos);\n  vec3 l = normalize(uSunDirection);\n  vec3 h = normalize(v + l);\n\n  vec4 base = vec4(uColour, uAlpha);\n  vec3 glow = uEmissive;\n  if (uHasBaseColour) {\n    vec4 sampled = texture(uBaseColourMap, vUv);\n    // glTF base colour textures are sRGB and the factor is linear.\n    // Skipping this makes every imported model look washed out.\n    vec3 picture = pow(sampled.rgb, vec3(2.2));\n    base *= vec4(picture, sampled.a);\n    if (uGlowMap) glow *= picture;\n  }\n  if (base.a < uAlphaCutoff) discard;\n\n  vec3 albedo = base.rgb;\n  if (uGridScale > 0.0) albedo = mix(albedo, albedo * 0.55, grid(vWorldPos.xz, uGridScale) * 0.8);\n\n  float ndotl = max(dot(n, l), 0.0);\n  float ndotv = max(dot(n, v), 1e-4);\n  float ndoth = max(dot(n, h), 0.0);\n\n  // The lowest tier: diffuse sun and the two-colour ambient, no highlight.\n  // Most of the look for a fraction of the arithmetic.\n  if (uLighting == 0) {\n    float flat_shadow = shadowAt(vLightSpace, ndotl);\n    vec3 plain = albedo * (uSunColour * ndotl * flat_shadow / PI + ambient(n)) + glow\n      + pointLights(n, v, albedo, vec3(0.04), 1.0, 0.0, false);\n    fragColour = vec4(toScreen(plain), base.a);\n    return;\n  }\n\n  // Metals have no diffuse and tint their reflection; dielectrics reflect\n  // 4% white. This line is why gold looks like gold.\n  vec3 f0 = mix(vec3(0.04), albedo, uMetallic);\n  vec3 f = fresnelSchlick(max(dot(h, v), 0.0), f0);\n  float ndf = distributionGGX(ndoth, uRoughness);\n  float g = geometrySmith(ndotv, ndotl, uRoughness);\n  vec3 specular = (ndf * g * f) / max(4.0 * ndotv * ndotl, 1e-4);\n  vec3 diffuse = (vec3(1.0) - f) * (1.0 - uMetallic) * albedo / PI;\n\n  float shadow = shadowAt(vLightSpace, ndotl);\n  vec3 direct = (diffuse + specular) * uSunColour * ndotl * shadow;\n  vec3 indirect = albedo * ambient(n) * mix(1.0, 0.35, uMetallic);\n\n  // The sky, reflected. What makes metal read as metal and a polished\n  // floor as polished: the colour of the sky or the ground in the mirror\n  // direction, by how glossy the surface is and how grazing the view.\n  if (uLighting >= 2) {\n    vec3 r = reflect(-v, n);\n    vec3 env = r.y >= 0.0\n      ? mix(uSkyColour, uZenithColour, pow(r.y, 0.45))\n      : mix(uSkyColour, uGroundColour, smoothstep(0.0, 0.25, -r.y));\n    float gloss = (1.0 - uRoughness) * (1.0 - uRoughness);\n    vec3 fr = f0 + (max(vec3(1.0 - uRoughness), f0) - f0) * pow(1.0 - ndotv, 5.0);\n    indirect += env * fr * gloss * mix(0.6, 1.0, shadow);\n  }\n  // A rim of sky light on the edges facing away from you, which lifts\n  // people and furniture off the background.\n  if (uLighting >= 3) {\n    float rim = pow(1.0 - ndotv, 4.0) * (0.55 + 0.45 * n.y);\n    indirect += uSkyColour * rim * 0.16 * (1.0 - uMetallic * 0.5);\n  }\n\n  vec3 lit = direct + indirect + glow + pointLights(n, v, albedo, f0, max(uRoughness, 0.08), uMetallic, true);\n  // A little air: far things lean towards the horizon colour, which is\n  // what gives a big space its depth. Nothing within the first 30 metres.\n  if (uLighting >= 3 && uFogDensity > 0.0) {\n    float d = max(length(uCameraPos - vWorldPos) - 30.0, 0.0);\n    lit = mix(lit, uSkyColour, (1.0 - exp(-d * uFogDensity)) * 0.55);\n  }\n  fragColour = vec4(toScreen(lit), base.a);\n}", Ei = "#version 300 es\nprecision highp float;\nlayout(location = 0) in vec3 aPosition;\nlayout(location = 4) in vec4 aJoints;\nlayout(location = 5) in vec4 aWeights;\nuniform mat4 uModel;\nuniform mat4 uLightViewProjection;\n\nconst int MAX_JOINTS = 48;\nuniform bool uSkinned;\nuniform mat4 uJoints[MAX_JOINTS];\n\nvoid main() {\n  vec3 position = aPosition;\n  if (uSkinned) {\n    mat4 m = uJoints[int(aJoints.x)] * aWeights.x\n           + uJoints[int(aJoints.y)] * aWeights.y\n           + uJoints[int(aJoints.z)] * aWeights.z\n           + uJoints[int(aJoints.w)] * aWeights.w;\n    float total = aWeights.x + aWeights.y + aWeights.z + aWeights.w;\n    if (total > 0.0001) position = (m / total * vec4(aPosition, 1.0)).xyz;\n  }\n  gl_Position = uLightViewProjection * uModel * vec4(position, 1.0);\n}", Mi = "#version 300 es\nprecision highp float;\nvoid main() {}", Ti = "#version 300 es\nprecision highp float;\nout vec2 vNdc;\nvoid main() {\n  // One oversized triangle. Two would have a seam down the diagonal\n  // where the derivative misbehaves.\n  vec2 pos = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);\n  vNdc = pos * 2.0 - 1.0;\n  gl_Position = vec4(vNdc, 1.0, 1.0);\n}", Si = "#version 300 es\nprecision highp float;\n\nin vec2 vNdc;\n\nuniform mat4 uInverseViewProjection;\nuniform vec3 uCameraPos;\nuniform vec3 uSunDirection;\nuniform vec3 uSunColour;\nuniform vec3 uZenith;\nuniform vec3 uHorizon;\nuniform vec3 uGround;\nuniform float uSunSize;\nuniform float uStars;\nuniform bool uLinearOut;\nuniform float uExposure;\n\nout vec4 fragColour;\n\nfloat hash13(vec3 p) {\n  p = fract(p * 0.1031);\n  p += dot(p, p.zyx + 31.32);\n  return fract((p.x + p.y) * p.z);\n}\n\nvoid main() {\n  vec4 far = uInverseViewProjection * vec4(vNdc, 1.0, 1.0);\n  vec3 dir = normalize(far.xyz / far.w - uCameraPos);\n  float h = dir.y;\n\n  // A soft band where sky meets ground \u2014 a hard line at y=0 looks like a\n  // cut-out. pow() pulls the gradient towards the horizon, which is where\n  // a real sky changes fastest.\n  float horizonBlend = smoothstep(-0.08, 0.08, h);\n  vec3 sky = mix(uHorizon, uZenith, pow(clamp(h, 0.0, 1.0), 0.45));\n  vec3 colour = mix(uGround, sky, horizonBlend);\n\n  float cosAngle = dot(dir, normalize(uSunDirection));\n  float disc = smoothstep(1.0 - uSunSize, 1.0 - uSunSize * 0.35, cosAngle);\n  float halo = pow(max(cosAngle, 0.0), 220.0) * 0.6 + pow(max(cosAngle, 0.0), 12.0) * 0.12;\n  colour += uSunColour * (disc * 6.0 + halo);\n\n  // Light scattered near the horizon towards the sun \u2014 the thing that\n  // makes a sunset look like a sunset and not an orange gradient.\n  float groundward = 1.0 - smoothstep(0.0, 0.35, abs(h));\n  colour += uSunColour * pow(max(cosAngle, 0.0), 4.0) * groundward * 0.25;\n\n  // Stars, at night: one in a few cells of a grid round the sky, each a\n  // soft point somewhere in its cell, some brighter than others.\n  if (uStars > 0.0 && h > 0.0) {\n    vec3 p = dir * 170.0;\n    vec3 cell = floor(p);\n    float r = hash13(cell);\n    if (r > 0.982) {\n      vec3 centre = cell + 0.5 + (vec3(hash13(cell + 1.7), hash13(cell + 3.1), hash13(cell + 5.3)) - 0.5) * 0.5;\n      float d = length(p - centre);\n      float bright = (r - 0.982) / 0.018;\n      float star = smoothstep(0.32, 0.0, d) * (0.35 + bright * bright * 1.8);\n      vec3 tint = mix(vec3(0.75, 0.85, 1.0), vec3(1.0, 0.92, 0.8), hash13(cell + 9.1));\n      colour += tint * star * uStars * smoothstep(0.0, 0.12, h) * 2.4;\n    }\n  }\n\n  if (!uLinearOut) colour = pow(clamp((colour * uExposure * (2.51 * colour * uExposure + 0.03)) / (colour * uExposure * (2.43 * colour * uExposure + 0.59) + 0.14), 0.0, 1.0), vec3(1.0 / 2.2));\n  fragColour = vec4(colour, 1.0);\n}", $t = class n {
  constructor(c = {}) {
    this.zenith = c.zenith || [0.2, 0.4, 0.78], this.horizon = c.horizon || [0.72, 0.83, 0.94], this.ground = c.ground || [0.16, 0.17, 0.2], this.sunColour = c.sunColour || [1, 0.96, 0.88], this.sunElevation = c.sunElevation ?? 42, this.sunAzimuth = c.sunAzimuth ?? 130, this.sunSize = c.sunSize ?? 4e-3, this.stars = c.stars ?? 0, this.ambient = c.ambient ?? 1, this.exposure = c.exposure ?? 0.62, this._dir = _.create();
  }
  ["direction"]() {
    let c = this.sunElevation * Math.PI / 180, l = this.sunAzimuth * Math.PI / 180;
    return _.set(this._dir, Math.cos(c) * Math.sin(l), Math.sin(c), Math.cos(c) * Math.cos(l));
  }
  static ["preset"](c) {
    switch (c) {
      case "sunset":
        return new n({ zenith: [0.14, 0.16, 0.34], horizon: [0.95, 0.52, 0.26], ground: [0.1, 0.08, 0.07], sunColour: [1, 0.65, 0.35], sunElevation: 3, sunAzimuth: 250, sunSize: 8e-3 });
      case "night":
        return new n({ zenith: [0.02, 0.03, 0.07], horizon: [0.06, 0.08, 0.15], ground: [0.02, 0.02, 0.03], sunColour: [0.35, 0.42, 0.6], sunElevation: 28, sunAzimuth: 300, sunSize: 3e-3, stars: 1 });
      case "golden":
        return new n({ zenith: [0.3, 0.48, 0.8], horizon: [0.98, 0.8, 0.62], ground: [0.52, 0.34, 0.2], sunColour: [3.1, 2.35, 1.6], sunElevation: 31, sunAzimuth: 118, sunSize: 6e-3, ambient: 0.42, exposure: 0.78 });
      case "overcast":
        return new n({ zenith: [0.52, 0.55, 0.6], horizon: [0.7, 0.72, 0.75], ground: [0.18, 0.19, 0.2], sunColour: [0.55, 0.56, 0.58], sunElevation: 60, sunAzimuth: 180, sunSize: 0.02 });
      default:
        return new n();
    }
  }
}, ee = { VERTICAL: "vertical", HORIZONTAL: "horizontal" }, Lo = 16 / 9, se = class {
  constructor({ fov: c = 60, fovAxis: l = ee.VERTICAL, near: F = 0.05, far: m = 2e3 } = {}) {
    this.fov = c, this.fovAxis = l, this.near = F, this.far = m, this.minHorizontalFov = 60, this.position = _.create(0, 1.7, 5), this.view = P.create(), this.projection = P.create(), this.viewProjection = P.create(), this.inverseViewProjection = P.create(), this.yaw = 0, this.pitch = 0, this._target = _.create(), this._fwd = _.create();
  }
  ["forward"](c = this._fwd) {
    let l = Math.cos(this.pitch);
    return _.set(c, -Math.sin(this.yaw) * l, Math.sin(this.pitch), -Math.cos(this.yaw) * l);
  }
  ["verticalFov"](c) {
    let l = this.fov;
    if (this.fovAxis === ee.HORIZONTAL) {
      let F = this.fov * Math.PI / 180 / 2;
      l = 2 * Math.atan(Math.tan(F) / Lo) * 180 / Math.PI;
    }
    if (2 * Math.atan(Math.tan(l * Math.PI / 360) * c) * 180 / Math.PI < this.minHorizontalFov) {
      let m = this.minHorizontalFov * Math.PI / 180 / 2;
      l = 2 * Math.atan(Math.tan(m) / c) * 180 / Math.PI;
    }
    return Math.min(Math.max(l, 1), 170);
  }
  ["horizontalFov"](c) {
    return 2 * Math.atan(Math.tan(this.verticalFov(c) * Math.PI / 360) * c) * 180 / Math.PI;
  }
  ["update"](c) {
    return P.perspective(this.projection, this.verticalFov(c) * Math.PI / 180, c, this.near, this.far), _.add(this._target, this.position, this.forward()), P.lookAt(this.view, this.position, this._target, [0, 1, 0]), P.multiply(this.viewProjection, this.projection, this.view), P.invert(this.inverseViewProjection, this.viewProjection), this;
  }
}, ie = class extends zt {
  constructor(c) {
    super(), this.gl = c, this.backend = "webgl", this.surface = ut(c, xi, bi, "surface"), this.skyProgram = ut(c, Ti, Si, "sky"), this.depth = ut(c, Ei, Mi, "depth"), this.shadows = new ts(c, 2048), this._white = No(c), this.emptyVao = c.createVertexArray(), this._uploaded = /* @__PURE__ */ new WeakMap(), this._msaa = null, this._textures = /* @__PURE__ */ new Set(), this._byImage = /* @__PURE__ */ new WeakMap(), this.maxSamples = (() => {
      try {
        return c.getParameter(c.MAX_SAMPLES) || 0;
      } catch {
        return 0;
      }
    })(), Ri(c);
  }
  ["configure"](c = {}) {
    if (c.lighting !== void 0 && (this.lighting = c.lighting | 0), c.reflections !== void 0 && (this.reflections = c.reflections | 0), c.mirrors !== void 0 && (this.mirrorSlots = Math.max(0, c.mirrors | 0)), c.post !== void 0 && (this.postLevel = c.post | 0, !this.postLevel && this.post && this.post.dispose()), c.shadowTaps !== void 0 && (this.shadowTaps = c.shadowTaps | 0), c.shadowEvery !== void 0 && (this.shadowEvery = Math.max(1, c.shadowEvery | 0)), c.msaa !== void 0 && this.setSamples(c.msaa), c.aniso !== void 0 && c.aniso !== this.anisotropy) {
      this.anisotropy = c.aniso;
      for (let l of this._textures) Pi(this.gl, l, this.anisotropy);
    }
    return this;
  }
  ["setSamples"](c) {
    let l = Math.max(0, c | 0);
    return this.samples = l ? Math.min(l, this.maxSamples || 0) : 0, this.samples || this._dropTarget(), this.samples;
  }
  ["_target"](F, m) {
    let S = this.gl, E = this.samplesFor(F, m);
    if (!E) return this._dropTarget(), null;
    let A = this._msaa;
    if (A && A.width === F && A.height === m && A.samples === E) return A.fb;
    this._dropTarget();
    try {
      let v = S.createFramebuffer(), g = S.createRenderbuffer(), b = S.createRenderbuffer();
      S.bindRenderbuffer(S.RENDERBUFFER, g), S.renderbufferStorageMultisample(S.RENDERBUFFER, E, S.RGBA8, F, m), S.bindRenderbuffer(S.RENDERBUFFER, b), S.renderbufferStorageMultisample(S.RENDERBUFFER, E, S.DEPTH_COMPONENT24, F, m), S.bindFramebuffer(S.FRAMEBUFFER, v), S.framebufferRenderbuffer(S.FRAMEBUFFER, S.COLOR_ATTACHMENT0, S.RENDERBUFFER, g), S.framebufferRenderbuffer(S.FRAMEBUFFER, S.DEPTH_ATTACHMENT, S.RENDERBUFFER, b);
      let O = S.checkFramebufferStatus(S.FRAMEBUFFER) === S.FRAMEBUFFER_COMPLETE, M = S.createFramebuffer(), T = S.createRenderbuffer();
      if (S.bindRenderbuffer(S.RENDERBUFFER, T), S.renderbufferStorage(S.RENDERBUFFER, S.RGBA8, F, m), S.bindFramebuffer(S.FRAMEBUFFER, M), S.framebufferRenderbuffer(S.FRAMEBUFFER, S.COLOR_ATTACHMENT0, S.RENDERBUFFER, T), O = O && S.checkFramebufferStatus(S.FRAMEBUFFER) === S.FRAMEBUFFER_COMPLETE, S.bindFramebuffer(S.FRAMEBUFFER, null), S.bindRenderbuffer(S.RENDERBUFFER, null), this._msaa = { fb: v, colour: g, depth: b, resolveFb: M, resolved: T, width: F, height: m, samples: E }, !O) throw new Error("incomplete");
      return v;
    } catch {
      return this._dropTarget(), this.samples = 0, this.maxSamples = 0, null;
    }
  }
  ["_dropTarget"]() {
    let c = this._msaa;
    if (!c) return;
    let l = this.gl;
    l.deleteFramebuffer(c.fb), l.deleteRenderbuffer(c.colour), l.deleteRenderbuffer(c.depth), c.resolveFb && l.deleteFramebuffer(c.resolveFb), c.resolved && l.deleteRenderbuffer(c.resolved), this._msaa = null;
  }
  ["upload"](c) {
    let l = this._uploaded.get(c);
    return l || (l = Ze(this.gl, c), this._uploaded.set(c, l)), l;
  }
  ["resize"](c, l) {
    let F = this.gl;
    (F.canvas.width !== c || F.canvas.height !== l) && (F.canvas.width = c, F.canvas.height = l), F.viewport(0, 0, c, l);
  }
  ["render"](F, S, E, A = null) {
    let b = this.gl, O = b.canvas.width, M = b.canvas.height;
    S.update(O / Math.max(M, 1)), this.stats.draws = 0, this.stats.triangles = 0, this.stats.culled = 0;
    let { drawables: T, lights: x, mirrors: y } = this._gather(F);
    this.stats.shadowDrawn = false, this.shadows.enabled && this._shadowPass(T, S, E);
    let q = null, L = null;
    this.postLevel > 0 && (this.post || (this.post = new Te(b)), L = this.post.begin(O, M, this.samplesFor(O, M)), L && (q = this.post, this._dropTarget())), q || (L = this._target(O, M));
    let I = !!(q && q.hdr);
    this.stats.post = q ? this.postLevel : 0;
    let z = this._mirrorStrips(y), K = z ? this._mirrorsInView(y, S, z) : [], H = K.length ? this._reflected(T) : T;
    K.length || (this.stats.mirrors = 0), this._reflection = null, this._reflection = K.length ? this._renderReflections(K, z, H, x, S, E, I, O, M) : null, b.bindFramebuffer(b.FRAMEBUFFER, L), b.viewport(0, 0, O, M);
    let d0 = this._drawWorld(T, x, S, E, I);
    if (q && q.keepDepth(), A && this._drawOverlay(A, d0), q) q.grade.exposure = E.exposure ?? 0.62, q.finish(S, this.postLevel);
    else {
      if (L) {
        let d1 = this._msaa;
        b.bindFramebuffer(b.READ_FRAMEBUFFER, L), b.bindFramebuffer(b.DRAW_FRAMEBUFFER, d1.resolveFb), b.blitFramebuffer(0, 0, O, M, 0, 0, O, M, b.COLOR_BUFFER_BIT, b.NEAREST), b.bindFramebuffer(b.READ_FRAMEBUFFER, d1.resolveFb), b.bindFramebuffer(b.DRAW_FRAMEBUFFER, null), b.blitFramebuffer(0, 0, O, M, 0, 0, O, M, b.COLOR_BUFFER_BIT, b.NEAREST), b.bindFramebuffer(b.FRAMEBUFFER, null);
      }
    }
    this.stats.samples = L ? this.samplesFor(O, M) : 0;
  }
  ["_drawWorld"](F, m, S, E, A, v = null) {
    let g = this.gl;
    g.clear(g.DEPTH_BUFFER_BIT), this._drawSky(S, E, A), g.useProgram(this.surface.program);
    let b = this.surface.uniforms;
    g.uniformMatrix4fv(b.uViewProjection, false, S.viewProjection), g.uniformMatrix4fv(b.uLightViewProjection, false, this.shadows.matrix), g.uniform3fv(b.uCameraPos, S.position), g.uniform3fv(b.uSunDirection, E.direction()), g.uniform3fv(b.uSunColour, E.sunColour), g.uniform3fv(b.uSkyColour, E.horizon), g.uniform3fv(b.uGroundColour, E.ground), g.uniform1i(b.uShadows, this.shadows.enabled ? 1 : 0), g.uniform2f(b.uShadowTexel, 1 / this.shadows.size, 1 / this.shadows.size), g.uniform1i(b.uShadowTaps, this.shadowTaps), g.uniform1i(b.uLighting, this.lighting), b.uLinearOut && g.uniform1i(b.uLinearOut, A ? 1 : 0), b.uExposure && g.uniform1f(b.uExposure, E.exposure ?? 0.62), b.uAmbientScale && g.uniform1f(b.uAmbientScale, E.ambient ?? 1), b.uZenithColour && g.uniform3fv(b.uZenithColour, E.zenith), b.uFogDensity && g.uniform1f(b.uFogDensity, this.fogDensity), this._lights(m, S, b), g.activeTexture(g.TEXTURE1), g.bindTexture(g.TEXTURE_2D, this.shadows.texture), g.uniform1i(b.uShadowMap, 1), g.uniform1i(b.uBaseColourMap, 0), b.uReflection && g.uniform1i(b.uReflection, 2);
    let { opaque: O, blended: M } = this._sorted(F, S, v);
    for (let T of O) this._drawNode(T, b);
    if (M.length) {
      g.enable(g.BLEND), g.blendFunc(g.SRC_ALPHA, g.ONE_MINUS_SRC_ALPHA), g.depthMask(false);
      for (let x of M) this._drawNode(x, b);
      g.depthMask(true), g.disable(g.BLEND);
    }
    return b;
  }
  ["_renderReflections"](F, S, E, A, b, O, M, T, x) {
    let y = this.gl, w = this.reflections >= 2 ? 1 : 0.5, q = this._maxTexture || (this._maxTexture = y.getParameter(y.MAX_TEXTURE_SIZE) || 4096), L = Math.max(16, Math.min(Math.round(T * w), Math.floor(q / S))), I = Math.max(16, Math.min(Math.round(x * w), q)), z = this._reflectionTarget(L * S, I, M);
    if (!z) return null;
    y.activeTexture(y.TEXTURE2), y.bindTexture(y.TEXTURE_2D, this._white), y.activeTexture(y.TEXTURE0), y.bindFramebuffer(y.FRAMEBUFFER, z.fb);
    let K = this.stats.draws, H = /* @__PURE__ */ new Map();
    return y.enable(y.SCISSOR_TEST), F.forEach((d0, d1) => {
      let d2 = this._mirrorView(d0, b, d1, S);
      y.viewport(d1 * L, 0, L, I), y.scissor(d1 * L, 0, L, I), this._drawWorld(E, A, d2, O, M, (d3) => !!d3.mirror || this._noMirror(d3)), H.set(d0.node, d2.textureMatrix);
    }), y.disable(y.SCISSOR_TEST), this.stats.reflectionDraws = this.stats.draws - K, this.stats.mirrors = F.length, y.bindTexture(y.TEXTURE_2D, z.tex), { texture: z.tex, matrices: H };
  }
  ["_reflectionTarget"](F, m, S) {
    let E = this.gl, A = this._refl;
    this._canFloat ??= !!(E.getExtension("EXT_color_buffer_float") || E.getExtension("EXT_color_buffer_half_float"));
    let v = S && this._canFloat;
    if (A && A.w === F && A.h === m && A.hdr === v) return A;
    if (A && (E.deleteFramebuffer(A.fb), E.deleteTexture(A.tex), E.deleteRenderbuffer(A.depth), this._refl = null), this._reflFailed) return null;
    let g = E.createTexture();
    E.bindTexture(E.TEXTURE_2D, g), E.texImage2D(E.TEXTURE_2D, 0, v ? E.RGBA16F : E.RGBA8, F, m, 0, E.RGBA, v ? E.HALF_FLOAT : E.UNSIGNED_BYTE, null);
    for (let [T, x] of [[E.TEXTURE_MIN_FILTER, E.LINEAR], [E.TEXTURE_MAG_FILTER, E.LINEAR], [E.TEXTURE_WRAP_S, E.CLAMP_TO_EDGE], [E.TEXTURE_WRAP_T, E.CLAMP_TO_EDGE]]) E.texParameteri(E.TEXTURE_2D, T, x);
    let b = E.createRenderbuffer();
    E.bindRenderbuffer(E.RENDERBUFFER, b), E.renderbufferStorage(E.RENDERBUFFER, E.DEPTH_COMPONENT24, F, m);
    let O = E.createFramebuffer();
    E.bindFramebuffer(E.FRAMEBUFFER, O), E.framebufferTexture2D(E.FRAMEBUFFER, E.COLOR_ATTACHMENT0, E.TEXTURE_2D, g, 0), E.framebufferRenderbuffer(E.FRAMEBUFFER, E.DEPTH_ATTACHMENT, E.RENDERBUFFER, b);
    let M = E.checkFramebufferStatus(E.FRAMEBUFFER) === E.FRAMEBUFFER_COMPLETE;
    return E.bindFramebuffer(E.FRAMEBUFFER, null), M ? (this._refl = { fb: O, tex: g, depth: b, w: F, h: m, hdr: v }, this._refl) : (E.deleteFramebuffer(O), E.deleteTexture(g), E.deleteRenderbuffer(b), this._reflFailed = true, null);
  }
  ["_drawOverlay"](c, l) {
    let F = this.gl, m = [];
    for (let u of c.visibleNodes()) u.mesh && m.push(u);
    if (m.length) {
      F.clear(F.DEPTH_BUFFER_BIT), F.uniform1i(l.uShadows, 0);
      for (let S of m) this._drawNode(S, l);
      F.uniform1i(l.uShadows, this.shadows.enabled ? 1 : 0);
    }
  }
  ["_drawNode"](F, m) {
    let u = this.gl, S = this.upload(F.mesh), E = F.material || Et, A = F.worldMatrix(), v = F.skin && F.skin.matrices ? F.skin : null;
    m.uSkinned && u.uniform1i(m.uSkinned, v ? 1 : 0), v && m.uJoints ? (u.uniformMatrix4fv(m.uJoints, false, v.matrices), u.uniformMatrix4fv(m.uModel, false, v.root ? v.root.worldMatrix() : Qt)) : u.uniformMatrix4fv(m.uModel, false, A), P.normalFromMat4(this._normalMatrix, A) && u.uniformMatrix3fv(m.uNormalMatrix, false, this._normalMatrix), u.uniform3fv(m.uColour, E.colour), u.uniform1f(m.uAlpha, E.alpha), u.uniform1f(m.uRoughness, Math.max(Number.isFinite(E.roughness) ? E.roughness : 0.7, 0.03)), u.uniform1f(m.uMetallic, Number.isFinite(E.metallic) ? E.metallic : 0), u.uniform3fv(m.uEmissive, E.emissive), u.uniform1f(m.uGridScale, E.grid), u.uniform1f(m.uAlphaCutoff, E.alphaCutoff);
    let g = this._textureFor(E);
    u.activeTexture(u.TEXTURE0), u.bindTexture(u.TEXTURE_2D, g || this._white), u.uniform1i(m.uHasBaseColour, g ? 1 : 0), m.uGlowMap && u.uniform1i(m.uGlowMap, E.glowMap && g ? 1 : 0);
    let b = this._reflection, O = b && m.uReflect ? b.matrices.get(F) : null;
    m.uReflect && u.uniform1i(m.uReflect, O ? 1 : 0), O && (u.uniformMatrix4fv(m.uReflectMatrix, false, O), u.activeTexture(u.TEXTURE2), u.bindTexture(u.TEXTURE_2D, b.texture), u.activeTexture(u.TEXTURE0)), E.doubleSided && u.disable(u.CULL_FACE), Me(u, S), E.doubleSided && u.enable(u.CULL_FACE), this.stats.draws++, this.stats.triangles += S.count / 3;
  }
  ["_textureFor"](c) {
    if (!c.map) return null;
    if (c._texture && c.mapVersion !== void 0 && c._uploadedVersion !== c.mapVersion) {
      let F = this.gl;
      F.activeTexture(F.TEXTURE0), F.bindTexture(F.TEXTURE_2D, c._texture), F.pixelStorei(F.UNPACK_FLIP_Y_WEBGL, true);
      let m = c.map.width, u = c.map.height;
      return c._uploadedSize === m + "x" + u ? F.texSubImage2D(F.TEXTURE_2D, 0, 0, 0, F.RGBA, F.UNSIGNED_BYTE, c.map) : F.texImage2D(F.TEXTURE_2D, 0, F.RGBA, F.RGBA, F.UNSIGNED_BYTE, c.map), c._uploadedSize = m + "x" + u, F.generateMipmap(F.TEXTURE_2D), F.pixelStorei(F.UNPACK_FLIP_Y_WEBGL, false), c._uploadedVersion = c.mapVersion, c._texture;
    }
    if (c._texture) return c._texture;
    if (c.mapVersion !== void 0) return c._texture = es(this.gl, c.map, { aniso: this.anisotropy }), c._uploadedVersion = c.mapVersion, this._textures.add(c._texture), c._texture;
    let l = typeof c.map == "object" && c.map ? this._byImage.get(c.map) : null;
    return l ? c._texture = l : (c._texture = es(this.gl, c.map, { aniso: this.anisotropy }), this._textures.add(c._texture), typeof c.map == "object" && c.map && this._byImage.set(c.map, c._texture), c._texture);
  }
  ["_shadowPass"](l, F, m) {
    let u = this.gl;
    if (!this._shadowFrame(l, F, m)) return;
    u.bindFramebuffer(u.FRAMEBUFFER, this.shadows.framebuffer), u.viewport(0, 0, this.shadows.size, this.shadows.size), u.clear(u.DEPTH_BUFFER_BIT), u.useProgram(this.depth.program), u.uniformMatrix4fv(this.depth.uniforms.uLightViewProjection, false, this.shadows.matrix), u.cullFace(u.FRONT);
    let S = this.depth.uniforms;
    for (let E of l) {
      let h = E.material || Et;
      if (!h.castShadow || h.alpha < 1) continue;
      let A = E.skin && E.skin.matrices ? E.skin : null;
      S.uSkinned && u.uniform1i(S.uSkinned, A ? 1 : 0), A && S.uJoints ? (u.uniformMatrix4fv(S.uJoints, false, A.matrices), u.uniformMatrix4fv(S.uModel, false, A.root ? A.root.worldMatrix() : Qt)) : u.uniformMatrix4fv(S.uModel, false, E.worldMatrix()), Me(u, this.upload(E.mesh));
    }
    u.cullFace(u.BACK);
  }
  ["_lights"](c, l, F) {
    let m = this.gl;
    if (!F.uPointCount) return;
    let u = this._pickLights(c, l);
    m.uniform1i(F.uPointCount, u), u && (m.uniform4fv(F.uPointPos, this._lightPos), m.uniform3fv(F.uPointColour, this._lightCol));
  }
  ["_drawSky"](c, l, F = false) {
    let m = this.gl;
    m.useProgram(this.skyProgram.program);
    let u = this.skyProgram.uniforms;
    u.uLinearOut && m.uniform1i(u.uLinearOut, F ? 1 : 0), u.uExposure && m.uniform1f(u.uExposure, l.exposure ?? 0.62), m.uniformMatrix4fv(u.uInverseViewProjection, false, c.inverseViewProjection), m.uniform3fv(u.uCameraPos, c.position), m.uniform3fv(u.uSunDirection, l.direction()), m.uniform3fv(u.uSunColour, l.sunColour), m.uniform3fv(u.uZenith, l.zenith), m.uniform3fv(u.uHorizon, l.horizon), m.uniform3fv(u.uGround, l.ground), m.uniform1f(u.uSunSize, l.sunSize), u.uStars && m.uniform1f(u.uStars, l.stars || 0), m.depthMask(false), m.disable(m.CULL_FACE), m.bindVertexArray(this.emptyVao), m.drawArrays(m.TRIANGLES, 0, 3), m.enable(m.CULL_FACE), m.depthMask(true);
  }
}, ts = class {
  constructor(c, l) {
    this.gl = c, this.extent = 22, this.enabled = true, this.supported = true, this.view = P.create(), this.projection = P.create(), this.matrix = P.create(), this._build(l);
  }
  ["resize"](c) {
    if (!c) {
      this.enabled = false;
      return;
    }
    if (c === this.size && this.texture) {
      this.enabled = this.supported;
      return;
    }
    let l = this.gl;
    this.texture && l.deleteTexture(this.texture), this.framebuffer && l.deleteFramebuffer(this.framebuffer), this._build(c);
  }
  ["_build"](c) {
    let l = this.gl;
    this.size = c, this.generation = (this.generation || 0) + 1, this.texture = l.createTexture(), l.bindTexture(l.TEXTURE_2D, this.texture), l.texImage2D(l.TEXTURE_2D, 0, l.DEPTH_COMPONENT24, c, c, 0, l.DEPTH_COMPONENT, l.UNSIGNED_INT, null), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_COMPARE_MODE, l.COMPARE_REF_TO_TEXTURE), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_COMPARE_FUNC, l.LEQUAL), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_MIN_FILTER, l.LINEAR), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_MAG_FILTER, l.LINEAR), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_WRAP_S, l.CLAMP_TO_EDGE), l.texParameteri(l.TEXTURE_2D, l.TEXTURE_WRAP_T, l.CLAMP_TO_EDGE), this.framebuffer = l.createFramebuffer(), l.bindFramebuffer(l.FRAMEBUFFER, this.framebuffer), l.framebufferTexture2D(l.FRAMEBUFFER, l.DEPTH_ATTACHMENT, l.TEXTURE_2D, this.texture, 0), l.drawBuffers([l.NONE]), l.readBuffer(l.NONE);
    let F = l.checkFramebufferStatus(l.FRAMEBUFFER);
    F !== l.FRAMEBUFFER_COMPLETE ? (console.warn("Shadow map unavailable (framebuffer status " + F + "); shadows are off."), this.enabled = false, this.supported = false) : this.enabled = true, l.bindFramebuffer(l.FRAMEBUFFER, null);
  }
};
function No(c) {
  let l = c.createTexture();
  return c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, l), c.texImage2D(c.TEXTURE_2D, 0, c.RGBA, 1, 1, 0, c.RGBA, c.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255])), l;
}
function es(c, l, { wrapS: F, wrapT: m, aniso: u = 8 } = {}) {
  let S = c.createTexture();
  return c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, S), c.pixelStorei(c.UNPACK_FLIP_Y_WEBGL, true), c.texImage2D(c.TEXTURE_2D, 0, c.RGBA, c.RGBA, c.UNSIGNED_BYTE, l), c.generateMipmap(c.TEXTURE_2D), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_MIN_FILTER, c.LINEAR_MIPMAP_LINEAR), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_MAG_FILTER, c.LINEAR), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_WRAP_S, F || c.REPEAT), c.texParameteri(c.TEXTURE_2D, c.TEXTURE_WRAP_T, m || c.REPEAT), Pi(c, S, u, true), c.pixelStorei(c.UNPACK_FLIP_Y_WEBGL, false), S;
}
var Ai = /* @__PURE__ */ new WeakMap();
function Ri(c) {
  let l = Ai.get(c);
  if (!l) {
    let F = c.getExtension("EXT_texture_filter_anisotropic");
    l = { ext: F, most: F && c.getParameter(F.MAX_TEXTURE_MAX_ANISOTROPY_EXT) || 1 }, Ai.set(c, l);
  }
  return l;
}
function Pi(c, l, F, m = false) {
  let { ext: u, most: S } = Ri(c);
  u && (m || (c.activeTexture(c.TEXTURE0), c.bindTexture(c.TEXTURE_2D, l)), c.texParameterf(c.TEXTURE_2D, u.TEXTURE_MAX_ANISOTROPY_EXT, Math.max(1, Math.min(F || 1, S))));
}
var Fi = "\nstruct Frame {\n  viewProj: mat4x4f,\n  lightViewProj: mat4x4f,\n  invViewProj: mat4x4f,\n  cameraPos: vec3f, exposure: f32,\n  sunDir: vec3f, ambientScale: f32,\n  sunColour: vec3f, fogDensity: f32,\n  skyColour: vec3f, shadows: f32,\n  groundColour: vec3f, linearOut: f32,\n  zenithColour: vec3f, lighting: f32,\n  shadowTexel: vec2f, shadowTaps: f32, pointCount: f32,\n  sunSize: f32, stars: f32, pad0: f32, pad1: f32,\n  pointPos: array<vec4f, 8>,\n  pointColour: array<vec4f, 8>,\n};\n", ki = "\nstruct Draw {\n  model: mat4x4f,\n  normalMat: mat3x3f,\n  colour: vec4f,      // rgb, alpha\n  emissive: vec4f,    // rgb, roughness\n  params: vec4f,      // metallic, grid, alpha cutoff, has a texture\n  reflectMat: mat4x4f,\n  flags: vec4f,       // shows the mirror's picture, the glow takes the map's colour, takes shadows\n};\nstruct Joints { m: array<mat4x4f, 48> };\n\nfn toDepth01(p: vec4f) -> vec4f { return vec4f(p.x, p.y, (p.z + p.w) * 0.5, p.w); }\n\nfn skinMatrix(j: vec4f, w: vec4f) -> mat4x4f {\n  // Weights are normalised by the exporter, but not always exactly, so\n  // a vertex whose weights sum to 0.98 would quietly shrink.\n  let m = J.m[u32(j.x)] * w.x + J.m[u32(j.y)] * w.y + J.m[u32(j.z)] * w.z + J.m[u32(j.w)] * w.w;\n  let total = w.x + w.y + w.z + w.w;\n  if (total > 0.0001) { return m * (1.0 / total); }\n  return mat4x4f(1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0);\n}\n", Ci = "\nfn aces(x: vec3f) -> vec3f {\n  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), vec3f(0.0), vec3f(1.0));\n}\nfn toScreen(c: vec3f) -> vec3f {\n  if (F.linearOut > 0.5) { return c; }\n  return pow(aces(c * F.exposure), vec3f(1.0 / 2.2));\n}\n", Ii = "\n" + Fi + "\n" + ki + "\n@group(0) @binding(0) var<uniform> F: Frame;\n@group(0) @binding(1) var shadowMap: texture_depth_2d;\n@group(0) @binding(2) var shadowSampler: sampler_comparison;\n@group(0) @binding(3) var reflTex: texture_2d<f32>;\n@group(0) @binding(4) var clampSampler: sampler;\n@group(0) @binding(5) var matSampler: sampler;\n@group(1) @binding(0) var<uniform> D: Draw;\n@group(1) @binding(1) var<uniform> J: Joints;\n@group(2) @binding(0) var baseMap: texture_2d<f32>;\n\n" + Ci + "\n\nstruct VOut {\n  @builtin(position) clip: vec4f,\n  @location(0) world: vec3f,\n  @location(1) normal: vec3f,\n  @location(2) uv: vec2f,\n  @location(3) lightSpace: vec4f,\n};\n\nfn place(position: vec3f, normal: vec3f, uv: vec2f) -> VOut {\n  var o: VOut;\n  let world = D.model * vec4f(position, 1.0);\n  o.world = world.xyz;\n  // The inverse-transpose, so non-uniform scale does not skew the normal.\n  o.normal = normalize(D.normalMat * normal);\n  o.uv = uv;\n  o.lightSpace = F.lightViewProj * world;\n  o.clip = toDepth01(F.viewProj * world);\n  return o;\n}\n\n@vertex fn vs(@location(0) pos: vec3f, @location(1) normal: vec3f, @location(2) uv: vec2f) -> VOut {\n  return place(pos, normal, uv);\n}\n\n@vertex fn vsSkinned(@location(0) pos: vec3f, @location(1) normal: vec3f, @location(2) uv: vec2f,\n                     @location(4) joints: vec4f, @location(5) weights: vec4f) -> VOut {\n  let s = skinMatrix(joints, weights);\n  return place((s * vec4f(pos, 1.0)).xyz, mat3x3f(s[0].xyz, s[1].xyz, s[2].xyz) * normal, uv);\n}\n\nconst PI = 3.14159265359;\n\n// Hemisphere ambient: sky from above, bounced ground light from below.\nfn ambient(n: vec3f) -> vec3f {\n  return mix(F.groundColour, F.skyColour, n.y * 0.5 + 0.5) * F.ambientScale;\n}\n\nfn grid(p: vec2f, scale: f32) -> f32 {\n  let coord = p * scale;\n  let d = fwidth(coord);\n  let g = abs(fract(coord - 0.5) - 0.5) / d;\n  return 1.0 - min(min(g.x, g.y), 1.0);\n}\n\nfn distributionGGX(ndoth: f32, roughness: f32) -> f32 {\n  let a = roughness * roughness;\n  let a2 = a * a;\n  let d = ndoth * ndoth * (a2 - 1.0) + 1.0;\n  return a2 / max(PI * d * d, 1e-5);\n}\n\nfn geometrySmith(ndotv: f32, ndotl: f32, roughness: f32) -> f32 {\n  let r = roughness + 1.0;\n  let k = (r * r) / 8.0;\n  let gv = ndotv / (ndotv * (1.0 - k) + k);\n  let gl = ndotl / (ndotl * (1.0 - k) + k);\n  return gv * gl;\n}\n\nfn fresnelSchlick(cosTheta: f32, f0: vec3f) -> vec3f {\n  return f0 + (1.0 - f0) * pow(clamp(1.0 - cosTheta, 0.0, 1.0), 5.0);\n}\n\nconst POISSON = array<vec2f, 12>(\n  vec2f(-0.326, -0.406), vec2f(-0.840, -0.074), vec2f(-0.696,  0.457), vec2f(-0.203,  0.621),\n  vec2f( 0.962, -0.195), vec2f( 0.473, -0.480), vec2f( 0.519,  0.767), vec2f( 0.185, -0.893),\n  vec2f( 0.507,  0.064), vec2f( 0.896,  0.412), vec2f(-0.322, -0.933), vec2f(-0.792, -0.598));\n\nfn shadowTap(uv: vec2f, depth: f32) -> f32 {\n  return textureSampleCompareLevel(shadowMap, shadowSampler, uv, depth);\n}\n\nfn shadowAt(lightSpace: vec4f, ndotl: f32, frag: vec2f) -> f32 {\n  if (F.shadows < 0.5 || D.flags.z < 0.5) { return 1.0; }\n  let proj = (lightSpace.xyz / lightSpace.w) * 0.5 + 0.5;\n  // Outside the map is LIT, not dark.\n  if (proj.z > 1.0 || proj.x < 0.0 || proj.x > 1.0 || proj.y < 0.0 || proj.y > 1.0) { return 1.0; }\n  let uv = vec2f(proj.x, 1.0 - proj.y);\n  // Slope-scaled bias.\n  let bias = max(0.0015 * (1.0 - ndotl), 0.0004);\n  let depth = proj.z - bias;\n  if (F.shadowTaps <= 1.0) { return shadowTap(uv, depth); }\n  if (F.shadowTaps <= 4.0) {\n    let o = F.shadowTexel * 0.5;\n    return 0.25 * (\n      shadowTap(uv + vec2f(-o.x, -o.y), depth) +\n      shadowTap(uv + vec2f( o.x, -o.y), depth) +\n      shadowTap(uv + vec2f(-o.x,  o.y), depth) +\n      shadowTap(uv + vec2f( o.x,  o.y), depth));\n  }\n  // Wide and soft: a dozen taps on a disc, turned a different way at every pixel.\n  let turn = 6.2831853 * fract(52.9829189 * fract(dot(frag, vec2f(0.06711056, 0.00583715))));\n  let c = cos(turn);\n  let s = sin(turn);\n  let spin = mat2x2f(c, -s, s, c);\n  let radius = F.shadowTexel * 2.4;\n  let wide = proj.z - bias * 1.6;\n  var sum = 0.0;\n  for (var i = 0u; i < 12u; i++) {\n    sum += shadowTap(uv + spin * POISSON[i] * radius, wide);\n  }\n  return sum / 12.0;\n}\n\nfn pointLights(pos: vec3f, n: vec3f, v: vec3f, albedo: vec3f, f0: vec3f, rough: f32, metal: f32, shiny: bool) -> vec3f {\n  var sum = vec3f(0.0);\n  let count = u32(F.pointCount);\n  for (var i = 0u; i < 8u; i++) {\n    if (i >= count) { break; }\n    let toLight = F.pointPos[i].xyz - pos;\n    let d = length(toLight);\n    let range = F.pointPos[i].w;\n    if (d >= range) { continue; }\n    let l = toLight / max(d, 1e-4);\n    let ndotl = max(dot(n, l), 0.0);\n    if (ndotl <= 0.0) { continue; }\n    let x = d / range;\n    let fade = clamp(1.0 - x * x * x * x, 0.0, 1.0);\n    let radiance = F.pointColour[i].rgb * (fade * fade / (1.0 + d * d));\n    var diffuse = (1.0 - metal) * albedo / PI;\n    var spec = vec3f(0.0);\n    if (shiny) {\n      let h = normalize(v + l);\n      let ndotv = max(dot(n, v), 1e-4);\n      let f = fresnelSchlick(max(dot(h, v), 0.0), f0);\n      spec = (distributionGGX(max(dot(n, h), 0.0), rough) * geometrySmith(ndotv, ndotl, rough) * f) / max(4.0 * ndotv * ndotl, 1e-4);\n      diffuse *= vec3f(1.0) - f;\n    }\n    sum += (diffuse + spec) * radiance * ndotl;\n  }\n  return sum;\n}\n\n@fragment fn fs(s: VOut) -> @location(0) vec4f {\n  // A mirror shows what is in front of it, already lit.\n  if (D.flags.x > 0.5) {\n    let at = D.reflectMat * vec4f(s.world, 1.0);\n    let p = at.xy / at.w;\n    let seen = textureSampleLevel(reflTex, clampSampler, vec2f(p.x, 1.0 - p.y), 0.0).rgb;\n    return vec4f(seen * vec3f(0.94, 0.96, 0.98), 1.0);\n  }\n  let n = normalize(s.normal);\n  let v = normalize(F.cameraPos - s.world);\n  let l = normalize(F.sunDir);\n  let h = normalize(v + l);\n\n  var base = D.colour;\n  var glow = D.emissive.rgb;\n  if (D.params.w > 0.5) {\n    let t = textureSample(baseMap, matSampler, s.uv);\n    // Base colour textures are sRGB and the factor is linear.\n    let picture = pow(t.rgb, vec3f(2.2));\n    base *= vec4f(picture, t.a);\n    if (D.flags.y > 0.5) { glow *= picture; }\n  }\n  if (base.a < D.params.z) { discard; }\n\n  var albedo = base.rgb;\n  if (D.params.y > 0.0) { albedo = mix(albedo, albedo * 0.55, grid(s.world.xz, D.params.y) * 0.8); }\n\n  let ndotl = max(dot(n, l), 0.0);\n  let ndotv = max(dot(n, v), 1e-4);\n  let ndoth = max(dot(n, h), 0.0);\n  let roughness = D.emissive.w;\n  let metallic = D.params.x;\n  let lighting = F.lighting;\n\n  if (lighting < 0.5) {\n    let flatShadow = shadowAt(s.lightSpace, ndotl, s.clip.xy);\n    let plain = albedo * (F.sunColour * ndotl * flatShadow / PI + ambient(n)) + glow\n      + pointLights(s.world, n, v, albedo, vec3f(0.04), 1.0, 0.0, false);\n    return vec4f(toScreen(plain), base.a);\n  }\n\n  let f0 = mix(vec3f(0.04), albedo, metallic);\n  let f = fresnelSchlick(max(dot(h, v), 0.0), f0);\n  let ndf = distributionGGX(ndoth, roughness);\n  let g = geometrySmith(ndotv, ndotl, roughness);\n  let specular = (ndf * g * f) / max(4.0 * ndotv * ndotl, 1e-4);\n  let diffuse = (vec3f(1.0) - f) * (1.0 - metallic) * albedo / PI;\n\n  let shadow = shadowAt(s.lightSpace, ndotl, s.clip.xy);\n  let direct = (diffuse + specular) * F.sunColour * ndotl * shadow;\n  var indirect = albedo * ambient(n) * mix(1.0, 0.35, metallic);\n\n  if (lighting >= 1.5) {\n    let r = reflect(-v, n);\n    var env: vec3f;\n    if (r.y >= 0.0) { env = mix(F.skyColour, F.zenithColour, pow(r.y, 0.45)); }\n    else { env = mix(F.skyColour, F.groundColour, smoothstep(0.0, 0.25, -r.y)); }\n    let gloss = (1.0 - roughness) * (1.0 - roughness);\n    let fr = f0 + (max(vec3f(1.0 - roughness), f0) - f0) * pow(1.0 - ndotv, 5.0);\n    indirect += env * fr * gloss * mix(0.6, 1.0, shadow);\n  }\n  if (lighting >= 2.5) {\n    let rim = pow(1.0 - ndotv, 4.0) * (0.55 + 0.45 * n.y);\n    indirect += F.skyColour * rim * 0.16 * (1.0 - metallic * 0.5);\n  }\n\n  var lit = direct + indirect + glow + pointLights(s.world, n, v, albedo, f0, max(roughness, 0.08), metallic, true);\n  if (lighting >= 2.5 && F.fogDensity > 0.0) {\n    let d = max(length(F.cameraPos - s.world) - 30.0, 0.0);\n    lit = mix(lit, F.skyColour, (1.0 - exp(-d * F.fogDensity)) * 0.55);\n  }\n  return vec4f(toScreen(lit), base.a);\n}\n", Li = "\n" + ki + "\nstruct Light { viewProj: mat4x4f };\n@group(0) @binding(0) var<uniform> L: Light;\n@group(1) @binding(0) var<uniform> D: Draw;\n@group(1) @binding(1) var<uniform> J: Joints;\n\n@vertex fn vs(@location(0) pos: vec3f) -> @builtin(position) vec4f {\n  return toDepth01(L.viewProj * D.model * vec4f(pos, 1.0));\n}\n\n@vertex fn vsSkinned(@location(0) pos: vec3f, @location(4) joints: vec4f, @location(5) weights: vec4f) -> @builtin(position) vec4f {\n  let total = weights.x + weights.y + weights.z + weights.w;\n  var p = pos;\n  if (total > 0.0001) { p = (skinMatrix(joints, weights) * vec4f(pos, 1.0)).xyz; }\n  return toDepth01(L.viewProj * D.model * vec4f(p, 1.0));\n}\n", Ni = "\n" + Fi + "\n@group(0) @binding(0) var<uniform> F: Frame;\n" + Ci + "\n\nstruct SkyOut { @builtin(position) clip: vec4f, @location(0) ndc: vec2f };\n\n@vertex fn vs(@builtin(vertex_index) id: u32) -> SkyOut {\n  let pos = vec2f(f32((id << 1u) & 2u), f32(id & 2u));\n  var o: SkyOut;\n  o.ndc = pos * 2.0 - 1.0;\n  o.clip = vec4f(o.ndc, 1.0, 1.0);\n  return o;\n}\n\nfn hash13(q: vec3f) -> f32 {\n  var p = fract(q * 0.1031);\n  p += dot(p, p.zyx + 31.32);\n  return fract((p.x + p.y) * p.z);\n}\n\n@fragment fn fs(s: SkyOut) -> @location(0) vec4f {\n  let far = F.invViewProj * vec4f(s.ndc, 1.0, 1.0);\n  let dir = normalize(far.xyz / far.w - F.cameraPos);\n  let h = dir.y;\n\n  let horizonBlend = smoothstep(-0.08, 0.08, h);\n  let sky = mix(F.skyColour, F.zenithColour, pow(clamp(h, 0.0, 1.0), 0.45));\n  var colour = mix(F.groundColour, sky, horizonBlend);\n\n  let cosAngle = dot(dir, normalize(F.sunDir));\n  let disc = smoothstep(1.0 - F.sunSize, 1.0 - F.sunSize * 0.35, cosAngle);\n  let halo = pow(max(cosAngle, 0.0), 220.0) * 0.6 + pow(max(cosAngle, 0.0), 12.0) * 0.12;\n  colour += F.sunColour * (disc * 6.0 + halo);\n\n  let groundward = 1.0 - smoothstep(0.0, 0.35, abs(h));\n  colour += F.sunColour * pow(max(cosAngle, 0.0), 4.0) * groundward * 0.25;\n\n  if (F.stars > 0.0 && h > 0.0) {\n    let p = dir * 170.0;\n    let cell = floor(p);\n    let r = hash13(cell);\n    if (r > 0.982) {\n      let centre = cell + 0.5 + (vec3f(hash13(cell + 1.7), hash13(cell + 3.1), hash13(cell + 5.3)) - 0.5) * 0.5;\n      let d = length(p - centre);\n      let bright = (r - 0.982) / 0.018;\n      let star = smoothstep(0.32, 0.0, d) * (0.35 + bright * bright * 1.8);\n      let tint = mix(vec3f(0.75, 0.85, 1.0), vec3f(1.0, 0.92, 0.8), hash13(cell + 9.1));\n      colour += tint * star * F.stars * smoothstep(0.0, 0.12, h) * 2.4;\n    }\n  }\n  return vec4f(toScreen(colour), 1.0);\n}\n", Di = "\n@vertex fn vsFar(@builtin(vertex_index) id: u32) -> @builtin(position) vec4f {\n  let pos = vec2f(f32((id << 1u) & 2u), f32(id & 2u));\n  return vec4f(pos * 2.0 - 1.0, 1.0, 1.0);\n}\n@fragment fn fsNothing() -> @location(0) vec4f { return vec4f(0.0); }\n\n@group(0) @binding(0) var src: texture_2d<f32>;\n@group(0) @binding(1) var smp: sampler;\nstruct BlitOut { @builtin(position) clip: vec4f, @location(0) uv: vec2f };\n@vertex fn vsBlit(@builtin(vertex_index) id: u32) -> BlitOut {\n  let pos = vec2f(f32((id << 1u) & 2u), f32(id & 2u));\n  var o: BlitOut;\n  o.clip = vec4f(pos * 2.0 - 1.0, 0.0, 1.0);\n  o.uv = vec2f(pos.x, 1.0 - pos.y);\n  return o;\n}\n@fragment fn fsBlit(s: BlitOut) -> @location(0) vec4f { return textureSampleLevel(src, smp, s.uv, 0.0); }\n", Vt = "\nstruct Post {\n  invProj: mat4x4f,\n  texel: vec2f, nearFar: vec2f,\n  radius: f32, intensity: f32, projScale: f32, samples: f32,\n  threshold: f32, exposure: f32, aoStrength: f32, bloomStrength: f32,\n  saturation: f32, contrast: f32, vignette: f32, debug: f32,\n  tint: vec3f, useAo: f32,\n  useBloom: f32, pad0: f32, pad1: f32, pad2: f32,\n};\n@group(0) @binding(0) var<uniform> P: Post;\n\nstruct FullOut { @builtin(position) clip: vec4f, @location(0) uv: vec2f };\n@vertex fn vs(@builtin(vertex_index) id: u32) -> FullOut {\n  let pos = vec2f(f32((id << 1u) & 2u), f32(id & 2u));\n  var o: FullOut;\n  o.clip = vec4f(pos * 2.0 - 1.0, 0.0, 1.0);\n  // Top row first, as WebGPU's pictures are.\n  o.uv = vec2f(pos.x, 1.0 - pos.y);\n  return o;\n}\n", Oi = (c) => "\n@group(1) @binding(0) var depthTex: " + (c ? "texture_depth_multisampled_2d" : "texture_depth_2d") + ";\nfn depthAt(uv: vec2f) -> f32 {\n  let size = vec2i(textureDimensions(depthTex));\n  let c = clamp(vec2i(floor(uv * vec2f(size))), vec2i(0), size - 1);\n  return textureLoad(depthTex, c, 0);\n}\n// The middle of the depth pixel a point of the picture falls in: where the\n// depth read there really is.\nfn depthUv(uv: vec2f) -> vec2f {\n  let size = vec2f(textureDimensions(depthTex));\n  return (clamp(floor(uv * size), vec2f(0.0), size - 1.0) + 0.5) / size;\n}\n", Ui = (c) => "\n" + Vt + "\n" + Oi(c) + "\n// A point of the picture, back in the camera's space. uv runs down the\n// screen here and up it in GL, so y is turned back over for the matrix.\n// Worked out at the middle of the depth pixel its depth came from: this\n// pass is half size, and a depth from one place put back at another tilts\n// a floor seen at a low angle a little differently every few rows, which\n// came out as soft dark bands across it at some window sizes.\nfn viewPos(uv: vec2f) -> vec3f {\n  let c = depthUv(uv);\n  let d = depthAt(c);\n  let p = P.invProj * vec4f(c.x * 2.0 - 1.0, 1.0 - c.y * 2.0, d * 2.0 - 1.0, 1.0);\n  return p.xyz / p.w;\n}\n\n@fragment fn fs(s: FullOut) -> @location(0) vec4f {\n  let d = depthAt(s.uv);\n  if (d >= 0.99999) { return vec4f(1.0); }\n  let P0 = viewPos(s.uv);\n  let tx = vec2f(P.texel.x, 0.0);\n  // Up the screen is down the picture.\n  let ty = vec2f(0.0, -P.texel.y);\n  let pr = viewPos(s.uv + tx) - P0;\n  let pl = P0 - viewPos(s.uv - tx);\n  let pu = viewPos(s.uv + ty) - P0;\n  let pd = P0 - viewPos(s.uv - ty);\n  var dx = pl;\n  if (abs(pr.z) < abs(pl.z)) { dx = pr; }\n  var dy = pd;\n  if (abs(pu.z) < abs(pd.z)) { dy = pu; }\n  let N = normalize(cross(dx, dy));\n\n  let screenR = P.radius * P.projScale / max(-P0.z, 0.1);\n  if (screenR < P.texel.x * 1.5) { return vec4f(1.0); }\n  let spin = 6.2831853 * fract(52.9829189 * fract(dot(s.clip.xy, vec2f(0.06711056, 0.00583715))));\n  let r2 = P.radius * P.radius;\n  let count = u32(P.samples);\n  var sum = 0.0;\n  for (var i = 0u; i < 24u; i++) {\n    if (i >= count) { break; }\n    let t = (f32(i) + 0.5) / P.samples;\n    let a = spin + f32(i) * 2.39996323;\n    // Offsets in screen terms, up being up: turned over for the picture.\n    let o = vec2f(cos(a), sin(a)) * screenR * sqrt(t);\n    let v = viewPos(s.uv + vec2f(o.x, -o.y)) - P0;\n    let vv = dot(v, v);\n    let vn = dot(v, N);\n    let fall = max(0.0, 1.0 - vv / (r2 * 1.6));\n    sum += max(0.0, vn + P0.z * 0.0015) / (vv + 0.0005) * fall;\n  }\n  let ao = max(0.0, 1.0 - 2.0 * P.intensity * sum / P.samples * P.radius * 0.6);\n  return vec4f(ao, ao, ao, 1.0);\n}\n", Bi = (c) => "\n" + Vt + "\n" + Oi(c) + "\n@group(1) @binding(1) var aoTex: texture_2d<f32>;\n@group(1) @binding(2) var lin: sampler;\n\nfn linearDepth(d: f32) -> f32 {\n  let z = d * 2.0 - 1.0;\n  return 2.0 * P.nearFar.x * P.nearFar.y / (P.nearFar.y + P.nearFar.x - z * (P.nearFar.y - P.nearFar.x));\n}\n\n@fragment fn fs(s: FullOut) -> @location(0) vec4f {\n  let centre = linearDepth(depthAt(s.uv));\n  var sum = 0.0;\n  var weight = 0.0;\n  for (var y = -2; y <= 1; y++) {\n    for (var x = -2; x <= 1; x++) {\n      let uv = s.uv + (vec2f(f32(x), f32(y)) + 0.5) * P.texel;\n      let z = linearDepth(depthAt(uv));\n      let w = 1.0 / (1.0 + abs(z - centre) * 8.0 / max(centre, 0.5));\n      sum += textureSampleLevel(aoTex, lin, uv, 0.0).r * w;\n      weight += w;\n    }\n  }\n  let ao = sum / max(weight, 1e-4);\n  return vec4f(ao, ao, ao, 1.0);\n}\n", ss = "\n@group(1) @binding(0) var source: texture_2d<f32>;\n@group(1) @binding(1) var lin: sampler;\nfn at(uv: vec2f) -> vec3f { return textureSampleLevel(source, lin, uv, 0.0).rgb; }\n", zi = "\n" + Vt + "\n" + ss + "\n@fragment fn fs(s: FullOut) -> @location(0) vec4f {\n  let t = P.texel;\n  let c = 0.25 * (at(s.uv + t * vec2f(-1.0, -1.0)) + at(s.uv + t * vec2f(1.0, -1.0)) +\n                  at(s.uv + t * vec2f(-1.0, 1.0)) + at(s.uv + t * vec2f(1.0, 1.0)));\n  let bright = max(c.r, max(c.g, c.b));\n  // A soft knee rather than a hard cut, so things fade into glowing.\n  let knee = P.threshold * 0.5;\n  var soft = clamp(bright - P.threshold + knee, 0.0, 2.0 * knee);\n  soft = soft * soft / (4.0 * knee + 1e-4);\n  let keep = max(soft, bright - P.threshold) / max(bright, 1e-4);\n  return vec4f(min(c * keep, vec3f(32.0)), 1.0);\n}\n", Gi = "\n" + Vt + "\n" + ss + "\n@fragment fn fs(s: FullOut) -> @location(0) vec4f {\n  let t = P.texel;\n  var c = at(s.uv) * 4.0;\n  c += at(s.uv + t * vec2f(-1.0, -1.0));\n  c += at(s.uv + t * vec2f(1.0, -1.0));\n  c += at(s.uv + t * vec2f(-1.0, 1.0));\n  c += at(s.uv + t * vec2f(1.0, 1.0));\n  return vec4f(c / 8.0, 1.0);\n}\n", $i = "\n" + Vt + "\n" + ss + "\n@fragment fn fs(s: FullOut) -> @location(0) vec4f {\n  let t = P.texel;\n  var c = vec3f(0.0);\n  c += at(s.uv + t * vec2f(-2.0, 0.0));\n  c += at(s.uv + t * vec2f(2.0, 0.0));\n  c += at(s.uv + t * vec2f(0.0, -2.0));\n  c += at(s.uv + t * vec2f(0.0, 2.0));\n  c += at(s.uv + t * vec2f(-1.0, -1.0)) * 2.0;\n  c += at(s.uv + t * vec2f(1.0, -1.0)) * 2.0;\n  c += at(s.uv + t * vec2f(-1.0, 1.0)) * 2.0;\n  c += at(s.uv + t * vec2f(1.0, 1.0)) * 2.0;\n  return vec4f(c / 12.0, 1.0);\n}\n", Vi = "\n" + Vt + "\n@group(1) @binding(0) var colourTex: texture_2d<f32>;\n@group(1) @binding(1) var aoTex: texture_2d<f32>;\n@group(1) @binding(2) var bloomTex: texture_2d<f32>;\n@group(1) @binding(3) var lin: sampler;\n\nfn aces(x: vec3f) -> vec3f {\n  return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), vec3f(0.0), vec3f(1.0));\n}\n\n@fragment fn fs(s: FullOut) -> @location(0) vec4f {\n  let aoSeen = textureSampleLevel(aoTex, lin, s.uv, 0.0).r;\n  if (P.debug > 0.5) { return vec4f(aoSeen, aoSeen, aoSeen, 1.0); }\n  var c = textureSampleLevel(colourTex, lin, s.uv, 0.0).rgb;\n  if (P.useAo > 0.5) { c *= mix(1.0, aoSeen, P.aoStrength); }\n  if (P.useBloom > 0.5) { c += textureSampleLevel(bloomTex, lin, s.uv, 0.0).rgb * P.bloomStrength; }\n  c = pow(aces(c * P.exposure), vec3f(1.0 / 2.2));\n  c = clamp(c, vec3f(0.0), vec3f(1.0));\n  // The grade: a gentle S of contrast, saturation round the luminance, a tint.\n  let l = dot(c, vec3f(0.2126, 0.7152, 0.0722));\n  c = mix(vec3f(l), c, P.saturation);\n  c = clamp((c - 0.5) * P.contrast + 0.5, vec3f(0.0), vec3f(1.0));\n  c *= P.tint;\n  let q = s.uv - 0.5;\n  c *= 1.0 - P.vignette * smoothstep(0.25, 0.85, dot(q, q) * 2.2);\n  // Dither, so smooth dark gradients do not band.\n  let n = fract(52.9829189 * fract(dot(s.clip.xy, vec2f(0.06711056, 0.00583715))));\n  c += (n - 0.5) / 255.0;\n  return vec4f(c, 1.0);\n}\n", Do = "rz.renderer", ji = "rz.gpu.lost";
function Xi() {
  try {
    let c = new URLSearchParams(globalThis.location?.search || "").get("renderer");
    if (c === "webgl" || c === "webgpu") return c;
  } catch {
  }
  try {
    let l = globalThis.localStorage?.getItem(Do);
    if (l === "webgl" || l === "webgpu") return l;
  } catch {
  }
  try {
    if (globalThis.sessionStorage?.getItem(ji)) return "webgl";
  } catch {
  }
  return "auto";
}
function Wi() {
  try {
    globalThis.sessionStorage?.setItem(ji, "1");
  } catch {
  }
}
var Hi = (c, l) => Promise.race([c, new Promise((F) => setTimeout(() => F(null), l))]);
async function is({ force: c = false } = {}) {
  if (!c && Xi() === "webgl") return null;
  let F = globalThis.navigator?.gpu;
  if (!F) return null;
  let m = null;
  try {
    let u = await Hi(F.requestAdapter({ powerPreference: "high-performance" }), 4e3);
    if (!u || (m = await Hi(u.requestDevice(), 4e3), !m)) return null;
    let S = Uo(u, m, F.getPreferredCanvasFormat());
    m.pushErrorScope("validation");
    for (let [h, A] of Object.entries(S.modules)) {
      let v = (A.getCompilationInfo ? await A.getCompilationInfo() : { messages: [] }).messages.filter((g) => g.type === "error");
      if (v.length) throw new Error(h + " shader: " + v[0].message + " (line " + v[0].lineNum + ")");
    }
    await Promise.all([Se(S, { format: S.format, samples: 1 }, true), Se(S, { format: S.format, samples: 4 }, true), Ae(S, S.format, 1, true), Ae(S, S.format, 4, true), ns(S, false, true)]);
    let E = await m.popErrorScope();
    if (E) throw new Error(E.message);
    return S.name = Oo(u), S;
  } catch (g) {
    console.warn("[render] WebGPU is not usable here, using WebGL:", g && g.message ? g.message : g);
    try {
      m && m.destroy();
    } catch {
    }
    return null;
  }
}
function Oo(c) {
  let l = "";
  try {
    let F = document.createElement("canvas"), m = F.getContext("webgl2") || F.getContext("webgl");
    if (m) {
      let u = m.getExtension("WEBGL_debug_renderer_info");
      l = String((u ? m.getParameter(u.UNMASKED_RENDERER_WEBGL) : m.getParameter(m.RENDERER)) || "");
      let S = m.getExtension("WEBGL_lose_context");
      S && S.loseContext();
    }
  } catch {
  }
  if (!l) {
    let E = c.info || {};
    l = [E.vendor, E.architecture, E.device, E.description].filter(Boolean).join(" ");
  }
  return l;
}
function Uo(F, m, u) {
  let S = GPUShaderStage, E = (T, x) => m.createShaderModule({ code: T, label: x }), A = { surface: E(Ii, "surface"), depth: E(Li, "depth"), sky: E(Ni, "sky"), util: E(Di, "util") }, v = m.createBindGroupLayout({ label: "frame", entries: [{ binding: 0, visibility: S.VERTEX | S.FRAGMENT, buffer: { type: "uniform" } }, { binding: 1, visibility: S.FRAGMENT, texture: { sampleType: "depth" } }, { binding: 2, visibility: S.FRAGMENT, sampler: { type: "comparison" } }, { binding: 3, visibility: S.FRAGMENT, texture: { sampleType: "float" } }, { binding: 4, visibility: S.FRAGMENT, sampler: { type: "filtering" } }, { binding: 5, visibility: S.FRAGMENT, sampler: { type: "filtering" } }] }), g = m.createBindGroupLayout({ label: "draw", entries: [{ binding: 0, visibility: S.VERTEX | S.FRAGMENT, buffer: { type: "uniform", hasDynamicOffset: true, minBindingSize: 240 } }, { binding: 1, visibility: S.VERTEX, buffer: { type: "uniform", hasDynamicOffset: true, minBindingSize: 3072 } }] }), b = m.createBindGroupLayout({ label: "texture", entries: [{ binding: 0, visibility: S.FRAGMENT, texture: { sampleType: "float" } }] }), O = m.createBindGroupLayout({ label: "light", entries: [{ binding: 0, visibility: S.VERTEX, buffer: { type: "uniform" } }] }), M = (T) => m.createPipelineLayout({ bindGroupLayouts: T });
  return { adapter: F, device: m, format: u, modules: A, groups: { frame: v, draw: g, texture: b, light: O }, layouts: { surface: M([v, g, b]), sky: M([v]), depth: M([O, g]), none: M([]) }, pipelines: /* @__PURE__ */ new Map(), postModules: null };
}
function Ht(c, l, F, m) {
  let u = c.pipelines.get(l);
  if (u) return m ? Promise.resolve(u) : u;
  let S = F();
  if (m) return c.device.createRenderPipelineAsync(S).then((h) => (c.pipelines.has(l) || c.pipelines.set(l, h), c.pipelines.get(l)));
  let E = c.device.createRenderPipeline(S);
  return c.pipelines.set(l, E), E;
}
var Mt = (c, l, F) => ({ arrayStride: F, attributes: [{ shaderLocation: c, offset: 0, format: l }] }), Bo = { color: { srcFactor: "src-alpha", dstFactor: "one-minus-src-alpha", operation: "add" }, alpha: { srcFactor: "src-alpha", dstFactor: "one-minus-src-alpha", operation: "add" } }, zo = { color: { srcFactor: "one", dstFactor: "one", operation: "add" }, alpha: { srcFactor: "one", dstFactor: "one", operation: "add" } };
function Se(c, { format: l, samples: F = 1, blend: m = false, cull: u = true, skinned: S = false }, E = false) {
  let h = "s|" + l + "|" + F + "|" + (m ? 1 : 0) + "|" + (u ? 1 : 0) + "|" + (S ? 1 : 0);
  return Ht(c, h, () => {
    let A = [Mt(0, "float32x3", 12), Mt(1, "float32x3", 12), Mt(2, "float32x2", 8)];
    return S && A.push(Mt(4, "float32x4", 16), Mt(5, "float32x4", 16)), { label: h, layout: c.layouts.surface, vertex: { module: c.modules.surface, entryPoint: S ? "vsSkinned" : "vs", buffers: A }, fragment: { module: c.modules.surface, entryPoint: "fs", targets: [{ format: l, blend: m ? Bo : void 0 }] }, primitive: { topology: "triangle-list", cullMode: u ? "back" : "none", frontFace: "ccw" }, depthStencil: { format: "depth24plus", depthWriteEnabled: !m, depthCompare: "less-equal" }, multisample: { count: F } };
  }, E);
}
function ns(c, l, F = false) {
  let m = "d|" + (l ? 1 : 0);
  return Ht(c, m, () => ({ label: m, layout: c.layouts.depth, vertex: { module: c.modules.depth, entryPoint: l ? "vsSkinned" : "vs", buffers: l ? [Mt(0, "float32x3", 12), Mt(4, "float32x4", 16), Mt(5, "float32x4", 16)] : [Mt(0, "float32x3", 12)] }, primitive: { topology: "triangle-list", cullMode: "front", frontFace: "ccw" }, depthStencil: { format: "depth32float", depthWriteEnabled: true, depthCompare: "less-equal" } }), F);
}
function Ae(c, l, F, m = false) {
  let u = "k|" + l + "|" + F;
  return Ht(c, u, () => ({ label: u, layout: c.layouts.sky, vertex: { module: c.modules.sky, entryPoint: "vs" }, fragment: { module: c.modules.sky, entryPoint: "fs", targets: [{ format: l }] }, primitive: { topology: "triangle-list", cullMode: "none" }, depthStencil: { format: "depth24plus", depthWriteEnabled: false, depthCompare: "always" }, multisample: { count: F } }), m);
}
function qi(c, l, F) {
  let m = "f|" + l + "|" + F;
  return Ht(c, m, () => ({ label: m, layout: c.layouts.none, vertex: { module: c.modules.util, entryPoint: "vsFar" }, fragment: { module: c.modules.util, entryPoint: "fsNothing", targets: [{ format: l, writeMask: 0 }] }, primitive: { topology: "triangle-list", cullMode: "none" }, depthStencil: { format: "depth24plus", depthWriteEnabled: true, depthCompare: "always" }, multisample: { count: F } }));
}
function Ki(c, l) {
  let F = "b|" + l;
  return Ht(c, F, () => ({ label: F, layout: "auto", vertex: { module: c.modules.util, entryPoint: "vsBlit" }, fragment: { module: c.modules.util, entryPoint: "fsBlit", targets: [{ format: l }] }, primitive: { topology: "triangle-list" } }));
}
function Ji(c, l, F, m = false) {
  let u = "p|" + l + "|" + F + "|" + (m ? 1 : 0);
  return Ht(c, u, () => {
    let S = c.postModules || (c.postModules = {}), E = { ao: () => Ui(m), blur: () => Bi(m), bright: () => zi, down: () => Gi, up: () => $i, composite: () => Vi }[l](), h = l + "|" + (m ? 1 : 0), A = S[h] || (S[h] = c.device.createShaderModule({ code: E, label: "post " + l }));
    return { label: u, layout: "auto", vertex: { module: A, entryPoint: "vs" }, fragment: { module: A, entryPoint: "fs", targets: [{ format: F, blend: l === "up" ? zo : void 0 }] }, primitive: { topology: "triangle-list" } };
  });
}
var Go = 1, R = class {
  constructor(c = "node") {
    this.id = Go++, this.name = c, this.parent = null, this.children = [], this.visible = true, this.position = _.create(), this.rotation = X.create(), this.scale = _.create(1, 1, 1), this.local = P.create(), this.world = P.create(), this._dirty = true, this.mesh = null, this.material = null;
  }
  ["add"](c) {
    return c.parent && c.parent.remove(c), c.parent = this, this.children.push(c), c.markDirty(), c;
  }
  ["remove"](c) {
    let l = this.children.indexOf(c);
    return l !== -1 && (this.children.splice(l, 1), c.parent = null), c;
  }
  ["markDirty"]() {
    if (!this._dirty) {
      this._dirty = true;
      for (let c of this.children) c.markDirty();
    }
  }
  ["setPosition"](c, l, F) {
    return _.set(this.position, c, l, F), this.markDirty(), this;
  }
  ["setScale"](c, l = c, F = c) {
    return _.set(this.scale, c, l, F), this.markDirty(), this;
  }
  ["setRotation"](c) {
    return X.copy(this.rotation, c), this.markDirty(), this;
  }
  ["setEuler"](c, l, F) {
    return X.fromEuler(this.rotation, c, l, F), this.markDirty(), this;
  }
  ["worldMatrix"]() {
    return this._dirty ? (P.fromRotationTranslationScale(this.local, this.rotation, this.position, this.scale), this.parent ? P.multiply(this.world, this.parent.worldMatrix(), this.local) : P.copy(this.world, this.local), this._dirty = false, this.world) : this.world;
  }
  ["worldPosition"](c = _.create()) {
    return P.getTranslation(c, this.worldMatrix());
  }
  *["visibleNodes"]() {
    if (this.visible) {
      yield this;
      for (let c of this.children) yield* c.visibleNodes();
    }
  }
  *["allNodes"]() {
    yield this;
    for (let c of this.children) yield* c.allNodes();
  }
  ["find"](c) {
    for (let l of this.allNodes()) if (l.name === c) return l;
    return null;
  }
  ["dispose"]() {
    for (let c of [...this.children]) c.dispose();
    this.parent && this.parent.remove(this);
  }
}, $o = { 5120: [Int8Array, 1], 5121: [Uint8Array, 1], 5122: [Int16Array, 2], 5123: [Uint16Array, 2], 5125: [Uint32Array, 4], 5126: [Float32Array, 4] }, Vo = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 }, os = { KHR_draco_mesh_compression: "Draco-compressed geometry", KHR_texture_basisu: "Basis Universal textures", EXT_meshopt_compression: "meshopt-compressed geometry" }, Y = class extends Error {
};
async function Re(F, m = {}) {
  let S = F instanceof Uint8Array ? F : new Uint8Array(F), { json: E, binary: A } = Ho(S) ? Xo(S) : { json: jo(S), binary: null };
  if (!E.asset || !String(E.asset.version || "").startsWith("2")) throw new Y("This is glTF " + (E.asset?.version || "of an unknown version") + "; the reader handles 2.x.");
  for (let q of E.extensionsRequired || []) if (os[q]) throw new Y("This file needs " + os[q] + " (" + q + "), which is not supported yet. Re-export it without that option, or run it through gltf-transform first.");
  let v = await Wo(E, A, m), g = await qo(E, v, m), b = (E.materials || []).map((L) => er(L, E, g)), O = (E.meshes || []).map((L, I) => Qo(L, I, E, v)), M = E.scene ?? 0, T = (E.scenes || [])[M] || { nodes: [] }, x = (E.nodes || []).map(sr), y = (E.skins || []).map((L, I) => nr(L, I, E, v)), w = (E.animations || []).map((L, I) => or(L, I, E, v));
  return { nodes: x, roots: T.nodes || [], meshes: O, materials: b, images: g, skins: y, animations: w, generator: E.asset.generator || "", warnings: rr(E) };
}
function Ho(c) {
  return c.byteLength < 12 ? false : new DataView(c.buffer, c.byteOffset, 4).getUint32(0, true) === 1179937895;
}
function jo(c) {
  try {
    return JSON.parse(new TextDecoder().decode(c));
  } catch (l) {
    throw new Y("That is neither a .glb nor readable .gltf JSON (" + l.message + ").");
  }
}
function Xo(F) {
  let m = new DataView(F.buffer, F.byteOffset, F.byteLength), u = m.getUint32(4, true);
  if (u !== 2) throw new Y("This is .glb container version " + u + "; the reader handles 2.");
  let S = m.getUint32(8, true);
  if (S > F.byteLength) throw new Y("The file says it is " + S + " bytes but only " + F.byteLength + " arrived \u2014 it is truncated.");
  let E = 12, h = null, A = null;
  for (; E + 8 <= S; ) {
    let v = m.getUint32(E, true), g = m.getUint32(E + 4, true), b = E + 8;
    if (b + v > F.byteLength) throw new Y("A chunk runs past the end of the file.");
    g === 1313821514 ? h = JSON.parse(new TextDecoder().decode(F.subarray(b, b + v))) : g === 5130562 && (A = F.subarray(b, b + v)), E = b + v + (4 - v % 4) % 4;
  }
  if (!h) throw new Y("The .glb has no JSON chunk.");
  return { json: h, binary: A };
}
async function Wo(c, l, F) {
  let m = [];
  for (let u of c.buffers || []) if (u.uri === void 0) {
    if (!l) throw new Y("A buffer refers to the .glb binary chunk, but there is none.");
    m.push(l);
  } else u.uri.startsWith("data:") ? m.push(Yi(u.uri)) : m.push(await Zi(u.uri, F, "buffer"));
  return m;
}
async function qo(c, l, F) {
  let m = [];
  for (let u of c.images || []) try {
    if (u.uri && u.uri.startsWith("data:")) m.push({ bytes: Yi(u.uri), mime: Ko(u.uri), name: u.name || "" });
    else {
      if (u.uri) m.push({ bytes: await Zi(u.uri, F, "image"), mime: Jo(u.uri), name: u.name || u.uri });
      else {
        if (u.bufferView !== void 0) {
          let S = c.bufferViews[u.bufferView], E = l[S.buffer], h = S.byteOffset || 0;
          m.push({ bytes: E.subarray(h, h + S.byteLength), mime: u.mimeType || "image/png", name: u.name || "" });
        } else m.push(null);
      }
    }
  } catch {
    m.push(null);
  }
  return m;
}
function Yi(c) {
  let l = c.indexOf(",");
  if (l === -1) throw new Y("A data: URI in the file is malformed.");
  let F = c.slice(5, l), m = c.slice(l + 1);
  if (!F.endsWith(";base64")) return new TextEncoder().encode(decodeURIComponent(m));
  let u = typeof atob == "function" ? atob(m) : Buffer.from(m, "base64").toString("binary"), S = new Uint8Array(u.length);
  for (let E = 0; E < u.length; E++) S[E] = u.charCodeAt(E);
  return S;
}
var Ko = (c) => c.slice(5, c.indexOf(";")) || "application/octet-stream", Jo = (c) => /\.jpe?g$/i.test(c) ? "image/jpeg" : /\.webp$/i.test(c) ? "image/webp" : "image/png";
async function Zi(c, l, F) {
  let m = Yo(c, l.baseUrl || ""), u = l.fetch || (typeof fetch == "function" ? fetch : null);
  if (!u) throw new Y("Cannot load the " + F + " at " + c + ": no way to fetch it here.");
  let S = await u(m);
  if (!S.ok) throw new Y("Could not load the " + F + " at " + m + " (HTTP " + S.status + ").");
  return new Uint8Array(await S.arrayBuffer());
}
function Yo(c, l) {
  if (!l) return c;
  try {
    return new URL(c, l).href;
  } catch {
  }
  if (typeof location < "u" && location.origin) try {
    return new URL(c, new URL(l, location.origin)).href;
  } catch {
  }
  let F = String(l).replace(/[^/]*$/, "");
  return /^(?:[a-z]+:)?\/\//i.test(c) || c.startsWith("/") ? c : F + c;
}
function Tt(F, S, E) {
  let A = F.accessors[E];
  if (!A) throw new Y("The file refers to accessor " + E + ", which does not exist.");
  let [v, b] = $o[A.componentType] || [];
  if (!v) throw new Y("Unknown component type " + A.componentType + ".");
  let O = Vo[A.type];
  if (!O) throw new Y("Unknown accessor type " + A.type + ".");
  let M = A.count, T = new v(M * O);
  if (A.bufferView === void 0) return T;
  let x = F.bufferViews[A.bufferView], y = S[x.buffer];
  if (!y) throw new Y("Buffer " + x.buffer + " is missing.");
  let w = (x.byteOffset || 0) + (A.byteOffset || 0), q = x.byteStride || O * b;
  if (q === O * b) {
    let L = new v(y.buffer, y.byteOffset + w, M * O);
    T.set(L);
  } else {
    let I = new DataView(y.buffer, y.byteOffset), z = Zo(A.componentType, I);
    for (let K = 0; K < M; K++) for (let H = 0; H < O; H++) T[K * O + H] = z(w + K * q + H * b);
  }
  return T;
}
function Zo(c, l) {
  switch (c) {
    case 5120:
      return (F) => l.getInt8(F);
    case 5121:
      return (F) => l.getUint8(F);
    case 5122:
      return (F) => l.getInt16(F, true);
    case 5123:
      return (F) => l.getUint16(F, true);
    case 5125:
      return (F) => l.getUint32(F, true);
    default:
      return (F) => l.getFloat32(F, true);
  }
}
function Qo(F, m, S, E) {
  let A = [];
  for (let v of F.primitives || []) {
    let g = v.mode ?? 4;
    if (g !== 4) {
      A.push({ unsupported: "primitive mode " + g + " (only triangles are drawn)" });
      continue;
    }
    let b = v.attributes.POSITION !== void 0 ? Tt(S, E, v.attributes.POSITION) : null;
    if (!b) {
      A.push({ unsupported: "a primitive with no POSITION" });
      continue;
    }
    let O = v.attributes.NORMAL !== void 0 ? Tt(S, E, v.attributes.NORMAL) : null, M = v.attributes.TEXCOORD_0 !== void 0 ? Tt(S, E, v.attributes.TEXCOORD_0) : null, T = v.indices !== void 0 ? Array.from(Tt(S, E, v.indices)) : null;
    if (!T) {
      T = new Array(b.length / 3);
      for (let w = 0; w < T.length; w++) T[w] = w;
    }
    O || (O = tr(b, T));
    let x = v.attributes.JOINTS_0 !== void 0 ? Float32Array.from(Tt(S, E, v.attributes.JOINTS_0)) : null, y = v.attributes.WEIGHTS_0 !== void 0 ? Float32Array.from(Tt(S, E, v.attributes.WEIGHTS_0)) : null;
    A.push({ positions: b, normals: O, uvs: M || new Float32Array(b.length / 3 * 2), indices: T, material: v.material, ...x && y ? { joints: x, weights: y } : {} });
  }
  return { name: F.name || "mesh" + m, primitives: A };
}
function tr(F, S) {
  let E = new Float32Array(F.length);
  for (let A = 0; A < S.length; A += 3) {
    let v = S[A] * 3, b = S[A + 1] * 3, O = S[A + 2] * 3, M = F[b] - F[v], T = F[b + 1] - F[v + 1], x = F[b + 2] - F[v + 2], y = F[O] - F[v], w = F[O + 1] - F[v + 1], q = F[O + 2] - F[v + 2], L = T * q - x * w, I = x * y - M * q, z = M * w - T * y;
    for (let K of [v, b, O]) E[K] += L, E[K + 1] += I, E[K + 2] += z;
  }
  for (let H = 0; H < E.length; H += 3) {
    let d0 = Math.hypot(E[H], E[H + 1], E[H + 2]) || 1;
    E[H] /= d0, E[H + 1] /= d0, E[H + 2] /= d0;
  }
  return E;
}
function er(c, l, F) {
  let m = c.pbrMetallicRoughness || {}, u = (S) => {
    if (!S || S.index === void 0) return null;
    let E = (l.textures || [])[S.index], h = E && (E.source ?? (E.extensions && E.extensions.EXT_texture_webp ? E.extensions.EXT_texture_webp.source : void 0));
    if (!E || h === void 0) return null;
    let A = F[h];
    if (!A) return null;
    let v = (l.samplers || [])[E.sampler] || {};
    return { image: A, wrapS: v.wrapS ?? 10497, wrapT: v.wrapT ?? 10497, uv: S.texCoord || 0 };
  };
  return { name: c.name || "", baseColour: m.baseColorFactor || [1, 1, 1, 1], metallic: m.metallicFactor ?? 1, roughness: m.roughnessFactor ?? 1, baseColourTexture: u(m.baseColorTexture), metallicRoughnessTexture: u(m.metallicRoughnessTexture), normalTexture: u(c.normalTexture), emissive: (c.emissiveFactor || [0, 0, 0]).map((S) => S * Math.min(4, c.extensions && c.extensions.KHR_materials_emissive_strength && c.extensions.KHR_materials_emissive_strength.emissiveStrength || 1)), emissiveTexture: u(c.emissiveTexture), alphaMode: c.alphaMode || "OPAQUE", alphaCutoff: c.alphaCutoff ?? 0.5, doubleSided: !!c.doubleSided };
}
function sr(c) {
  let l = c.translation || [0, 0, 0], F = c.rotation || [0, 0, 0, 1], m = c.scale || [1, 1, 1];
  return c.matrix && ({ position: l, rotation: F, scale: m } = ir(c.matrix)), { name: c.name || "", mesh: c.mesh, skin: c.skin, children: c.children || [], position: l, rotation: F, scale: m };
}
function ir(F) {
  let m = [F[12], F[13], F[14]], u = Math.hypot(F[0], F[1], F[2]), S = Math.hypot(F[4], F[5], F[6]), E = Math.hypot(F[8], F[9], F[10]);
  F[0] * (F[5] * F[10] - F[6] * F[9]) - F[4] * (F[1] * F[10] - F[2] * F[9]) + F[8] * (F[1] * F[6] - F[2] * F[5]) < 0 && (u = -u);
  let h = [F[0] / u, F[1] / u, F[2] / u, F[4] / S, F[5] / S, F[6] / S, F[8] / E, F[9] / E, F[10] / E], A = h[0] + h[4] + h[8], v;
  if (A > 0) {
    let g = Math.sqrt(A + 1) * 2;
    v = [(h[5] - h[7]) / g, (h[6] - h[2]) / g, (h[1] - h[3]) / g, 0.25 * g];
  } else {
    if (h[0] > h[4] && h[0] > h[8]) {
      let b = Math.sqrt(1 + h[0] - h[4] - h[8]) * 2;
      v = [0.25 * b, (h[3] + h[1]) / b, (h[6] + h[2]) / b, (h[5] - h[7]) / b];
    } else {
      if (h[4] > h[8]) {
        let O = Math.sqrt(1 + h[4] - h[0] - h[8]) * 2;
        v = [(h[3] + h[1]) / O, 0.25 * O, (h[7] + h[5]) / O, (h[6] - h[2]) / O];
      } else {
        let M = Math.sqrt(1 + h[8] - h[0] - h[4]) * 2;
        v = [(h[6] + h[2]) / M, (h[7] + h[5]) / M, 0.25 * M, (h[1] - h[3]) / M];
      }
    }
  }
  return { position: m, rotation: v, scale: [u, S, E] };
}
function nr(c, l, F, m) {
  let u = c.joints || [], S = null;
  return c.inverseBindMatrices !== void 0 && (S = Tt(F, m, c.inverseBindMatrices)), { name: c.name || "skin" + l, joints: u, skeleton: c.skeleton, inverseBind: S || new Float32Array(u.length * 16).map((E, h) => h % 17 === 0 ? 1 : 0) };
}
function or(F, m, u, S) {
  let E = (F.samplers || []).map((v) => ({ times: Tt(u, S, v.input), values: Tt(u, S, v.output), interpolation: v.interpolation || "LINEAR" })), h = [];
  for (let v of F.channels || []) {
    let g = E[v.sampler], b = v.target || {};
    !g || b.node === void 0 || ["translation", "rotation", "scale"].includes(b.path) && h.push({ node: b.node, path: b.path, ...g });
  }
  let A = h.reduce((O, M) => Math.max(O, M.times.length ? M.times[M.times.length - 1] : 0), 0);
  return { name: F.name || "animation" + m, tracks: h, duration: A };
}
function rr(c) {
  let l = [];
  (c.meshes || []).some((F) => (F.primitives || []).some((m) => m.targets)) && l.push("Morph targets are ignored."), c.cameras?.length && l.push(c.cameras.length + " camera(s) ignored.");
  for (let F of c.extensionsUsed || []) os[F] && l.push(F + " is used but not supported; parts of this model may be missing.");
  return l;
}
var Pe = 48, kt = class {
  constructor(c, l, F = null) {
    this.joints = c, this.inverseBind = l, this.root = F, this.tooMany = c.length > Pe, this.matrices = new Float32Array(Pe * 16);
    for (let m = 0; m < Pe; m++) Qi(this.matrices, m);
    this._bind = P.create(), this._inverseRoot = P.create();
  }
  ["update"]() {
    if (this.tooMany) return this;
    this.root && P.invert(this._inverseRoot, this.root.worldMatrix()) || P.identity(this._inverseRoot);
    for (let c = 0; c < this.joints.length; c++) {
      let l = this.joints[c];
      if (!l) {
        Qi(this.matrices, c);
        continue;
      }
      ar(this._bind, this.inverseBind, c), P.multiply(this._bind, l.worldMatrix(), this._bind), P.multiply(this._bind, this._inverseRoot, this._bind), this.matrices.set(this._bind, c * 16);
    }
    return this;
  }
};
function Qi(c, l) {
  let F = l * 16;
  for (let m = 0; m < 16; m++) c[F + m] = 0;
  c[F] = 1, c[F + 5] = 1, c[F + 10] = 1, c[F + 15] = 1;
}
function ar(c, l, F) {
  return c.set(l.subarray(F * 16, F * 16 + 16)), c;
}
var oe = class {
  constructor(c, l) {
    this.clips = c || [], this.nodes = l, this.clip = null, this.time = 0, this.speed = 1, this.loop = true, this.playing = false;
  }
  get ["names"]() {
    return this.clips.map((c) => c.name);
  }
  ["play"](c = 0, { loop: l = true, speed: F = 1 } = {}) {
    if (c === "all") return this.clips.length ? (this.layers = this.clips.map((u) => ({ clip: u, time: 0 })), this.clip = this.clips[0], this.time = 0, this.loop = l, this.speed = F, this.playing = true, this.apply(), true) : false;
    this.layers = null;
    let m = typeof c == "string" ? this.clips.find((u) => u.name === c) : this.clips[c];
    return m ? (this.clip = m, this.time = 0, this.loop = l, this.speed = F, this.playing = true, this.apply(), true) : false;
  }
  ["stop"]() {
    return this.playing = false, this;
  }
  ["update"](c) {
    if (!this.playing || !this.clip) return this;
    if (this.layers) {
      for (let F of this.layers) {
        let m = F.clip.duration || 0;
        F.time += c * this.speed, m > 0 && (F.time = this.loop ? (F.time % m + m) % m : Math.min(F.time, m));
      }
      return this.apply(), this;
    }
    let l = this.clip.duration || 0;
    return this.time += c * this.speed, l > 0 && (this.loop ? (this.time %= l, this.time < 0 && (this.time += l)) : this.time >= l && (this.time = l, this.playing = false)), this.apply(), this;
  }
  ["apply"]() {
    if (!this.clip) return this;
    if (this.layers) {
      for (let c of this.layers) this._pose(c.clip, c.time);
      return this;
    }
    return this._pose(this.clip, this.time), this;
  }
  ["_pose"](c, l) {
    for (let F of c.tracks) {
      let m = this.nodes.get(F.node);
      if (!m) continue;
      let u = tn(F, l);
      u && (F.path === "translation" ? _.set(m.position, u[0], u[1], u[2]) : F.path === "scale" ? _.set(m.scale, u[0], u[1], u[2]) : F.path === "rotation" && (m.rotation[0] = u[0], m.rotation[1] = u[1], m.rotation[2] = u[2], m.rotation[3] = u[3]), m.markDirty());
    }
    return this;
  }
};
function tn(F, m) {
  let S = F.times, E = F.path === "rotation" ? 4 : 3;
  if (!S || !S.length) return null;
  let A = F.interpolation === "CUBICSPLINE" ? E * 3 : E, v = F.interpolation === "CUBICSPLINE" ? E : 0, g = (q, L) => F.values[q * A + v + L];
  if (m <= S[0]) return ne(g, 0, E);
  let b = S.length - 1;
  if (m >= S[b]) return ne(g, b, E);
  let O = 0;
  for (; O + 1 <= b && S[O + 1] <= m; ) O++;
  let M = Math.min(O + 1, b), T = S[M] - S[O], x = T > 0 ? (m - S[O]) / T : 0;
  if (F.interpolation === "STEP") return ne(g, O, E);
  let y = ne(g, O, E), w = ne(g, M, E);
  return E === 4 ? cr(y, w, x) : y.map((q, L) => q + (w[L] - q) * x);
}
var ne = (c, l, F) => Array.from({ length: F }, (m, u) => c(l, u));
function cr(c, l, F) {
  let m = X.create();
  return X.slerp(m, Float32Array.from(c), Float32Array.from(l), F), Array.from(m);
}
var rs = /* @__PURE__ */ new Map(), cs = "/public/";
function lr(c) {
  return cs = String(c || "/public/").replace(/\/*$/, "/"), cs;
}
function ls(c) {
  let l = String(c || "");
  return l.startsWith("rz:") ? cs + l.slice(3).replace(/^\/+/, "") : l;
}
function hr(c) {
  let l = rs.get(c);
  return l || (l = (async () => {
    let F = await fetch(c);
    if (!F.ok) throw new Error("Could not fetch " + c + " (HTTP " + F.status + ").");
    return Re(new Uint8Array(await F.arrayBuffer()), { baseUrl: c });
  })(), l.catch(() => rs.delete(c)), rs.set(c, l)), l;
}
var as = /* @__PURE__ */ new Map();
function sn(c) {
  let l = ls(c), F = as.get(l);
  return F || (F = new Promise((m, u) => {
    if (typeof Image > "u") return u(new Error("No images here."));
    let S = new Image();
    S.crossOrigin = "anonymous", S.onload = () => m(S), S.onerror = () => u(new Error("Could not load " + l)), S.src = l;
  }), F.catch(() => as.delete(l)), as.set(l, F)), F;
}
function ur(c) {
  let l = String(c || "").lastIndexOf("#");
  return l === -1 ? { url: String(c || ""), node: null } : { url: String(c).slice(0, l), node: decodeURIComponent(String(c).slice(l + 1)) };
}
async function Ct(c, l = {}) {
  let { url: F, node: m } = ur(ls(c)), u = await hr(F);
  return us(u, m ? { ...l, only: m } : l);
}
async function hs(c, l = {}) {
  let F = new Uint8Array(await c.arrayBuffer()), m = await Re(F), u = await us(m, l);
  return u.name = c.name.replace(/\.(glb|gltf)$/i, ""), u;
}
var en = /* @__PURE__ */ new WeakMap();
async function us(F, S = {}) {
  let E = en.get(F);
  E || (E = Promise.all((F.images || []).map(pr)), en.set(F, E));
  let A = await E, v = (F.materials || []).map((w) => dr(w, A)), b = new N({ colour: [0.8, 0.8, 0.82], roughness: 0.8 }), O = new R(S.name || "model"), M = /* @__PURE__ */ new Map(), T = null;
  if (S.only) {
    let w = F.nodes.findIndex((q) => q && q.name === S.only);
    if (w === -1) throw new Error('No node called "' + S.only + '" in that file.');
    T = w;
  }
  let x = (q) => {
    if (M.has(q)) return M.get(q);
    let L = F.nodes[q];
    if (!L) return null;
    let I = new R(L.name || "node" + q);
    if (_.set(I.position, L.position[0], L.position[1], L.position[2]), X.copy(I.rotation, Float32Array.from(L.rotation)), _.set(I.scale, L.scale[0], L.scale[1], L.scale[2]), I.markDirty(), M.set(q, I), L.mesh !== void 0 && F.meshes[L.mesh]) {
      let z = F.meshes[L.mesh];
      for (let [K, H] of z.primitives.entries()) {
        if (H.unsupported) continue;
        let d0 = new R(z.name + ":" + K);
        d0.mesh = { positions: H.positions, normals: H.normals, uvs: H.uvs, indices: H.indices }, d0.material = H.material !== void 0 && v[H.material] || b, I.add(d0);
      }
    }
    for (let d1 of L.children) {
      let d2 = x(d1);
      d2 && I.add(d2);
    }
    return I;
  };
  if (T !== null) {
    let q = x(T);
    q && (_.set(q.position, 0, 0, 0), X.identity(q.rotation), _.set(q.scale, 1, 1, 1), q.markDirty(), O.add(q));
  } else for (let L of F.roots) {
    let I = x(L);
    I && O.add(I);
  }
  let y = [];
  for (let [z, K] of F.nodes.entries()) {
    if (K.skin === void 0 || !M.has(z)) continue;
    let H = (F.skins || [])[K.skin];
    if (!H) continue;
    let d0 = H.joints.map((d2) => M.get(d2) || null), d1 = new kt(d0, H.inverseBind, M.get(z) || O);
    d1.tooMany && console.warn(H.name + " has " + d0.length + " joints and the shader holds 48, so it stays in its bind pose.");
    for (let d2 of (M.get(z) || O).allNodes()) d2.mesh && (d2.skin = d1);
    y.push(d1);
  }
  return O.skeletons = y, O.animator = (F.animations || []).length ? new oe(F.animations, M) : null, O.tick = (d3) => {
    O.animator && O.animator.update(d3);
    for (let d4 of y) d4.update();
  }, O.tick(0), S.fitTo && nn(O, S.fitTo), S.dropToFloor && on(O), S.play !== false && O.animator && O.animator.play(S.play ?? (fr(F) ? "all" : 0)), O;
}
function fr(c) {
  let l = c.animations || [];
  if (l.length < 2) return false;
  let F = /* @__PURE__ */ new Set();
  for (let m of l) {
    let u = new Set(m.tracks.map((S) => S.node));
    for (let S of u) if (F.has(S)) return false;
    for (let E of u) F.add(E);
  }
  return true;
}
function dr(c, l) {
  let F = c.emissive && c.emissive.some((S) => S > 0) && c.emissiveTexture, m = c.baseColourTexture || (F ? c.emissiveTexture : null), u = !!(F && m && c.emissiveTexture.image === m.image);
  return new N({ colour: [c.baseColour[0], c.baseColour[1], c.baseColour[2]], alpha: c.alphaMode === "OPAQUE" ? 1 : c.baseColour[3], roughness: c.roughness, metallic: c.metallic, emissive: c.emissive, glowMap: u, map: m && m.image._decoded || null, alphaCutoff: c.alphaMode === "MASK" ? c.alphaCutoff : 0, doubleSided: c.doubleSided });
}
async function pr(c) {
  if (!c) return null;
  try {
    let l = new Blob([c.bytes], { type: c.mime }), F = typeof createImageBitmap == "function" ? await createImageBitmap(l) : await mr(l);
    return c._decoded = F, F;
  } catch (m) {
    return console.warn("Could not decode a texture (" + (c.name || "unnamed") + "): " + m.message), c._decoded = null, null;
  }
}
function mr(c) {
  return new Promise((l, F) => {
    let m = URL.createObjectURL(c), u = new Image();
    u.onload = () => {
      URL.revokeObjectURL(m), l(u);
    }, u.onerror = () => {
      URL.revokeObjectURL(m), F(new Error("decode failed"));
    }, u.src = m;
  });
}
function fs(l) {
  let F = [1 / 0, 1 / 0, 1 / 0], m = [-1 / 0, -1 / 0, -1 / 0], u = _.create();
  for (let S of l.allNodes()) {
    if (!S.mesh) continue;
    let E = S.worldMatrix(), h = S.mesh.positions;
    for (let A = 0; A < h.length; A += 3) {
      _.transformMat4(u, [h[A], h[A + 1], h[A + 2]], E);
      for (let v = 0; v < 3; v++) u[v] < F[v] && (F[v] = u[v]), u[v] > m[v] && (m[v] = u[v]);
    }
  }
  return Number.isFinite(F[0]) ? { min: F, max: m, size: [m[0] - F[0], m[1] - F[1], m[2] - F[2]] } : { min: [0, 0, 0], max: [0, 0, 0], size: [0, 0, 0] };
}
function nn(c, l) {
  let { size: F } = fs(c), m = Math.max(F[0], F[1], F[2]);
  if (m > 1e-6 && l > 0) {
    let u = l / m;
    _.set(c.scale, c.scale[0] * u, c.scale[1] * u, c.scale[2] * u), c.markDirty();
  }
  return c;
}
function on(c) {
  let { min: l } = fs(c);
  return c.position[1] -= l[1], c.markDirty(), c;
}
var gr = "rz.rawmouse";
function vr() {
  try {
    return globalThis.localStorage?.getItem(gr) === "1";
  } catch {
    return false;
  }
}
function ds(c, { raw: l = vr() } = {}) {
  if (!c || !c.requestPointerLock) return Promise.resolve();
  if (!l) try {
    let m = c.requestPointerLock();
    return m && typeof m.catch == "function" ? m.catch(() => {
    }) : Promise.resolve();
  } catch {
    return Promise.resolve();
  }
  let F;
  try {
    F = c.requestPointerLock({ unadjustedMovement: true });
  } catch {
    F = null;
  }
  return F && typeof F.catch == "function" ? F.catch(() => {
    try {
      return c.requestPointerLock();
    } catch {
      return;
    }
  }) : Promise.resolve();
}
function ps({ spike: c = 260, ratio: l = 8 } = {}) {
  let F = 0, m = 0, u = null, S = () => {
    m = 2, F = 0;
  };
  return typeof document < "u" && document.addEventListener("pointerlockchange", S), function(E, h) {
    if (!Number.isFinite(E) || !Number.isFinite(h)) return null;
    if (m > 0) return m--, null;
    let A = Math.max(Math.abs(E), Math.abs(h));
    return A > c && A > Math.max(F, 12) * l && !(u && u[0] * E + u[1] * h > 0) ? (u = [E, h], null) : (u = null, F = F * 0.85 + A * 0.15, [E, h]);
  };
}
var re = 256, Fe = 64, ms = 3072, ae = 768, gs = 144, vs = 64, rn = 16, an = typeof GPUTextureUsage < "u" && GPUTextureUsage.TRANSIENT_ATTACHMENT || 0, ce = class extends zt {
  constructor(c, l) {
    super();
    let F = c.getContext("webgpu");
    if (!F) throw new Error("This canvas will not take WebGPU.");
    this.canvas = c, this.context = F, this.gl = null, this.backend = "webgpu", this.maxSamples = 4, this.ready = false, this._init(l);
  }
  ["_init"](c) {
    this.kit = c;
    let l = this.device = c.device;
    this.gpuName = c.name || "", this._gen = (this._gen || 0) + 1, this.context.configure({ device: l, format: c.format, alphaMode: "opaque" });
    let F = GPUBufferUsage, m = (S, E = F.UNIFORM | F.COPY_DST) => l.createBuffer({ size: S, usage: E });
    this._uploaded = /* @__PURE__ */ new WeakMap(), this._byImage = /* @__PURE__ */ new WeakMap(), this._frameData = new Float32Array(gs), this._frameBufs = { main: m(gs * 4) }, this._frameGroups = { main: null }, this._newFrameBuf = () => m(gs * 4), this._lightBuf = m(64), this._lightGroup = l.createBindGroup({ layout: c.groups.light, entries: [{ binding: 0, resource: { buffer: this._lightBuf } }] }), this._postBuf = m(rn * re), this._postData = new Float32Array(rn * vs), this._drawCap = 0, this._jointCap = 0, this._drawBuf = this._jointBuf = this._drawGroup = null, this._grow(512, 8), this._slots = /* @__PURE__ */ new Map(), this._jointSlots = /* @__PURE__ */ new Map(), this._compare = l.createSampler({ compare: "less-equal", magFilter: "linear", minFilter: "linear" }), this._clamp = l.createSampler({ magFilter: "linear", minFilter: "linear" }), this._matSampler = null, this._matAniso = 0;
    let u = (S) => {
      let E = l.createTexture({ size: [1, 1], format: "rgba8unorm", usage: GPUTextureUsage.TEXTURE_BINDING | GPUTextureUsage.COPY_DST });
      return l.queue.writeTexture({ texture: E }, new Uint8Array(S), { bytesPerRow: 4 }, [1, 1]), E;
    };
    if (this._white = u([255, 255, 255, 255]), this._whiteGroup = l.createBindGroup({ layout: c.groups.texture, entries: [{ binding: 0, resource: this._white.createView() }] }), this._noReflection = u([0, 0, 0, 255]).createView(), this._zeros = null, this._targets = null, this._refl = null, this._postSize = null, this._reflection = null, !this.shadows) this.shadows = new ws(this, 2048);
    else {
      let S = this.shadows.enabled;
      this.shadows._build(this.shadows.size || 2048), this.shadows.enabled = S;
    }
    l.lost.then((E) => this._lost(E, l)), this.ready = true;
  }
  async ["_lost"](c, l) {
    if (l !== this.device || this._disposed || (this.ready = false, console.warn("[render] the WebGPU device was lost:", c && c.message), c && c.reason === "destroyed")) return;
    let F = await is({ force: true });
    if (F && !this._disposed) try {
      this._init(F);
      return;
    } catch (m) {
      console.warn("[render] could not start WebGPU again:", m.message);
    }
    Wi(), console.warn("[render] WebGPU could not be restarted. Reload to carry on with WebGL.");
  }
  ["configure"](c = {}) {
    return c.lighting !== void 0 && (this.lighting = c.lighting | 0), c.reflections !== void 0 && (this.reflections = c.reflections | 0), c.mirrors !== void 0 && (this.mirrorSlots = Math.max(0, c.mirrors | 0)), c.post !== void 0 && (this.postLevel = c.post | 0, this.postLevel || this._dropPost()), c.shadowTaps !== void 0 && (this.shadowTaps = c.shadowTaps | 0), c.shadowEvery !== void 0 && (this.shadowEvery = Math.max(1, c.shadowEvery | 0)), c.msaa !== void 0 && this.setSamples(c.msaa), c.aniso !== void 0 && (this.anisotropy = c.aniso), this;
  }
  ["setSamples"](c) {
    let l = Math.max(0, c | 0);
    return this.samples = l ? Math.min(l, this.maxSamples) : 0, this.samples;
  }
  ["_sampleCount"](c, l) {
    let F = this.samplesFor(c, l);
    return F >= 4 || F >= 2 && c * l <= 24e5 ? 4 : 1;
  }
  ["_materialSampler"]() {
    let c = Math.max(1, Math.min(16, Math.round(this.anisotropy || 1)));
    return this._matSampler && this._matAniso === c ? this._matSampler : (this._matAniso = c, this._matSampler = this.device.createSampler({ addressModeU: "repeat", addressModeV: "repeat", magFilter: "linear", minFilter: "linear", mipmapFilter: "linear", maxAnisotropy: c }), this._matSampler);
  }
  ["_grow"](c, l) {
    if (c <= this._drawCap && l <= this._jointCap && this._drawGroup) return;
    let F = GPUBufferUsage;
    c > this._drawCap && (this._drawCap = Math.max(c, this._drawCap * 2, 64), this._drawBuf && this._drawBuf.destroy(), this._drawBuf = this.device.createBuffer({ size: this._drawCap * re, usage: F.UNIFORM | F.COPY_DST }), this._drawData = new Float32Array(this._drawCap * Fe)), l > this._jointCap && (this._jointCap = Math.max(l, this._jointCap * 2, 4), this._jointBuf && this._jointBuf.destroy(), this._jointBuf = this.device.createBuffer({ size: this._jointCap * ms, usage: F.UNIFORM | F.COPY_DST }), this._jointData = new Float32Array(this._jointCap * ae)), this._drawGroup = this.device.createBindGroup({ layout: this.kit.groups.draw, entries: [{ binding: 0, resource: { buffer: this._drawBuf, size: 240 } }, { binding: 1, resource: { buffer: this._jointBuf, size: ms } }] });
  }
  ["upload"](F) {
    let m = this._uploaded.get(F);
    if (m && m.gen === this._gen) return m;
    let u = this.device, S = GPUBufferUsage, E = F.positions.length / 3, A = (O, M) => {
      let T = O.byteLength + 3 & -4, x = u.createBuffer({ size: Math.max(4, T), usage: M | S.COPY_DST, mappedAtCreation: true });
      return new O.constructor(x.getMappedRange(0, T)).set(O), x.unmap(), x;
    }, v = (O) => O instanceof Float32Array ? O : new Float32Array(O), g = this._zerosFor(E * 16), b = (O) => O ? A(v(O), S.VERTEX) : g;
    if (m = { gen: this._gen, positions: A(v(F.positions), S.VERTEX), normals: b(F.normals), uvs: b(F.uvs), skinned: !!(F.joints && F.weights), joints: null, weights: null, index: null, indexFormat: "uint16", count: E }, m.skinned && (m.joints = b(F.joints), m.weights = b(F.weights)), F.indices) {
      let O = E > 65535;
      m.index = A(O ? new Uint32Array(F.indices) : new Uint16Array(F.indices), S.INDEX), m.indexFormat = O ? "uint32" : "uint16", m.count = F.indices.length;
    }
    return this._uploaded.set(F, m), m;
  }
  ["_zerosFor"](c) {
    if (this._zeros && this._zeros.size >= c) return this._zeros;
    let l = Math.max(1024, 1 << Math.ceil(Math.log2(Math.max(c, 4))));
    return this._zeros = this.device.createBuffer({ size: l, usage: GPUBufferUsage.VERTEX }), this._zeros;
  }
  ["resize"](c, l) {
    (this.canvas.width !== c || this.canvas.height !== l) && (this.canvas.width = c, this.canvas.height = l);
  }
  ["render"](F, S, A, O = null) {
    if (!this.ready) return;
    let T = this.canvas.width, x = this.canvas.height;
    S.update(T / Math.max(x, 1)), this.stats.draws = 0, this.stats.triangles = 0, this.stats.culled = 0, this.stats.shadowDrawn = false;
    let { drawables: q, lights: L, mirrors: I } = this._gather(F), z = this._mirrorStrips(I), K = z ? this._mirrorsInView(I, S, z) : [], H = K.length ? this._reflected(q) : q;
    K.length || (this.stats.mirrors = 0);
    let d0 = [];
    if (O) {
      for (let d8 of O.visibleNodes()) d8.mesh && d0.push(d8);
    }
    let d1 = 0;
    for (let d9 of [H, d0]) for (let dd of d9) dd.skin && dd.skin.matrices && d1++;
    this._grow(H.length + d0.length + 1, d1 + 1), this._slots.clear(), this._jointSlots.clear(), this._slotCount = 0, this._jointCount = 0, this._materialSampler();
    let d2 = this.device.createCommandEncoder();
    this.shadows.enabled && this._shadowPass(d2, q, S, A);
    let d3 = this.postLevel > 0, d4 = d3, d5 = this._sampleCount(T, x);
    this.stats.post = d3 ? this.postLevel : 0, this._reflection = null, this._reflection = K.length ? this._renderReflections(d2, K, z, H, L, S, A, d4, T, x) : null;
    let d6 = this.context.getCurrentTexture().createView();
    d3 ? this._renderPost(d2, q, L, S, A, d0, d6, T, x, d5) : this._renderDirect(d2, q, L, S, A, d0, d6, T, x, d5), this.stats.samples = d5 > 1 ? d5 : 0;
    let d7 = this.device.queue;
    this._slotCount && d7.writeBuffer(this._drawBuf, 0, this._drawData, 0, this._slotCount * Fe), this._jointCount && d7.writeBuffer(this._jointBuf, 0, this._jointData, 0, this._jointCount * ae), d7.submit([d2.finish()]);
  }
  ["_renderDirect"](F, m, S, E, A, v, g, b, O, M) {
    let T = this._screenTargets(b, O, M), x = F.beginRenderPass({ colorAttachments: [T.colour ? { view: T.colour, resolveTarget: g, loadOp: "clear", clearValue: [0, 0, 0, 1], storeOp: "discard" } : { view: g, loadOp: "clear", clearValue: [0, 0, 0, 1], storeOp: "store" }], depthStencilAttachment: { view: T.depth, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "discard" } }), y = { format: this.kit.format, samples: M };
    this._drawWorld(x, "main", m, S, E, A, false, y, null), v.length && (x.setPipeline(qi(this.kit, y.format, M)), x.draw(3), this._drawNodes(x, v, y, false, "overlay")), x.end();
  }
  ["_screenTargets"](c, l, F) {
    let m = this._targets;
    if (m && m.w === c && m.h === l && m.samples === F) return m;
    m && (m.depthTex.destroy(), m.colourTex && m.colourTex.destroy());
    let u = GPUTextureUsage.RENDER_ATTACHMENT | an, S = this.device.createTexture({ size: [c, l], format: "depth24plus", sampleCount: F, usage: u }), E = F > 1 ? this.device.createTexture({ size: [c, l], format: this.kit.format, sampleCount: F, usage: u }) : null;
    return this._targets = { w: c, h: l, samples: F, depthTex: S, colourTex: E, depth: S.createView(), colour: E ? E.createView() : null }, this._targets;
  }
  ["_drawWorld"](F, m, S, E, A, v, g, b, O) {
    this._writeFrame(m, A, v, E, g), F.setPipeline(Ae(this.kit, b.format, b.samples)), F.setBindGroup(0, this._frameGroup(m)), F.draw(3);
    let { opaque: M, blended: T } = this._sorted(S, A, O);
    this._drawNodes(F, M, b, false, m), T.length && this._drawNodes(F, T, b, true, m);
  }
  ["_writeFrame"](l, F, m, u, S) {
    let E = this._frameData;
    E.set(F.viewProjection, 0), E.set(this.shadows.matrix, 16), E.set(F.inverseViewProjection, 32), E.set(F.position, 48), E[51] = m.exposure ?? 0.62, E.set(m.direction(), 52), E[55] = m.ambient ?? 1, E.set(m.sunColour, 56), E[59] = this.fogDensity, E.set(m.horizon, 60), E[63] = this.shadows.enabled ? 1 : 0, E.set(m.ground, 64), E[67] = S ? 1 : 0, E.set(m.zenith, 68), E[71] = this.lighting, E[72] = E[73] = 1 / (this.shadows.size || 1), E[74] = this.shadowTaps;
    let h = this._pickLights(u, F);
    E[75] = h, E[76] = m.sunSize, E[77] = m.stars || 0;
    for (let A = 0; A < h; A++) E.set(this._lightPos.subarray(A * 4, A * 4 + 4), 80 + A * 4), E.set(this._lightCol.subarray(A * 3, A * 3 + 3), 112 + A * 4);
    this.device.queue.writeBuffer(this._frameBufs[l] || (this._frameBufs[l] = this._newFrameBuf()), 0, E);
  }
  ["_frameGroup"](c) {
    let l = c === "main" && this._reflection ? this._reflection.view : this._noReflection, F = this._frameGroups[c];
    if (F && F.shadow === this.shadows.depthView && F.refl === l && F.sampler === this._matSampler) return F.group;
    let m = this.device.createBindGroup({ layout: this.kit.groups.frame, entries: [{ binding: 0, resource: { buffer: this._frameBufs[c] } }, { binding: 1, resource: this.shadows.depthView }, { binding: 2, resource: this._compare }, { binding: 3, resource: l }, { binding: 4, resource: this._clamp }, { binding: 5, resource: this._matSampler }] });
    return this._frameGroups[c] = { shadow: this.shadows.depthView, refl: l, sampler: this._matSampler, group: m }, m;
  }
  ["_slot"](F) {
    let m = this._slots.get(F);
    if (m !== void 0) return m;
    m = this._slotCount++, this._slots.set(F, m);
    let u = this._drawData, S = m * Fe, E = F.material || Et, h = F.worldMatrix(), A = F.skin && F.skin.matrices ? F.skin : null;
    u.set(A ? A.root ? A.root.worldMatrix() : Qt : h, S), wr(u, S + 16, h);
    let v = E.colour, g = E.emissive;
    return u[S + 28] = v[0], u[S + 29] = v[1], u[S + 30] = v[2], u[S + 31] = E.alpha, u[S + 32] = g[0], u[S + 33] = g[1], u[S + 34] = g[2], u[S + 35] = Math.max(Number.isFinite(E.roughness) ? E.roughness : 0.7, 0.03), u[S + 36] = Number.isFinite(E.metallic) ? E.metallic : 0, u[S + 37] = E.grid, u[S + 38] = E.alphaCutoff, u[S + 39] = 0, u[S + 56] = 0, u[S + 57] = E.glowMap ? 1 : 0, u[S + 58] = 1, m;
  }
  ["_jointOffset"](c) {
    let l = this._jointSlots.get(c);
    if (l === void 0) {
      l = this._jointCount++, this._jointSlots.set(c, l);
      let F = c.matrices;
      this._jointData.set(F.length > ae ? F.subarray(0, ae) : F, l * ae);
    }
    return l * ms;
  }
  ["_drawNodes"](F, S, A, O, T) {
    let x = this._drawData, q = T === "main" ? this._reflection : null, L = null, I = null, z = null, K = false;
    for (let H of S) {
      let d0 = this.upload(H.mesh), d1 = H.material || Et, d2 = H.skin && H.skin.matrices ? H.skin : null, d3 = !!d2 && d0.skinned, d4 = this._slot(H), d5 = d4 * Fe, d6 = this._textureFor(d1);
      x[d5 + 39] = d6 ? 1 : 0, x[d5 + 58] = T === "overlay" ? 0 : 1;
      let d7 = q && q.matrices.get(H);
      d7 && (x.set(d7, d5 + 40), x[d5 + 56] = 1);
      let d8 = Se(this.kit, { format: A.format, samples: A.samples, blend: O, cull: !d1.doubleSided, skinned: d3 });
      d8 !== L && (F.setPipeline(d8), L = d8), F.setBindGroup(1, this._drawGroup, [d4 * re, d3 ? this._jointOffset(d2) : 0]);
      let d9 = d6 ? d6.group : this._whiteGroup;
      d9 !== I && (F.setBindGroup(2, d9), I = d9), (d0 !== z || d3 !== K) && (F.setVertexBuffer(0, d0.positions), F.setVertexBuffer(1, d0.normals), F.setVertexBuffer(2, d0.uvs), d3 && (F.setVertexBuffer(3, d0.joints), F.setVertexBuffer(4, d0.weights)), d0.index && F.setIndexBuffer(d0.index, d0.indexFormat), z = d0, K = d3), d0.index ? F.drawIndexed(d0.count) : F.draw(d0.count), this.stats.draws++, this.stats.triangles += d0.count / 3;
    }
  }
  ["_textureFor"](c) {
    let l = c.map;
    if (!l) return null;
    let F = c._texture;
    if (F && F.gen !== this._gen && (F = c._texture = null), F && c.mapVersion !== void 0 && c._uploadedVersion !== c.mapVersion) {
      let u = this._uploadPicture(l, F);
      return c._uploadedVersion = c.mapVersion, c._texture = u || F;
    }
    if (F) return F;
    if (c.mapVersion !== void 0) return F = this._uploadPicture(l, null), F && (c._texture = F, c._uploadedVersion = c.mapVersion), F;
    let m = typeof l == "object" ? this._byImage.get(l) : null;
    return m && m.gen === this._gen ? c._texture = m : (F = this._uploadPicture(l, null), F ? (c._texture = F, typeof l == "object" && this._byImage.set(l, F), F) : null);
  }
  ["_uploadPicture"](F, m) {
    let u = F.naturalWidth || F.videoWidth || F.width || 0, S = F.naturalHeight || F.videoHeight || F.height || 0;
    if (!u || !S) return null;
    let E = this.device, A = GPUTextureUsage, v = m && m.w === u && m.h === S ? m : null;
    if (!v) {
      let b = Math.floor(Math.log2(Math.max(u, S))) + 1, O = E.createTexture({ size: [u, S], format: "rgba8unorm", mipLevelCount: b, usage: A.TEXTURE_BINDING | A.COPY_DST | A.RENDER_ATTACHMENT });
      v = { gen: this._gen, texture: O, w: u, h: S, levels: b, group: E.createBindGroup({ layout: this.kit.groups.texture, entries: [{ binding: 0, resource: O.createView() }] }) }, m && m.texture && m.texture.destroy();
    }
    let g = !(typeof ImageBitmap < "u" && F instanceof ImageBitmap);
    try {
      E.queue.copyExternalImageToTexture({ source: F, flipY: g }, { texture: v.texture }, [u, S]);
    } catch {
      let M = document.createElement("canvas");
      M.width = u, M.height = S, M.getContext("2d").drawImage(F, 0, 0, u, S), E.queue.copyExternalImageToTexture({ source: M, flipY: g }, { texture: v.texture }, [u, S]);
    }
    return this._mipmaps(v), v;
  }
  ["_mipmaps"](c) {
    if (c.levels < 2) return;
    let l = this.device, F = Ki(this.kit, "rgba8unorm"), m = l.createCommandEncoder();
    for (let u = 1; u < c.levels; u++) {
      let S = l.createBindGroup({ layout: F.getBindGroupLayout(0), entries: [{ binding: 0, resource: c.texture.createView({ baseMipLevel: u - 1, mipLevelCount: 1 }) }, { binding: 1, resource: this._clamp }] }), E = m.beginRenderPass({ colorAttachments: [{ view: c.texture.createView({ baseMipLevel: u, mipLevelCount: 1 }), loadOp: "clear", clearValue: [0, 0, 0, 0], storeOp: "store" }] });
      E.setPipeline(F), E.setBindGroup(0, S), E.draw(3), E.end();
    }
    l.queue.submit([m.finish()]);
  }
  ["_shadowPass"](F, m, S, E) {
    if (!this._shadowFrame(m, S, E)) return;
    this.device.queue.writeBuffer(this._lightBuf, 0, this.shadows.matrix);
    let A = F.beginRenderPass({ colorAttachments: [], depthStencilAttachment: { view: this.shadows.depthView, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" } });
    A.setBindGroup(0, this._lightGroup);
    let v = null;
    for (let g of m) {
      let b = g.material || Et;
      if (!b.castShadow || b.alpha < 1) continue;
      let O = this.upload(g.mesh), M = g.skin && g.skin.matrices ? g.skin : null, T = !!M && O.skinned, x = this._slot(g), y = ns(this.kit, T);
      y !== v && (A.setPipeline(y), v = y), A.setBindGroup(1, this._drawGroup, [x * re, T ? this._jointOffset(M) : 0]), A.setVertexBuffer(0, O.positions), T && (A.setVertexBuffer(1, O.joints), A.setVertexBuffer(2, O.weights)), O.index ? (A.setIndexBuffer(O.index, O.indexFormat), A.drawIndexed(O.count)) : A.draw(O.count);
    }
    A.end();
  }
  ["_renderReflections"](F, S, E, A, b, O, M, T, x, y) {
    let q = this.reflections >= 2 ? 1 : 0.5, L = this.device.limits && this.device.limits.maxTextureDimension2D || 8192, I = Math.max(16, Math.min(Math.round(x * q), Math.floor(L / E))), z = Math.max(16, Math.min(Math.round(y * q), L)), K = this._reflectionTarget(I * E, z, T), H = F.beginRenderPass({ colorAttachments: [{ view: K.view, loadOp: "clear", clearValue: [0, 0, 0, 1], storeOp: "store" }], depthStencilAttachment: { view: K.depth, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "discard" } }), d0 = this.stats.draws, d1 = /* @__PURE__ */ new Map();
    return S.forEach((d2, d3) => {
      let d4 = this._mirrorView(d2, O, d3, E);
      H.setViewport(d3 * I, 0, I, z, 0, 1), H.setScissorRect(d3 * I, 0, I, z), this._drawWorld(H, "mirror" + d3, A, b, d4, M, T, { format: K.format, samples: 1 }, (d5) => !!d5.mirror || this._noMirror(d5)), d1.set(d2.node, d4.textureMatrix);
    }), H.end(), this.stats.reflectionDraws = this.stats.draws - d0, this.stats.mirrors = S.length, { view: K.view, matrices: d1 };
  }
  ["_reflectionTarget"](l, F, m) {
    let u = m ? "rgba16float" : "rgba8unorm", S = this._refl;
    if (S && S.w === l && S.h === F && S.format === u) return S;
    S && (S.tex.destroy(), S.depthTex.destroy());
    let E = GPUTextureUsage, h = this.device.createTexture({ size: [l, F], format: u, usage: E.RENDER_ATTACHMENT | E.TEXTURE_BINDING }), A = this.device.createTexture({ size: [l, F], format: "depth24plus", usage: E.RENDER_ATTACHMENT | an });
    return this._refl = { w: l, h: F, format: u, tex: h, depthTex: A, view: h.createView(), depth: A.createView() }, this._refl;
  }
  ["_renderPost"](F, S, A, O, T, q, L, I, z, K) {
    let H = this._postTargets(I, z, K), d0 = te[this.postLevel] || te[1], d1 = K > 1, d2 = (dC, dc) => d1 ? { view: H.msView, resolveTarget: H.colourView, loadOp: dC, clearValue: [0, 0, 0, 1], storeOp: dc ? "store" : "discard" } : { view: H.colourView, loadOp: dC, clearValue: [0, 0, 0, 1], storeOp: "store" }, d3 = F.beginRenderPass({ colorAttachments: [d2("clear", q.length > 0)], depthStencilAttachment: { view: H.depthView, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "store" } }), d4 = { format: "rgba16float", samples: K };
    this._drawWorld(d3, "main", S, A, O, T, true, d4, null), d3.end();
    let d5 = this._postData, d6 = this._invProj || (this._invProj = P.create());
    P.invert(d6, O.projection);
    let d7 = (dC, dc) => {
      let dl = dC * vs;
      d5.fill(0, dl, dl + vs), dc(dl);
    }, d8 = this.grade;
    d7(0, (dC) => {
      d5.set(d6, dC), d5[dC + 16] = 1 / H.ao.w, d5[dC + 17] = 1 / H.ao.h, d5[dC + 20] = d0.aoRadius, d5[dC + 21] = d0.aoIntensity, d5[dC + 22] = O.projection[5] * 0.5, d5[dC + 23] = d0.aoSamples;
    }), d7(1, (dC) => {
      d5[dC + 16] = 1 / H.ao.w, d5[dC + 17] = 1 / H.ao.h, d5[dC + 18] = O.near, d5[dC + 19] = O.far;
    }), d7(2, (dC) => {
      d5[dC + 16] = 1 / I, d5[dC + 17] = 1 / z, d5[dC + 24] = d0.threshold;
    });
    let d9 = Math.min(d0.bloom, H.chain.length);
    for (let dC = 1; dC < d9; dC++) d7(2 + dC, (dc) => {
      d5[dc + 16] = 1 / H.chain[dC - 1].w, d5[dc + 17] = 1 / H.chain[dC - 1].h;
    });
    for (let dc = d9 - 1; dc > 0; dc--) d7(7 + dc, (dl) => {
      d5[dl + 16] = 1 / H.chain[dc].w, d5[dl + 17] = 1 / H.chain[dc].h;
    });
    d7(14, (dl) => {
      d5[dl + 25] = T.exposure ?? 0.62, d5[dl + 26] = d0.aoStrength, d5[dl + 27] = d0.bloomStrength / Math.max(1, d9 - 1), d5[dl + 28] = d8.saturation, d5[dl + 29] = d8.contrast, d5[dl + 30] = d8.vignette, d5[dl + 31] = this.debug === "ao" ? 1 : 0, d5[dl + 32] = d8.tint[0], d5[dl + 33] = d8.tint[1], d5[dl + 34] = d8.tint[2], d5[dl + 35] = 1, d5[dl + 36] = d9 > 0 ? 1 : 0;
    }), this.device.queue.writeBuffer(this._postBuf, 0, d5);
    let dd = (dl, dF, dk = "clear") => {
      let dm = F.beginRenderPass({ colorAttachments: [{ view: dF, loadOp: dk, clearValue: [0, 0, 0, 0], storeOp: "store" }] });
      dm.setPipeline(dl.pipe), dm.setBindGroup(0, dl.uniforms), dm.setBindGroup(1, dl.textures), dm.draw(3), dm.end();
    };
    dd(H.steps.ao, H.ao.view), dd(H.steps.blur, H.aoBlur.view), q.length && (d3 = F.beginRenderPass({ colorAttachments: [d2("load", false)], depthStencilAttachment: { view: H.depthView, depthClearValue: 1, depthLoadOp: "clear", depthStoreOp: "discard" } }), d3.setBindGroup(0, this._frameGroup("main")), this._drawNodes(d3, q, d4, false, "overlay"), d3.end()), dd(H.steps.bright, H.chain[0].view);
    for (let dl = 1; dl < d9; dl++) dd(H.steps.down[dl], H.chain[dl].view);
    for (let dF = d9 - 1; dF > 0; dF--) dd(H.steps.up[dF], H.chain[dF - 1].view, "load");
    dd(H.steps.composite, L);
  }
  get ["grade"]() {
    return this._grade || (this._grade = { exposure: 1, saturation: 0.97, contrast: 1.05, vignette: 0.26, tint: [1, 1, 1] });
  }
  ["_postTargets"](F, S, A) {
    let O = this._postSize;
    if (O && O.width === F && O.height === S && O.samples === A) return O;
    this._dropPost();
    let T = this.device, q = GPUTextureUsage, L = this.kit, I = (dC, dc, dl, dF = 0, dk = 1) => {
      let dm = T.createTexture({ size: [dC, dc], format: dl, sampleCount: dk, usage: q.RENDER_ATTACHMENT | dF });
      return { tex: dm, view: dm.createView(), w: dC, h: dc };
    }, z = I(F, S, "rgba16float", q.TEXTURE_BINDING), K = A > 1 ? I(F, S, "rgba16float", 0, A) : null, H = I(F, S, "depth24plus", q.TEXTURE_BINDING, A), d0 = Math.max(1, F >> 1), d1 = Math.max(1, S >> 1), d2 = I(d0, d1, "rgba8unorm", q.TEXTURE_BINDING), d3 = I(d0, d1, "rgba8unorm", q.TEXTURE_BINDING), d4 = [], d5 = d0, d6 = d1;
    for (let dC = 0; dC < 6; dC++) d4.push(I(d5, d6, "rgba16float", q.TEXTURE_BINDING)), d5 = Math.max(1, d5 >> 1), d6 = Math.max(1, d6 >> 1);
    let d7 = A > 1, d8 = (dc, dl, dF, dk) => {
      let dm = Ji(L, dc, dl, (dc === "ao" || dc === "blur") && d7);
      return { pipe: dm, uniforms: T.createBindGroup({ layout: dm.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: this._postBuf, offset: dF * re, size: 160 } }] }), textures: T.createBindGroup({ layout: dm.getBindGroupLayout(1), entries: dk.map((du, dj) => ({ binding: dj, resource: du })) }) };
    }, d9 = this._clamp, dd = { ao: d8("ao", "rgba8unorm", 0, [H.view]), blur: d8("blur", "rgba8unorm", 1, [H.view, d2.view, d9]), bright: d8("bright", "rgba16float", 2, [z.view, d9]), down: [], up: [], composite: d8("composite", L.format, 14, [z.view, d3.view, d4[0].view, d9]) };
    for (let dc = 1; dc < 6; dc++) dd.down[dc] = d8("down", "rgba16float", 2 + dc, [d4[dc - 1].view, d9]), dd.up[dc] = d8("up", "rgba16float", 7 + dc, [d4[dc].view, d9]);
    return this._postSize = { width: F, height: S, samples: A, colour: z, ms: K, depth: H, ao: d2, aoBlur: d3, chain: d4, steps: dd, colourView: z.view, msView: K ? K.view : null, depthView: H.view }, this._postSize;
  }
  ["_dropPost"]() {
    let c = this._postSize;
    if (c) {
      for (let l of [c.colour, c.ms, c.depth, c.ao, c.aoBlur, ...c.chain]) l && l.tex.destroy();
      this._postSize = null;
    }
  }
  ["dispose"]() {
    this._disposed = true, this.ready = false;
    try {
      this.device.destroy();
    } catch {
    }
  }
}, ws = class {
  constructor(c, l) {
    this.renderer = c, this.extent = 22, this.enabled = true, this.supported = true, this.view = P.create(), this.projection = P.create(), this.matrix = P.create(), this.texture = null, this.generation = 0, this._build(l);
  }
  ["resize"](c) {
    if (!c) {
      this.enabled = false;
      return;
    }
    if (c === this.size && this.texture) {
      this.enabled = this.supported;
      return;
    }
    this._build(c);
  }
  ["_build"](c) {
    let l = this.renderer.device;
    this.texture && this.texture.destroy(), this.size = c, this.generation++, this.texture = l.createTexture({ size: [c, c], format: "depth32float", usage: GPUTextureUsage.RENDER_ATTACHMENT | GPUTextureUsage.TEXTURE_BINDING }), this.depthView = this.texture.createView(), this.enabled = true;
  }
};
function wr(F, S, E) {
  let A = E[0], v = E[1], g = E[2], b = E[4], O = E[5], M = E[6], T = E[8], x = E[9], y = E[10], w = y * O - M * x, q = -y * b + M * T, L = x * b - O * T, I = A * w + v * q + g * L;
  if (!I) {
    F[S] = 1, F[S + 1] = 0, F[S + 2] = 0, F[S + 4] = 0, F[S + 5] = 1, F[S + 6] = 0, F[S + 8] = 0, F[S + 9] = 0, F[S + 10] = 1;
    return;
  }
  I = 1 / I, F[S] = w * I, F[S + 1] = q * I, F[S + 2] = L * I, F[S + 4] = (-y * v + g * x) * I, F[S + 5] = (y * A - g * T) * I, F[S + 6] = (-x * A + v * T) * I, F[S + 8] = (M * v - g * O) * I, F[S + 9] = (-M * A + g * b) * I, F[S + 10] = (O * A - v * b) * I;
}
function ke(d0, d1) {
  let d2 = new Float32Array(d0 * 3), d3 = new Float32Array(d0 * 3), d4 = new Float32Array(d0 * 3), d5 = [0, 0, 0];
  for (let dk = 0; dk < d0; dk++) {
    let dm = 1 / 0, du = 1 / 0, dj = 1 / 0, dW = -1 / 0, dS = -1 / 0, dE = -1 / 0;
    for (let dA = 0; dA < 3; dA++) d1(dk, dA, d5), d5[0] < dm && (dm = d5[0]), d5[0] > dW && (dW = d5[0]), d5[1] < du && (du = d5[1]), d5[1] > dS && (dS = d5[1]), d5[2] < dj && (dj = d5[2]), d5[2] > dE && (dE = d5[2]);
    let dh = dk * 3;
    d2[dh] = dm, d2[dh + 1] = du, d2[dh + 2] = dj, d3[dh] = dW, d3[dh + 1] = dS, d3[dh + 2] = dE, d4[dh] = (dm + dW) / 2, d4[dh + 1] = (du + dS) / 2, d4[dh + 2] = (dj + dE) / 2;
  }
  let d6 = new Uint32Array(d0);
  for (let dv = 0; dv < d0; dv++) d6[dv] = dv;
  let d7 = Math.max(1, d0 * 2), d8 = new Float32Array(d7 * 3), d9 = new Float32Array(d7 * 3), dd = new Int32Array(d7), dC = new Uint32Array(d7), dc = new Uint32Array(d7), dl = 0, dF = [[dl++, 0, d0]];
  for (; dF.length; ) {
    let [dZ, dg, db] = dF.pop(), dJ = 1 / 0, dO = 1 / 0, dM = 1 / 0, dT = -1 / 0, dD = -1 / 0, dG = -1 / 0, dR = 1 / 0, dx = 1 / 0, df = 1 / 0, dy = -1 / 0, dN = -1 / 0, dX = -1 / 0;
    for (let dK = dg; dK < db; dK++) {
      let dH = d6[dK] * 3;
      d2[dH] < dJ && (dJ = d2[dH]), d3[dH] > dT && (dT = d3[dH]), d2[dH + 1] < dO && (dO = d2[dH + 1]), d3[dH + 1] > dD && (dD = d3[dH + 1]), d2[dH + 2] < dM && (dM = d2[dH + 2]), d3[dH + 2] > dG && (dG = d3[dH + 2]), d4[dH] < dR && (dR = d4[dH]), d4[dH] > dy && (dy = d4[dH]), d4[dH + 1] < dx && (dx = d4[dH + 1]), d4[dH + 1] > dN && (dN = d4[dH + 1]), d4[dH + 2] < df && (df = d4[dH + 2]), d4[dH + 2] > dX && (dX = d4[dH + 2]);
    }
    d8[dZ * 3] = dJ, d8[dZ * 3 + 1] = dO, d8[dZ * 3 + 2] = dM, d9[dZ * 3] = dT, d9[dZ * 3 + 1] = dD, d9[dZ * 3 + 2] = dG;
    let dP = db - dg;
    if (dP <= 6) {
      dd[dZ] = -1, dC[dZ] = dg, dc[dZ] = dP;
      continue;
    }
    let dw = dy - dR, dq = dN - dx, dL = dX - df, dp = dw >= dq && dw >= dL ? 0 : dq >= dL ? 1 : 2, dB = dp === 0 ? (dR + dy) / 2 : dp === 1 ? (dx + dN) / 2 : (df + dX) / 2, dV = dg, dI = db - 1;
    for (; dV <= dI; ) if (d4[d6[dV] * 3 + dp] < dB) dV++;
    else {
      let dQ = d6[dV];
      d6[dV] = d6[dI], d6[dI] = dQ, dI--;
    }
    let dz = dV;
    (dz === dg || dz === db) && (dz = dg + db >> 1);
    let dY = dl++, dU = dl++;
    dd[dZ] = dY, dF.push([dU, dz, db], [dY, dg, dz]);
  }
  return { lo: d8.slice(0, dl * 3), hi: d9.slice(0, dl * 3), left: dd.slice(0, dl), start: dC.slice(0, dl), size: dc.slice(0, dl), order: d6, nodes: dl, count: d0 };
}
function ys(F, m, S, E, A, v, g, b, O) {
  let M = m * 3, T = 0, x = O, y = (F.lo[M] - S) * v, w = (F.hi[M] - S) * v;
  if (y > w) {
    let q = y;
    y = w, w = q;
  }
  if (y > T && (T = y), w < x && (x = w), T > x) return -1;
  if (y = (F.lo[M + 1] - E) * g, w = (F.hi[M + 1] - E) * g, y > w) {
    let L = y;
    y = w, w = L;
  }
  if (y > T && (T = y), w < x && (x = w), T > x) return -1;
  if (y = (F.lo[M + 2] - A) * b, w = (F.hi[M + 2] - A) * b, y > w) {
    let I = y;
    y = w, w = I;
  }
  return y > T && (T = y), w < x && (x = w), T > x ? -1 : T;
}
var cn = [], jt = 0, ln = () => cn[jt] || (cn[jt] = []);
function Ce(F, S, A, O, M) {
  if (!F || !F.nodes) return null;
  let T = 1 / A[0], x = 1 / A[1], q = 1 / A[2], L = O, I = -1;
  if (ys(F, 0, S[0], S[1], S[2], T, x, q, L) < 0) return null;
  let z = ln();
  jt++;
  try {
    let K = 0;
    for (z[K++] = 0; K > 0; ) {
      let H = z[--K];
      if (F.left[H] < 0) {
        let d4 = F.start[H], d5 = d4 + F.size[H];
        for (let d6 = d4; d6 < d5; d6++) {
          let d7 = F.order[d6], d8 = M(d7);
          d8 > 0 && d8 < L && (L = d8, I = d7);
        }
        continue;
      }
      let d0 = F.left[H], d1 = d0 + 1, d2 = ys(F, d0, S[0], S[1], S[2], T, x, q, L), d3 = ys(F, d1, S[0], S[1], S[2], T, x, q, L);
      d2 >= 0 && d3 >= 0 ? d2 <= d3 ? (z[K++] = d1, z[K++] = d0) : (z[K++] = d0, z[K++] = d1) : d2 >= 0 ? z[K++] = d0 : d3 >= 0 && (z[K++] = d1);
    }
  } finally {
    jt--;
  }
  return I < 0 ? null : { t: L, tri: I };
}
function hn(F, m, u, S) {
  if (!F || !F.nodes) return;
  let E = ln();
  jt++;
  try {
    let A = 0;
    for (E[A++] = 0; A > 0; ) {
      let v = E[--A], g = v * 3;
      if (!(F.lo[g] > u[0] || F.hi[g] < m[0] || F.lo[g + 1] > u[1] || F.hi[g + 1] < m[1] || F.lo[g + 2] > u[2] || F.hi[g + 2] < m[2])) {
        if (F.left[v] < 0) {
          let b = F.start[v], O = b + F.size[v];
          for (let M = b; M < O; M++) S(F.order[M]);
          continue;
        }
        E[A++] = F.left[v] + 1, E[A++] = F.left[v];
      }
    }
  } finally {
    jt--;
  }
}
var le = class n2 {
  constructor(c, l) {
    this.min = Float32Array.from(c), this.max = Float32Array.from(l);
  }
  static ["fromCentreSize"](c, l) {
    return new n2([c[0] - l[0] / 2, c[1] - l[1] / 2, c[2] - l[2] / 2], [c[0] + l[0] / 2, c[1] + l[1] / 2, c[2] + l[2] / 2]);
  }
  ["contains"](c) {
    return c[0] >= this.min[0] && c[0] <= this.max[0] && c[1] >= this.min[1] && c[1] <= this.max[1] && c[2] >= this.min[2] && c[2] <= this.max[2];
  }
  ["closestPoint"](c, l) {
    return _.set(c, mt(l[0], this.min[0], this.max[0]), mt(l[1], this.min[1], this.max[1]), mt(l[2], this.min[2], this.max[2]));
  }
}, It = class n3 {
  constructor() {
    this.boxes = [], this.meshes = [], this._count = 0;
  }
  get ["triangleCount"]() {
    return this._count;
  }
  get ["_tris"]() {
    return { length: this._count };
  }
  ["add"](c) {
    return this.boxes.push(c), c;
  }
  ["addBox"](c, l) {
    return this.add(le.fromCentreSize(c, l));
  }
  ["clear"]() {
    this.boxes.length = 0, this.meshes.length = 0, this._count = 0;
  }
  ["addMesh"](c, l = {}) {
    return this.addBuilt(n3.buildMesh(c, l));
  }
  ["addBuilt"](c) {
    return c ? (this.meshes.push(c), this._count += c.count, c) : null;
  }
  static ["buildMesh"](F, S = {}) {
    let A = Math.floor(F.length / 9);
    if (!A) return null;
    let O = new Uint8Array(A), T = new Float32Array(A * 3), q = 0;
    for (let d0 = 0; d0 < A; d0++) {
      let d1 = d0 * 9, d2 = F[d1 + 3] - F[d1], d3 = F[d1 + 4] - F[d1 + 1], d4 = F[d1 + 5] - F[d1 + 2], d5 = F[d1 + 6] - F[d1], d6 = F[d1 + 7] - F[d1 + 1], d7 = F[d1 + 8] - F[d1 + 2], d8 = d3 * d7 - d4 * d6, d9 = d4 * d5 - d2 * d7, dd = d2 * d6 - d3 * d5, dC = Math.hypot(d8, d9, dd);
      dC < 1e-10 || (O[d0] = 1, T[d0 * 3] = d8 / dC, T[d0 * 3 + 1] = d9 / dC, T[d0 * 3 + 2] = dd / dC, q++);
    }
    if (!q) return null;
    let L = new Float32Array(q * 9), I = new Float32Array(q * 3), z = [1 / 0, 1 / 0, 1 / 0], K = [-1 / 0, -1 / 0, -1 / 0];
    for (let dc = 0, dl = 0; dc < A; dc++) if (O[dc]) {
      for (let dF = 0; dF < 9; dF++) {
        let dk = F[dc * 9 + dF];
        L[dl * 9 + dF] = dk;
        let dm = dF % 3;
        dk < z[dm] && (z[dm] = dk), dk > K[dm] && (K[dm] = dk);
      }
      I[dl * 3] = T[dc * 3], I[dl * 3 + 1] = T[dc * 3 + 1], I[dl * 3 + 2] = T[dc * 3 + 2], dl++;
    }
    let H = ke(q, (du, dj, dW) => {
      let dS = du * 9 + dj * 3;
      dW[0] = L[dS], dW[1] = L[dS + 1], dW[2] = L[dS + 2];
    });
    return { V: L, N: I, count: q, bvh: H, box: new le(z, K), meta: S };
  }
  ["_near"](c, l, F) {
    let m = [c[0] - l, c[1] - l, c[2] - l], u = [c[0] + l, c[1] + l, c[2] + l];
    for (let S of this.meshes) {
      let E = S.box;
      E.min[0] > u[0] || E.max[0] < m[0] || E.min[1] > u[1] || E.max[1] < m[1] || E.min[2] > u[2] || E.max[2] < m[2] || hn(S.bvh, m, u, (h) => F(S, h));
    }
  }
  ["resolveCapsule"](F, S, A, O = 4) {
    let M = { ground: false, ceiling: false, wall: false, normal: _.create() }, T = _.create(), x = _.create(), q = _.create(), L = _.create();
    for (let I = 0; I < O; I++) {
      let z = false;
      for (let K of this.boxes) {
        _.set(T, F[0], F[1] + S, F[2]), _.set(x, F[0], F[1] + A - S, F[2]);
        let H = _r(q, T, x, K);
        K.closestPoint(L, H), _.sub(L, H, L);
        let d0 = _.lengthSq(L);
        if (d0 >= S * S) {
          if (d0 > 1e-8 || !K.contains(H)) continue;
          let d6 = fn(H, K);
          _.add(F, F, d6), z = true;
          continue;
        }
        let d1 = Math.sqrt(d0), d2, d3, d4;
        if (d1 > 1e-6) d2 = L[0] / d1, d3 = L[1] / d1, d4 = L[2] / d1;
        else {
          let d7 = fn(H, K), d8 = _.length(d7) || 1;
          d2 = d7[0] / d8, d3 = d7[1] / d8, d4 = d7[2] / d8;
        }
        let d5 = S - d1;
        F[0] += d2 * d5, F[1] += d3 * d5, F[2] += d4 * d5, z = true, d3 > 0.6 ? (M.ground = true, _.set(M.normal, d2, d3, d4)) : d3 < -0.6 ? M.ceiling = true : M.wall = true;
      }
      if (this._count) {
        let d9 = [S, A / 2, A - S];
        for (let dd of d9) {
          let dC = [F[0], F[1] + dd, F[2]];
          this._near(dC, S, (dc, dl) => {
            dC[0] = F[0], dC[1] = F[1] + dd, dC[2] = F[2];
            let dF = dc.V, dk = dl * 9, dm = dc.N, du = dl * 3;
            yr(q, dC, dF, dk);
            let dj = dC[0] - q[0], dW = dC[1] - q[1], dS = dC[2] - q[2], dE = dj * dj + dW * dW + dS * dS;
            if (dE >= S * S) return;
            let dh = Math.sqrt(dE), dA, dv, dZ;
            if (dh > 1e-5) dA = dj / dh, dv = dW / dh, dZ = dS / dh;
            else {
              let db = (F[0] - dF[dk]) * dm[du] + (F[1] + A / 2 - dF[dk + 1]) * dm[du + 1] + (F[2] - dF[dk + 2]) * dm[du + 2] < 0 ? -1 : 1;
              dA = dm[du] * db, dv = dm[du + 1] * db, dZ = dm[du + 2] * db;
            }
            let dg = S - dh;
            F[0] += dA * dg, F[1] += dv * dg, F[2] += dZ * dg, z = true, dc.meta && dc.meta.climb && Math.abs(dv) < 0.8 && (M.climb = true), dv > 0.6 ? (M.ground = true, _.set(M.normal, dA, dv, dZ)) : dv < -0.6 ? M.ceiling = true : M.wall = true;
          });
        }
      }
      if (!z) break;
    }
    return M;
  }
  ["groundAt"](c, l, F, m) {
    let u = null;
    for (let S of this.boxes) {
      if (c < S.min[0] || c > S.max[0] || l < S.min[2] || l > S.max[2]) continue;
      let E = S.max[1];
      E <= F && E >= F - m && (u === null || E > u) && (u = E);
    }
    if (this._count) {
      let h = [c, F, l], A = [0, -1, 0];
      this._near([c, F - m / 2, l], m / 2 + 0.05, (v, g) => {
        let b = v.N[g * 3 + 1];
        if (b < 0.6 && b > -0.6) return;
        let O = un(h, A, v.V, g * 9);
        if (O !== null && O <= m) {
          let M = F - O;
          (u === null || M > u) && (u = M);
        }
      });
    }
    return u;
  }
  ["raycast"](F, m, S = 100, { ignoreInside: E = false } = {}) {
    let A = null;
    for (let v of this.boxes) {
      if (E && v.contains(F)) continue;
      let g = dn(F, m, v, S);
      g !== null && (!A || g < A.distance) && (A = { distance: g, box: v });
    }
    for (let b of this.meshes) {
      let O = A ? A.distance : S;
      if (!b.box.contains(F) && dn(F, m, b.box, O) === null) continue;
      let M = b.V, T = Ce(b.bvh, F, m, O, (x) => {
        let y = un(F, m, M, x * 9);
        return y === null ? -1 : y;
      });
      if (T && T.t < (A ? A.distance : S)) {
        let x = b.N, y = T.tri * 3, w = x[y] * m[0] + x[y + 1] * m[1] + x[y + 2] * m[2] > 0 ? -1 : 1;
        A = { distance: T.t, box: null, normal: [x[y] * w, x[y + 1] * w, x[y + 2] * w], meta: b.meta };
      }
    }
    return A;
  }
};
function yr(H, d0, d1, d2) {
  let d3 = d1[d2], d4 = d1[d2 + 1], d5 = d1[d2 + 2], d6 = d1[d2 + 3], d7 = d1[d2 + 4], d8 = d1[d2 + 5], d9 = d1[d2 + 6], dd = d1[d2 + 7], dC = d1[d2 + 8], dc = d6 - d3, dl = d7 - d4, dF = d8 - d5, dk = d9 - d3, dm = dd - d4, du = dC - d5, dj = d0[0] - d3, dW = d0[1] - d4, dS = d0[2] - d5, dE = dc * dj + dl * dW + dF * dS, dh = dk * dj + dm * dW + du * dS;
  if (dE <= 0 && dh <= 0) return _.set(H, d3, d4, d5);
  let dA = d0[0] - d6, dv = d0[1] - d7, dZ = d0[2] - d8, dg = dc * dA + dl * dv + dF * dZ, db = dk * dA + dm * dv + du * dZ;
  if (dg >= 0 && db <= dg) return _.set(H, d6, d7, d8);
  let dJ = dE * db - dg * dh;
  if (dJ <= 0 && dE >= 0 && dg <= 0) {
    let dX = dE / (dE - dg);
    return _.set(H, d3 + dc * dX, d4 + dl * dX, d5 + dF * dX);
  }
  let dO = d0[0] - d9, dM = d0[1] - dd, dT = d0[2] - dC, dD = dc * dO + dl * dM + dF * dT, dG = dk * dO + dm * dM + du * dT;
  if (dG >= 0 && dD <= dG) return _.set(H, d9, dd, dC);
  let dR = dD * dh - dE * dG;
  if (dR <= 0 && dh >= 0 && dG <= 0) {
    let dP = dh / (dh - dG);
    return _.set(H, d3 + dk * dP, d4 + dm * dP, d5 + du * dP);
  }
  let dx = dg * dG - dD * db;
  if (dx <= 0 && db - dg >= 0 && dD - dG >= 0) {
    let dw = (db - dg) / (db - dg + (dD - dG));
    return _.set(H, d6 + (d9 - d6) * dw, d7 + (dd - d7) * dw, d8 + (dC - d8) * dw);
  }
  let df = 1 / (dx + dR + dJ), dy = dR * df, dN = dJ * df;
  return _.set(H, d3 + dc * dy + dk * dN, d4 + dl * dy + dm * dN, d5 + dF * dy + du * dN);
}
function un(F, O, q, L) {
  let I = q[L], z = q[L + 1], K = q[L + 2], H = q[L + 3] - I, d0 = q[L + 4] - z, d1 = q[L + 5] - K, d2 = q[L + 6] - I, d3 = q[L + 7] - z, d4 = q[L + 8] - K, d5 = O[1] * d4 - O[2] * d3, d6 = O[2] * d2 - O[0] * d4, d7 = O[0] * d3 - O[1] * d2, d8 = H * d5 + d0 * d6 + d1 * d7;
  if (Math.abs(d8) < 1e-12) return null;
  let d9 = 1 / d8, dd = F[0] - I, dC = F[1] - z, dc = F[2] - K, dl = (dd * d5 + dC * d6 + dc * d7) * d9;
  if (dl < 0 || dl > 1) return null;
  let dF = dC * d1 - dc * d0, dk = dc * H - dd * d1, dm = dd * d0 - dC * H, du = (O[0] * dF + O[1] * dk + O[2] * dm) * d9;
  if (du < 0 || dl + du > 1) return null;
  let dj = (d2 * dF + d3 * dk + d4 * dm) * d9;
  return dj > 1e-5 ? dj : null;
}
function _r(c, l, F, m) {
  let u = _.sub(_.create(), F, l), S = _.lengthSq(u);
  if (S < 1e-8) return _.copy(c, l);
  let E = _.set(_.create(), (m.min[0] + m.max[0]) / 2, (m.min[1] + m.max[1]) / 2, (m.min[2] + m.max[2]) / 2), h = mt(_.dot(_.sub(_.create(), E, l), u) / S, 0, 1);
  return _.scaleAndAdd(c, l, u, h);
}
function fn(F, m) {
  let u = _.create(), S = 0, E = 1 / 0, h = 1;
  for (let A = 0; A < 3; A++) {
    let v = F[A] - m.min[A], g = m.max[A] - F[A], b = Math.min(v, g);
    b < E && (E = b, S = A, h = v < g ? -1 : 1);
  }
  return u[S] = h * (E + 1e-3), u;
}
function dn(F, m, u, S) {
  let E = 0, A = S;
  for (let v = 0; v < 3; v++) {
    if (Math.abs(m[v]) < 1e-8) {
      if (F[v] < u.min[v] || F[v] > u.max[v]) return null;
      continue;
    }
    let g = 1 / m[v], b = (u.min[v] - F[v]) * g, O = (u.max[v] - F[v]) * g;
    if (b > O) {
      let M = b;
      b = O, O = M;
    }
    if (b > E && (E = b), O < A && (A = O), E > A) return null;
  }
  return E;
}
var pn = { walkSpeed: 4.2, sprintSpeed: 7, jumpSpeed: 5, gravity: 18, eyeHeight: 1.62, radius: 0.32, height: 1.8, stepHeight: 0.5, lookSensitivity: 22e-4, airControl: 0.25, handRest: 0.62, handExtend: 0.95, handDrop: 0.44, handSpread: 0.34, handFollow: 14, handReach: 0.5, shownSpread: 0.41, shownDrop: 0.92, shownForward: 0.12, wield: { 1: [0.24, -0.27, -0.36], 2: [0.32, -0.56, -0.5], 3: [0.17, -0.23, -0.36], 4: [0.16, -0.24, -0.44] }, climbSpeed: 2.6, pitchLimit: 1.54 }, he = class {
  constructor(c) {
    this.side = c, this.position = _.create(), this.shown = _.create(), this.aiming = false, this.extended = false, this.holding = false, this.held = null;
  }
}, ue = class {
  constructor(c, l = {}) {
    this.o = { ...pn, ...l }, this.world = c, this.position = _.create(0, 1, 0), this.velocity = _.create(), this.yaw = 0, this.pitch = 0, this.grounded = false, this.left = new he("left"), this.right = new he("right"), this.wielding = 0, this._aimOffset = [0, 0], this._aiming = null, this._eye = _.create(), this._wish = _.create(), this._target = _.create(), this._rest = _.create();
  }
  ["eye"](c = this._eye) {
    return _.set(c, this.position[0], this.position[1] + this.o.eyeHeight, this.position[2]);
  }
  ["look"](c, l) {
    if (this._aiming) {
      this._aimOffset[0] = mt(this._aimOffset[0] + c * this.o.lookSensitivity * 2, -this.o.handReach, this.o.handReach), this._aimOffset[1] = mt(this._aimOffset[1] + l * this.o.lookSensitivity * 2, -this.o.handReach, this.o.handReach);
      return;
    }
    this.yaw -= c * this.o.lookSensitivity, this.pitch = mt(this.pitch - l * this.o.lookSensitivity, -this.o.pitchLimit, this.o.pitchLimit);
  }
  ["update"](c, l) {
    c = Math.min(c, 0.1), this._updateAiming(l), this._move(c, l), this._updateHands(c);
  }
  ["_updateAiming"](c) {
    let l = null;
    c.aimLeft && (l = this.left), c.aimRight && (l = this.right), l !== this._aiming && (this._aiming = l, this._aimOffset[0] = 0, this._aimOffset[1] = 0), this.left.aiming = this._aiming === this.left, this.right.aiming = this._aiming === this.right, this.left.extended = !!c.gripLeft, this.right.extended = !!c.gripRight;
  }
  ["_move"](F, S) {
    let E = this.o, A = (S.right ? 1 : 0) - (S.left ? 1 : 0), O = (S.back ? 1 : 0) - (S.forward ? 1 : 0), M = Math.hypot(A, O);
    M > 1 && (A /= M, O /= M);
    let [T, x] = _s(A, O, this.yaw), q = S.sprint ? E.sprintSpeed : E.walkSpeed, L = this.grounded ? 1 : E.airControl;
    this.velocity[0] = Je(this.velocity[0], T * q, 18 * L, F), this.velocity[2] = Je(this.velocity[2], x * q, 18 * L, F), this.grounded && S.jump ? (this.velocity[1] = E.jumpSpeed, this.grounded = false) : (this.velocity[1] -= E.gravity * F, this.velocity[1] < -50 && (this.velocity[1] = -50)), this._climbing && O < -0.1 && (this.velocity[1] = Math.max(this.velocity[1], E.climbSpeed));
    let I = Math.hypot(this.velocity[0], this.velocity[1], this.velocity[2]) * F, z = Math.min(8, Math.max(1, Math.ceil(I / (E.radius * 0.8)))), K = false, H = false, d0 = false, d1 = this.grounded;
    for (let d2 = 0; d2 < z; d2++) {
      let d3 = this._from || (this._from = _.create());
      _.copy(d3, this.position), _.scaleAndAdd(this.position, this.position, this.velocity, F / z);
      let d4 = this.world.resolveCapsule(this.position, E.radius, E.height);
      if (d4.wall && d1 && E.stepHeight > 0) {
        let d5 = this._stepUp(d3, F / z);
        d5 && (d4 = d5);
      }
      K = K || d4.ground, H = H || d4.ceiling, d0 = d0 || !!d4.climb, d4.ground && this.velocity[1] < 0 && (this.velocity[1] = 0), d4.ceiling && this.velocity[1] > 0 && (this.velocity[1] = 0);
    }
    this.grounded = K, this._climbing = d0;
  }
  ["_stepUp"](F, S) {
    let E = this.o, A = [this.velocity[0] * S, this.velocity[2] * S], v = Math.hypot(A[0], A[1]);
    if (v < 1e-5 || !this.world.groundAt) return null;
    let b = (L) => ((L[0] - F[0]) * A[0] + (L[2] - F[2]) * A[1]) / v, O = b(this.position);
    if (O > v * 0.6) return null;
    let M = [A[0] / v, A[1] / v], T = F[1] + E.stepHeight + 0.01, x = null;
    for (let L of [E.radius * 0.95, E.radius * 0.5, 0]) {
      let I = this.world.groundAt(F[0] + A[0] + M[0] * L, F[2] + A[1] + M[1] * L, T, E.stepHeight + 0.01);
      I !== null && (x === null || I > x) && (x = I);
    }
    if (x === null) return null;
    let y = x - F[1];
    if (y < 0.02 || y > E.stepHeight + 0.01) return null;
    let w = this._stepPos || (this._stepPos = _.create());
    if (_.set(w, F[0], x + 1e-3, F[2]), this.world.resolveCapsule(w, E.radius, E.height).ceiling || w[1] < x - 0.01) return null;
    w[0] += A[0], w[2] += A[1];
    let q = this.world.resolveCapsule(w, E.radius, E.height);
    return q.ceiling || w[1] < x - 0.05 || b(w) < Math.max(O + v * 0.3, v * 0.5) ? null : (_.copy(this.position, w), q.ground = true, this.velocity[1] < 0 && (this.velocity[1] = 0), q);
  }
  ["_updateHands"](F) {
    let A = this.o, O = this.eye(), q = Math.cos(this.pitch), L = Math.sin(this.pitch), I = Math.hypot(this.velocity[0], this.velocity[2]), z = this.grounded ? Math.min(I / A.walkSpeed, 1.4) : 0;
    this._walk = (this._walk || 0) + (z - (this._walk || 0)) * mt(F * 8, 0, 1), this._stride = ((this._stride || 0) + F * I * 2.3) % (Math.PI * 2);
    let K = Math.sin(this._stride) * this._walk, H = Math.abs(Math.cos(this._stride)) * this._walk;
    for (let d0 of [this.left, this.right]) {
      let d1 = d0 === this.left ? -1 : 1, d2 = d0.extended ? A.handExtend : A.handRest, d3 = d1 * A.handSpread, d4 = -A.handDrop - H * 0.014, d5 = -d2, d6 = d1 > 0 && this.wielding ? A.wield[this.wielding] : null;
      d0.holding = !!d6, d6 ? (d3 = d6[0], d4 = d6[1] - H * 0.01, d5 = d6[2]) : d0.aiming && (d3 += this._aimOffset[0], d4 -= this._aimOffset[1]);
      let d7 = d4 * q - d5 * L, d8 = d4 * L + d5 * q, [d9, dd] = _s(d3, d8, this.yaw);
      _.set(this._target, O[0] + d9, O[1] + d7, O[2] + dd);
      let dC = mt(A.handFollow * F, 0, 1);
      if (_.lerp(d0.position, d0.position, this._target, dC), d0.aiming || d0.extended || d0.holding) _.lerp(d0.shown, d0.shown, this._target, dC);
      else {
        let dc = A.shownForward + K * d1 * -0.16;
        this._idle = ((this._idle || 0) + F * (1.6 - this._walk)) % (Math.PI * 2);
        let dl = Math.sin(this._idle + (d1 > 0 ? 0.9 : 0)) * 0.012 * (1 - Math.min(1, this._walk)), [dF, dk] = _s(d1 * (A.shownSpread + dl * 0.4), -dc, this.yaw);
        _.set(this._rest, O[0] + dF, O[1] - A.shownDrop + Math.abs(K) * 0.035 + dl, O[2] + dk), _.lerp(d0.shown, d0.shown, this._rest, dC);
      }
    }
  }
  ["snapshot"]() {
    return { p: [gt(this.position[0]), gt(this.position[1]), gt(this.position[2])], y: gt(this.yaw), t: gt(this.pitch), l: [gt(this.left.shown[0]), gt(this.left.shown[1]), gt(this.left.shown[2])], r: [gt(this.right.shown[0]), gt(this.right.shown[1]), gt(this.right.shown[2])], g: (this.left.extended ? 1 : 0) | (this.right.extended ? 2 : 0), w: this.wielding | 0 };
  }
};
function _s(c, l, F) {
  let m = Math.sin(F), u = Math.cos(F);
  return [c * u + l * m, -c * m + l * u];
}
var gt = (c) => Math.round(c * 1e3) / 1e3, fe = 0.47, xs = 0.66, bs = 0.82, Es = 0.07, Ms = { open: { bends: [0.04, 0.02, -0.18], thumb: -0.12, point: 0 }, grab: { bends: [1.18, 1.05, 0.95], thumb: 0.95, point: 0 }, hold: { bends: [0.95, 0.88, 0.7], thumb: 0.72, point: 0 }, point: { bends: [1.22, 1.08, 0.95], thumb: 0.95, point: 1 } }, mn = (c, l, F) => Math.min(F, Math.max(l, c));
function xr(d0, d1) {
  let d2 = [], d3 = [], d4 = [], d5 = [];
  for (let dR of d0) {
    let dx = dR.mesh, df = d2.length / 3;
    for (let dN = 0; dN < dx.positions.length; dN += 3) d2.push(dx.positions[dN] + dR.offset[0], dx.positions[dN + 1] + dR.offset[1], dx.positions[dN + 2] + dR.offset[2]);
    if (dx.normals) {
      for (let dX of dx.normals) d3.push(dX);
    }
    if (dx.uvs) {
      for (let dP of dx.uvs) d4.push(dP);
    } else {
      for (let dw = 0; dw < dx.positions.length / 3; dw++) d4.push(0, 0);
    }
    let dy = dx.indices || Array.from({ length: dx.positions.length / 3 }, (dq, dL) => dL);
    for (let dq of dy) d5.push(df + dq);
  }
  let d6 = d2.length / 3, d7 = [1 / 0, 1 / 0, 1 / 0], d8 = [-1 / 0, -1 / 0, -1 / 0];
  for (let dL = 0; dL < d2.length; dL += 3) for (let dp = 0; dp < 3; dp++) d7[dp] = Math.min(d7[dp], d2[dL + dp]), d8[dp] = Math.max(d8[dp], d2[dL + dp]);
  let d9 = d8[1] - d7[1], dd = (dB) => d8[1] - dB * d9, dC = 0, dc = 0, dl = 0;
  for (let dB = 0; dB < d2.length; dB += 3) dl += d2[dB], d2[dB + 1] < dd(0.85) && (dC += d2[dB], dc++);
  dl /= d6;
  let dF = dc && dC / dc < dl ? -1 : 1, dk = 1 / 0, dm = -1 / 0;
  for (let dV = 0; dV < d2.length; dV += 3) d2[dV + 1] < dd(0.6) && (dk = Math.min(dk, d2[dV + 2]), dm = Math.max(dm, d2[dV + 2]));
  let du = dk - d7[2] > d8[2] - dm, dj = du ? dk - 0.012 : dm + 0.012, dW = (dI, dz, dY) => (du ? dY < dj : dY > dj) && dz > dd(0.62), dS = (d7[0] + d8[0]) / 2, dE = dS + dF * (d8[0] - d7[0]) * 0.3, dh = (dk + dm) / 2, dA = [[dS, (d7[1] + d8[1]) / 2, dh], [dE, dd(fe), dh], [dE, dd(xs), dh], [dE, dd(bs), dh], [dS, dd(0.18), dj]], dv = new Float32Array(d6 * 4), dZ = new Float32Array(d6 * 4), dg = (dI) => (d8[1] - dI) / d9;
  for (let dI = 0; dI < d6; dI++) {
    let dz = d2[dI * 3], dY = d2[dI * 3 + 1], dU = d2[dI * 3 + 2], dK = dI * 4;
    if (dW(dz, dY, dU)) {
      let C3 = mn((du ? dj - dU : dU - dj) / 0.035, 0, 1);
      dv[dK] = 4, dZ[dK] = C3, dv[dK + 1] = 0, dZ[dK + 1] = 1 - C3;
      continue;
    }
    let dH = dg(dY), dQ = [[0, 0], [fe, 1], [xs, 2], [bs, 3]], C0 = dQ[0], C1 = dQ[0];
    for (let C4 = 0; C4 < dQ.length; C4++) dH >= dQ[C4][0] - Es && (C0 = dQ[Math.max(0, C4 - 1)], C1 = dQ[C4]);
    let C2 = C1 === C0 ? 1 : mn((dH - (C1[0] - Es)) / (2 * Es), 0, 1);
    dv[dK] = C1[1], dZ[dK] = C2, dv[dK + 1] = C0[1], dZ[dK + 1] = 1 - C2;
  }
  let db = new Float32Array(80);
  dA.forEach((C5, C6) => {
    let C7 = P.create();
    C7[12] = -C5[0], C7[13] = -C5[1], C7[14] = -C5[2], db.set(C7, C6 * 16);
  });
  let dJ = (dm - dk) * 0.36, dO = (d8[0] - d7[0]) * 0.66, dM = (bs - fe) * d9 + 0.04 * d9, dT = du ? dk + dJ * 0.62 : dm - dJ * 0.62, dD = Math.min(dJ, dO) / 2 - 1e-3, dG = Z(dO, dM + 2 * dD, dJ, dD, 4);
  return { mesh: { positions: new Float32Array(d2), normals: new Float32Array(d3), uvs: new Float32Array(d4), indices: d5, joints: dv, weights: dZ }, inverseBind: db, pivots: dA, palm: dF, side: d1, thumbSign: du ? -1 : 1, finger: { mesh: dG, length: dM, at: [dS + dF * (d8[0] - d7[0]) * 0.05, dd(fe), dT], split: (xs - fe) * d9 } };
}
var Ts = /* @__PURE__ */ new Map();
function Ss(F, S, A, O = "" + A) {
  if (!S || !S.length) return null;
  Ts.has(O) || Ts.set(O, xr(S, A));
  let q = Ts.get(O), L = (F.children.find((dF) => dF.mesh) || {}).material || null;
  for (let dF of [...F.children]) dF.mesh && dF.dispose();
  let I = new R("posed hand");
  I.mesh = q.mesh, I.material = L, F.add(I);
  let z = q.pivots.map(() => new R("hand joint")), K = [null, 0, 1, 2, 0];
  z.forEach((dk, dm) => {
    let du = q.pivots[dm], dj = K[dm] === null ? [0, 0, 0] : q.pivots[K[dm]];
    dk.setPosition(du[0] - dj[0], du[1] - dj[1], du[2] - dj[2]), (K[dm] === null ? I : z[K[dm]]).add(dk);
  });
  let H = new kt(z, q.inverseBind, I);
  I.skin = H;
  let d0 = new R("index finger"), d1 = q.pivots[1];
  d0.setPosition(q.finger.at[0] - d1[0], 0, q.finger.at[2] - d1[2]), z[1].add(d0);
  let d2 = (dk, dm, du, dj) => {
    let dW = new R("index");
    dW.setPosition(0, dj, 0);
    let dS = new R("index part");
    dS.mesh = q.finger.mesh, dS.material = L;
    let dE = q.finger.length, dh = dm - dk;
    return dS.setScale(1, dh / dE, 1), dS.setPosition(0, -dh / 2, 0), dW.add(dS), du.add(dW), dW;
  }, d3 = q.finger.split, d4 = d2(0, d3, d0, 0), d5 = d2(d3, q.finger.length, d4, -d3), d6 = { bends: [0, 0, 0], thumb: 0, point: 0 }, d7 = Ms.open, d8 = "open", d9 = q.palm, dd = (dk) => X.setAxisAngle(X.create(), [0, 0, 1], dk * d9), dC = (dk) => X.setAxisAngle(X.create(), [0, 1, 0], dk * d9 * q.thumbSign), dc = () => {
    for (let dm = 0; dm < 3; dm++) z[dm + 1].setRotation(dd(d6.bends[dm]));
    z[4].setRotation(dC(d6.thumb));
    let dk = 1 - d6.point;
    d4.setRotation(dd(-d6.bends[0] * d6.point)), d5.setRotation(dd(d6.bends[1] * dk)), d0.visible = d6.point > 0.02, H.update();
  }, dl = { node: F, bones: z, get name() {
    return d8;
  }, pose(dk) {
    return !Ms[dk] || dk === d8 || (d8 = dk, d7 = Ms[dk]), dl;
  }, setMaterial(dk) {
    I.material = dk;
    for (let dm of d0.allNodes()) dm.mesh && (dm.material = dk);
  }, update(dk) {
    let dm = [16, 13, 11];
    for (let du = 0; du < 3; du++) d6.bends[du] += (d7.bends[du] - d6.bends[du]) * Math.min(1, dk * dm[du]);
    d6.thumb += (d7.thumb - d6.thumb) * Math.min(1, dk * 12), d6.point += (d7.point - d6.point) * Math.min(1, dk * 14), dc();
  } };
  return dc(), dl;
}
var gn = "rz:assets/reczone/player.glb", br = 0.72, vn = 0.42, de = null;
async function Er(c) {
  return de || (de = (async () => {
    let l = await Ct(c, { name: "avatar" }), F = {};
    for (let m of l.allNodes()) {
      let u = String(m.name || "").toLowerCase();
      for (let S of ["torso", "head", "lhand", "rhand"]) !F[S] && u.startsWith(S) && (F[S] = m);
    }
    if (!F.torso || !F.head) throw new Error("player.glb has no torso or head in it.");
    return { torso: Ie(F.torso), head: Ie(F.head), left: Ie(F.lhand, { recentre: true }), right: Ie(F.rhand, { recentre: true }) };
  })(), de.catch(() => {
    de = null;
  })), de;
}
function Ie(c, { recentre: l = false } = {}) {
  if (!c) return [];
  let F = [];
  for (let u of c.allNodes()) u.mesh && F.push({ mesh: u.mesh, material: u.material, offset: [0, 0, 0] });
  if (!l || !F.length) return F;
  let m = Mr(F);
  for (let S of F) S.offset = [-m[0], -m[1], -m[2]];
  return F;
}
function Mr(c) {
  let l = [1 / 0, 1 / 0, 1 / 0], F = [-1 / 0, -1 / 0, -1 / 0];
  for (let m of c) {
    let u = m.mesh.positions;
    for (let S = 0; S < u.length; S += 3) for (let E = 0; E < 3; E++) u[S + E] < l[E] && (l[E] = u[S + E]), u[S + E] > F[E] && (F[E] = u[S + E]);
  }
  return Number.isFinite(l[0]) ? [0, 1, 2].map((h) => (l[h] + F[h]) / 2) : [0, 0, 0];
}
var Lt = class {
  constructor() {
    this.root = new R("avatar"), this.body = new R("body"), this.head = new R("head"), this.left = new R("left hand"), this.right = new R("right hand"), this.root.add(this.body), this.root.add(this.head), this.ready = false, this.failed = null, this.worn = [], this.outfit = null;
  }
  async ["load"]({ url: l = gn, colour: F = null, hands: m = true, handScale: u = br } = {}) {
    let S;
    try {
      S = await Er(l);
    } catch (A) {
      throw this.failed = A, A;
    }
    let E = F ? new N({ colour: F, roughness: 0.6 }) : null, h = (v, g) => {
      for (let b of g) {
        let O = new R("part");
        O.mesh = b.mesh, O.material = E || b.material, b.offset && O.setPosition(...b.offset), v.add(O);
      }
    };
    return this.parts = { body: this.body, head: this.head, left: this.left, right: this.right }, h(this.body, S.torso), h(this.head, S.head), m && (h(this.left, S.left), h(this.right, S.right), this.left.setScale(u), this.right.setScale(u), this.poses = { left: Ss(this.left, S.left, -1, "left"), right: Ss(this.right, S.right, 1, "right") }), this.head.setPosition(0, 1.7, 0), this.ready = true, this.outfit && this.dress(this.outfit), this;
  }
  ["dress"](c) {
    if (!c) return this;
    if (this.outfit = c, !this.ready) return this;
    for (let m of this.worn) m.dispose();
    this.worn = [];
    let l = (u, S) => {
      if (!S) return;
      let E = new N({ colour: S, roughness: 0.75 });
      for (let h of u.children) h.mesh && (h.material = E);
    };
    l(this.head, c.skin), l(this.left, c.skin), l(this.right, c.skin);
    for (let [u, S] of Object.entries(this.poses || {})) {
      let E = S && this[u].children.find((h) => h.mesh);
      E && S.setMaterial(E.material);
    }
    l(this.body, c.shirt);
    let F = (h, A) => {
      for (let v of A || []) {
        let g = new R("worn");
        g.mesh = v.mesh, g.material = v.material, h.add(g), this.worn.push(g);
      }
    };
    return F(this.head, c.head), F(this.body, c.torso), this;
  }
  ["place"](c, l) {
    return this.root.setPosition(c[0], c[1], c[2]), this.root.setEuler(0, l, 0), this;
  }
  ["hands"](c, l) {
    return this.left.setPosition(c[0], c[1], c[2]), this.right.setPosition(l[0], l[1], l[2]), this;
  }
  ["addTo"](c) {
    return c.add(this.root), c.add(this.left), c.add(this.right), this;
  }
  ["setPoses"](c, l) {
    return this.poses ? (this.poses.left && this.poses.left.pose(c), this.poses.right && this.poses.right.pose(l), this) : this;
  }
  ["updatePoses"](c) {
    return this.poses ? (this.poses.left && this.poses.left.update(c), this.poses.right && this.poses.right.update(c), this) : this;
  }
  ["dispose"]() {
    this.root.dispose(), this.left.dispose(), this.right.dispose();
  }
}, pe = class {
  constructor() {
    this.items = [], this.interval = 50, this.velocity = [0, 0, 0];
  }
  ["push"](c, l) {
    let F = this.items, m = F[F.length - 1];
    if (m) {
      l <= m.time && (l = m.time + 1);
      let u = l - m.time;
      u < 1e3 && (this.interval += (Math.min(Math.max(u, 8), 500) - this.interval) * 0.1), Math.hypot(c.p[0] - m.s.p[0], c.p[1] - m.s.p[1], c.p[2] - m.s.p[2]) > 6 && (F.length = 0);
    }
    for (F.push({ time: l, s: c }); F.length > 2 && F[0].time < l - 2e3; ) F.shift();
    F.length > 40 && F.splice(0, F.length - 40);
  }
  get ["delay"]() {
    return Math.min(Math.max(this.interval * 1.6 + 25, 70), 400);
  }
  ["sample"](F, S = {}) {
    let E = this.items;
    if (!E.length) return null;
    let A = F - this.delay, O = E[0], M = E[0];
    if (A <= E[0].time) O = M = E[0];
    else {
      let d4 = E.length - 1;
      for (; d4 > 0 && E[d4].time > A; ) d4--;
      O = E[d4], M = E[Math.min(d4 + 1, E.length - 1)];
    }
    let T = M.time - O.time, x = T > 0 ? (A - O.time) / T : 0, q = 0;
    if (O === M && A > M.time && E.length > 1) {
      let d5 = E[E.length - 2];
      O = d5;
      let d6 = M.time - d5.time;
      q = Math.min(A - M.time, 80), x = d6 > 0 && d6 < 300 ? 1 + q / d6 * 0.5 : 1;
    }
    x = Math.max(0, x);
    let L = O.s, I = M.s, z = (d7, d8) => d7 + (d8 - d7) * x, K = Math.min(x, 1), H = (d7, d8) => d7 + (d8 - d7) * K, d0 = S.p || (S.p = [0, 0, 0]), d1 = S.l || (S.l = [0, 0, 0]), d2 = S.r || (S.r = [0, 0, 0]);
    for (let d7 = 0; d7 < 3; d7++) d0[d7] = z(L.p[d7], I.p[d7]), d1[d7] = H(L.l[d7], I.l[d7]), d2[d7] = H(L.r[d7], I.r[d7]);
    S.y = L.y + Tr(L.y, I.y) * K, S.t = H(L.t, I.t), S.g = I.g;
    let d3 = (M.time - O.time) / 1e3;
    return d3 > 0 && d3 < 0.5 && q < 80 ? (this.velocity[0] = (I.p[0] - L.p[0]) / d3, this.velocity[1] = (I.p[1] - L.p[1]) / d3, this.velocity[2] = (I.p[2] - L.p[2]) / d3) : this.velocity[0] = this.velocity[1] = this.velocity[2] = 0, S.v = this.velocity, S;
  }
}, Xt = class {
  constructor() {
    this.speed = 0, this.phase = 0, this.time = Math.random() * 10, this.lean = 0, this.roll = 0, this.stretch = 0, this.vy = 0, this.airborne = false, this.landing = 0, this.out = { bob: 0, lean: 0, roll: 0, sy: 1, sxz: 1, look: 0 };
  }
  ["update"](F, S, E, A = 0) {
    F = Math.min(Math.max(F, 0), 0.1), this.time += F;
    let b = (d2) => 1 - Math.exp(-d2 * F), O = S[0], M = S[2], T = Math.hypot(O, M);
    this.speed += (Math.min(T, 9) - this.speed) * b(8);
    let x = Math.sin(E), y = Math.cos(E), q = -(O * x + M * y), L = O * y - M * x;
    this.vy += (S[1] - this.vy) * b(14);
    let I = this.airborne;
    Math.abs(this.vy) > 1.4 ? this.airborne = true : this.airborne && Math.abs(this.vy) < 0.4 && (this.airborne = false, I && (this.landing = 0.24)), this.landing = Math.max(0, this.landing - F);
    let z = this.airborne ? 0 : Math.min(this.speed / 4.2, 1.6);
    this.phase += F * (5 + this.speed * 1.6) * (z > 0.05 ? 1 : 0);
    let K = Math.abs(Math.sin(this.phase)) * 0.032 * z, H = Math.sin(this.time * 1.7) * 6e-3 * Math.max(0, 1 - z * 2);
    this.lean += (Le(q / 7, -1, 1) * 0.13 - this.lean) * b(6), this.roll += (Le(-L / 7, -1, 1) * 0.07 - this.roll) * b(6);
    let d0 = 0;
    this.airborne && (d0 = Le(this.vy / 6, -0.6, 1) * 0.07), this.landing > 0 && (d0 = -Math.sin(this.landing / 0.24 * Math.PI) * 0.09), this.stretch += (d0 - this.stretch) * b(18);
    let d1 = this.out;
    return d1.bob = K + H, d1.lean = this.lean, d1.roll = this.roll, d1.sy = 1 + this.stretch + H * 0.6, d1.sxz = 1 - this.stretch * 0.5, d1.look = Le(A, -0.9, 0.9) * 0.55, d1;
  }
};
function Tr(c, l) {
  let F = (l - c) % (Math.PI * 2);
  return F > Math.PI && (F -= Math.PI * 2), F < -Math.PI && (F += Math.PI * 2), F;
}
var Le = (c, l, F) => Math.min(Math.max(c, l), F), wn = /* @__PURE__ */ new WeakMap(), yn = /* @__PURE__ */ new WeakMap(), _n = /* @__PURE__ */ new WeakMap(), Sr = 48;
function Ar(c) {
  let l = c.worldMatrix(), F = _n.get(c);
  if (F) {
    let m = F.world, u = true;
    for (let S = 0; S < 16; S++) if (m[S] !== l[S]) {
      u = false;
      break;
    }
    if (u) return F.ok ? F.inv : null;
  } else F = { world: new Float32Array(16), inv: P.create(), ok: false }, _n.set(c, F);
  return F.world.set(l), F.ok = !!P.invert(F.inv, l), F.ok ? F.inv : null;
}
function As(c) {
  return Math.floor((c.indices ? c.indices.length : c.positions.length / 3) / 3);
}
function bn(c) {
  let l = c.positions, F = c.indices || null, m = As(c);
  if (m < Sr) return null;
  let u = yn.get(c);
  if (u && u.p === l && u.idx === F && u.count === m) return u.bvh;
  let S = ke(m, F ? (E, h, A) => {
    let v = F[E * 3 + h] * 3;
    A[0] = l[v], A[1] = l[v + 1], A[2] = l[v + 2];
  } : (E, h, A) => {
    let v = (E * 3 + h) * 3;
    A[0] = l[v], A[1] = l[v + 1], A[2] = l[v + 2];
  });
  return yn.set(c, { p: l, idx: F, count: m, bvh: S }), S;
}
function Rs(c, { idle: l = false } = {}) {
  let F = [], m = (A) => {
    let v = A.mesh;
    v && v.positions && v.positions.length && !A.skin && !A.unpickable && F.push(v);
    for (let g of A.children) m(g);
  };
  m(c);
  let u = (A) => {
    bn(A), En(A);
  };
  if (!l) {
    F.forEach(u);
    return;
  }
  F.sort((A, v) => As(A) - As(v));
  let S = typeof requestIdleCallback == "function" ? (A) => requestIdleCallback(A, { timeout: 1e3 }) : (A) => setTimeout(() => A({ timeRemaining: () => 6 }), 16), E = () => typeof performance < "u" ? performance.now() : Date.now(), h = (A) => {
    let v = E();
    for (; F.length && (u(F.pop()), !(A.timeRemaining() <= 1 || E() - v > 6)); ) ;
    F.length && S(h);
  };
  S(h);
}
function En(c) {
  let l = c.positions, F = wn.get(c);
  if (F && F.p === l) return F;
  F = [1 / 0, 1 / 0, 1 / 0, -1 / 0, -1 / 0, -1 / 0], F.p = l;
  for (let m = 0; m < l.length; m += 3) for (let u = 0; u < 3; u++) l[m + u] < F[u] && (F[u] = l[m + u]), l[m + u] > F[u + 3] && (F[u + 3] = l[m + u]);
  return wn.set(c, F), F;
}
function Rr(F, m, u, S) {
  let E = 0, h = S;
  for (let A = 0; A < 3; A++) {
    if (Math.abs(m[A]) < 1e-12) {
      if (F[A] < u[A] || F[A] > u[A + 3]) return false;
      continue;
    }
    let v = (u[A] - F[A]) / m[A], g = (u[A + 3] - F[A]) / m[A];
    if (v > g) {
      let b = v;
      v = g, g = b;
    }
    if (v > E && (E = v), g < h && (h = g), E > h) return false;
  }
  return true;
}
function xn(O, q, L, I, z, K) {
  let H = L[I], d0 = L[I + 1], d1 = L[I + 2], d2 = L[z] - H, d3 = L[z + 1] - d0, d4 = L[z + 2] - d1, d5 = L[K] - H, d6 = L[K + 1] - d0, d7 = L[K + 2] - d1, d8 = q[1] * d7 - q[2] * d6, d9 = q[2] * d5 - q[0] * d7, dd = q[0] * d6 - q[1] * d5, dC = d2 * d8 + d3 * d9 + d4 * dd;
  if (Math.abs(dC) < 1e-12) return -1;
  let dc = 1 / dC, dl = O[0] - H, dF = O[1] - d0, dk = O[2] - d1, dm = dc * (dl * d8 + dF * d9 + dk * dd);
  if (dm < 0 || dm > 1) return -1;
  let du = dF * d4 - dk * d3, dj = dk * d2 - dl * d4, dW = dl * d3 - dF * d2, dS = dc * (q[0] * du + q[1] * dj + q[2] * dW);
  return dS < 0 || dm + dS > 1 ? -1 : dc * (d5 * du + d6 * dj + d7 * dW);
}
function Nt(F, m, S, E, A = null, v = null) {
  let g = E, b = false, O = [0, 0, 0], M = [0, 0, 0], T = null, x = 0, y = null, w = (q) => {
    if (!q.visible || q.unpickable || A && A.has(q)) return;
    let L = q.mesh;
    if (L && L.positions && L.positions.length && !q.skin) {
      let I = Ar(q);
      if (I && (O[0] = I[0] * m[0] + I[4] * m[1] + I[8] * m[2] + I[12], O[1] = I[1] * m[0] + I[5] * m[1] + I[9] * m[2] + I[13], O[2] = I[2] * m[0] + I[6] * m[1] + I[10] * m[2] + I[14], M[0] = I[0] * S[0] + I[4] * S[1] + I[8] * S[2], M[1] = I[1] * S[0] + I[5] * S[1] + I[9] * S[2], M[2] = I[2] * S[0] + I[6] * S[1] + I[10] * S[2], Rr(O, M, En(L), g))) {
        let z = L.positions, K = L.indices, H = bn(L);
        if (H) {
          let d0 = Ce(H, O, M, g, (d1) => {
            let d2 = d1 * 3, d3 = (K ? K[d2] : d2) * 3, d4 = (K ? K[d2 + 1] : d2 + 1) * 3, d5 = (K ? K[d2 + 2] : d2 + 2) * 3, d6 = xn(O, M, z, d3, d4, d5);
            return d6 > 1e-4 ? d6 : -1;
          });
          d0 && (g = d0.t, b = true, v && (T = L, x = d0.tri * 3, y = I));
        } else {
          let d1 = K ? K.length : z.length / 3;
          for (let d2 = 0; d2 < d1; d2 += 3) {
            let d3 = (K ? K[d2] : d2) * 3, d4 = (K ? K[d2 + 1] : d2 + 1) * 3, d5 = (K ? K[d2 + 2] : d2 + 2) * 3, d6 = xn(O, M, z, d3, d4, d5);
            d6 > 1e-4 && d6 < g && (g = d6, b = true, v && (T = L, x = d2, y = I));
          }
        }
      }
    }
    for (let d7 of q.children) w(d7);
  };
  return w(F), b && v && T && (v.normal = Pr(T, x, y, S)), b ? g : null;
}
function Pr(F, S, A, O) {
  let M = F.positions, T = F.indices, x = (T ? T[S] : S) * 3, q = (T ? T[S + 1] : S + 1) * 3, L = (T ? T[S + 2] : S + 2) * 3, I = M[q] - M[x], z = M[q + 1] - M[x + 1], K = M[q + 2] - M[x + 2], H = M[L] - M[x], d0 = M[L + 1] - M[x + 1], d1 = M[L + 2] - M[x + 2], d2 = z * d1 - K * d0, d3 = K * H - I * d1, d4 = I * d0 - z * H, d5 = A[0] * d2 + A[1] * d3 + A[2] * d4, d6 = A[4] * d2 + A[5] * d3 + A[6] * d4, d7 = A[8] * d2 + A[9] * d3 + A[10] * d4, d8 = Math.hypot(d5, d6, d7) || 1;
  return d5 /= d8, d6 /= d8, d7 /= d8, d5 * O[0] + d6 * O[1] + d7 * O[2] > 0 && (d5 = -d5, d6 = -d6, d7 = -d7), [d5, d6, d7];
}
var Dt = ["potato", "low", "medium", "high", "ultra"], Fr = { potato: "Potato", low: "Low", medium: "Medium", high: "High", ultra: "Ultra" }, kr = { potato: { maxDpr: 1, scale: 0.85, floor: 0.5, msaa: 0, shadowSize: 0, shadowExtent: 0, shadowTaps: 0, shadowEvery: 0, lighting: 0, aniso: 1, far: 250, post: 0, reflections: 0, mirrors: 0 }, low: { maxDpr: 1, scale: 1, floor: 0.6, msaa: 0, shadowSize: 1024, shadowExtent: 16, shadowTaps: 1, shadowEvery: 4, lighting: 1, aniso: 2, far: 600, post: 0, reflections: 1, mirrors: 1 }, medium: { maxDpr: 1.5, scale: 1, floor: 0.7, msaa: 2, shadowSize: 2048, shadowExtent: 22, shadowTaps: 4, shadowEvery: 3, lighting: 1, aniso: 4, far: 1200, post: 0, reflections: 1, mirrors: 3 }, high: { maxDpr: 1.5, scale: 1, floor: 0.75, msaa: 4, shadowSize: 2048, shadowExtent: 26, shadowTaps: 4, shadowEvery: 2, lighting: 2, aniso: 8, far: 2e3, post: 1, reflections: 1, mirrors: 3 }, ultra: { maxDpr: 2, scale: 1, floor: 0.85, msaa: 4, shadowSize: 4096, shadowExtent: 32, shadowTaps: 12, shadowEvery: 1, lighting: 3, aniso: 16, far: 3e3, post: 2, reflections: 2, mirrors: 3 } };
function Ps({ userAgent: F = "", platform: S = "", gpu: E = "", cores: A = 0, memory: b = 0, dpr: O = 1, touch: M = false } = {}) {
  let T = F.toLowerCase(), x = E.toLowerCase(), y = /oculusbrowser|quest|meta quest|pacific/.test(T), q = !y && /mac/.test(S.toLowerCase() || T) && !M, L = !y && (/android|iphone|ipad|mobile/.test(T) || M && !q && O > 1.5), I = /swiftshader|llvmpipe|software|basic render|microsoft basic/.test(x), z = /apple m\d|apple gpu|apple/.test(x) && !/intel/.test(x), K = /nvidia|geforce|rtx|gtx|quadro|radeon rx|radeon pro|amd radeon(?! graphics)|arc a\d/.test(x), H = /intel|uhd|iris|radeon graphics|vega \d+ graphics|adreno|mali/.test(x), d0 = "pc";
  y ? d0 = "quest" : L ? d0 = "mobile" : q && (d0 = "mac");
  let d1 = z && /\bm\d+\s*(max|ultra)\b/.test(x), d2;
  return I ? d2 = "potato" : y || L ? d2 = "low" : q && d1 ? d2 = "high" : q && z ? d2 = "medium" : q ? d2 = "low" : K ? d2 = A >= 8 || b >= 8 ? "ultra" : "high" : d2 = "medium", b && b <= 2 && Dt.indexOf(d2) > 1 && (d2 = "low"), { kind: d0, tier: d2, software: I, gpu: E || "unknown", maxDpr: q ? 1.25 : 0 };
}
function Tn(c, l = "") {
  let F = l || "";
  if (!F) try {
    let u = c && c.getExtension("WEBGL_debug_renderer_info");
    F = u ? c.getParameter(u.UNMASKED_RENDERER_WEBGL) : c ? c.getParameter(c.RENDERER) : "";
  } catch {
  }
  let m = typeof navigator < "u" ? navigator : {};
  return { userAgent: m.userAgent || "", platform: m.userAgentData?.platform || m.platform || "", gpu: String(F || ""), cores: m.hardwareConcurrency || 0, memory: m.deviceMemory || 0, dpr: typeof devicePixelRatio < "u" && devicePixelRatio || 1, touch: typeof navigator < "u" && (navigator.maxTouchPoints || 0) > 1 };
}
var Ne = class extends EventTarget {
  constructor({ device: c, mode: l = "auto", apply: F = () => {
  } } = {}) {
    super(), this.device = c || Ps(), this.apply = F, this.mode = l, this.tier = Dt.includes(l) ? l : this.device.tier, this.ceiling = this.tier, this.scale = this.preset.scale || 1, this.refresh = 60, this._samples = [], this._ema = 1e3 / 60, this._slowFor = 0, this._fastFor = 0, this._cooldown = 0, this._settled = false, this._commit("start");
  }
  get ["preset"]() {
    return kr[this.tier];
  }
  get ["targetMs"]() {
    return 1e3 / this.refresh;
  }
  ["frame"](c) {
    if (!Number.isFinite(c) || c <= 0 || c > 250 || (this._measureRefresh(c), this._ema += (c - this._ema) * 0.08, this.mode !== "auto")) return;
    this._cooldown = Math.max(0, this._cooldown - c);
    let l = this.targetMs;
    this._ema > l * 1.18 ? (this._slowFor += c, this._fastFor = 0) : this._ema < l * 1.04 ? (this._fastFor += c, this._slowFor = 0) : (this._slowFor = Math.max(0, this._slowFor - c * 0.5), this._fastFor = 0), !(this._cooldown > 0) && (this._slowFor > 900 ? this.down() : this._fastFor > 6e3 && this.up());
  }
  ["down"]() {
    this._slowFor = 0, this._fastFor = 0, this._cooldown = 1500;
    let c = this.preset.floor;
    if (this.scale > c + 1e-3) return this.scale = Math.max(c, Mn(this.scale - 0.1)), this._commit("slower");
    let l = Dt.indexOf(this.tier);
    return l > 0 ? (this.tier = Dt[l - 1], this.ceiling = this.tier, this.scale = this.preset.scale || 1, this._commit("tier down")) : false;
  }
  ["up"]() {
    this._fastFor = 0, this._cooldown = 3e3;
    let c = this.preset.scale || 1;
    return this.scale < c - 1e-3 ? (this.scale = Math.min(c, Mn(this.scale + 0.1)), this._commit("faster")) : false;
  }
  ["setTarget"](c) {
    c > 0 ? (this.refresh = c, this._settled = true) : (this._settled = false, this._samples = []), this._ema = this.targetMs, this._slowFor = 0, this._fastFor = 0, this._cooldown = 1500, this.dispatchEvent(new CustomEvent("changed", { detail: this.describe() }));
  }
  ["setMode"](c) {
    this.mode = Dt.includes(c) ? c : "auto", this.mode === "auto" ? (this.tier = this.device.tier, this.ceiling = this.tier) : this.tier = this.mode, this.scale = this.preset.scale || 1, this._slowFor = 0, this._fastFor = 0, this._cooldown = 1500, this._commit("mode");
  }
  ["describe"]() {
    return { mode: this.mode, tier: this.tier, label: Fr[this.tier] || this.tier, scale: this.scale, refresh: this.refresh, fps: Math.round(1e3 / Math.max(this._ema, 1)), device: this.device.kind, gpu: this.device.gpu };
  }
  ["_measureRefresh"](c) {
    if (this._settled || (this._samples.push(c), this._samples.length < 90)) return;
    let l = [...this._samples].sort((u, S) => u - S), F = l.slice(0, Math.floor(l.length / 3)), m = 1e3 / F[Math.floor(F.length / 2)];
    this.refresh = [144, 120, 90, 72, 60, 30].find((u) => m >= u * 0.92) || 30, this._settled = true, this._samples = [], this.dispatchEvent(new CustomEvent("changed", { detail: this.describe() }));
  }
  ["_commit"](c) {
    let l = { ...this.preset }, F = this.mode === "auto" && this.device.maxDpr;
    return F && (l.maxDpr = Math.min(l.maxDpr, F)), this.apply({ ...l, scale: this.scale, tier: this.tier, why: c }), this.dispatchEvent(new CustomEvent("changed", { detail: { ...this.describe(), why: c } })), true;
  }
}, Mn = (c) => Math.round(c * 100) / 100, De = ["auto", "60", "120", "144", "240", "max"], Sn = { auto: "Auto", 60: "60", 120: "120", 144: "144", 240: "240", max: "Max" }, Cr = [60, 75, 90, 120, 144, 165, 240, 300, 360], Ir = 150, Lr = 0.82, me = class {
  constructor({ unlocked: c = false, displayHz: l = 0, choice: F = "auto", mac: m = false } = {}) {
    this.unlocked = !!c, this.mac = !!m, this.displayHz = Number(l) || 0, this.choice = "auto", this.cap = 0, this.measuring = false, this.measured = 0, this._samples = [], this._last = -1 / 0, this.set(F);
  }
  get ["base"]() {
    return Math.max(60, this.displayHz || 60);
  }
  ["configure"]({ unlocked: c, displayHz: l } = {}) {
    return c !== void 0 && (this.unlocked = !!c), l && (this.displayHz = Number(l) || 0), this.set(this.choice), this;
  }
  ["set"](c) {
    let l = String(c ?? "auto").toLowerCase();
    return this.choice = De.includes(l) ? l : "auto", this.measuring = false, this._samples = [], this.choice === "max" ? this.cap = 0 : this.choice === "auto" ? (this.cap = this.unlocked && this.mac ? this.base : 0, this.measuring = this.unlocked && !this.mac) : this.cap = Number(this.choice), this;
  }
  ["due"](c, l = 0) {
    let F = l && (!this.cap || this.cap > l) ? l : this.cap;
    return F ? c - this._last >= 1e3 / F - 0.5 : true;
  }
  ["waitFor"](c, l = 0) {
    let F = l && (!this.cap || this.cap > l) ? l : this.cap;
    return F ? Math.max(0, 1e3 / F - 0.5 - (c - this._last)) : 0;
  }
  ["ran"](c) {
    this._last = c;
  }
  ["sample"](c) {
    if (!this.measuring || !(c > 0) || c > 250 || (this._samples.push(c), this._samples.length < Ir)) return;
    let l = [...this._samples].sort((u, S) => u - S), F = 1e3 / l[Math.floor(l.length / 2)];
    this.measured = Math.round(F);
    let m = Cr.filter((u) => u <= F * Lr);
    this.cap = Math.max(this.base, m.length ? m[m.length - 1] : 60), this.measuring = false, this._samples = [];
  }
  ["target"]() {
    return this.unlocked ? this.choice === "max" || this.measuring ? this.base : this.cap || this.base : this.cap && this.cap < this.base ? this.cap : 0;
  }
  ["describe"]() {
    return { choice: this.choice, label: Sn[this.choice] || this.choice, cap: this.cap, unlocked: this.unlocked, measuring: this.measuring, measured: this.measured, displayHz: this.displayHz };
  }
}, ks = class {
  constructor(c, l = {}) {
    if (this.canvas = c, this.gl = null, this.renderer = null, l.gpu) try {
      this.renderer = new ce(c, l.gpu);
    } catch (u) {
      console.warn("[render] WebGPU would not start on this canvas, using WebGL:", u.message);
    }
    this.renderer || (this.gl = Ye(c, l), this.renderer = new ie(this.gl)), this.scene = new R("world"), this.collision = new It(), this.sky = l.sky instanceof $t ? l.sky : $t.preset(l.sky || "day"), this.camera = new se({ fov: l.fov || 60, fovAxis: l.fovAxis || void 0, near: l.near || 0.05 }), this.player = new ue(this.collision, l.player), this.input = {}, this.time = 0, this.remotes = /* @__PURE__ */ new Map(), this.animated = /* @__PURE__ */ new Set(), this._running = false, this._last = 0, this._handNodes = null, this.overlay = null, this.autoLock = l.autoLock !== false, this.renderScale = 1, this.maxDpr = 2, this._holds = /* @__PURE__ */ new Set(), this._easeOff = /* @__PURE__ */ new Set(), this._easeEvery = 2, this.device = Ps(Tn(this.gl, this.renderer.gpuName)), this.quality = new Ne({ device: this.device, mode: l.quality || Ur(), apply: (S) => this._applyQuality(S) }), this.onTick = l.onTick || null, this.view = Dr(), this.thirdDistance = Or(), this._camDist = this.thirdDistance, this._self = null, this._selfOutfit = null, this._pivot = _.create(), this._back = _.create(), this._updaters = [], this._afterDraw = [];
    let F = typeof navigator < "u" ? navigator : {}, m = /mac/i.test(F.userAgentData && F.userAgentData.platform || F.platform || "") && !(F.maxTouchPoints > 1);
    this.pacer = new me({ choice: Nr(), mac: m });
    try {
      let S = globalThis.reczoneDesktop?.info?.();
      S && typeof S.then == "function" && S.then((E) => {
        this.pacer.configure({ unlocked: !!(E && E.fpsUnlocked), displayHz: E && E.displayHz }), this._syncFrameTarget();
      }).catch(() => {
      });
    } catch {
    }
    this._bindInput();
  }
  ["setFrameRate"](c) {
    this.pacer.set(c);
    try {
      localStorage.setItem(Rn, this.pacer.choice);
    } catch {
    }
    return this._syncFrameTarget(), this.pacer.describe();
  }
  ["_syncFrameTarget"]() {
    this.quality.setTarget(this.pacer.target());
  }
  ["addBox"](c, l, F) {
    let m = new R("box");
    return m.mesh = B(l[0], l[1], l[2]), m.material = F || new N(), m.setPosition(c[0], c[1], c[2]), this.scene.add(m), this.collision.addBox(c, l), m;
  }
  ["animate"](c) {
    return c && typeof c.tick == "function" && this.animated.add(c), c;
  }
  ["unanimate"](c) {
    return this.animated.delete(c), this;
  }
  ["addMesh"](c, l = [0, 0, 0], F) {
    let m = new R("mesh");
    return m.mesh = c, m.material = F || new N(), m.setPosition(l[0], l[1], l[2]), this.scene.add(m), m;
  }
  ["addRoom"]({ size: c = 24, height: l = 4, wall: F = 0.4 } = {}) {
    let m = c / 2, u = this.addBox([0, -0.5, 0], [c, 1, c], new N({ colour: [0.24, 0.26, 0.3], roughness: 0.85, grid: 1 })), S = new N({ colour: [0.32, 0.33, 0.37], roughness: 0.9 });
    return this.addBox([0, l / 2, -m], [c, l, F], S), this.addBox([0, l / 2, m], [c, l, F], S), this.addBox([-m, l / 2, 0], [F, l, c], S), this.addBox([m, l / 2, 0], [F, l, c], S), u;
  }
  ["showHands"](c = [0.92, 0.78, 0.66]) {
    let l = U(0.05, 14, 10), F = new N({ colour: c, roughness: 0.6 });
    this._handNodes = { left: this.addMesh(l, [0, 0, 0], F), right: this.addMesh(l, [0, 0, 0], F) }, this._handNodes.left.noMirror = true, this._handNodes.right.noMirror = true;
    let m = new Lt(), u = this._handNodes;
    return m.load({ hands: true, handScale: vn }).then(() => {
      if (this._handNodes !== u) {
        m.dispose();
        return;
      }
      this._handNodes.left.dispose(), this._handNodes.right.dispose(), this.scene.add(m.left), this.scene.add(m.right), this._handNodes = { left: m.left, right: m.right };
      for (let S of [m.left, m.right]) S.noMirror = true;
      this._handAvatar = m, this._handSkin && m.dress({ skin: this._handSkin }), this._showViewParts();
    }).catch((S) => {
      console.warn("Hands are placeholders: " + S.message);
    }), this._showViewParts(), this._handNodes;
  }
  ["setView"](c) {
    this.view = c === "third" ? "third" : "first";
    try {
      localStorage.setItem(Pn, this.view);
    } catch {
    }
    return this.view === "third" && this._ensureSelf(), this._camDist = this.thirdDistance, this._showViewParts(), this.view;
  }
  ["setThirdDistance"](c) {
    this.thirdDistance = Math.min(Math.max(Number(c) || 3.2, Ue), kn);
    try {
      localStorage.setItem(Fn, String(this.thirdDistance));
    } catch {
    }
    return this.thirdDistance;
  }
  ["dressSelf"](c) {
    return c ? (this._selfOutfit = c, c.skin && this.setHandColour(c.skin), this._self && this._self.avatar.ready && this._self.avatar.dress(c), this) : this;
  }
  ["_ensureSelf"]() {
    if (this._self) return this._self;
    let c = new Lt(), l = { avatar: c, motion: new Xt(), ready: false };
    return this._self = l, c.load({}).then(() => {
      if (this._self !== l) {
        c.dispose();
        return;
      }
      c.addTo(this.scene), this._selfOutfit && c.dress(this._selfOutfit), l.ready = true, this._showViewParts();
    }).catch((F) => console.warn("Your avatar did not load: " + F.message)), l;
  }
  ["_showViewParts"]() {
    let c = this.view === "third";
    this._handNodes && (this._handNodes.left.visible = !c, this._handNodes.right.visible = !c);
    let l = this._self;
    l && l.ready && (l.avatar.root.visible = c, l.avatar.left.visible = c, l.avatar.right.visible = c);
  }
  ["setHandColour"](c) {
    if (this._handSkin = c, this._handAvatar) this._handAvatar.dress({ skin: c });
    else {
      if (this._handNodes) {
        let l = new N({ colour: c, roughness: 0.75 });
        this._handNodes.left.material = l, this._handNodes.right.material = l;
      }
    }
    return this;
  }
  ["dressRemote"](c, l) {
    let F = this.remotes.get(c);
    return F ? (F.outfit = l, F.avatar && F.avatar.dress(l), true) : false;
  }
  ["addUpdater"](c) {
    return typeof c == "function" && this._updaters.push(c), this;
  }
  ["wielding"]() {
    return (this.player.wielding | 0) > 0;
  }
  ["_driveHands"](c) {
    let l = this.player, F = (u) => u.aiming ? "point" : u.holding || u.carrying ? "hold" : u.extended ? "grab" : "open", m = [F(l.left), l.wielding ? "hold" : F(l.right)];
    this._handAvatar && this._handAvatar.setPoses(...m).updatePoses(c), this._self && this._self.ready && this._self.avatar.setPoses(...m).updatePoses(c);
    for (let u of this.remotes.values()) {
      if (!u.avatar) continue;
      let S = (u.pose && u.pose.g) | 0, E = u.target ? u.target.w | 0 : 0;
      u.avatar.setPoses(S & 1 ? "grab" : "open", E ? "hold" : S & 2 ? "grab" : "open").updatePoses(c);
    }
  }
  ["hideHands"]() {
    return this._handNodes ? (this._handNodes.left.dispose(), this._handNodes.right.dispose(), this._handNodes = null, this) : this;
  }
  ["addRemote"](F, m = [0.35, 0.55, 1]) {
    let S = new R("player:" + F), E = new N({ colour: m, roughness: 0.55 }), A = new R("body");
    A.mesh = V(0.3, 1.1, 16), A.material = E, A.setPosition(0, 0.55, 0);
    let v = new R("head");
    v.mesh = U(0.21, 18, 12), v.material = E, v.setPosition(0, 1.42, 0);
    let g = U(0.085, 12, 8), b = new R("left");
    b.mesh = g, b.material = E;
    let O = new R("right");
    O.mesh = g, O.material = E, S.add(A), S.add(v), this.scene.add(S), this.scene.add(b), this.scene.add(O);
    let M = { root: S, body: A, head: v, left: b, right: O, target: null, buffer: new pe(), motion: new Xt(), pose: {} };
    this.remotes.set(F, M);
    let T = new Lt();
    return T.load({}).then(() => {
      if (this.remotes.get(F) !== M) {
        T.dispose();
        return;
      }
      S.dispose(), b.dispose(), O.dispose(), T.addTo(this.scene), M.avatar = T, M.outfit && T.dress(M.outfit), M.root = T.root, M.body = T.body, M.head = T.head, M.left = T.left, M.right = T.right;
    }).catch(() => {
    }), M;
  }
  ["removeRemote"](c) {
    let l = this.remotes.get(c);
    l && (l.root.dispose(), l.left.dispose(), l.right.dispose(), this.remotes.delete(c));
  }
  ["applySnapshot"](c, l, F = Oe()) {
    if (!l) return;
    let m = this.remotes.get(c) || this.addRemote(c);
    m.target = l, m.buffer.push(l, F);
  }
  ["setFov"](c, l = ee.VERTICAL) {
    return this.camera.fov = Math.min(Math.max(Number(c) || 60, 20), 140), this.camera.fovAxis = l, this;
  }
  ["spawn"](c, l, F) {
    return _.set(this.player.position, c, l, F), _.set(this.player.velocity, 0, 0, 0), this;
  }
  ["start"]() {
    if (this._running) return this;
    this._running = true, this._last = Oe();
    let c = () => {
      if (!this._running) return;
      let l = Oe();
      if (!this.pacer.due(l, this._holds.size ? 60 : 0)) {
        let E = this.pacer.waitFor(l, this._holds.size ? 60 : 0);
        E > 1.5 ? this._timer = setTimeout(() => {
          this._raf = requestAnimationFrame(c);
        }, E - 1) : this._raf = requestAnimationFrame(c);
        return;
      }
      this.pacer.ran(l);
      let F = l - this._last, m = Math.min(F / 1e3, 0.1);
      this._last = l, this._frame = (this._frame || 0) + 1;
      let u = this._holds.size ? 0 : this._easeOff.size ? this._easeEvery : 1, S = u > 0 && this._frame % u === 0;
      u === 1 && (this.quality.frame(F), this.pacer.measuring && (this.pacer.sample(F), this.pacer.measuring || this._syncFrameTarget())), this.tick(m, S), this._raf = requestAnimationFrame(c);
    };
    return this._raf = requestAnimationFrame(c), this;
  }
  ["stop"]() {
    return this._running = false, this._raf && cancelAnimationFrame(this._raf), this._timer && clearTimeout(this._timer), this;
  }
  ["hold"](c, l = true) {
    return l ? this._holds.add(c) : this._holds.delete(c), this;
  }
  ["easeOff"](c, l = true, F = 2) {
    return l ? (this._easeOff.add(c), this._easeEvery = Math.max(2, F | 0)) : this._easeOff.delete(c), this;
  }
  get ["drawingFully"]() {
    return !this._holds.size && !this._easeOff.size;
  }
  ["tick"](c, l = true) {
    this.time += c, this.player.update(c, this.input);
    let F = this.player.eye();
    if (this.view === "third") this._placeThirdPerson(c, F);
    else {
      if (_.copy(this.camera.position, F), this.mirrorSelf) {
        let m = this._poseSelf(c);
        if (m) {
          let u = m.avatar;
          u.root.visible = false, u.left.visible = false, u.right.visible = false, this.renderer.mirrorExtras = [u.root, u.left, u.right];
        }
      } else this.renderer.mirrorExtras = null;
    }
    if (this.view === "third" && (this.renderer.mirrorExtras = null), this.camera.yaw = this.player.yaw, this.camera.pitch = this.player.pitch, this._handNodes) {
      let S = this.player.left.position, E = this.player.right.position;
      this._handNodes.left.setPosition(S[0], S[1], S[2]), this._handNodes.right.setPosition(E[0], E[1], E[2]), this._handNodes.left.setEuler(this.player.pitch, this.player.yaw, 0), this._handNodes.right.setEuler(this.player.pitch, this.player.yaw, 0);
    }
    for (let h of this.animated) h.tick(c);
    for (let A of this.remotes.values()) this._interpolate(A, c);
    for (let v of this._updaters) v(c, this);
    if (this._driveHands(c), this.onTick && this.onTick(c, this), l) {
      this.render();
      for (let g of this._afterDraw) g(this);
    }
  }
  ["afterDraw"](c) {
    return typeof c == "function" && this._afterDraw.push(c), this;
  }
  ["_placeThirdPerson"](F, m) {
    let S = this.player, E = Math.cos(S.pitch), A = _.set(this._back, Math.sin(S.yaw) * E, -Math.sin(S.pitch), Math.cos(S.yaw) * E), v = _.set(this._pivot, m[0], m[1] + 0.18, m[2]), g = this.thirdDistance, b = g + 0.35, O = this.collision.raycast(v, A, b, { ignoreInside: true }), M = Nt(this.scene, v, A, b, this._cameraSkip()), T = Math.min(O ? O.distance : 1 / 0, M ?? 1 / 0);
    T < 1 / 0 && (g = Math.max(0.35, Math.min(g, T - 0.3))), g < this._camDist ? this._camDist = g : this._camDist += (g - this._camDist) * (1 - Math.exp(-5 * F)), _.scaleAndAdd(this.camera.position, v, A, this._camDist);
    let x = this._poseSelf(F);
    if (!x) return;
    let y = x.avatar;
    y.head.visible = this._camDist > 1.4;
    let w = this._camDist > 0.6;
    y.root.visible = w, y.left.visible = w, y.right.visible = w;
  }
  ["_poseSelf"](c) {
    let l = this.player, F = this._self || this._ensureSelf();
    if (!F.ready) return null;
    let m = F.motion.update(c, l.velocity, l.yaw, l.pitch), u = F.avatar;
    u.root.setPosition(l.position[0], l.position[1] + m.bob, l.position[2]), u.root.setEuler(0, l.yaw, 0), u.body.setEuler(-m.lean, 0, m.roll), u.body.setScale(m.sxz, m.sy, m.sxz), u.head.setEuler(m.look, 0, 0), u.head.visible = true;
    let S = (E, h) => {
      let A = h.aiming || h.extended;
      E.setPosition(h.shown[0], h.shown[1], h.shown[2]), E.setEuler(h.holding ? l.pitch : A ? l.pitch * 0.6 : 0, l.yaw, 0);
    };
    return S(u.left, l.left), S(u.right, l.right), F;
  }
  ["_cameraSkip"]() {
    let c = this._skipSet || (this._skipSet = /* @__PURE__ */ new Set());
    c.clear();
    let l = this._self && this._self.avatar;
    l && (c.add(l.root), c.add(l.left), c.add(l.right)), this._handNodes && (c.add(this._handNodes.left), c.add(this._handNodes.right));
    for (let F of this.remotes.values()) c.add(F.root), c.add(F.left), c.add(F.right);
    return c;
  }
  ["_interpolate"](c, l) {
    let F = c.buffer.sample(Oe(), c.pose);
    if (!F) return;
    let m = F.y, u = c.motion.update(l, F.v, m, F.t);
    c.root.setPosition(F.p[0], F.p[1] + u.bob, F.p[2]), c.root.setEuler(0, m, 0), c.body && (c.body.setEuler(-u.lean, 0, u.roll), c.body.setScale(u.sxz, u.sy, u.sxz)), c.head && c.head.setEuler(u.look, 0, 0);
    let S = (E, A, v, g = false) => {
      E.setPosition(A[0], A[1], A[2]), E.setEuler(g ? F.t : v ? F.t * 0.6 : 0, m, 0);
    };
    S(c.left, F.l, (F.g & 1) !== 0), S(c.right, F.r, (F.g & 2) !== 0, !!(c.target && c.target.w));
  }
  ["_applyQuality"](c) {
    this.renderScale = c.scale, this.maxDpr = c.maxDpr, this.renderer.configure(c), this._shadowsWanted === void 0 && (this._shadowsWanted = true), this.renderer.shadows.resize(this._shadowsWanted ? c.shadowSize : 0), c.shadowExtent && (this.renderer.shadows.extent = c.shadowExtent), this.camera.far = Math.max(c.far, this.minFar || 0);
  }
  ["setShadows"](c) {
    this._shadowsWanted = !!c, this.renderer.shadows.resize(c ? this.quality.preset.shadowSize : 0);
  }
  get ["backend"]() {
    return this.renderer.backend;
  }
  ["setQuality"](c) {
    this.quality.setMode(c);
    try {
      localStorage.setItem(Cn, this.quality.mode);
    } catch {
    }
  }
  ["render"]() {
    let c = Math.min(globalThis.devicePixelRatio || 1, this.maxDpr) * this.renderScale, [l, F] = this._canvasSize();
    this.renderer.resize(Math.max(1, Math.floor(l * c) || this.canvas.width), Math.max(1, Math.floor(F * c) || this.canvas.height)), this.renderer.render(this.scene, this.camera, this.sky, this.overlay);
  }
  ["_canvasSize"]() {
    let c = this.canvas;
    return this._cssSize ? this._cssSize : typeof ResizeObserver == "function" && c && typeof c.getBoundingClientRect == "function" ? (this._cssSize = [c.clientWidth, c.clientHeight], this._sizeWatch = new ResizeObserver((l) => {
      let F = l[l.length - 1], m = F.contentBoxSize && F.contentBoxSize[0];
      this._cssSize = m ? [m.inlineSize, m.blockSize] : [F.contentRect.width, F.contentRect.height];
    }), this._sizeWatch.observe(c), this._cssSize) : [c.clientWidth, c.clientHeight];
  }
  ["_bindInput"]() {
    if (typeof window > "u") return;
    let c = { KeyW: "forward", KeyS: "back", KeyA: "left", KeyD: "right", ArrowUp: "forward", ArrowDown: "back", ArrowLeft: "left", ArrowRight: "right", Space: "jump", ShiftLeft: "sprint", ShiftRight: "sprint", KeyF: "aimLeft", KeyG: "aimRight" }, l = (m, u) => {
      c[m] && (this.input[c[m]] = u);
    };
    window.addEventListener("keydown", (m) => {
      Fs(m.target) || (c[m.code] && m.preventDefault(), l(m.code, true));
    }), window.addEventListener("keyup", (m) => l(m.code, false)), window.addEventListener("focusin", (m) => {
      Fs(m.target) && (this.input = {});
    }), window.addEventListener("blur", () => {
      this.input = {};
    }), this.canvas.addEventListener("mousedown", (m) => {
      if (document.pointerLockElement !== this.canvas) {
        this.autoLock && ds(this.canvas);
        return;
      }
      this.wielding() || (m.button === 0 && (this.input.gripLeft = true), m.button === 2 && (this.input.gripRight = true));
    }), window.addEventListener("mouseup", (m) => {
      m.button === 0 && (this.input.gripLeft = false), m.button === 2 && (this.input.gripRight = false);
    }), this.canvas.addEventListener("contextmenu", (m) => m.preventDefault());
    let F = ps();
    window.addEventListener("mousemove", (m) => {
      if (document.pointerLockElement !== this.canvas) return;
      let u = F(m.movementX, m.movementY);
      u && this.player.look(u[0], u[1]);
    }), window.addEventListener("keydown", (m) => {
      m.code !== "KeyC" || m.repeat || m.ctrlKey || m.metaKey || m.altKey || Fs(m.target) || document.pointerLockElement === this.canvas && this.setView(this.view === "third" ? "first" : "third");
    }), this.canvas.addEventListener("wheel", (m) => {
      if (document.pointerLockElement !== this.canvas) return;
      m.preventDefault();
      let u = m.deltaY > 0;
      if (this.view === "first") {
        u && (this.setThirdDistance(Ue + 0.4), this.setView("third"));
        return;
      }
      let S = this.thirdDistance * (u ? 1.15 : 1 / 1.15);
      if (!u && S < Ue) {
        this.setView("first");
        return;
      }
      this.setThirdDistance(S);
    }, { passive: false });
  }
}, Oe = () => typeof performance < "u" ? performance.now() : Date.now();
function Fs(c) {
  return !c || !c.tagName ? false : c.isContentEditable || c.tagName === "TEXTAREA" || c.tagName === "SELECT" ? true : c.tagName !== "INPUT" ? false : !["checkbox", "radio", "range", "button", "submit", "color"].includes(c.type);
}
var Rn = "rz.fps.v1", An = "60";
function Nr() {
  try {
    let c = globalThis.localStorage?.getItem(Rn);
    return De.includes(c) ? c : An;
  } catch {
    return An;
  }
}
var Pn = "rz.view.v1", Fn = "rz.view.distance", Ue = 1.4, kn = 7;
function Dr() {
  try {
    return globalThis.localStorage?.getItem(Pn) === "third" ? "third" : "first";
  } catch {
    return "first";
  }
}
function Or() {
  try {
    let c = Number(globalThis.localStorage?.getItem(Fn));
    return c >= Ue && c <= kn ? c : 3.2;
  } catch {
    return 3.2;
  }
}
var Cn = "rz.quality.v1";
function Ur() {
  try {
    let c = globalThis.localStorage?.getItem(Cn);
    return Dt.includes(c) ? c : "auto";
  } catch {
    return "auto";
  }
}
var et = { HELLO: "hello", STATE: "state", CHAT: "chat", PING: "ping", EDIT: "edit", SCENE: "scene", VOICE: "voice", VSTATE: "vstate", OBJ: "obj", SCORE: "score", TOOL: "tool", LT: "lt" }, J = { WELCOME: "welcome", JOINED: "joined", LEFT: "left", STATE: "state", BULK: "bulk", CHAT: "chat", PONG: "pong", ERROR: "error", EDIT: "edit", SCENE: "scene", VOICE: "voice", VSTATE: "vstate", OBJ: "obj", SCORE: "score", TOOL: "tool", RESET: "reset", STAFF: "staff", LT: "lt" }, G = { none: 0, rpg: 1, hammer: 2, builder: 3, duck: 4, blaster: 5 }, In = ["panel", "rpg", "hammer"];
function Ln(c) {
  return c === true ? In.slice() : Array.isArray(c) ? In.filter((l) => c.includes(l)) : [];
}
var Nn = 2.6, Br = 12 * 1024, Dn = 30, D = { ADD: "add", REMOVE: "remove", MOVE: "move", MATERIAL: "mat", RENAME: "name" }, zr = 4096, Gr = 512 * 1024;
function lt(c, l = {}) {
  return JSON.stringify({ t: c, ...l });
}
function On(c) {
  if (typeof c != "string" || c.length > Gr) return null;
  let l;
  try {
    l = JSON.parse(c);
  } catch {
    return null;
  }
  return !l || typeof l != "object" || typeof l.t != "string" || c.length > zr && l.t !== et.SCENE && l.t !== J.SCENE && (l.t !== et.VOICE || c.length > Br) ? null : l;
}
var Q = (c) => typeof c == "number" && Number.isFinite(c) ? c : 0, Cs = (c) => Array.isArray(c) && c.length === 3 ? [Q(c[0]), Q(c[1]), Q(c[2])] : [0, 0, 0];
function Is(c) {
  return !c || typeof c != "object" ? null : { p: Cs(c.p), y: Q(c.y), t: Q(c.t), l: Cs(c.l), r: Cs(c.r), g: (Q(c.g) | 0) & 3, w: Math.min(Math.max(Q(c.w) | 0, 0), 5) };
}
var ge = (c, l) => Array.isArray(c) && c.length === 3 ? [Q(c[0]), Q(c[1]), Q(c[2])] : l.slice();
function pl(c) {
  if (!c || typeof c != "object") return null;
  let l = String(c.id ?? "").slice(0, 40);
  return /^[A-Za-z0-9_:-]+$/.test(l) ? { id: l, kind: ["box", "sphere", "cylinder", "plane", "model", "stroke"].includes(c.kind) ? c.kind : "box", name: String(c.name ?? "").slice(0, 48), position: ge(c.position, [0, 0, 0]), rotation: ge(c.rotation, [0, 0, 0]), scale: ge(c.scale, [1, 1, 1]), colour: ge(c.colour, [0.8, 0.8, 0.82]).map((F) => Math.min(Math.max(F, 0), 1)), roughness: Math.min(Math.max(typeof c.roughness == "number" && Number.isFinite(c.roughness) ? c.roughness : 0.7, 0), 1), metallic: Math.min(Math.max(Q(c.metallic), 0), 1), src: typeof c.src == "string" ? c.src.slice(0, 500) : "", solid: c.solid !== false, ...c.hidden ? { hidden: true } : {}, ...c.locked ? { locked: true } : {}, ...c.castShadow === false ? { castShadow: false } : {}, ...Array.isArray(c.emissive) && c.emissive.some((F) => Q(F) > 0) ? { emissive: ge(c.emissive, [0, 0, 0]).map((F) => Math.min(Math.max(F, 0), 4)) } : {}, ...c.opacity !== void 0 && Q(c.opacity) < 1 ? { opacity: Math.min(Math.max(Q(c.opacity), 0.05), 1) } : {}, ...typeof c.tag == "string" && c.tag ? { tag: c.tag.slice(0, 32) } : {}, ...typeof c.notes == "string" && c.notes ? { notes: c.notes.slice(0, 300) } : {}, ...c.kind === "stroke" ? Hr(c) : {}, ...typeof c.texture == "string" && /^rz:assets\/[\w./-]+\.(jpe?g|png|webp)$/i.test(c.texture) && !c.texture.includes("..") ? { texture: c.texture.slice(0, 200), tile: Math.min(Math.max(Q(c.tile) || 1, 0.1), 20) } : {}, ...jr(c.paint), ...Array.isArray(c.tint) && c.tint.length === 3 && c.tint.every((F) => typeof F == "number" && Number.isFinite(F)) ? { tint: c.tint.map((F) => Math.round(Math.min(Math.max(F, 0), 1) * 1e3) / 1e3) } : {} } : null;
}
var $r = 120, Vr = ["walls", "ceiling", "trim", "accents", "basket", "balls"];
function Hr(c) {
  let l = (Array.isArray(c.points) ? c.points : []).slice(0, $r).filter((m) => Array.isArray(m) && m.length === 3 && m.every((u) => typeof u == "number" && Number.isFinite(u))).map((m) => m.map((u) => Math.round(Math.min(Math.max(u, -40), 40) * 100) / 100)), F = Math.min(Math.max(Q(c.width) || 0.03, 5e-3), 0.15);
  return { points: l, width: Math.round(F * 1e3) / 1e3 };
}
function jr(c) {
  if (!c || typeof c != "object") return {};
  let l = {};
  for (let F of Vr) {
    let m = c[F];
    Array.isArray(m) && m.length === 3 && m.every((u) => typeof u == "number" && Number.isFinite(u)) && (l[F] = m.map((u) => Math.round(Math.min(Math.max(u, 0), 1) * 1e3) / 1e3));
  }
  return Object.keys(l).length ? { paint: l } : {};
}
var Wr = 45e3, Ls = class extends EventTarget {
  constructor({ url: c, name: l = "Guest", room: F = "LOBBY", ticket: m = null } = {}) {
    super(), this.url = c, this.name = l, this.room = F, this.ticket = m, this.id = 0, this.players = /* @__PURE__ */ new Map(), this.voices = /* @__PURE__ */ new Map(), this.ice = null, this.noVoice = false, this.features = [], this.staff = false, this.staffPerms = [], this.connected = false, this.latency = 0, this._socket = null, this._sendTimer = null, this._pingTimer = null, this._retry = 0, this._closedByUs = false, this._snapshot = null;
  }
  ["source"](c) {
    return this._snapshot = c, this;
  }
  ["connect"]() {
    this._closedByUs = false, this.refused = null;
    let c = new WebSocket(this.url);
    return this._socket = c, c.addEventListener("open", async () => {
      let l = null;
      if (typeof this.ticket == "function") try {
        l = await this.ticket();
      } catch {
        l = null;
      }
      else this.ticket && (l = this.ticket);
      c.readyState === 1 && c.send(lt(et.HELLO, { name: this.name, room: this.room, ticket: l }));
    }), c.addEventListener("message", (l) => this._receive(String(l.data))), c.addEventListener("close", () => {
      let l = this.connected;
      this.connected = false, this._stopTimers(), this.players.clear(), this.voices.clear(), l && this._emit("disconnected"), !this._closedByUs && !this.refused && this._scheduleRetry();
    }), c.addEventListener("error", () => this._emit("neterror")), this;
  }
  ["disconnect"]() {
    this._closedByUs = true, clearTimeout(this._pausedTimer), this._stopTimers(), this._socket && this._socket.close(), this.connected = false;
  }
  ["say"](c) {
    this.connected && this._socket.send(lt(et.CHAT, { text: c }));
  }
  ["sendEdit"](c) {
    this.connected && this._socket.send(lt(et.EDIT, { op: c }));
  }
  ["sendScene"](c, l = null) {
    this.connected && this._socket.send(lt(et.SCENE, { objects: c, ...l ? { spawns: l } : {} }));
  }
  ["sendVoice"](c, l, F = null) {
    this.connected && this._socket.send(lt(et.VOICE, { to: c, kind: l, data: F }));
  }
  ["sendObj"]({ id: c, p: l, v: F, held: m }) {
    this.connected && this._socket.send(lt(et.OBJ, { id: c, p: l, v: F, held: !!m }));
  }
  ["sendScore"](c) {
    this.connected && this._socket.send(lt(et.SCORE, { id: c }));
  }
  ["canStaff"](c) {
    return this.staffPerms.includes(c);
  }
  ["_setStaff"](c) {
    this.staffPerms = Ln(c), this.staff = this.staffPerms.length > 0;
  }
  ["sendTool"](c) {
    this.connected && this._socket.send(lt(et.TOOL, c));
  }
  ["serverTimeOf"](c) {
    return this._clock === void 0 ? null : c - this._clock;
  }
  ["sendLaserTag"](c) {
    this.connected && this._socket.send(lt(et.LT, c));
  }
  ["sendVoiceState"]({ on: c, muted: l }) {
    this.connected && this._socket.send(lt(et.VSTATE, { on: !!c, muted: !!l }));
  }
  ["_receive"](c) {
    let l = On(c);
    if (l) switch (l.t) {
      case J.WELCOME:
        this._retry = 0, this.refused = null, this._clock = void 0, this.id = l.id, this.room = l.room, this.connected = true, this.ice = Array.isArray(l.ice) ? l.ice : null, this.features = Array.isArray(l.features) ? l.features.map(String) : [], this.og = Number(l.og) || 0, this._setStaff(l.staff), this.noVoice = l.noVoice === true, this.voices.clear();
        for (let F of l.players || []) this.players.set(F.id, { id: F.id, name: F.name, og: Number(F.og) || 0, bot: F.bot === true }), F.voice && this.voices.set(F.id, { on: !!F.voice.on, muted: !!F.voice.muted }), F.state && this._emit("state", { id: F.id, state: Is(F.state) });
        this._startTimers(), this._emit("connected", { id: this.id, room: this.room });
        for (let m of Array.isArray(l.objects) ? l.objects : []) this._emit("obj", m);
        break;
      case J.JOINED:
        this.players.set(l.id, { id: l.id, name: l.name, og: Number(l.og) || 0, bot: l.bot === true }), this._emit("joined", { id: l.id, name: l.name, bot: l.bot === true });
        break;
      case J.LT:
        this._emit("lt", l);
        break;
      case J.LEFT:
        this.players.delete(l.id), this.voices.delete(l.id), this._emit("left", { id: l.id });
        break;
      case J.VSTATE: {
        let u = { on: l.on === true, muted: l.muted !== false };
        this.voices.set(l.id, u), this._emit("vstate", { id: l.id, ...u });
        break;
      }
      case J.VOICE:
        this._emit("voice", { from: l.from, kind: l.kind, data: l.data });
        break;
      case J.OBJ:
        this._emit("obj", { id: l.id, owner: l.owner, held: !!l.held, p: l.p, v: l.v });
        break;
      case J.SCORE:
        this._emit("score", { id: l.id, by: l.by, name: l.name });
        break;
      case J.TOOL:
        this._emit("tool", l);
        break;
      case J.RESET:
        this._emit("reset", { by: l.by, why: l.why });
        break;
      case J.STAFF:
        this._setStaff(l.staff), this._emit("staff", { staff: this.staffPerms.slice() });
        break;
      case J.BULK: {
        let S = this._timeOf(l.at);
        for (let E of Object.keys(l.states || {})) {
          let h = Number(E);
          h !== this.id && this._emit("state", { id: h, state: Is(l.states[E]), time: S });
        }
        break;
      }
      case J.CHAT:
        this._emit("chat", { id: l.id, name: l.name, text: l.text });
        break;
      case J.EDIT:
        this._emit("edit", { from: l.from, op: l.op, fixed: l.fixed === true, notes: Array.isArray(l.notes) ? l.notes : [] });
        break;
      case J.SCENE:
        this._emit("scene", { objects: l.objects || [] });
        break;
      case J.PONG:
        typeof l.time == "number" && (this.latency = Date.now() - l.time);
        break;
      case J.ERROR:
        (!this.connected || l.code === "replaced" || l.code === "paused") && (this.refused = l.why || "refused"), this._emit("refused", { why: l.why, code: l.code }), l.code === "paused" && (clearTimeout(this._pausedTimer), this._pausedTimer = setTimeout(() => {
          this._closedByUs || this.connected || (this.refused = null, this.connect());
        }, Wr + Math.random() * 15e3));
        break;
    }
  }
  ["_timeOf"](c) {
    let l = typeof performance < "u" ? performance.now() : Date.now();
    if (typeof c != "number" || !Number.isFinite(c)) return l;
    let F = l - c;
    return this._clock === void 0 || F < this._clock ? this._clock = F : this._clock += (F - this._clock) * 2e-3, c + this._clock;
  }
  ["_startTimers"]() {
    this._stopTimers(), this._sendTimer = setInterval(() => {
      if (!this.connected || !this._snapshot) return;
      let c = this._snapshot();
      c && this._socket.send(lt(et.STATE, { s: c }));
    }, 1e3 / Dn), this._pingTimer = setInterval(() => {
      this.connected && this._socket.send(lt(et.PING, { time: Date.now() }));
    }, 3e3);
  }
  ["_stopTimers"]() {
    clearInterval(this._sendTimer), clearInterval(this._pingTimer), this._sendTimer = null, this._pingTimer = null;
  }
  ["_scheduleRetry"]() {
    this._retry++;
    let c = Math.min(1e3 * 2 ** (this._retry - 1), 15e3);
    this._emit("retrying", { in: c, attempt: this._retry }), setTimeout(() => {
      this._closedByUs || this.connect();
    }, c);
  }
  ["_emit"](c, l = {}) {
    this.dispatchEvent(new CustomEvent(c, { detail: l }));
  }
}, zn = "rz.voice.v1", qr = { mic: false, ptt: false, pttKey: "KeyV", input: "", output: "", volume: 1, spatial: true, people: {} }, Ns = class extends EventTarget {
  constructor({ net: c, game: l = null, storage: F = Zr() } = {}) {
    super(), this.net = c, this.game = l, this.storage = F, this.settings = { ...qr, ...Yr(F) }, this.settings.people = { ...this.settings.people || {} }, this.supported = !!(globalThis.RTCPeerConnection && globalThis.navigator?.mediaDevices?.getUserMedia && (globalThis.AudioContext || globalThis.webkitAudioContext)), this.peers = /* @__PURE__ */ new Map(), this.ctx = null, this.master = null, this.mic = null, this.micTrack = null, this.muted = false, this.pttHeld = false, this.speaking = false, this.error = "", this.state = this.supported ? "idle" : "unsupported", this._micLevel = null, this._timers = [], this._disposed = false, this.supported && this._bind();
  }
  get ["live"]() {
    return !!this.micTrack && !this.muted && (!this.settings.ptt || this.pttHeld);
  }
  get ["blockedBecause"]() {
    return this.supported ? this.net.connected ? this.net.noVoice ? "Voice chat is off for your account while you are muted." : (this.net.features || []).includes("voice") ? null : "Voice chat needs the game server updated. It will work once the server is updated." : null : "This browser cannot do voice chat.";
  }
  get ["announced"]() {
    return { on: this.supported && !this.blockedBecause, muted: !this.micTrack || this.muted };
  }
  ["stateOf"](c) {
    let l = this.peers.get(c), F = this.net.voices.get(c), m = this._person(this._nameOf(c));
    return { on: !!(F && F.on), connected: !!(l && l.connected), speaking: !!(l && l.speaking && !m.muted), muted: !!(F && F.on && F.muted), blocked: !!m.muted, volume: m.volume ?? 1 };
  }
  async ["enableMic"]() {
    if (!this.supported) return false;
    let c = this.blockedBecause;
    if (c) return this._fail(c), false;
    if (this._resume(), this.micTrack) return this.setMuted(false), true;
    this.state = "asking", this._changed();
    let l = null, F = (m) => ({ audio: { ...m ? { deviceId: { exact: m } } : {}, echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 }, video: false });
    try {
      l = await navigator.mediaDevices.getUserMedia(F(this.settings.input));
    } catch (m) {
      if (this.settings.input && (m.name === "OverconstrainedError" || m.name === "NotFoundError")) try {
        l = await navigator.mediaDevices.getUserMedia(F(""));
      } catch (u) {
        m = u;
      }
      if (!l) return this._fail(m.name === "NotAllowedError" || m.name === "SecurityError" ? globalThis.reczoneDesktop ? "The microphone is blocked by your computer's privacy settings. Allow it for REC.ZONE there and try again." : "The microphone is blocked. Allow it for this site in the browser (or the system's privacy settings) and try again." : m.name === "NotFoundError" ? "No microphone found." : m.name === "NotReadableError" ? "The microphone is in use by something else." : "The microphone did not start (" + (m.name || "error") + ")."), this.settings.mic = false, this._save(), false;
    }
    if (this._disposed) return Be(l), false;
    if (this.mic = l, this.micTrack = l.getAudioTracks()[0] || null, !this.micTrack) return Be(l), this._fail("No microphone found."), false;
    this.micTrack.addEventListener("ended", () => this._micLost()), this.error = "", this.muted = false, this.settings.mic = true, this._save(), this._watchMic(), this._gate();
    for (let S of this.peers.values()) this._sendFrom(S);
    return this.state = "on", this._announce(), this._changed(), true;
  }
  ["disableMic"]({ remember: c = true } = {}) {
    this.mic && Be(this.mic), this.mic = null, this.micTrack = null, this._micLevel = null, this.speaking = false;
    for (let l of this.peers.values()) this._sendFrom(l);
    c && (this.settings.mic = false, this._save()), this.state = this.supported ? "idle" : "unsupported", this._announce(), this._changed();
  }
  ["setMuted"](c) {
    this.muted = !!c, this._gate(), this._announce(), this._changed();
  }
  async ["toggle"]() {
    return this.micTrack ? (this.setMuted(!this.muted), true) : this.enableMic();
  }
  ["setPushToTalk"](c, l = this.settings.pttKey) {
    this.settings.ptt = !!c, l && (this.settings.pttKey = l), this.pttHeld = false, this._save(), this._gate(), this._changed();
  }
  ["setVolume"](c) {
    this.settings.volume = Bn(Number(c) || 0, 0, 1), this._save(), this.master && (this.master.gain.value = this.settings.volume), this._changed();
  }
  ["setSpatial"](c) {
    this.settings.spatial = !!c, this._save(), this._changed();
  }
  ["setPersonVolume"](c, l) {
    let F = this._nameOf(c);
    F && (this._person(F, { volume: Bn(Number(l) || 0, 0, 2) }), this._changed());
  }
  ["setPersonMuted"](c, l) {
    let F = this._nameOf(c);
    F && (this._person(F, { muted: !!l }), this._changed());
  }
  async ["devices"]() {
    if (!navigator.mediaDevices?.enumerateDevices) return { inputs: [], outputs: [] };
    let c = await navigator.mediaDevices.enumerateDevices().catch(() => []), l = (F) => c.filter((m) => m.kind === F).map((m, u) => ({ id: m.deviceId, label: m.label || (F === "audioinput" ? "Microphone" : "Speaker") + " " + (u + 1) }));
    return { inputs: l("audioinput"), outputs: this._canPickOutput() ? l("audiooutput") : [] };
  }
  async ["setInput"](c) {
    if (this.settings.input = c || "", this._save(), this.micTrack) {
      let l = this.muted;
      this.disableMic({ remember: false }), await this.enableMic(), l && this.setMuted(true);
    }
    this._changed();
  }
  async ["setOutput"](c) {
    if (this.settings.output = c || "", this._save(), this.ctx && this._canPickOutput()) try {
      await this.ctx.setSinkId(this.settings.output || "");
    } catch {
    }
    this._changed();
  }
  ["dispose"]() {
    this._disposed = true;
    for (let c of this._timers) clearInterval(c);
    this._timers = [];
    for (let l of [...this.peers.keys()]) this._hangUp(l, false);
    this.mic && Be(this.mic), this.mic = null, this.micTrack = null;
    for (let [F, m, u] of this._listeners || []) F.removeEventListener(m, u);
    this._listeners = [], this.ctx && this.ctx.close().catch(() => {
    }), this.ctx = null;
  }
  ["_bind"]() {
    this._listeners = [];
    let c = (m, u, S, E) => {
      m && (m.addEventListener(u, S, E), this._listeners.push([m, u, S]));
    }, l = this.net;
    c(l, "connected", () => this._joined()), c(l, "disconnected", () => {
      for (let m of [...this.peers.keys()]) this._hangUp(m, false);
      this._changed();
    }), c(l, "left", (m) => {
      this._hangUp(m.detail.id, false), this._changed();
    }), c(l, "vstate", (m) => this._theirState(m.detail.id)), c(l, "voice", (m) => this._signal(m.detail)), l.connected && this._joined();
    let F = () => this._resume();
    c(globalThis.window, "pointerdown", F, { capture: true }), c(globalThis.window, "keydown", F, { capture: true }), c(globalThis.window, "keydown", (m) => {
      !this.settings.ptt || m.code !== this.settings.pttKey || m.repeat || Jr(m.target) || (this.pttHeld = true, this._gate(), this._changed());
    }), c(globalThis.window, "keyup", (m) => {
      !this.settings.ptt || m.code !== this.settings.pttKey || (this.pttHeld = false, this._gate(), this._changed());
    }), c(globalThis.window, "blur", () => {
      this.pttHeld && (this.pttHeld = false, this._gate(), this._changed());
    }), c(globalThis.window, "pagehide", () => this.dispose()), this._timers.push(setInterval(() => this._levels(), 100)), this._timers.push(setInterval(() => this._place(), 50));
  }
  ["_joined"]() {
    for (let l of [...this.peers.keys()]) this._hangUp(l, false);
    let c = this.blockedBecause;
    if (c) {
      this.micTrack && this.disableMic({ remember: false }), this.state = "unavailable", this.error = c, this._changed();
      return;
    }
    this.state === "unavailable" && (this.state = "idle", this.error = ""), this._announce();
    for (let F of this.net.players.keys()) this._theirState(F);
    this.settings.mic && !this.micTrack && Kr().then((m) => {
      m && !this._disposed && !this.micTrack && this.enableMic();
    }), this._changed();
  }
  ["_announce"]() {
    this.net.connected && this.net.sendVoiceState(this.announced);
  }
  ["_theirState"](c) {
    let l = this.net.voices.get(c), F = this.announced;
    if (!l || !l.on || !F.on) {
      this.peers.has(c) && this._hangUp(c, true), this._changed();
      return;
    }
    !this.peers.has(c) && this.net.id < c && this._call(c), this._changed();
  }
  ["_peer"](c) {
    let l = this.peers.get(c);
    if (l) return l;
    let F = new RTCPeerConnection({ iceServers: this.net.ice || void 0, bundlePolicy: "max-bundle", rtcpMuxPolicy: "require" });
    return l = { id: c, pc: F, caller: this.net.id < c, transceiver: null, connected: false, outbox: [], flush: null, pending: [], speaking: false, loudAt: 0, nodes: null, retries: 0, failedAt: 0 }, this.peers.set(c, l), F.addEventListener("icecandidate", (m) => {
      !m.candidate || !m.candidate.candidate || (l.outbox.push({ candidate: m.candidate.candidate, sdpMid: m.candidate.sdpMid, sdpMLineIndex: m.candidate.sdpMLineIndex }), l.flush || (l.flush = setTimeout(() => {
        for (l.flush = null; l.outbox.length; ) this.net.sendVoice(c, "ice", { c: l.outbox.splice(0, 24) });
      }, 60)));
    }), F.addEventListener("track", (m) => this._hear(l, m.streams && m.streams[0] ? m.streams[0] : new MediaStream([m.track]))), F.addEventListener("connectionstatechange", () => {
      let m = F.connectionState;
      l.connected = m === "connected", m === "connected" && (l.retries = 0, this._limitBitrate(l)), (m === "failed" || m === "disconnected") && l.caller && (clearTimeout(l.restart), l.restart = setTimeout(() => {
        this.peers.get(c) === l && F.connectionState !== "connected" && (l.retries++ >= 4 || this._offer(l, { iceRestart: true }));
      }, m === "failed" ? 300 : 4e3)), this._changed();
    }), l;
  }
  ["_call"](c) {
    let l = this._peer(c);
    l.transceiver = l.pc.addTransceiver("audio", { direction: "sendrecv" }), this._sendFrom(l), this._offer(l);
  }
  async ["_offer"](c, { iceRestart: l = false } = {}) {
    try {
      let F = await c.pc.createOffer({ iceRestart: l });
      F.sdp = Ds(F.sdp), await c.pc.setLocalDescription(F), this.net.sendVoice(c.id, "offer", { type: "offer", sdp: c.pc.localDescription.sdp });
    } catch (m) {
      console.warn("[voice] could not call " + c.id + ": " + m.message);
    }
  }
  async ["_signal"]({ from: c, kind: l, data: F }) {
    if (!this.supported || this._disposed) return;
    if (l === "bye") {
      this._hangUp(c, false), this._changed();
      return;
    }
    let m = this.net.voices.get(c);
    if (!(!m || !m.on || !this.announced.on)) try {
      if (l === "offer") {
        if (this.net.id < c) return;
        let u = this._peer(c);
        await u.pc.setRemoteDescription({ type: "offer", sdp: F.sdp }), u.transceiver || (u.transceiver = u.pc.getTransceivers().find((E) => E.receiver.track && E.receiver.track.kind === "audio") || u.pc.getTransceivers()[0], u.transceiver && (u.transceiver.direction = "sendrecv")), this._sendFrom(u), await this._drain(u);
        let S = await u.pc.createAnswer();
        S.sdp = Ds(S.sdp), await u.pc.setLocalDescription(S), this.net.sendVoice(c, "answer", { type: "answer", sdp: u.pc.localDescription.sdp });
      } else {
        if (l === "answer") {
          let E = this.peers.get(c);
          if (!E || E.pc.signalingState !== "have-local-offer") return;
          await E.pc.setRemoteDescription({ type: "answer", sdp: F.sdp }), await this._drain(E);
        } else {
          if (l === "ice") {
            let h = this.peers.get(c) || (this.net.id > c ? this._peer(c) : null);
            if (!h) return;
            if (!h.pc.remoteDescription) {
              h.pending.push(...F.c);
              return;
            }
            for (let A of F.c) await h.pc.addIceCandidate(A).catch(() => {
            });
          }
        }
      }
    } catch (v) {
      console.warn("[voice] " + l + " from " + c + ": " + v.message);
    }
  }
  async ["_drain"](c) {
    let l = c.pending.splice(0);
    for (let F of l) await c.pc.addIceCandidate(F).catch(() => {
    });
  }
  ["_hangUp"](c, l) {
    let F = this.peers.get(c);
    if (F) {
      this.peers.delete(c), l && this.net.sendVoice(c, "bye"), clearTimeout(F.flush), clearTimeout(F.restart);
      try {
        F.pc.close();
      } catch {
      }
      if (F.nodes) {
        let m = F.nodes;
        try {
          m.source.disconnect(), m.gain.disconnect(), m.panner.disconnect(), m.analyser.disconnect();
        } catch {
        }
        m.element && (m.element.srcObject = null);
      }
    }
  }
  ["_sendFrom"](c) {
    let l = c.transceiver && c.transceiver.sender;
    l && l.replaceTrack(this.micTrack || null).catch(() => {
    });
  }
  async ["_limitBitrate"](c) {
    let l = c.transceiver && c.transceiver.sender;
    if (!(!l || !l.getParameters)) try {
      let F = l.getParameters();
      (!F.encodings || !F.encodings.length) && (F.encodings = [{}]), F.encodings[0].maxBitrate = 32e3, await l.setParameters(F);
    } catch {
    }
  }
  ["_audio"]() {
    if (this.ctx) return this.ctx;
    let c = globalThis.AudioContext || globalThis.webkitAudioContext;
    return this.ctx = new c({ latencyHint: "interactive" }), this.master = this.ctx.createGain(), this.master.gain.value = this.settings.volume, this.master.connect(this.ctx.destination), this.settings.output && this._canPickOutput() && this.ctx.setSinkId(this.settings.output).catch(() => {
    }), this.ctx;
  }
  ["_resume"]() {
    let c = this._audio();
    c.state === "suspended" && c.resume().catch(() => {
    });
  }
  ["_canPickOutput"]() {
    return typeof globalThis.AudioContext?.prototype?.setSinkId == "function";
  }
  ["_hear"](F, m) {
    let u = this._audio();
    if (F.nodes) return;
    let S = new Audio();
    S.muted = true, S.srcObject = m, S.play().catch(() => {
    });
    let E = u.createMediaStreamSource(m), h = u.createAnalyser();
    h.fftSize = 512;
    let A = u.createGain(), v = u.createPanner(), g = this.game && this.game.quality ? this.game.quality.tier : "medium";
    v.panningModel = g === "potato" || g === "low" ? "equalpower" : "HRTF", v.distanceModel = "inverse", v.refDistance = 2, v.maxDistance = 32, v.rolloffFactor = 0.9, E.connect(h), E.connect(A), A.connect(v), v.connect(this.master), F.nodes = { element: S, source: E, analyser: h, gain: A, panner: v, buf: new Float32Array(h.fftSize) }, this._resume(), this._place();
  }
  ["_place"]() {
    if (!this.ctx || !this.peers.size) return;
    let F = this.game, m = F && F.camera, S = this.ctx.currentTime, E = this.ctx.listener;
    if (m) {
      let A = m.position, v = m.forward();
      st(E, "positionX", A[0], S), st(E, "positionY", A[1], S), st(E, "positionZ", A[2], S), st(E, "forwardX", v[0], S), st(E, "forwardY", v[1], S), st(E, "forwardZ", v[2], S), st(E, "upX", 0, S), st(E, "upY", 1, S), st(E, "upZ", 0, S), !E.positionX && E.setPosition && (E.setPosition(A[0], A[1], A[2]), E.setOrientation(v[0], v[1], v[2], 0, 1, 0));
    }
    for (let g of this.peers.values()) {
      let b = g.nodes;
      if (!b) continue;
      let O = this._person(this._nameOf(g.id)), M = O.muted ? 0 : O.volume ?? 1, T = F && F.remotes && F.remotes.get(g.id), x = T && T.head ? T.head.worldPosition() : null;
      if (this.settings.spatial && x && m) {
        let f = Math.hypot(x[0] - m.position[0], x[1] - m.position[1], x[2] - m.position[2]);
        M *= f > 32 ? 0 : f > 32 * 0.75 ? 1 - (f - 32 * 0.75) / (32 * 0.25) : 1, st(b.panner, "positionX", x[0], S), st(b.panner, "positionY", x[1], S), st(b.panner, "positionZ", x[2], S), !b.panner.positionX && b.panner.setPosition && b.panner.setPosition(x[0], x[1], x[2]);
      } else {
        if (m) {
          let y = m.position;
          st(b.panner, "positionX", y[0], S), st(b.panner, "positionY", y[1], S), st(b.panner, "positionZ", y[2], S);
        }
      }
      b.gain.gain.setTargetAtTime(M, S, 0.05);
    }
  }
  ["_levels"]() {
    let c = performance.now(), l = false;
    for (let F of this.peers.values()) {
      let m = F.nodes;
      if (!m) continue;
      m.analyser.getFloatTimeDomainData(m.buf), Un(m.buf) > 0.012 && (F.loudAt = c);
      let u = c - F.loudAt < 320;
      u !== F.speaking && (F.speaking = u, l = true);
    }
    if (this._micLevel) {
      let S = this._micLevel;
      S.analyser.getFloatTimeDomainData(S.buf), this.live && Un(S.buf) > 0.012 && (S.loudAt = c);
      let E = this.live && c - S.loudAt < 320;
      E !== this.speaking && (this.speaking = E, l = true);
    }
    l && this._changed();
  }
  ["_watchMic"]() {
    let c = this._audio(), l = c.createMediaStreamSource(this.mic), F = c.createAnalyser();
    F.fftSize = 512, l.connect(F), this._micLevel = { source: l, analyser: F, buf: new Float32Array(F.fftSize), loudAt: 0 };
  }
  ["_gate"]() {
    this.micTrack && (this.micTrack.enabled = this.live);
  }
  ["_micLost"]() {
    this.disableMic({ remember: false }), this._fail("The microphone was disconnected.");
  }
  ["_fail"](c) {
    this.error = c, this.state = "error", this._changed(), this.dispatchEvent(new CustomEvent("problem", { detail: { message: c } }));
  }
  ["_nameOf"](c) {
    let l = this.net.players.get(c);
    return l ? String(l.name || "").toLowerCase() : "";
  }
  ["_person"](c, l) {
    if (!c) return {};
    let F = this.settings.people;
    if (l) {
      let m = { ...F[c] || {}, ...l };
      m.muted || delete m.muted, (m.volume === void 0 || m.volume === 1) && delete m.volume, Object.keys(m).length ? F[c] = m : delete F[c], this._save();
    }
    return F[c] || {};
  }
  ["_save"]() {
    try {
      this.storage?.setItem(zn, JSON.stringify(this.settings));
    } catch {
    }
  }
  ["_changed"]() {
    this._pendingChange || (this._pendingChange = true, queueMicrotask(() => {
      this._pendingChange = false, this.dispatchEvent(new CustomEvent("change"));
    }));
  }
};
function Ds(c) {
  if (typeof c != "string") return c;
  let l = c.match(/a=rtpmap:(\d+) opus\/48000/i);
  if (!l) return c;
  let F = l[1], m = { useinbandfec: "1", usedtx: "1", stereo: "0", "sprop-stereo": "0", maxaveragebitrate: String(32e3) }, u = new RegExp("a=fmtp:" + F + " ([^\\r\\n]*)");
  return u.test(c) ? c.replace(u, (S, E) => {
    let h = Object.fromEntries(E.split(";").map((A) => A.trim()).filter(Boolean).map((A) => A.split("=")));
    return "a=fmtp:" + F + " " + Object.entries({ ...h, ...m }).map(([A, v]) => A + "=" + v).join(";");
  }) : c.replace(l[0], l[0] + "\r\na=fmtp:" + F + " " + Object.entries(m).map(([S, E]) => S + "=" + E).join(";"));
}
function Un(c) {
  let l = 0;
  for (let F = 0; F < c.length; F++) l += c[F] * c[F];
  return Math.sqrt(l / c.length);
}
function st(c, l, F, m) {
  let u = c && c[l];
  u && typeof u.setValueAtTime == "function" && u.setValueAtTime(F, m);
}
function Be(c) {
  for (let l of c.getTracks()) l.stop();
}
async function Kr() {
  try {
    let c = await navigator.permissions?.query({ name: "microphone" });
    return !!c && c.state === "granted";
  } catch {
    return true;
  }
}
function Jr(c) {
  return !c || !c.tagName ? false : c.isContentEditable || c.tagName === "TEXTAREA" || c.tagName === "SELECT" ? true : c.tagName === "INPUT" && !["checkbox", "radio", "range", "button", "submit", "color"].includes(c.type);
}
function Yr(c) {
  try {
    let l = JSON.parse(c?.getItem(zn) || "null");
    return l && typeof l == "object" ? l : {};
  } catch {
    return {};
  }
}
function Zr() {
  try {
    return globalThis.localStorage || null;
  } catch {
    return null;
  }
}
var Bn = (c, l, F) => Math.min(Math.max(c, l), F), rt = 0.13, Qr = 9.81, ta = 0.72, ea = 0.86, sa = 0.55, Bs = 2e-3, ia = 1 / 15, na = 3.2, Os = 4.5, oa = 12.5, Gn = 0.9;
function Hn(F, S, A, O = []) {
  if (F.asleep) return false;
  F.v[1] -= Qr * S;
  let M = Math.max(0, 1 - 0.08 * S);
  F.v[0] *= M, F.v[2] *= M;
  let T = false, x = Math.hypot(F.v[0], F.v[1], F.v[2]), q = x * S;
  if (q > 1e-6) {
    let z = [F.v[0] / x, F.v[1] / x, F.v[2] / x], K = A(F.p, z, q + rt);
    if (K && K.distance - rt < q) {
      let H = Math.max(0, K.distance - rt - 1e-3);
      for (let d2 = 0; d2 < 3; d2++) F.p[d2] += z[d2] * H;
      let d0 = K.normal, d1 = F.v[0] * d0[0] + F.v[1] * d0[1] + F.v[2] * d0[2];
      if (d1 < 0) {
        for (let d3 = 0; d3 < 3; d3++) {
          let d4 = d1 * d0[d3], d5 = F.v[d3] - d4;
          F.v[d3] = d5 * ea - d4 * ta;
        }
        T = -d1 > 1.2;
      }
    } else {
      for (let d6 = 0; d6 < 3; d6++) F.p[d6] += F.v[d6] * S;
    }
  }
  for (let d7 of O) {
    let d8 = d7.centre, d9 = F.p[0] - d8[0], dd = F.p[2] - d8[2], dC = Math.hypot(d9, dd) || 1e-6, dc = [d8[0] + d9 / dC * d7.radius, d8[1], d8[2] + dd / dC * d7.radius], dl = [F.p[0] - dc[0], F.p[1] - dc[1], F.p[2] - dc[2]], dF = Math.hypot(dl[0], dl[1], dl[2]), dk = rt + d7.tube;
    if (dF < dk && dF > 1e-6) {
      let dm = [dl[0] / dF, dl[1] / dF, dl[2] / dF];
      for (let dj = 0; dj < 3; dj++) F.p[dj] = dc[dj] + dm[dj] * dk;
      let du = F.v[0] * dm[0] + F.v[1] * dm[1] + F.v[2] * dm[2];
      if (du < 0) {
        for (let dW = 0; dW < 3; dW++) F.v[dW] -= (1 + sa) * du * dm[dW];
        T = T || -du > 0.8;
      }
      if (dm[1] > 0.97) {
        let dS = Math.random() < 0.5 ? -1 : 1;
        F.v[0] += d9 / dC * 0.35 * dS, F.v[2] += dd / dC * 0.35 * dS;
      }
    }
  }
  let L = A(F.p, [0, -1, 0], rt + 0.03);
  L && L.distance < rt + Bs && (F.p[1] += rt + Bs - L.distance, F.v[1] < 0 && (F.v[1] = 0));
  let I = Math.hypot(F.v[0], F.v[2]);
  if (L && I < 0.35 && Math.abs(F.v[1]) < 0.6) {
    F.v[1] = Math.min(Math.max(F.v[1], 0), 0.05);
    let dE = Math.max(0, 1 - 2.5 * S);
    F.v[0] *= dE, F.v[2] *= dE, F.restFor = (F.restFor || 0) + S, F.restFor > 0.4 && (F.asleep = true, F.v = [0, 0, 0]);
  } else F.restFor = 0;
  return T;
}
function ra(F, m = () => false) {
  for (let S = 0; S < F.length; S++) for (let E = S + 1; E < F.length; E++) {
    let A = F[S], v = F[E], g = [v.p[0] - A.p[0], v.p[1] - A.p[1], v.p[2] - A.p[2]], b = Math.hypot(g[0], g[1], g[2]), O = rt * 2 - b;
    if (O <= 0 || b < 1e-6) continue;
    let M = [g[0] / b, g[1] / b, g[2] / b], T = m(A) ? 0 : m(v) ? 1 : 0.5, x = m(v) ? 0 : 1 - T;
    for (let w = 0; w < 3; w++) A.p[w] -= M[w] * O * T, v.p[w] += M[w] * O * x;
    let y = (A.v[0] - v.v[0]) * M[0] + (A.v[1] - v.v[1]) * M[1] + (A.v[2] - v.v[2]) * M[2];
    if (y > 0) {
      let q = y * 0.85;
      for (let L = 0; L < 3; L++) A.v[L] -= M[L] * q * (T ? 1 : 0), v.v[L] += M[L] * q * (x ? 1 : 0);
      y > 0.25 && (T && (A.asleep = false), x && (v.asleep = false));
    }
    O > 3e-3 && (T && (A.asleep = false), x && (v.asleep = false));
  }
}
function jn(c, l, F) {
  let m = F.centre;
  return c >= m[1] && l.p[1] < m[1] && l.v[1] < 0 ? Math.hypot(l.p[0] - m[0], l.p[2] - m[2]) < F.radius - rt * 0.35 : false;
}
var Us = /* @__PURE__ */ new Map(), Xn = [0.894, 0.424, 0.133];
function aa(F = 1024, S = Xn) {
  if (typeof document > "u") return null;
  let E = F, A = F / 2, O = document.createElement("canvas");
  O.width = E, O.height = A;
  let M = O.getContext("2d"), T = M.createLinearGradient(0, 0, 0, A), x = (d3) => "rgb(" + S.map((d4) => Math.round(Math.min(1, Math.max(0, d4 * d3)) * 255)).join(",") + ")";
  T.addColorStop(0, x(0.86)), T.addColorStop(0.5, x(1)), T.addColorStop(1, x(0.86)), M.fillStyle = T, M.fillRect(0, 0, E, A);
  let q = 7, L = () => (q = q * 16807 % 2147483647) / 2147483647, I = Math.round(E * A / 22);
  for (let d3 = 0; d3 < I; d3++) {
    let d4 = L() * E, d5 = L() * A, d6 = 0.8 + L() * 1.1;
    M.fillStyle = "rgba(70,22,0,0.22)", M.beginPath(), M.arc(d4, d5 + 0.6, d6, 0, Math.PI * 2), M.fill(), M.fillStyle = "rgba(255,190,140,0.16)", M.beginPath(), M.arc(d4, d5 - 0.4, d6 * 0.7, 0, Math.PI * 2), M.fill();
  }
  let z = (d7) => {
    let d8 = Math.acos(Math.max(-1, Math.min(1, d7[1]))), d9 = Math.atan2(d7[2], d7[0]);
    return d9 < 0 && (d9 += Math.PI * 2), { x: d9 / (Math.PI * 2) * E, y: (1 - d8 / Math.PI) * A, stretch: 1 / Math.max(Math.sin(d8), 0.12) };
  }, K = (d7, d8, d9) => {
    M.fillStyle = d9;
    for (let dd of d7) {
      let dC = z(dd), dc = Math.min(d8 * dC.stretch, E / 4);
      for (let dl of [-E, 0, E]) dC.x + dl + dc < 0 || dC.x + dl - dc > E || (M.beginPath(), M.ellipse(dC.x + dl, dC.y, dc, d8, 0, 0, Math.PI * 2), M.fill());
    }
  }, H = (d7, d8, d9, dd = 2400) => {
    let dC = [];
    for (let dc = 0; dc < dd; dc++) {
      let dl = dc / dd * Math.PI * 2, dF = [0, 1, 2].map((dm) => d7[dm] + d8[dm] * Math.cos(dl) + d9[dm] * Math.sin(dl)), dk = Math.hypot(dF[0], dF[1], dF[2]);
      dC.push([dF[0] / dk, dF[1] / dk, dF[2] / dk]);
    }
    return dC;
  }, d0 = 0.9, d1 = [H([0, 0, 0], [1, 0, 0], [0, 0, 1]), H([0, 0, 0], [0, 1, 0], [0, 0, 1]), H([Math.cos(d0), 0, 0], [0, Math.sin(d0), 0], [0, 0, Math.sin(d0)]), H([-Math.cos(d0), 0, 0], [0, Math.sin(d0), 0], [0, 0, Math.sin(d0)])], d2 = A / 92;
  for (let d7 of d1) K(d7, d2 * 1.9, "rgba(90,30,4,0.20)");
  for (let d8 of d1) K(d8, d2, "#17100c");
  return O;
}
function $n(c = null) {
  let l = Array.isArray(c) && c.length === 3 ? c.map((S) => Math.min(1, Math.max(0, Number(S) || 0))) : Xn, F = l.map((S) => S.toFixed(3)).join(",");
  if (Us.has(F)) return Us.get(F);
  let m = aa(1024, l), u = new N({ colour: m ? [1, 1, 1] : l.slice(), roughness: 0.72, map: m });
  return Us.set(F, u), u;
}
var zs = class extends EventTarget {
  constructor({ game: c, net: l = null, hud: F = null }) {
    super(), this.game = c, this.net = l, this.hud = F, this.balls = /* @__PURE__ */ new Map(), this.hoops = [], this.held = null, this.charging = 0, this._chargingButton = -1, this._skip = /* @__PURE__ */ new Set(), this._mesh = U(rt, 40, 28), this._buildHints(), this._bind(), c.addUpdater((m) => this.update(m));
  }
  ["addBall"](c, l) {
    if (this.balls.has(c)) return this.balls.get(c);
    let F = new R("ball:" + c);
    F.mesh = this._mesh, F.material = $n(this.ballColour), F.noCull = false, this.game.scene.add(F);
    let m = { id: c, node: F, home: l.slice(), p: l.slice(), v: [0, 0, 0], asleep: true, restFor: 0, owner: 0, held: false, hand: null, corr: [0, 0, 0], sendIn: 0, quiet: true, prevY: l[1], scoredAt: 0, spin: 0 };
    return F.setPosition(m.p[0], m.p[1], m.p[2]), this.balls.set(c, m), m;
  }
  ["restHeight"](c, l, F) {
    let m = this._caster()([c, F, l], [0, -1, 0], 6);
    return m ? F - m.distance + rt + Bs : null;
  }
  ["setBallColour"](c) {
    this.ballColour = Array.isArray(c) && c.length === 3 ? c.slice() : null;
    let l = $n(this.ballColour);
    for (let F of this.balls.values()) F.node.material = l;
    return this;
  }
  ["clear"]() {
    for (let c of this.balls.values()) c.node.dispose();
    this.balls.clear(), this.hoops = [], this.held = null, this.charging = 0, this._chargingButton = -1;
  }
  ["addHoop"]({ centre: c, radius: l = 0.29, tube: F = 0.025 }) {
    this.hoops.push({ centre: c.slice(), radius: l, tube: F });
  }
  ["update"](F) {
    if (!this.balls.size) return;
    F = Math.min(F, 0.05);
    let m = this.net ? this.net.id : -1, u = this._caster();
    for (let E of this.balls.values()) {
      if (E === this.held) this._carry(E, F);
      else {
        if (E.held && E.owner !== m) {
          for (let v = 0; v < 3; v++) E.p[v] += E.corr[v] * Math.min(1, F * 14), E.corr[v] *= Math.max(0, 1 - F * 14);
        } else {
          let g = Math.min(8, Math.max(1, Math.ceil(Math.hypot(E.v[0], E.v[1], E.v[2]) * F / 0.05))), b = F / g;
          for (let O = 0; O < g; O++) E.prevY = E.p[1], Hn(E, b, u, this.hoops), E.owner === m && !E.asleep && this._checkScore(E);
          if (E.owner !== m) {
            let M = Math.min(1, F * 10);
            for (let T = 0; T < 3; T++) E.p[T] += E.corr[T] * M, E.corr[T] *= 1 - M;
          }
          E.owner === m && (E.p[1] < -20 || Math.hypot(E.p[0] - E.home[0], E.p[2] - E.home[2]) > 80) && (E.p = E.home.slice(), E.v = [0, 0, 0], E.asleep = true, E.quiet = false);
        }
      }
      let A = Math.hypot(E.v[0], E.v[2]);
      E.spin += A * F / rt, E.node.setPosition(E.p[0], E.p[1], E.p[2]), E.node.setEuler(E.spin, Math.atan2(E.v[0], E.v[2]), 0), this._send(E, F, m);
    }
    if (this.balls.size > 1) {
      let x = this._list || (this._list = []);
      x.length = 0;
      for (let f of this.balls.values()) x.push(f);
      ra(x, (y) => y === this.held || y.held && y.owner !== m);
      for (let y of x) y.node.setPosition(y.p[0], y.p[1], y.p[2]);
    }
    let S = this.game.player;
    S && S.left && (S.left.carrying = !!(this.held && this.held.hand === "left"), S.right.carrying = !!(this.held && this.held.hand === "right")), (this.charging || this._chargingButton >= 0) && (this.charging += F), this._hint();
  }
  ["_carry"](l, F) {
    let m = this.game, u = m.view === "third" ? m.player[l.hand].shown : m.player[l.hand].position, S = m.camera.forward(), E = [u[0] + S[0] * 0.14, u[1] + S[1] * 0.14 + 0.02, u[2] + S[2] * 0.14];
    for (let h = 0; h < 3; h++) {
      let A = l.p[h];
      l.p[h] = E[h], l.v[h] = (l.p[h] - A) / Math.max(F, 1e-3);
    }
    l.asleep = false;
  }
  ["_checkScore"](c) {
    for (let l of this.hoops) {
      if (!jn(c.prevY, c, l)) continue;
      let F = performance.now();
      if (F - c.scoredAt < 1500) return;
      c.scoredAt = F, this.net && this.net.connected ? this.net.sendScore(c.id) : this._scored({ id: c.id, name: this.net ? this.net.name : "You", mine: true });
      return;
    }
  }
  ["_send"](c, l, F) {
    if (!this.net || !this.net.connected || c.owner !== F) return;
    c.sendIn -= l;
    let m = !c.asleep || c === this.held;
    !m && c.quiet || c.sendIn > 0 && m || (c.sendIn = ia, this.net.sendObj({ id: c.id, p: Vn(c.p), v: Vn(c.v), held: c === this.held }), c.quiet = !m);
  }
  ["receive"]({ id: c, owner: l, held: F, p: m, v: u }) {
    let S = this.balls.get(c);
    if (!S || !Array.isArray(m)) return;
    let E = this.net ? this.net.id : -1;
    if (l === E) return;
    this.held === S && (this.held = null, this.charging = 0, this._chargingButton = -1), S.owner = l, S.held = !!F, S.asleep = false, S.restFor = 0, S.v = Array.isArray(u) ? u.slice() : [0, 0, 0], Math.hypot(m[0] - S.p[0], m[1] - S.p[1], m[2] - S.p[2]) > 2.5 ? (S.p = m.slice(), S.corr = [0, 0, 0]) : S.corr = [m[0] - S.p[0], m[1] - S.p[1], m[2] - S.p[2]];
  }
  ["_scored"]({ id: c, name: l, mine: F }) {
    this.dispatchEvent(new CustomEvent("score", { detail: { id: c, name: l, mine: F } })), this.hud && (this.hud.flash?.(F ? "SCORE!" : l + " scored!", F ? "+2" : ""), this.hud.say(l + " scored a basket", "join"));
  }
  ["target"]() {
    let F = this.game, m = F.camera.position, S = F.camera.forward(), E = this.net ? this.net.id : -1, A = null, v = 1 / 0;
    for (let g of this.balls.values()) {
      if (g === this.held || g.held && g.owner !== E && this.net && this.net.players.has(g.owner)) continue;
      let b = [g.p[0] - m[0], g.p[1] - m[1], g.p[2] - m[2]], O = Math.hypot(b[0], b[1], b[2]), M = Math.hypot(g.p[0] - F.player.position[0], g.p[2] - F.player.position[2]);
      if (M > na) continue;
      let T = (b[0] * S[0] + b[1] * S[1] + b[2] * S[2]) / (O || 1), x = M < 0.9;
      if (!x && T < 0.94) continue;
      let y = x ? M : O * (2 - T);
      y < v && (A = g, v = y);
    }
    return A;
  }
  ["pickUp"](c, l = "right") {
    if (!c) return false;
    let F = this.net ? this.net.id : -1;
    return this.held && this.drop(), this.held = c, c.owner = F, c.held = true, c.hand = l, c.asleep = false, c.quiet = false, c.sendIn = 0, this.dispatchEvent(new CustomEvent("pickup", { detail: { id: c.id } })), true;
  }
  ["drop"]() {
    let c = this.held;
    c && (this.held = null, c.held = false, c.v = [this.game.player.velocity[0], 0, this.game.player.velocity[2]], c.quiet = false, c.sendIn = 0);
  }
  ["throw"](l = Os) {
    let F = this.held;
    if (!F) return;
    let m = this.game, u = m.camera.forward(), S = m.player.velocity;
    this.held = null, F.held = false, F.asleep = false;
    let E = m.player.eye(), h = [F.p[0] - E[0], F.p[1] - E[1], F.p[2] - E[2]], A = Math.hypot(h[0], h[1], h[2]) || 1;
    this._caster()(E, h.map((v) => v / A), A + rt) && (F.p = [E[0] + u[0] * 0.35, E[1] + u[1] * 0.35, E[2] + u[2] * 0.35]), F.v = [u[0] * l + S[0] * 0.5, u[1] * l + 1.4 + Math.max(0, S[1]) * 0.5, u[2] * l + S[2] * 0.5], F.quiet = false, F.sendIn = 0, this.dispatchEvent(new CustomEvent("throw", { detail: { id: F.id, power: l } }));
  }
  ["_bind"]() {
    if (typeof window > "u") return;
    let c = () => document.pointerLockElement === this.game.canvas, l = (F) => F && (/^(INPUT|TEXTAREA|SELECT)$/.test(F.tagName) || F.isContentEditable);
    window.addEventListener("keydown", (F) => {
      F.code !== "KeyE" || F.repeat || l(F.target) || !c() || (this.held ? this.drop() : this.pickUp(this.target(), "right"));
    }), this.game.canvas.addEventListener("mousedown", (F) => {
      if (!c() || F.button !== 0 && F.button !== 2 || this.game.wielding && this.game.wielding()) return;
      let m = F.button === 0 ? "left" : "right";
      if (this.held) {
        this._chargingButton = F.button, this.charging = 1e-4;
        return;
      }
      let u = this.target();
      u && (this.pickUp(u, m), this._swallow = F.button);
    }), window.addEventListener("mouseup", (F) => {
      if (this._swallow === F.button) {
        this._swallow = -1;
        return;
      }
      if (this._chargingButton !== F.button || !this.held) return;
      let m = Math.min(this.charging / Gn, 1);
      this._chargingButton = -1, this.charging = 0, this.throw(Os + (oa - Os) * m);
    });
  }
  ["_caster"]() {
    let c = this.game, l = this._skip;
    if (l.clear(), c._cameraSkip) {
      for (let m of c._cameraSkip()) l.add(m);
    }
    for (let u of this.balls.values()) l.add(u.node);
    for (let S of this.extraSkip || []) l.add(S);
    let F = {};
    return (E, h, A) => {
      let v = null, g = Nt(c.scene, E, h, A, l, F);
      g !== null && (v = { distance: g, normal: F.normal });
      let b = c.collision.raycast(E, h, A, { ignoreInside: true });
      return b && (!v || b.distance < v.distance) && (v = { distance: b.distance, normal: b.normal || ca(E, h, b) }), v;
    };
  }
  ["_buildHints"]() {
    typeof document > "u" || !this.hud || !this.hud.root || (this.hintEl = document.createElement("div"), this.hintEl.className = "hud-pick", this.hintEl.innerHTML = '<span class="hud-picktext"></span><i class="hud-pickbar"><b></b></i>', this.hud.root.appendChild(this.hintEl));
  }
  ["_hint"]() {
    let c = this.hintEl;
    if (!c) return;
    let l = "";
    this.held ? l = this._chargingButton >= 0 ? "Release to throw" : "Hold click to throw  \xB7  E to drop" : document.pointerLockElement === this.game.canvas && this.target() && (l = "Click to pick up");
    let F = this._chargingButton >= 0 ? Math.min(this.charging / Gn, 1) : 0;
    c.dataset.text !== l && (c.dataset.text = l, c.querySelector(".hud-picktext").textContent = l, c.classList.toggle("is-on", !!l)), c.classList.toggle("is-charging", F > 0), c.querySelector(".hud-pickbar b").style.width = Math.round(F * 100) + "%";
  }
  ["connect"]() {
    return this.net ? (this.net.addEventListener("obj", (c) => this.receive(c.detail)), this.net.addEventListener("score", (c) => {
      this._scored({ id: c.detail.id, name: c.detail.name, mine: c.detail.by === this.net.id });
    }), this.net.addEventListener("connected", () => {
      for (let c of this.balls.values()) {
        if (c === this.held) {
          c.owner = this.net.id, c.quiet = false;
          continue;
        }
        c.owner = 0, c.held = false;
      }
    }), this) : this;
  }
};
function ca(F, m, { distance: S, box: E }) {
  let A = [F[0] + m[0] * S, F[1] + m[1] * S, F[2] + m[2] * S], v = 0, g = 1 / 0, b = 1;
  for (let M = 0; M < 3; M++) {
    let T = Math.abs(A[M] - E.min[M]), x = Math.abs(A[M] - E.max[M]);
    T < g && (g = T, v = M, b = -1), x < g && (g = x, v = M, b = 1);
  }
  let O = [0, 0, 0];
  return O[v] = b, O;
}
var Vn = (c) => c.map((l) => Math.round(l * 1e3) / 1e3), Wt = [Math.PI / 2, 0, 0], ze = null;
function la() {
  return ze || (ze = { body: V(0.017, 0.15, 28), grip: V(0.0188, 0.07, 28), ridge: W(0.0188, 22e-4, 28, 6), ring: W(0.0176, 26e-4, 28, 8), collar: ct(0.017, 0.0115, 0.022, 28), tip: ct(0.0115, 22e-4, 0.042, 28), crystal: U(85e-4, 18, 12), halo: W(0.02, 16e-4, 36, 6), cap: U(0.017, 24, 14), button: U(65e-4, 14, 10), clip: B(5e-3, 6e-3, 0.075), clipEnd: U(45e-4, 10, 8), strip: B(32e-4, 32e-4, 0.085) }, ze);
}
var it = (c, l, F, m = null, u = null) => {
  let S = new R("pen part");
  return S.mesh = c, S.material = l, S.setPosition(F[0], F[1], F[2]), m && S.setEuler(m[0], m[1], m[2]), u && S.setScale(u[0], u[1], u[2]), S;
};
function Wn(F = [0.25, 0.6, 1]) {
  let m = la(), S = new N({ colour: [0.95, 0.96, 0.98], roughness: 0.18, metallic: 0.05 }), E = new N({ colour: [0.07, 0.11, 0.24], roughness: 0.75 }), A = new N({ colour: [0.16, 0.42, 0.98], roughness: 0.25, metallic: 0.4, emissive: [0.02, 0.07, 0.2] }), v = new N({ colour: [0.86, 0.88, 0.92], roughness: 0.12, metallic: 1 }), g = new N({ colour: F, roughness: 0.2, emissive: F, castShadow: false }), b = new N({ colour: F, roughness: 0.3, emissive: F.map((q) => q * 0.8), castShadow: false }), O = new R("builder pen");
  O.add(it(m.cap, S, [0, 0, 0.088], null, [1, 1, 0.55])), O.add(it(m.button, A, [0, 0, 0.097])), O.add(it(m.body, S, [0, 0, 0.013], Wt)), O.add(it(m.ring, A, [0, 0, 0.078], Wt)), O.add(it(m.ring, A, [0, 0, -0.024], Wt)), O.add(it(m.grip, E, [0, 0, -0.058], Wt));
  for (let q of [-0.08, -0.068, -0.056, -0.044, -0.034]) O.add(it(m.ridge, E, [0, 0, q], Wt));
  O.add(it(m.collar, v, [0, 0, -0.104], [-Math.PI / 2, 0, 0])), O.add(it(m.tip, S, [0, 0, -0.136], [-Math.PI / 2, 0, 0]));
  let M = it(m.crystal, g, [0, 0, -0.16], null, [1, 1, 1.7]);
  O.add(M);
  let T = new R("pen halo");
  T.setPosition(0, 0, -0.146);
  let x = it(m.halo, g, [0, 0, 0], Wt);
  T.add(x), O.add(T), O.add(it(m.clip, v, [0, 0.0205, 0.045])), O.add(it(m.clipEnd, v, [0, 0.0205, 8e-3])), O.add(it(m.strip, b, [0.0168, 0, 0.03])), O.add(it(m.strip, b, [-0.0168, 0, 0.03])), O.setScale(1.7, 1.7, 1.7), O.tipLocal = [0, 0, -0.175];
  let y = 0, w = 0;
  return O.setInk = (L) => {
    let I = L.slice(0, 3);
    return g.colour = I, g.emissive = I.map((z) => Math.min(1, z * 1.15 + 0.05)), b.colour = I, b.emissive = I.map((z) => z * 0.8), O;
  }, O.tick = (L) => {
    y += L * 2.2, w += L * 3, T.setEuler(0.35 * Math.sin(y * 0.7), 0, y);
    let I = 1 + Math.sin(w) * 0.08;
    x.setScale(I, I, I);
  }, O.setInk(F), O;
}
var ft = (c, l = {}) => new N({ colour: c, roughness: 0.5, ...l }), nt = (c, l, F = [0, 0, 0], m = [0, 0, 0], u = null) => {
  let S = new R("duck part");
  return S.mesh = c, S.material = l, S.setPosition(F[0], F[1], F[2]), S.setEuler(m[0], m[1], m[2]), u && S.setScale(u[0], u[1], u[2]), S;
}, ha = "#ffcb1f", Gs = /* @__PURE__ */ new Map();
function ua(c) {
  if (typeof document > "u") return null;
  let l = String(c || "");
  if (Gs.has(l)) return Gs.get(l);
  let F = document.createElement("canvas");
  F.width = 1024, F.height = 512;
  let m = F.getContext("2d"), u = m.createLinearGradient(0, 0, 0, F.height);
  u.addColorStop(0, "#f0a400"), u.addColorStop(0.55, ha), u.addColorStop(1, "#ffe066"), m.fillStyle = u, m.fillRect(0, 0, F.width, F.height);
  let S = (E) => {
    m.save(), m.translate(E, F.height * 0.47), m.scale(-0.55, -1);
    let h = m.createLinearGradient(0, -90, 0, 90);
    h.addColorStop(0, "#fff4c2"), h.addColorStop(0.45, "#f2b82a"), h.addColorStop(1, "#9a5d05"), m.fillStyle = "rgba(120,70,0,0.35)", m.beginPath(), m.ellipse(0, 6, 156, 92, 0, 0, Math.PI * 2), m.fill(), m.fillStyle = h, m.beginPath(), m.ellipse(0, 0, 152, 88, 0, 0, Math.PI * 2), m.fill();
    let A = m.createRadialGradient(-30, -40, 10, 0, 0, 150);
    A.addColorStop(0, "#ffe79a"), A.addColorStop(0.6, "#e9a91d"), A.addColorStop(1, "#c4820b"), m.fillStyle = A, m.beginPath(), m.ellipse(0, 0, 134, 74, 0, 0, Math.PI * 2), m.fill(), m.strokeStyle = "rgba(110,62,0,0.55)", m.lineWidth = 3, m.beginPath(), m.ellipse(0, 0, 124, 66, 0, 0, Math.PI * 2), m.stroke(), m.textAlign = "center", m.textBaseline = "middle";
    let v = (g, b, O) => {
      m.font = "900 " + b + "px system-ui, sans-serif", m.fillStyle = "rgba(255,248,220,0.75)", m.fillText(g, 0, O + 3), m.fillStyle = "#3a2200", m.fillText(g, 0, O);
    };
    v("OG", 80, c ? -16 : 2), c && v("#" + c, 50, 40), m.restore();
  };
  return S(F.width * 0.53), S(F.width * -0.03), S(F.width * 0.97), Gs.set(l, F), F;
}
var $s = null;
function fa() {
  if ($s) return $s;
  let F = U(1, 64, 40), S = F.positions, E = (M, T, x) => {
    let q = Math.min(1, Math.max(0, (x - M) / (T - M)));
    return q * q * (3 - 2 * q);
  };
  for (let M = 0; M < S.length; M += 3) {
    let T = S[M], x = S[M + 1], q = S[M + 2], L = E(0.1, 1, q), I = E(0.2, 1, -q);
    T *= 0.078 * (1 - 0.42 * L * L), x *= 0.062, q *= 0.108, q -= 0.01 * I * (1 - Math.abs(S[M + 1])), x += 0.052 * Math.pow(L, 1.6) * (0.55 + 0.45 * Math.max(0, S[M + 1] + 0.3)), q += 0.012 * L * Math.max(0, S[M + 1]), x < -0.04 && (x = -0.04 + (x + 0.04) * 0.15), S[M] = T, S[M + 1] = x, S[M + 2] = q;
  }
  let A = new Float32Array(S.length), b = F.indices;
  for (let z = 0; z < b.length; z += 3) {
    let K = b[z] * 3, H = b[z + 1] * 3, d0 = b[z + 2] * 3, d1 = S[H] - S[K], d2 = S[H + 1] - S[K + 1], d3 = S[H + 2] - S[K + 2], d4 = S[d0] - S[K], d5 = S[d0 + 1] - S[K + 1], d6 = S[d0 + 2] - S[K + 2], d7 = d2 * d6 - d3 * d5, d8 = d3 * d4 - d1 * d6, d9 = d1 * d5 - d2 * d4;
    for (let dd of [K, H, d0]) A[dd] += d7, A[dd + 1] += d8, A[dd + 2] += d9;
  }
  let O = /* @__PURE__ */ new Map();
  for (let dC = 0; dC < S.length; dC += 3) {
    let dc = S[dC].toFixed(5) + "," + S[dC + 1].toFixed(5) + "," + S[dC + 2].toFixed(5), dl = O.get(dc);
    dl === void 0 ? O.set(dc, dC) : (A[dl] += A[dC], A[dl + 1] += A[dC + 1], A[dl + 2] += A[dC + 2], A[dC] = A[dl], A[dC + 1] = A[dl + 1], A[dC + 2] = A[dl + 2]);
  }
  for (let dF = 0; dF < S.length; dF += 3) {
    let dk = O.get(S[dF].toFixed(5) + "," + S[dF + 1].toFixed(5) + "," + S[dF + 2].toFixed(5));
    dk !== void 0 && dk !== dF && (A[dF] = A[dk], A[dF + 1] = A[dk + 1], A[dF + 2] = A[dk + 2]);
    let dm = Math.hypot(A[dF], A[dF + 1], A[dF + 2]) || 1;
    A[dF] /= dm, A[dF + 1] /= dm, A[dF + 2] /= dm;
  }
  return F.normals = A, $s = F, F;
}
function qn(F = 0) {
  let S = new R("og duck"), E = ua(F), A = E ? new N({ colour: [1, 1, 1], map: E, roughness: 0.22 }) : ft([1, 0.78, 0.08], { roughness: 0.22 }), b = ft([1, 0.7, 0.04], { roughness: 0.3 }), O = ft([0.98, 0.7, 0.05], { roughness: 0.26 }), M = ft([1, 0.42, 0.04], { roughness: 0.28 }), T = ft([0.86, 0.3, 0.03], { roughness: 0.32 }), x = ft([1, 1, 1], { roughness: 0.3, emissive: [0.6, 0.6, 0.6] }), q = ft([1, 0.5, 0.55], { roughness: 0.9 }), L = ft([0.02, 0.02, 0.03], { roughness: 0.06, metallic: 0.2 }), I = ft([1, 1, 1], { emissive: [0.6, 0.6, 0.6], roughness: 0.1 }), z = ft([1, 0.77, 0.25], { roughness: 0.18, metallic: 1 }), K = ft([0.85, 0.05, 0.12], { roughness: 0.1, metallic: 0.3, emissive: [0.18, 0, 0.02] }), H = ft([0.1, 0.3, 0.95], { roughness: 0.1, metallic: 0.3, emissive: [0, 0.03, 0.15] });
  S.add(nt(fa(), A, [0, 0.042, 0]));
  for (let d1 of [-1, 1]) S.add(nt(U(0.05, 32, 20), O, [d1 * 0.06, 0.078, 0.058], [-0.42, d1 * 0.2, d1 * 0.3], [0.24, 0.42, 0.86]));
  S.add(nt(U(0.064, 48, 32), b, [0, 0.135, -0.05])), S.add(nt(U(0.026, 28, 18), M, [0, 0.122, -0.11], [-0.1, 0, 0], [1.15, 0.42, 1])), S.add(nt(U(0.02, 24, 14), T, [0, 0.112, -0.104], [0.12, 0, 0], [1, 0.32, 0.9]));
  for (let d2 of [-1, 1]) S.add(nt(U(0.011, 20, 14), L, [d2 * 0.03, 0.152, -0.105], [0, 0, 0], [0.9, 1.15, 0.55])), S.add(nt(U(36e-4, 10, 8), x, [d2 * 0.027, 0.157, -0.111])), S.add(nt(U(0.012, 16, 10), q, [d2 * 0.044, 0.127, -0.097], [0, d2 * 0.6, 0], [1, 0.6, 0.3]));
  let d0 = new R("crown");
  d0.setPosition(0, 0.185, -0.05), d0.setEuler(-0.15, 0, 0), S.add(d0), S.remove(d0), d0.add(nt(V(0.032, 0.02, 40, true), z)), d0.add(nt(W(0.032, 35e-4, 40, 8), z, [0, -0.01, 0])), d0.add(nt(W(0.032, 28e-4, 40, 8), z, [0, 0.01, 0]));
  for (let d3 = 0; d3 < 5; d3++) {
    let d4 = d3 / 5 * Math.PI * 2 - Math.PI / 2, d5 = Math.cos(d4) * 0.029, d6 = Math.sin(d4) * 0.029;
    d0.add(nt(ct(0.01, 2e-3, 0.026, 10), z, [d5, 0.023, d6])), d0.add(nt(U(42e-4, 10, 8), z, [d5, 0.037, d6]));
  }
  d0.add(nt(U(72e-4, 14, 10), K, [0, 0, -0.033], [0, 0, 0], [1, 1, 0.55]));
  for (let d7 of [-1, 1]) d0.add(nt(U(48e-4, 12, 8), H, [d7 * 0.024, 0, -0.024], [0, 0, 0], [1, 1, 0.55]));
  return S.number = F, S;
}
var qt = (c, l = {}) => new N({ colour: c, roughness: 0.5, ...l }), tt = (c, l, F = [0, 0, 0], m = [0, 0, 0], u = null) => {
  let S = new R("blaster part");
  return S.mesh = c, S.material = l, S.setPosition(F[0], F[1], F[2]), S.setEuler(m[0], m[1], m[2]), u && S.setScale(u[0], u[1], u[2]), S;
}, ve = (c, l = 2.4) => c.map((F) => F * l + 0.05);
function Kn(F = [0.2, 0.6, 1]) {
  let m = new R("laser blaster"), S = qt([0.9, 0.92, 0.95], { roughness: 0.32, metallic: 0.05 }), E = qt([0.07, 0.075, 0.09], { roughness: 0.42, metallic: 0.4 }), A = qt([0.42, 0.45, 0.5], { roughness: 0.25, metallic: 1 }), v = qt([0.9, 0.95, 1], { roughness: 0.05, emissive: [1.2, 1.3, 1.5] }), g = qt(F, { roughness: 0.3, emissive: ve(F) }), b = qt(F.map((y) => y * 0.3), { roughness: 0.4, emissive: ve(F, 0.35) }), O = [Math.PI / 2, 0, 0];
  m.add(tt(Z(0.075, 0.085, 0.25, 0.022), S, [0, 0.085, -0.05])), m.add(tt(Z(0.081, 0.032, 0.2, 0.01), E, [0, 0.05, -0.06])), m.add(tt(Z(0.022, 0.03, 0.17, 8e-3), E, [0, 0.138, -0.06])), m.add(tt(B(0.012, 0.016, 0.012), g, [0, 0.158, -0.13]));
  for (let y of [-1, 1]) m.add(tt(Z(6e-3, 0.026, 0.15, 3e-3), g, [y * 0.0395, 0.092, -0.05])), m.add(tt(Z(4e-3, 0.044, 0.18, 3e-3), E, [y * 0.0385, 0.092, -0.05]));
  m.add(tt(V(0.024, 0.15, 24), E, [0, 0.088, -0.24], O));
  for (let w = 0; w < 3; w++) m.add(tt(W(0.026, 45e-4, 24, 8), g, [0, 0.088, -0.19 - w * 0.042], O));
  m.add(tt(ct(0.026, 0.02, 0.03, 24), A, [0, 0.088, -0.33], [-Math.PI / 2, 0, 0])), m.add(tt(bt ? bt(0.016, 24) : V(0.016, 4e-3, 24), v, [0, 0.088, -0.346], [-Math.PI / 2, 0, 0])), m.add(tt(Z(0.046, 0.13, 0.058, 0.018), E, [0, -5e-3, 0.01], [0.28, 0, 0])), m.add(tt(Z(0.012, 0.03, 0.012, 5e-3), A, [0, 0.025, -0.045], [0.2, 0, 0])), m.add(tt(Z(0.018, 8e-3, 0.07, 4e-3), E, [0, 4e-3, -0.05]));
  for (let q = 0; q < 3; q++) m.add(tt(B(0.09, 8e-3, 0.012), A, [0, 0.07 + q * 0.022, 0.085]));
  m.add(tt(Z(0.05, 0.016, 6e-3, 3e-3), E, [0, 0.112, 0.077]));
  let M = new R("energy");
  M.setPosition(-0.022, 0.112, 0.081), m.add(M);
  let T = tt(B(0.044, 0.01, 4e-3), g, [0.022, 0, 0]);
  M.add(T);
  let x = new R("muzzle");
  return x.setPosition(0, 0.088, -0.36), m.add(x), m.muzzle = x, m.setTeam = (L) => (g.colour = L.slice(), g.emissive = ve(L), b.colour = L.map((p) => p * 0.3), b.emissive = ve(L, 0.35), m.team = L, m), m.setEnergy = (L) => {
    let p = Math.max(0.02, Math.min(1, L));
    return M.setScale(p, 1, 1), g.emissive = ve(m.team || F, 0.8 + 1.6 * p), m;
  }, m.team = F, m;
}
var Ge = [0.62, 0.22, 1], da = 42, Vs = 120, j = (c, l = {}) => new N({ colour: c, roughness: 0.6, ...l }), k = (c, l, F = [0, 0, 0], m = [0, 0, 0], u = null) => {
  let S = new R("part");
  return S.mesh = c, S.material = l, S.setPosition(F[0], F[1], F[2]), S.setEuler(m[0], m[1], m[2]), u && S.setScale(u[0], u[1], u[2]), S;
}, Hs = /* @__PURE__ */ new Map();
function js(c, l) {
  return Hs.has(c) || Hs.set(c, l()), Hs.get(c);
}
function pa() {
  if (typeof document > "u") return null;
  let l = document.createElement("canvas");
  l.width = 256, l.height = 128;
  let F = l.getContext("2d"), m = F.createLinearGradient(0, 0, 0, 128);
  m.addColorStop(0, "#6a3c1c"), m.addColorStop(0.5, "#7d4a24"), m.addColorStop(1, "#5a3116"), F.fillStyle = m, F.fillRect(0, 0, 256, 128);
  let u = 7, S = () => (u = u * 16807 % 2147483647) / 2147483647;
  for (let E = 0; E < 70; E++) {
    let h = S() * 128, A = 2 + S() * 4;
    F.strokeStyle = "rgba(" + (S() < 0.5 ? "40,20,8" : "150,95,50") + "," + (0.15 + S() * 0.3) + ")", F.lineWidth = 0.6 + S() * 1.8, F.beginPath();
    for (let v = 0; v <= 256; v += 8) F.lineTo(v, h + Math.sin(v / 30 + E) * A);
    F.stroke();
  }
  return l;
}
function Xs() {
  let F = new R("rpg"), m = j([0.13, 0.14, 0.15], { roughness: 0.38, metallic: 0.65 }), S = j([0.04, 0.04, 0.045], { roughness: 0.6, metallic: 0.2 }), E = j([0.6, 0.62, 0.65], { roughness: 0.22, metallic: 0.95 }), A = j([0.27, 0.31, 0.17], { roughness: 0.55, metallic: 0.15 }), v = j([0.06, 0.06, 0.06], { roughness: 0.95 }), g = j(Ge, { emissive: [0.9, 0.3, 1.6], roughness: 0.35 }), b = j([0.2, 0.9, 1], { emissive: [0.15, 0.9, 1.2], roughness: 0.1, metallic: 0.3 }), O = js("grain", pa), M = O ? new N({ colour: [1, 1, 1], map: O, roughness: 0.5 }) : j([0.42, 0.24, 0.11], { roughness: 0.5 }), T = [Math.PI / 2, 0, 0], x = [-Math.PI / 2, 0, 0];
  F.add(k(V(0.046, 1, 24), m, [0, 0, 0.04], T)), F.add(k(V(0.058, 0.34, 24), M, [0, 0, 0.02], T));
  for (let w of [-0.15, 0.19]) F.add(k(V(0.061, 0.03, 24), E, [0, 0, w], T));
  F.add(k(ct(0.05, 0.082, 0.16, 24), S, [0, 0, 0.61], T)), F.add(k(W(0.081, 6e-3, 32, 8), E, [0, 0, 0.69], T)), F.add(k(bt(0.075, 32, 2), j([0.01, 0.01, 0.01]), [0, 0, 0.684], T)), F.add(k(V(0.054, 0.07, 24), m, [0, 0, -0.44], T)), F.add(k(W(0.054, 7e-3, 32, 8), E, [0, 0, -0.475], T)), F.add(k(Z(0.04, 0.15, 0.06, 0.012, 3), v, [0, -0.115, 0.06], [-0.28, 0, 0])), F.add(k(B(0.036, 0.03, 0.08), m, [0, -0.055, 0.04])), F.add(k(B(0.012, 0.03, 0.012), E, [0, -0.072, 0], [0.3, 0, 0])), F.add(k(W(0.032, 5e-3, 20, 6), m, [0, -0.08, -2e-3], [0, 0, Math.PI / 2])), F.add(k(Z(0.036, 0.12, 0.05, 0.01, 3), v, [0, -0.1, -0.22], [0.12, 0, 0])), F.add(k(B(0.034, 0.026, 0.07), m, [0, -0.053, -0.22])), F.add(k(Z(0.075, 0.035, 0.16, 0.014, 3), A, [0, -0.052, 0.36])), F.add(k(B(0.018, 0.02, 0.2), m, [-0.05, 0.03, -0.06])), F.add(k(V(0.022, 0.16, 18), S, [-0.072, 0.06, -0.06], T)), F.add(k(V(0.026, 0.035, 18), S, [-0.072, 0.06, -0.15], T)), F.add(k(bt(0.021, 24, 2), b, [-0.072, 0.06, -0.168], x)), F.add(k(bt(0.017, 24, 2), j([0.02, 0.05, 0.07], { roughness: 0.08, metallic: 0.4 }), [-0.072, 0.06, 0.021], T)), F.add(k(B(0.012, 0.035, 0.012), m, [-0.072, 0.09, -0.06])), F.add(k(B(8e-3, 0.035, 8e-3), E, [0, 0.062, -0.4]));
  for (let q of [-0.32, 0.46]) F.add(k(W(0.014, 3e-3, 14, 6), E, [0.05, 0, q], [0, 0, Math.PI / 2]));
  let y = new R("warhead");
  y.setPosition(0, 0, -0.5), F.add(y), y.add(k(V(0.022, 0.12, 14), m, [0, 0, -0.04], T));
  for (let L = 0; L < 4; L++) {
    let I = L / 4 * Math.PI * 2 + Math.PI / 4;
    y.add(k(B(4e-3, 0.03, 0.07), E, [Math.cos(I) * 0.03, Math.sin(I) * 0.03, -0.02], [0, 0, I + Math.PI / 2]));
  }
  return y.add(k(ct(0.026, 0.07, 0.08, 24), A, [0, 0, -0.14], x)), y.add(k(V(0.07, 0.1, 24), A, [0, 0, -0.23], T)), y.add(k(W(0.07, 6e-3, 32, 8), g, [0, 0, -0.2], T)), y.add(k(ct(0.07, 0.014, 0.17, 24), A, [0, 0, -0.365], x)), y.add(k(U(0.016, 12, 8), g, [0, 0, -0.45])), F.muzzle = [0, 0, -0.85], Jn && Ct(Jn, {}).then((z) => {
    for (let K of [...F.children]) K.dispose();
    F.add(z);
  }).catch((z) => console.warn("[staff] RPG model did not load, using the built one: " + z.message)), F;
}
var Jn = "";
function Yn(c, l, F, m = false, u = false) {
  let S = new R("sign");
  S.setPosition(F[0], F[1], F[2]), m && S.setEuler(0, Math.PI, 0);
  let E = new R("sign-tilt");
  E.setEuler(Math.PI / 2, 0, 0), S.add(E);
  let h = u ? bt(l / 2, 48, 3) : Yt(l, l);
  return E.add(k(h, c, [0, 0, 0], [0, Math.PI, 0])), S;
}
function ma(c, l) {
  if (typeof document > "u") return null;
  let F = document.createElement("canvas");
  F.width = 512, F.height = 512;
  let m = F.getContext("2d");
  m.translate(512, 0), m.scale(-1, 1);
  let u = m.createRadialGradient(220, 200, 30, 256, 256, 300);
  return u.addColorStop(0, "#ff4a57"), u.addColorStop(0.55, "#c3121f"), u.addColorStop(1, "#5c0710"), m.fillStyle = u, m.fillRect(0, 0, 512, 512), m.strokeStyle = "#ffd7a8", m.lineWidth = 22, m.beginPath(), m.arc(256, 256, 236, 0, Math.PI * 2), m.stroke(), m.strokeStyle = "rgba(255,255,255,0.55)", m.lineWidth = 5, m.beginPath(), m.arc(256, 256, 206, 0, Math.PI * 2), m.stroke(), m.textAlign = "center", m.textBaseline = "middle", m.font = "900 172px system-ui, sans-serif", m.shadowColor = "rgba(255,220,180,0.9)", m.shadowBlur = 26, m.fillStyle = "#fff6ec", m.fillText(c, 256, l ? 238 : 256), m.shadowBlur = 0, m.lineWidth = 4, m.strokeStyle = "rgba(90,0,8,0.5)", m.strokeText(c, 256, l ? 238 : 256), l && (m.font = "800 40px system-ui, sans-serif", m.fillStyle = "rgba(255,240,225,0.92)", m.fillText(l.toUpperCase(), 256, 352)), F;
}
function ga() {
  if (typeof document > "u") return null;
  let c = document.createElement("canvas");
  c.width = 128, c.height = 256;
  let l = c.getContext("2d");
  l.fillStyle = "#16120f", l.fillRect(0, 0, 128, 256);
  for (let F = -128; F < 384; F += 36) {
    l.save(), l.translate(0, F), l.transform(1, -0.35, 0, 1, 0, 0);
    let m = l.createLinearGradient(0, 0, 0, 30);
    m.addColorStop(0, "#3a2c22"), m.addColorStop(0.5, "#2a1f18"), m.addColorStop(1, "#110d0a"), l.fillStyle = m, l.fillRect(0, 0, 128, 30), l.fillStyle = "rgba(210,170,120,0.55)";
    for (let u = 4; u < 128; u += 10) l.fillRect(u, 3, 5, 2);
    l.restore();
  }
  return c;
}
function Ws() {
  let F = new R("ban hammer"), S = j([0.22, 0.12, 0.07], { roughness: 0.45 }), E = j([0.62, 0.04, 0.07], { roughness: 0.22, metallic: 0.15 }), A = j([0.035, 0.035, 0.04], { roughness: 0.35, metallic: 0.3 }), v = j([0.5, 0.52, 0.56], { roughness: 0.2, metallic: 1 }), g = j([0.95, 0.68, 0.24], { roughness: 0.25, metallic: 1 }), b = j([1, 0.08, 0.1], { emissive: [2.6, 0.12, 0.16], roughness: 0.4 }), O = js("wrap", ga), M = O ? new N({ colour: [1, 1, 1], map: O, roughness: 0.85 }) : j([0.1, 0.08, 0.07], { roughness: 0.9 }), T = new R("swing");
  F.add(T), F.swing = T;
  let x = [Math.PI / 2, 0, 0];
  T.add(k(U(0.036, 18, 12), v, [0, -0.15, 0], [0, 0, 0], [1, 0.8, 1])), T.add(k(W(0.03, 7e-3, 24, 8), g, [0, -0.125, 0])), T.add(k(V(0.029, 0.25, 20), M, [0, 0, 0])), T.add(k(W(0.029, 5e-3, 24, 8), v, [0, -0.118, 0])), T.add(k(W(0.029, 5e-3, 24, 8), v, [0, 0.122, 0])), T.add(k(V(0.022, 0.4, 16), S, [0, 0.31, 0])), T.add(k(ct(0.024, 0.036, 0.07, 20), v, [0, 0.49, 0])), T.add(k(W(0.034, 6e-3, 24, 8), g, [0, 0.462, 0]));
  let y = 0.6, w = new R("head");
  w.setPosition(0, y, 0), T.add(w), w.add(k(V(0.098, 0.3, 32), E, [0, 0, 0], x)), w.add(k(V(0.104, 0.07, 32), A, [0, 0, 0], x));
  for (let L = 0; L < 10; L++) {
    let I = L / 10 * Math.PI * 2;
    w.add(k(U(0.011, 10, 8), g, [Math.cos(I) * 0.106, Math.sin(I) * 0.106, 0]));
  }
  for (let z of [-0.042, 0.042]) w.add(k(W(0.1, 45e-4, 40, 8), b, [0, 0, z], x));
  for (let K of [1, -1]) w.add(k(V(0.106, 0.035, 32), v, [0, 0, K * 0.152], x)), w.add(k(W(0.104, 8e-3, 40, 10), v, [0, 0, K * 0.17], x)), w.add(k(W(0.098, 35e-4, 40, 8), b, [0, 0, K * 0.12], x));
  let q = js("ban", () => ma("BAN", "for show"));
  if (q) {
    let H = new N({ colour: [1, 1, 1], map: q, roughness: 0.35, emissive: [0.18, 0.05, 0.05] });
    w.add(Yn(H, 0.18, [0, 0, 0.1705], false, true)), w.add(Yn(H, 0.18, [0, 0, -0.1705], true, true));
  }
  return w.add(k(B(0.05, 0.02, 0.05), v, [0, 0.1, 0])), T.setEuler(-0.3, 0, 0), F;
}
var qs = class extends EventTarget {
  constructor({ game: c, net: l, hud: F = null, respawn: m = null }) {
    super(), this.game = c, this.net = l, this.hud = F, this.respawn = m, this.models = { 1: Xs(), 2: Ws() }, this.held = null, this.attached = /* @__PURE__ */ new Map(), this.pens = /* @__PURE__ */ new Map(), this.penInkOf = () => [0.25, 0.6, 1], this.blasters = /* @__PURE__ */ new Map(), this.blasterTeamOf = () => [0.2, 0.6, 1], this.effects = [], this._swingT = 0, this._cooldown = 0, c.addUpdater((u) => this.update(u)), this._bind();
  }
  get ["allowed"]() {
    return !!(this.net && this.net.connected && this.net.staff);
  }
  ["can"](c) {
    if (!this.allowed) return false;
    let l = c === G.rpg ? "rpg" : c === G.hammer ? "hammer" : c;
    return typeof this.net.canStaff == "function" ? this.net.canStaff(l) : true;
  }
  ["mayHoldDuck"]() {
    let c = this.net;
    return !!(c && c.og > 0 && (c.features || []).includes("duck") && c.room !== "PAINTBALL");
  }
  ["mayHoldBlaster"]() {
    let c = this.net;
    return !!(c && c.connected && c.room === "PAINTBALL" && (c.features || []).includes("lasertag"));
  }
  ["duckNumberOf"](c) {
    if (c === "mine") return this.net && this.net.og || 0;
    let l = this.net && this.net.players && this.net.players.get(c);
    return l && l.og || 0;
  }
  ["equip"](c) {
    let l = this.allowed ? Math.min(Math.max(c | 0, 0), 2) : 0;
    return l && !this.can(l) && (l = 0), this.game.player.wielding = l, this.dispatchEvent(new CustomEvent("equip", { detail: { tool: l } })), l;
  }
  ["update"](c) {
    let l = this.game;
    l.player.wielding && l.player.wielding !== G.builder && l.player.wielding !== G.duck && l.player.wielding !== G.blaster && !this.can(l.player.wielding) && (l.player.wielding = 0), l.player.wielding === G.blaster && !this.mayHoldBlaster() && (l.player.wielding = 0), l.player.wielding === G.duck && !this.mayHoldDuck() && (l.player.wielding = 0), this._cooldown = Math.max(0, this._cooldown - c);
    let F = l.view === "third" && l._self && l._self.ready ? l._self.avatar.right : l._handNodes && l._handNodes.right;
    this._hold(F, l.player.wielding, "mine");
    for (let [u, S] of l.remotes) this._hold(S.right, S.target ? S.target.w | 0 : 0, u);
    for (let E of [...this.attached.keys()]) E !== "mine" && !l.remotes.has(E) && this._drop(E);
    let m = this.attached.get("mine");
    if (m && m.w === 2 && m.node.swing) {
      this._swingT = Math.max(0, this._swingT - c);
      let h = this._swingT / 0.28;
      m.node.swing.setEuler(-0.3 - Math.sin(h * Math.PI) * 1.3, 0, 0);
    }
    for (let A of this.pens.values()) A.tick(c);
    for (let v of [...this.effects]) v.t += c, v.update(v.t, c) === false && (v.dispose(), this.effects.splice(this.effects.indexOf(v), 1));
  }
  ["_hold"](c, l, F) {
    let m = this.attached.get(F);
    if (m && (m.w !== l || m.hand !== c) && this._drop(F), !l || !c || this.attached.has(F)) return;
    let u = F === "mine" && this.models[l] ? this.models[l] : l === G.rpg ? Xs() : l === G.builder ? Wn(this.penInkOf(F)) : l === G.duck ? qn(this.duckNumberOf(F)) : l === G.blaster ? Kn(this.blasterTeamOf(F)) : Ws();
    l === G.builder && this.pens.set(F, u), l === G.blaster && this.blasters.set(F, u);
    let S = (c.scale ? 1 / Math.max(c.scale[0], 1e-3) : 1) * (l === G.duck ? 1.35 : 1);
    u.setScale(S, S, S), l === G.rpg ? u.setPosition(0, 0.11 * S, -0.06 * S) : l === G.builder ? (u.setPosition(0, 0.05 * S, -0.08 * S), u.setEuler(0.2, 0.3, 0)) : l === G.blaster ? u.setPosition(0, -0.01 * S, -0.03 * S) : l === G.duck ? (u.setPosition(0, 0.03 * S, -0.04 * S), u.setEuler(0, Math.PI / 2, 0)) : u.setPosition(0, 0, 0), c.add(u), this.attached.set(F, { w: l, node: u, hand: c });
  }
  ["_drop"](c) {
    let l = this.attached.get(c);
    l && (l.node.parent && (l.node.parent.remove ? l.node.parent.remove(l.node) : l.node.dispose()), (c !== "mine" || l.w === G.builder || l.w === G.blaster) && l.node.dispose(), this.attached.delete(c), this.pens.delete(c), this.blasters.delete(c));
  }
  ["fire"]() {
    if (!this.can("rpg") || this.game.player.wielding !== G.rpg || this._cooldown > 0) return false;
    this._cooldown = 0.9;
    let F = this.game, m = F.camera.position, S = F.camera.forward(), E = [m[0] + S[0] * 0.8, m[1] + S[1] * 0.8 - 0.05, m[2] + S[2] * 0.8], A = Vs, v = Nt(F.scene, m, S, Vs, F._cameraSkip ? F._cameraSkip() : null);
    v !== null && (A = Math.min(A, v));
    let g = F.collision.raycast(m, S, Vs, { ignoreInside: true });
    g && (A = Math.min(A, g.distance));
    for (let O of F.remotes.values()) {
      if (!O.root) continue;
      let M = O.root.worldPosition(), T = [M[0], M[1] + 0.9, M[2]], x = [T[0] - m[0], T[1] - m[1], T[2] - m[2]], y = x[0] * S[0] + x[1] * S[1] + x[2] * S[2];
      if (y < 0 || y > A) continue;
      Math.hypot(x[0] - S[0] * y, x[1] - S[1] * y, x[2] - S[2] * y) < 0.55 && (A = y);
    }
    let b = [m[0] + S[0] * A, m[1] + S[1] * A, m[2] + S[2] * A];
    return this.net.sendTool({ kind: "rpg", from: E, to: b }), true;
  }
  ["swing"]() {
    if (!this.can("hammer") || this.game.player.wielding !== G.hammer || this._swingT > 0) return false;
    this._swingT = 0.28;
    let F = this.game, m = F.player.position, u = F.camera.forward(), S = null, E = 1 / 0;
    for (let [A, v] of F.remotes) {
      if (!v.root) continue;
      let g = v.root.worldPosition(), b = [g[0] - m[0], 0, g[2] - m[2]], O = Math.hypot(b[0], b[2]);
      O > 3.2 || (b[0] * u[0] + b[2] * u[2]) / (O || 1) / (Math.hypot(u[0], u[2]) || 1) < 0.5 && O > 1 || O < E && (S = A, E = O);
    }
    return S !== null && this.net.sendTool({ kind: "hammer", target: S }), true;
  }
  ["sendBack"](c) {
    return this.can("rpg") ? (this.net.sendTool({ kind: "reset", target: c }), true) : false;
  }
  ["show"](c) {
    c.kind === "rpg" ? this._rocket(c) : c.kind === "hammer" ? this._bonk(c) : c.kind === "reset" && this.hud && this.hud.say(c.name + " sent " + c.targetName + " back to spawn", "info");
  }
  ["hit"]({ by: c, why: l }) {
    this.respawn && this.respawn(), this.hud && (l === "rpg" ? this.hud.flash?.("BOOM", c + " got you with the RPG. Back to spawn.") : this.hud.flash?.("Back to spawn", c + " (staff) sent you back."));
  }
  ["_rocket"]({ from: F, to: m, name: S, hit: E }) {
    let A = this.game, v = new R("rocket");
    v.add(k(V(0.05, 0.42, 12), j([0.25, 0.29, 0.18]), [0, 0, 0], [Math.PI / 2, 0, 0])), v.add(k(U(0.06, 12, 8), j(Ge, { emissive: [0.6, 0.2, 1.2] }), [0, 0, -0.24], [0, 0, 0], [1, 1, 1.6]));
    let g = k(U(0.07, 10, 8), j([1, 0.7, 1], { emissive: [1.6, 0.6, 2.4], castShadow: false }), [0, 0, 0.26]);
    v.add(g), A.scene.add(v);
    let b = [m[0] - F[0], m[1] - F[1], m[2] - F[2]], O = Math.hypot(b[0], b[1], b[2]) || 1, M = b.map((y) => y / O);
    v.setEuler(Math.asin(Math.max(-1, Math.min(1, M[1]))), Math.atan2(-M[0], -M[2]), 0);
    let T = O / da, x = [];
    if (this.effects.push({ t: 0, update: (y) => {
      let w = Math.min(y / T, 1);
      if (v.setPosition(F[0] + b[0] * w, F[1] + b[1] * w, F[2] + b[2] * w), g.setScale(1, 1, 1 + Math.sin(y * 60) * 0.3), x.length < 40 && Math.random() < 0.8) {
        let q = k(U(0.05, 8, 6), j([0.75, 0.6, 1], { alpha: 0.55, castShadow: false, emissive: [0.3, 0.1, 0.5] }), [F[0] + b[0] * w, F[1] + b[1] * w, F[2] + b[2] * w]);
        q.born = y, A.scene.add(q), x.push(q);
      }
      for (let L of x) {
        let I = y - L.born;
        L.setScale(1 + I * 4, 1 + I * 4, 1 + I * 4), L.material.alpha = Math.max(0, 0.55 - I * 0.9), L.visible = L.material.alpha > 0.02;
      }
      return w >= 1 ? (v.parent && (v.dispose(), this._explode(m)), y < T + 0.7) : true;
    }, dispose: () => {
      v.parent && v.dispose();
      for (let y of x) y.dispose();
    } }), this.hud && E && E.length) {
      let y = E.map((w) => w === this.net.id ? "you" : this.net.players.get(w)?.name || "somebody").join(", ");
      this.hud.say(S + "'s RPG got " + y, "warn");
    }
  }
  ["_explode"](F) {
    let m = this.game, S = k(U(1, 24, 16), j([1, 0.85, 1], { emissive: [2.2, 1.2, 3.2], alpha: 0.95, castShadow: false }), F), E = k(U(1, 28, 18), j(Ge, { emissive: [0.9, 0.25, 1.6], alpha: 0.6, castShadow: false, doubleSided: true }), F);
    m.scene.add(S), m.scene.add(E);
    let A = [], v = U(0.05, 6, 4);
    for (let b = 0; b < 36; b++) {
      let O = Math.random() * 2 - 1, M = Math.random() * Math.PI * 2, T = Math.sqrt(1 - O * O), x = 4 + Math.random() * 7, y = k(v, j(b % 3 ? Ge : [1, 0.8, 1], { emissive: [1.2, 0.4, 2], castShadow: false, alpha: 0.999 }), F);
      y.vel = [T * Math.cos(M) * x, O * x + 2, T * Math.sin(M) * x], y.pos = F.slice(), m.scene.add(y), A.push(y);
    }
    this.effects.push({ t: 0, update: (w, q) => {
      let L = Math.min(w / 0.3, 1), p = Nn * (0.2 + 0.8 * (1 - (1 - L) ** 3));
      S.setScale(p * 0.55, p * 0.55, p * 0.55), S.material.alpha = Math.max(0, 0.95 - w * 3.2), E.setScale(p, p, p), E.material.alpha = Math.max(0, 0.6 - w * 1.1), S.visible = S.material.alpha > 0.02, E.visible = E.material.alpha > 0.02;
      for (let I of A) {
        I.vel[1] -= 9.8 * q;
        for (let z = 0; z < 3; z++) I.pos[z] += I.vel[z] * q;
        I.setPosition(I.pos[0], I.pos[1], I.pos[2]), I.material.alpha = Math.max(0, 0.999 - w * 0.9), I.visible = I.material.alpha > 0.02;
      }
      return w < 1.2;
    }, dispose: () => {
      S.dispose(), E.dispose();
      for (let w of A) w.dispose();
    } }), this._boom(F);
    let g = m.camera.position;
    if (Math.hypot(F[0] - g[0], F[1] - g[1], F[2] - g[2]) < 12 && typeof document < "u") {
      let w = document.createElement("div");
      w.className = "hud-boomflash", document.body.appendChild(w), setTimeout(() => w.remove(), 600);
    }
  }
  ["_boom"](F) {
    try {
      let m = globalThis.AudioContext || globalThis.webkitAudioContext;
      if (!m) return;
      let S = this._ctx || (this._ctx = new m());
      S.state === "suspended" && S.resume().catch(() => {
      });
      let E = this.game.camera.position, A = Math.hypot(F[0] - E[0], F[1] - E[1], F[2] - E[2]), v = Math.min(1, 6 / Math.max(A, 1)) * 0.6, g = Math.floor(S.sampleRate * 0.9), b = S.createBuffer(1, g, S.sampleRate), O = b.getChannelData(0);
      for (let y = 0; y < g; y++) O[y] = (Math.random() * 2 - 1) * Math.exp(-y / (S.sampleRate * 0.18));
      let M = S.createBufferSource();
      M.buffer = b;
      let T = S.createBiquadFilter();
      T.type = "lowpass", T.frequency.value = 420;
      let x = S.createGain();
      x.gain.value = v, M.connect(T), T.connect(x), x.connect(S.destination), M.start();
    } catch {
    }
  }
  ["_bonk"]({ name: F, target: m, targetName: S, by: E }) {
    let A = this.game, v = this.net && m === this.net.id;
    this.hud && (v && this.hud.flash?.("BONK!", F + " hit you with the ban hammer. It is for show: you are not banned."), this.hud.say(F + " bonked " + S + " with the ban hammer (for show, nobody was banned)", "warn"));
    let g = A.remotes.get(m), b = g && g.head ? g.head.worldPosition() : v ? A.player.eye() : null;
    if (!b) return;
    let O = [], M = U(0.045, 8, 6);
    for (let T = 0; T < 6; T++) {
      let x = k(M, j([1, 0.9, 0.3], { emissive: [1.4, 1.1, 0.3], castShadow: false }), b);
      A.scene.add(x), O.push(x);
    }
    this.effects.push({ t: 0, update: (y) => {
      let w = g && g.head ? g.head.worldPosition() : b;
      return O.forEach((q, L) => {
        let I = y * 6 + L / O.length * Math.PI * 2;
        q.setPosition(w[0] + Math.cos(I) * 0.3, w[1] + 0.32 + Math.sin(y * 9 + L) * 0.03, w[2] + Math.sin(I) * 0.3);
      }), y < 2;
    }, dispose: () => {
      for (let y of O) y.dispose();
    } }), E === (this.net && this.net.id) && this.dispatchEvent(new CustomEvent("bonked", { detail: { target: m, targetName: S } }));
  }
  ["_bind"]() {
    if (this.net && (this.net.addEventListener("tool", (F) => this.show(F.detail)), this.net.addEventListener("reset", (F) => this.hit(F.detail)), this.net.addEventListener("disconnected", () => {
      this.game.player.wielding = 0;
    }), this.net.addEventListener("staff", () => {
      this.game.player.wielding && !this.can(this.game.player.wielding) && this.equip(G.none);
    })), typeof window > "u") return;
    let c = () => document.pointerLockElement === this.game.canvas, l = (F) => F && (/^(INPUT|TEXTAREA|SELECT)$/.test(F.tagName) || F.isContentEditable);
    window.addEventListener("keydown", (F) => {
      !this.allowed || F.repeat || l(F.target) || !c() || (F.code === "Digit1" ? this.equip(G.none) : F.code === "Digit2" ? this.equip(this.game.player.wielding === G.rpg ? G.none : G.rpg) : F.code === "Digit3" && this.equip(this.game.player.wielding === G.hammer ? G.none : G.hammer));
    }), this.game.canvas.addEventListener("mousedown", (F) => {
      F.button !== 0 || !c() || !this.game.player.wielding || (this.game.player.wielding === G.rpg ? this.fire() : this.game.player.wielding === G.hammer && this.swing());
    });
  }
};
function $e(c, l, F) {
  let m = c.inverseViewProjection, u = Zn(l, F, -1, m), S = Zn(l, F, 1, m), E = _.normalize(_.create(), _.sub(_.create(), S, u));
  return { origin: u, dir: E };
}
function Zn(c, l, F, m) {
  let u = m[3] * c + m[7] * l + m[11] * F + m[15];
  return _.create((m[0] * c + m[4] * l + m[8] * F + m[12]) / u, (m[1] * c + m[5] * l + m[9] * F + m[13]) / u, (m[2] * c + m[6] * l + m[10] * F + m[14]) / u);
}
function Ks(l, F, m) {
  let u = _.normalize(_.create(), m), S = _.sub(_.create(), F, l.origin), E = _.dot(u, l.dir), h = 1 - E * E;
  if (h < 2e-3) return null;
  let A = _.dot(u, S), v = _.dot(l.dir, S);
  return (E * v - A) / h;
}
function Ve(c, l, F) {
  let m = _.normalize(_.create(), F), u = _.dot(m, c.dir);
  if (Math.abs(u) < 1e-6) return null;
  let S = _.dot(m, _.sub(_.create(), l, c.origin)) / u;
  return S < 0 ? null : _.scaleAndAdd(_.create(), c.origin, c.dir, S);
}
function Js(c, l, F) {
  let m = _.normalize(_.create(), F), { u, v: S } = va(m), E = _.sub(_.create(), c, l);
  return Math.atan2(_.dot(E, S), _.dot(E, u));
}
function va(c) {
  let l = Math.abs(c[0]) < 0.9 ? [1, 0, 0] : [0, 1, 0], F = _.normalize(_.create(), _.cross(_.create(), l, c)), m = _.cross(_.create(), c, F);
  return { u: F, v: m };
}
function Qn(c, l) {
  let F = (l - c) % (Math.PI * 2);
  return F > Math.PI && (F -= Math.PI * 2), F < -Math.PI && (F += Math.PI * 2), F;
}
function He(c, l) {
  return l ? Math.round(c / l) * l : c;
}
function to(F, m, S) {
  let E = _.sub(_.create(), S, m), A = _.length(E);
  if (A < 1e-9) return { distance: _.distance(F.origin, m), t: 0 };
  let v = _.scale(_.create(), E, 1 / A), g = _.sub(_.create(), m, F.origin), b = _.dot(F.dir, v), O = 1 - b * b, M;
  O < 1e-6 ? M = 0 : M = (b * _.dot(F.dir, g) - _.dot(v, g)) / O, M = Math.min(Math.max(M, 0), A);
  let T = _.scaleAndAdd(_.create(), m, v, M), x = Math.max(_.dot(_.sub(_.create(), T, F.origin), F.dir), 0), y = _.scaleAndAdd(_.create(), F.origin, F.dir, x);
  return { distance: _.distance(T, y), t: M / A, depth: x };
}
function eo(c, l, F, m = 0.18) {
  return 2 * Math.max(_.distance(c, l), 1e-3) * Math.tan(F * Math.PI / 360) * m;
}
var vt = { SELECT: "select", MOVE: "move", ROTATE: "rotate", SCALE: "scale" }, Ys = [[0.86, 0.22, 0.26], [0.42, 0.78, 0.22], [0.22, 0.48, 0.92]], wa = [1, 0.85, 0.25], je = [[1, 0, 0], [0, 1, 0], [0, 0, 1]], ya = 0.13, Xe = class {
  constructor() {
    this.root = new R("gizmo"), this.root.visible = false, this.tool = vt.MOVE, this.snap = { move: 0, rotate: 0, scale: 0 }, this.hover = -1, this.size = 1, this.origin = _.create(), this._handles = [], this._drag = null, this._build();
  }
  ["setTool"](c) {
    return c === this.tool ? this : (this.tool = c, this._build(), this);
  }
  ["attach"](c) {
    return this.object = c || null, this.root.visible = !!c && this.tool !== vt.SELECT, c && _.set(this.origin, ...c.position), this;
  }
  ["update"](c, l = 16 / 9) {
    this.root.visible && (this.size = eo(c.position, this.origin, c.verticalFov(l)), this.root.setPosition(this.origin[0], this.origin[1], this.origin[2]), this.root.setScale(this.size));
  }
  ["pick"](F, m, u) {
    if (!this.root.visible) return -1;
    let S = $e(F, m, u), E = this.size * ya, A = -1, v = E, g = 1 / 0;
    for (let b = 0; b < 3; b++) {
      let O = this.tool === vt.ROTATE ? this._ringDistance(S, b) : to(S, this.origin, this._axisEnd(b));
      O && (O.distance < v - 1e-6 || Math.abs(O.distance - v) < 1e-6 && O.depth < g) && (v = O.distance, g = O.depth, A = b);
    }
    return A;
  }
  ["setHover"](c) {
    if (c !== this.hover) {
      this.hover = c;
      for (let l of this._handles) {
        let F = l.axis === c ? wa : Ys[l.axis];
        l.node.material.colour = F.map((m) => m * 0.25), l.node.material.emissive = F.map((m) => m * 0.92);
      }
    }
  }
  ["begin"](l, F, m, u) {
    if (u < 0 || !this.object) return false;
    let S = $e(l, F, m), E = je[u], h = { axis: u, origin: [...this.origin], position: [...this.object.position], rotation: [...this.object.rotation], scale: [...this.object.scale] };
    if (this.tool === vt.ROTATE) {
      let A = Ve(S, this.origin, E);
      if (!A) return false;
      h.angle = Js(A, this.origin, E);
    } else {
      let v = Ks(S, this.origin, E);
      if (v === null) return false;
      h.t = v;
    }
    return this._drag = h, true;
  }
  ["move"](F, m, S) {
    let E = this._drag;
    if (!E) return null;
    let A = $e(F, m, S), v = E.axis, g = je[v];
    if (this.tool === vt.ROTATE) {
      let T = Ve(A, E.origin, g);
      if (!T) return null;
      let x = Js(T, E.origin, g), y = Qn(E.angle, x) * 180 / Math.PI;
      v !== 1 && (y = -y);
      let w = [...E.rotation];
      return w[v] = He(E.rotation[v] + y, this.snap.rotate), { rotation: w };
    }
    let b = Ks(A, E.origin, g);
    if (b === null) return null;
    let O = b - E.t;
    if (this.tool === vt.SCALE) {
      let q = [...E.scale], L = Math.max(Math.abs(E.scale[v]), 0.05), I = Math.max(E.scale[v] + O * (L / Math.max(this.size, 0.05)), 0.01);
      return q[v] = He(I, this.snap.scale) || 0.01, { scale: q };
    }
    let M = [...E.position];
    return M[v] = He(E.position[v] + O, this.snap.move), _.set(this.origin, ...M), { position: M };
  }
  ["end"]() {
    let c = this._drag;
    return this._drag = null, !!c;
  }
  get ["dragging"]() {
    return !!this._drag;
  }
  ["_axisEnd"](c) {
    return _.scaleAndAdd(_.create(), this.origin, je[c], this.size);
  }
  ["_ringDistance"](c, l) {
    let F = Ve(c, this.origin, je[l]);
    if (!F) return null;
    let m = _.distance(F, this.origin), u = _.distance(c.origin, F);
    return { distance: Math.abs(m - this.size), depth: u };
  }
  ["_build"]() {
    for (let c of [...this.root.children]) c.dispose();
    if (this._handles = [], this.tool === vt.SELECT) {
      this.root.visible = false;
      return;
    }
    for (let l = 0; l < 3; l++) {
      let F = new R("axis" + l);
      F.material = new N({ colour: Ys[l].map((m) => m * 0.25), emissive: Ys[l].map((m) => m * 0.92), roughness: 0.5, castShadow: false }), F.mesh = this._meshFor(l), Ma(F, l, this.tool), this.root.add(F), this._handles.push({ axis: l, node: F });
    }
    this.setHover(this.hover);
  }
  ["_meshFor"](c) {
    switch (this.tool) {
      case vt.MOVE:
        return _a();
      case vt.SCALE:
        return xa();
      case vt.ROTATE:
        return ba();
      default:
        return B(0.1, 0.1, 0.1);
    }
  }
};
function _a() {
  let c = V(0.018, 0.82, 10);
  we(c, 0, 0.41, 0);
  let l = Ea(0.055, 0.18, 14);
  return we(l, 0, 0.91, 0), Pt([c, l]);
}
function xa() {
  let c = V(0.018, 0.86, 10);
  we(c, 0, 0.43, 0);
  let l = B(0.1, 0.1, 0.1);
  return we(l, 0, 0.9, 0), Pt([c, l]);
}
function ba(l = 56, F = 0.016) {
  let m = [];
  for (let u = 0; u < l; u++) {
    let S = u / l * Math.PI * 2, E = (u + 1) / l * Math.PI * 2, h = (S + E) / 2, A = Math.hypot(Math.cos(E) - Math.cos(S), Math.sin(E) - Math.sin(S)) * 1.15, v = B(A, F * 2, F * 2);
    Ta(v, -(h + Math.PI / 2)), we(v, Math.cos(h), 0, Math.sin(h)), m.push(v);
  }
  return Pt(m);
}
function Ea(F, m, S) {
  let E = [], A = [], v = [], g = [], b = Math.atan2(F, m);
  for (let M = 0; M <= S; M++) {
    let T = M / S * Math.PI * 2, x = Math.cos(T), y = Math.sin(T);
    E.push(x * F, 0, y * F), A.push(x * Math.cos(b), Math.sin(b), y * Math.cos(b)), v.push(M / S, 0), E.push(0, m, 0), A.push(x * Math.cos(b), Math.sin(b), y * Math.cos(b)), v.push(M / S, 1);
  }
  for (let w = 0; w < S; w++) {
    let q = w * 2;
    g.push(q, q + 1, q + 2);
  }
  let O = E.length / 3;
  E.push(0, 0, 0), A.push(0, -1, 0), v.push(0.5, 0.5);
  for (let L = 0; L <= S; L++) {
    let p = L / S * Math.PI * 2;
    E.push(Math.cos(p) * F, 0, Math.sin(p) * F), A.push(0, -1, 0), v.push(0.5, 0.5);
  }
  for (let I = 0; I < S; I++) g.push(O, O + I + 2, O + I + 1);
  return { positions: new Float32Array(E), normals: new Float32Array(A), uvs: new Float32Array(v), indices: g };
}
function Ma(c, l, F) {
  F === vt.ROTATE ? (l === 0 && X.fromEuler(c.rotation, 0, 0, -Math.PI / 2), l === 2 && X.fromEuler(c.rotation, Math.PI / 2, 0, 0)) : (l === 0 && X.fromEuler(c.rotation, 0, 0, -Math.PI / 2), l === 2 && X.fromEuler(c.rotation, Math.PI / 2, 0, 0)), c.markDirty();
}
function we(c, l, F, m) {
  let u = c.positions;
  for (let S = 0; S < u.length; S += 3) u[S] += l, u[S + 1] += F, u[S + 2] += m;
  return c;
}
function Ta(c, l) {
  let F = Math.sin(l), m = Math.cos(l);
  for (let u of [c.positions, c.normals]) for (let S = 0; S < u.length; S += 3) {
    let E = u[S], h = u[S + 2];
    u[S] = E * m + h * F, u[S + 2] = -E * F + h * m;
  }
  return c;
}
var so = 0;
function Kt(c = "o") {
  return so++, "" + c + Date.now().toString(36) + so.toString(36) + Math.random().toString(36).slice(2, 6);
}
function _e(c = "box", l = {}) {
  return { id: Kt(), kind: c, name: c, position: [0, 0.5, 0], rotation: [0, 0, 0], scale: [1, 1, 1], colour: [0.78, 0.78, 0.82], roughness: 0.7, metallic: 0, src: "", solid: true, ...l };
}
function Ot(c) {
  if (!c || typeof c != "object") return c;
  let l = (u, S, E = 0, h = 1) => typeof u == "number" && Number.isFinite(u) ? Math.min(h, Math.max(E, u)) : S, F = Array.isArray(c.colour) && c.colour.length >= 3 && c.colour.slice(0, 3).every((u) => Number.isFinite(Number(u))) ? c.colour.slice(0, 3).map((u) => Math.min(1, Math.max(0, Number(u)))) : [0.78, 0.78, 0.82], m = { ...c, colour: F, roughness: l(c.roughness, 0.7), metallic: l(c.metallic, 0) };
  if (c.emissive !== void 0) {
    let u = Array.isArray(c.emissive) ? c.emissive.slice(0, 3).map((S) => l(Number(S), 0, 0, 4)) : [0, 0, 0];
    u.length === 3 && u.some((S) => S > 0) ? m.emissive = u : delete m.emissive;
  }
  return m;
}
var ye = class n4 extends EventTarget {
  constructor() {
    super(), this.objects = /* @__PURE__ */ new Map(), this.claims = /* @__PURE__ */ new Map(), this.holdMs = 600;
  }
  ["list"]() {
    return [...this.objects.values()];
  }
  ["get"](c) {
    return this.objects.get(c);
  }
  get ["size"]() {
    return this.objects.size;
  }
  ["apply"](l, { local: F = true, from: m = 0 } = {}) {
    switch (l.k) {
      case D.ADD:
        this.objects.set(l.o.id, Ot(l.o));
        break;
      case D.REMOVE:
        this.objects.delete(l.id), this.claims.delete(l.id);
        break;
      case D.MOVE: {
        if (!F && this.heldByMe(l.o.id)) break;
        this.objects.set(l.o.id, Ot(l.o));
        break;
      }
      case D.MATERIAL: {
        let u = this.objects.get(l.o.id);
        if (!F && u && this.heldByMe(l.o.id)) {
          let { position: S, rotation: E, scale: h, ...A } = l.o;
          this.objects.set(l.o.id, Ot({ ...A, position: u.position, rotation: u.rotation, scale: u.scale }));
          break;
        }
        this.objects.set(l.o.id, Ot(l.o));
        break;
      }
      case D.RENAME: {
        let v = this.objects.get(l.id);
        v && (v.name = l.name);
        break;
      }
      default:
        return false;
    }
    return this.dispatchEvent(new CustomEvent("changed", { detail: { op: l, local: F, from: m } })), true;
  }
  ["replaceAll"](c) {
    this.objects.clear();
    for (let l of c) l && l.id !== void 0 && this.objects.set(l.id, Ot(l));
    this.dispatchEvent(new CustomEvent("reset", { detail: { count: this.objects.size } }));
  }
  ["claim"](c, l = "me") {
    this.claims.set(c, { who: l, at: Date.now() });
  }
  ["release"](c) {
    this.claims.delete(c);
  }
  ["heldBy"](c) {
    let l = this.claims.get(c);
    return l ? Date.now() - l.at > this.holdMs ? (this.claims.delete(c), null) : l.who : null;
  }
  ["heldByMe"](c) {
    return this.heldBy(c) === "me";
  }
  ["toJSON"]() {
    return { version: 1, objects: this.list() };
  }
  static ["fromJSON"](c) {
    let l = new n4();
    return c && Array.isArray(c.objects) && l.replaceAll(c.objects), l;
  }
}, yt = { GAME_OBJECT: 1, TRANSFORM: 4, MESH_RENDERER: 23, MESH_FILTER: 33, MESH_COLLIDER: 64, BOX_COLLIDER: 65, SPHERE_COLLIDER: 135, CAPSULE_COLLIDER: 136, LIGHT: 108, CAMERA: 20, MONO_BEHAVIOUR: 114, PREFAB_INSTANCE: 1001 }, io = { 10202: "cube", 10206: "cylinder", 10207: "sphere", 10208: "capsule", 10209: "plane", 10210: "quad" }, We = class extends Error {
};
function ti(F) {
  if (typeof F != "string" || !F.includes("%YAML")) throw new We("That does not look like a Unity scene \u2014 it should start with %YAML.");
  let S = Sa(F), E = new Map(S.map((d0) => [d0.id, d0])), A = [], b = S.filter((d0) => d0.cls === yt.TRANSFORM), O = /* @__PURE__ */ new Map();
  for (let d0 of b) {
    let d1 = Zs(d0.body, "m_GameObject"), d2 = d1 ? E.get(d1) : null;
    O.set(d0.id, { id: d0.id, gameObject: d1, name: d2 && St(d2.body, "m_Name") || "GameObject", active: d2 ? St(d2.body, "m_IsActive") !== "0" : true, parent: Zs(d0.body, "m_Father") || null, localPosition: Jt(d0.body, "m_LocalPosition") || [0, 0, 0], localRotation: Aa(d0.body, "m_LocalRotation") || [0, 0, 0, 1], localScale: Jt(d0.body, "m_LocalScale") || [1, 1, 1], children: [], mesh: null, colliders: [], light: null, scripts: [] });
  }
  for (let d3 of O.values()) d3.parent && O.has(d3.parent) && O.get(d3.parent).children.push(d3.id);
  let M = /* @__PURE__ */ new Map();
  for (let d4 of O.values()) M.set(d4.gameObject, d4);
  for (let d5 of S) {
    let d6 = M.get(Zs(d5.body, "m_GameObject"));
    if (d6) switch (d5.cls) {
      case yt.MESH_FILTER: {
        let d7 = Qs(d5.body, "m_Mesh");
        if (!d7) break;
        io[d7.fileID] ? d6.mesh = { kind: io[d7.fileID], builtIn: true } : (d6.mesh = { kind: "external", builtIn: false, guid: d7.guid || null }, A.push('"' + d6.name + '" uses a model from another file (guid ' + (d7.guid || "?") + ") \u2014 import that model separately."));
        break;
      }
      case yt.BOX_COLLIDER:
        d6.colliders.push({ type: "box", size: Jt(d5.body, "m_Size") || [1, 1, 1], center: Jt(d5.body, "m_Center") || [0, 0, 0], trigger: St(d5.body, "m_IsTrigger") === "1" });
        break;
      case yt.SPHERE_COLLIDER:
        d6.colliders.push({ type: "sphere", radius: Number(St(d5.body, "m_Radius") || 0.5), center: Jt(d5.body, "m_Center") || [0, 0, 0] });
        break;
      case yt.CAPSULE_COLLIDER:
        d6.colliders.push({ type: "capsule", radius: Number(St(d5.body, "m_Radius") || 0.5), height: Number(St(d5.body, "m_Height") || 2), center: Jt(d5.body, "m_Center") || [0, 0, 0] });
        break;
      case yt.MESH_COLLIDER: {
        let d8 = Qs(d5.body, "m_Mesh");
        d6.colliders.push({ type: "mesh", external: !!(d8 && d8.guid), guid: d8 ? d8.guid : null });
        break;
      }
      case yt.LIGHT:
        d6.light = { type: Number(St(d5.body, "m_Type") ?? 1), colour: Ra(d5.body, "m_Color") || [1, 1, 1], intensity: Number(St(d5.body, "m_Intensity") || 1), range: Number(St(d5.body, "m_Range") || 10) };
        break;
      case yt.MONO_BEHAVIOUR:
        d6.scripts.push(Qs(d5.body, "m_Script")?.guid || "unknown");
        break;
    }
  }
  let T = [...O.values()].filter((d9) => !d9.parent || !O.has(d9.parent));
  for (let d9 of T) no(d9, O, [0, 0, 0], [1, 1, 1]);
  let x = [...O.values()], f = x.filter((dd) => /spawn/i.test(dd.name) && !dd.mesh && dd.active), q = x.filter((dd) => dd.light), L = S.filter((dd) => dd.cls === yt.PREFAB_INSTANCE).length, I = S.filter((dd) => dd.cls === yt.MESH_COLLIDER).length - x.reduce((dd, dC) => dd + dC.colliders.filter((dc) => dc.type === "mesh").length, 0);
  L && A.push(L + " prefab instance(s) are placed here \u2014 what they contain lives in .prefab files beside this scene."), I > 0 && A.push(I + " mesh collider(s) belong to prefabs or models that are not in this file. That is usually where the room geometry went: import the .fbx or .prefab it came from.");
  let z = /* @__PURE__ */ new Set();
  for (let dd of x) {
    dd.mesh && !dd.mesh.builtIn && dd.mesh.guid && z.add(dd.mesh.guid);
    for (let dC of dd.colliders) dC.type === "mesh" && dC.guid && z.add(dC.guid);
  }
  let K = x.reduce((dc, dl) => dc + dl.colliders.filter((dF) => dF.type === "mesh").length, 0), H = x.filter((dc) => dc.mesh && dc.mesh.builtIn).length;
  return z.size && A.push(K + " collider(s) and " + z.size + " model file(s) are referenced but not in this scene \u2014 the geometry lives in .fbx/.obj files beside it. Import those and the shapes will line up with these colliders."), !H && !x.some((dc) => dc.mesh) && A.push("No geometry at all in this scene \u2014 everything visible comes from model files referenced from it."), { objects: x, roots: T.map((dc) => dc.id), spawns: f, lights: q, warnings: A };
}
function Sa(c) {
  let l = [], F = /^--- !u!(\d+) &(\d+)(?:\s+stripped)?\s*$/gm, m, u = null;
  for (; (m = F.exec(c)) !== null; ) u && (u.body = c.slice(u.start, m.index)), u = { cls: Number(m[1]), id: m[2], start: F.lastIndex }, l.push(u);
  return u && (u.body = c.slice(u.start)), l;
}
var St = (c, l) => {
  let F = new RegExp("^\\s*" + l + ":\\s*(.+)$", "m").exec(c || "");
  return F ? F[1].trim() : null;
}, Zs = (c, l) => {
  let F = new RegExp(l + ":\\s*\\{fileID:\\s*(\\d+)", "").exec(c || "");
  return F && F[1] !== "0" ? F[1] : null;
}, Qs = (c, l) => {
  let F = new RegExp(l + ":\\s*\\{fileID:\\s*(-?\\d+)(?:,\\s*guid:\\s*([0-9a-f]+))?", "").exec(c || "");
  return F ? { fileID: Number(F[1]), guid: F[2] || null } : null;
}, _t = "(-?[\\d.eE+]+)";
function Jt(c, l) {
  let F = new RegExp(l + ":\\s*\\{x:\\s*" + _t + ",\\s*y:\\s*" + _t + ",\\s*z:\\s*" + _t, "").exec(c || "");
  return F ? [Number(F[1]), Number(F[2]), Number(F[3])] : null;
}
function Aa(c, l) {
  let F = new RegExp(l + ":\\s*\\{x:\\s*" + _t + ",\\s*y:\\s*" + _t + ",\\s*z:\\s*" + _t + ",\\s*w:\\s*" + _t, "").exec(c || "");
  return F ? [Number(F[1]), Number(F[2]), Number(F[3]), Number(F[4])] : null;
}
function Ra(c, l) {
  let F = new RegExp(l + ":\\s*\\{r:\\s*" + _t + ",\\s*g:\\s*" + _t + ",\\s*b:\\s*" + _t, "").exec(c || "");
  return F ? [Number(F[1]), Number(F[2]), Number(F[3])] : null;
}
function no(c, l, F, m) {
  c.position = [F[0] + c.localPosition[0] * m[0], F[1] + c.localPosition[1] * m[1], F[2] + c.localPosition[2] * m[2]], c.scale = [c.localScale[0] * m[0], c.localScale[1] * m[1], c.localScale[2] * m[2]], c.rotation = c.localRotation;
  for (let u of c.children) {
    let S = l.get(u);
    S && no(S, l, c.position, c.scale);
  }
}
function ei(F, { idPrefix: m = "u" } = {}) {
  let u = [], S = 0;
  for (let h of F.objects) {
    if (!h.active) continue;
    let A = h.mesh && h.mesh.builtIn, v = h.colliders.find((O) => O.type === "box");
    if (!A && !v) continue;
    let g = v ? [Math.abs(h.scale[0] * v.size[0]), Math.abs(h.scale[1] * v.size[1]), Math.abs(h.scale[2] * v.size[2])] : [Math.abs(h.scale[0]), Math.abs(h.scale[1]), Math.abs(h.scale[2])], b = v ? [h.position[0] + v.center[0], h.position[1] + v.center[1], h.position[2] + v.center[2]] : h.position;
    u.push({ id: "" + m + (++S).toString(36), kind: A ? Pa(h.mesh.kind) : "box", name: h.name, position: [b[0], b[1], -b[2]], rotation: [0, 0, 0], scale: g, colour: [0.75, 0.75, 0.78], roughness: 0.8, metallic: 0, src: "", solid: !(v && v.trigger) });
  }
  let E = F.spawns.map((O) => ({ name: O.name, position: [O.position[0], O.position[1], -O.position[2]] }));
  return { objects: u, spawns: E, warnings: F.warnings };
}
var Pa = (c) => ({ cube: "box", sphere: "sphere", cylinder: "cylinder", capsule: "cylinder", plane: "plane", quad: "plane" })[c] || "box";
function si(F, { height: m = 3.2, thickness: S = 0.3, idPrefix: E = "shell" } = {}) {
  let A = Fa(F);
  if (!A) return [];
  let [v, g, b] = A.position, O = A.scale[0], M = A.scale[2], T = g + A.scale[1] / 2, x = T + m / 2, y = [0.68, 0.69, 0.73], w = 0, q = (L, I, z, K = y) => ({ id: "" + E + (++w).toString(36), kind: "box", name: L, position: I, rotation: [0, 0, 0], scale: z, colour: K, roughness: 0.9, metallic: 0, src: "", solid: true });
  return [q("Shell wall north", [v, x, b - M / 2], [O + S * 2, m, S]), q("Shell wall south", [v, x, b + M / 2], [O + S * 2, m, S]), q("Shell wall west", [v - O / 2, x, b], [S, m, M]), q("Shell wall east", [v + O / 2, x, b], [S, m, M]), q("Shell ceiling", [v, T + m, b], [O + S * 2, S, M + S * 2], [0.8, 0.81, 0.84])];
}
function Fa(c) {
  let l = null, F = 0;
  for (let m of c) {
    let [u, S, E] = m.scale;
    if (S > Math.min(u, E) * 0.5) continue;
    let h = u * E;
    h > F && (F = h, l = m);
  }
  return F >= 16 ? l : null;
}
var ka = 700, Ca = 200;
function oo(c, l) {
  switch (c.k) {
    case D.ADD:
      return { k: D.REMOVE, id: c.o.id };
    case D.REMOVE:
      return l ? { k: D.ADD, o: { ...l } } : null;
    case D.MOVE:
    case D.MATERIAL:
      return l ? { k: c.k, o: { ...l } } : null;
    case D.RENAME:
      return l ? { k: D.RENAME, id: c.id, name: l.name } : null;
    default:
      return null;
  }
}
function ro(c, l) {
  let F = l && l.name || c.o && c.o.name || "object";
  switch (c.k) {
    case D.ADD:
      return "Add " + F;
    case D.REMOVE:
      return "Delete " + F;
    case D.MOVE:
      return "Move " + F;
    case D.MATERIAL:
      return "Change " + F;
    case D.RENAME:
      return "Rename " + F;
    default:
      return "Edit";
  }
}
var xe = class extends EventTarget {
  constructor({ limit: c = Ca } = {}) {
    super(), this.limit = c, this.past = [], this.future = [], this.replaying = false, this._openedAt = 0;
  }
  get ["canUndo"]() {
    return this.past.length > 0;
  }
  get ["canRedo"]() {
    return this.future.length > 0;
  }
  get ["undoLabel"]() {
    return this.past.length ? this.past[this.past.length - 1].label : "";
  }
  get ["redoLabel"]() {
    return this.future.length ? this.future[this.future.length - 1].label : "";
  }
  ["record"](c, l, { label: F = "" } = {}) {
    if (this.replaying) return;
    let m = { label: F || ro(c, l), redo: [c], undo: [oo(c, l)].filter(Boolean), key: Ia(c) };
    if (!m.undo.length) return;
    let u = this.past[this.past.length - 1], S = Date.now();
    u && u.key && u.key === m.key && S - this._openedAt < ka ? (u.redo = m.redo, u.label = m.label) : (this.past.push(m), this.past.length > this.limit && this.past.shift()), this._openedAt = S, this.future.length = 0, this._changed();
  }
  ["seal"]() {
    this._openedAt = 0;
  }
  ["undo"](c) {
    let l = this.past.pop();
    if (!l) return null;
    this.replaying = true;
    try {
      for (let F of l.undo) c(F);
    } finally {
      this.replaying = false;
    }
    return this.future.push(l), this.seal(), this._changed(), l;
  }
  ["redo"](c) {
    let l = this.future.pop();
    if (!l) return null;
    this.replaying = true;
    try {
      for (let F of l.redo) c(F);
    } finally {
      this.replaying = false;
    }
    return this.past.push(l), this.seal(), this._changed(), l;
  }
  ["clear"]() {
    this.past.length = 0, this.future.length = 0, this.seal(), this._changed();
  }
  ["_changed"]() {
    this.dispatchEvent(new CustomEvent("changed", { detail: { canUndo: this.canUndo, canRedo: this.canRedo, undoLabel: this.undoLabel, redoLabel: this.redoLabel } }));
  }
};
function Ia(c) {
  return c.k !== D.MOVE && c.k !== D.MATERIAL ? null : c.k + ":" + c.o.id;
}
var ni = class extends EventTarget {
  constructor(c, { net: l = null } = {}) {
    super(), this.game = c, this.net = l, this.doc = new ye(), this.selected = null, this.spawns = [], this.nodes = /* @__PURE__ */ new Map(), this.root = new R("edited"), c.scene.add(this.root), this.gizmo = new Xe(), this.overlay = new R("overlay"), this.overlay.add(this.gizmo.root), c.overlay = this.overlay, this.history = new xe(), this.doc.addEventListener("changed", (F) => this._sync(F.detail)), this.doc.addEventListener("reset", () => {
      this.history.clear(), this._rebuildAll();
    }), l && this._wireNet(l);
  }
  ["add"](c, l = {}) {
    let F = _e(c, l);
    return this._do({ k: D.ADD, o: F }), this.select(F.id), F;
  }
  async ["addModel"](c, l = {}) {
    let F = typeof c == "string" ? c : c.name, m = _e("model", { src: F, name: La(F), ...l });
    return this._do({ k: D.ADD, o: m }), typeof c != "string" && (this._pending ??= /* @__PURE__ */ new Map(), this._pending.set(m.id, c)), await this._build(m), this.select(m.id), m;
  }
  ["importUnity"](F, { shell: m = true } = {}) {
    let u = ti(F), S = Kt("imp"), { objects: E, spawns: A, warnings: v } = ei(u, { idPrefix: S + "_" }), g = m ? si(E, { idPrefix: S + "_s" }) : [], b = [...E, ...g];
    for (let O of b) this._do({ k: D.ADD, o: O });
    if (A.length) {
      this.spawns = A;
      let M = A[0].position;
      this.game.spawn(M[0], M[1] + 1.2, M[2]);
    }
    return this.select(null), { added: b.length, shell: g.length, spawns: A, lights: u.lights.length, warnings: v };
  }
  ["insert"](c, { offset: l = [0, 0, 0] } = {}) {
    if (!c || !c.kind) return null;
    let F = _e(c.kind, { ...c, id: Kt(), position: (c.position || [0, 0, 0]).map((m, u) => m + (l[u] || 0)) });
    return this._do({ k: D.ADD, o: F }), this.select(F.id), F;
  }
  ["remove"](c = this.selected) {
    !c || !this.doc.get(c) || (this.isolated === c && this.isolate(null), this._do({ k: D.REMOVE, id: c }), this.selected === c && this.select(null));
  }
  ["duplicate"](c = this.selected) {
    let l = this.doc.get(c);
    if (!l) return null;
    let F = { ...l, id: Kt(), position: [l.position[0] + 1, l.position[1], l.position[2]] };
    return this._do({ k: D.ADD, o: F }), this.select(F.id), F;
  }
  ["transform"](c, { position: l, rotation: F, scale: m } = {}) {
    let u = this.doc.get(c);
    if (!u) return;
    let S = { ...u, position: l || u.position, rotation: F || u.rotation, scale: m || u.scale };
    this._do({ k: D.MOVE, o: S });
  }
  ["setMaterial"](c, { colour: l, roughness: F, metallic: m, solid: u } = {}) {
    let S = this.doc.get(c);
    S && this._do({ k: D.MATERIAL, o: { ...S, colour: l || S.colour, roughness: F ?? S.roughness, metallic: m ?? S.metallic, solid: u ?? S.solid } });
  }
  ["isolate"](c = null) {
    this.isolated = c && this.doc.get(c) ? c : null;
    for (let [l, F] of this.nodes) {
      let m = this.doc.get(l);
      m && (F.visible = this._shows(m));
    }
    return this.dispatchEvent(new CustomEvent("isolated", { detail: { id: this.isolated } })), this.isolated;
  }
  ["_shows"](c) {
    return c.hidden ? false : !this.isolated || c.id === this.isolated;
  }
  ["setProps"](c, l = {}) {
    let F = this.doc.get(c);
    if (!F) return;
    let m = { ...F, ...l };
    for (let [u, S] of [["hidden", false], ["locked", false], ["castShadow", true], ["tag", ""], ["notes", ""]]) u in l && l[u] === S && delete m[u];
    "opacity" in l && l.opacity >= 1 && delete m.opacity, "emissive" in l && !(l.emissive || []).some((E) => E > 0) && delete m.emissive, this._do({ k: D.MATERIAL, o: m }), l.locked && this.selected === c && this.gizmo.attach(null), l.locked === false && this.selected === c && this.gizmo.attach(m);
  }
  ["rename"](c, l) {
    this.doc.get(c) && this._do({ k: D.RENAME, id: c, name: l });
  }
  ["select"](c) {
    this.selected = c && this.doc.get(c) ? c : null;
    let l = this.doc.get(this.selected) || null;
    this.gizmo.attach(l && !l.locked ? l : null), this.dispatchEvent(new CustomEvent("selected", { detail: { id: this.selected } }));
  }
  ["setTool"](c) {
    return this.gizmo.setTool(c), this.gizmo.attach(this.doc.get(this.selected) || null), this.dispatchEvent(new CustomEvent("tool", { detail: { tool: c } })), this;
  }
  get ["tool"]() {
    return this.gizmo.tool;
  }
  ["bounds"]() {
    let c = [1 / 0, 1 / 0, 1 / 0], l = [-1 / 0, -1 / 0, -1 / 0];
    for (let F of this.doc.list()) {
      let m = this._sizeOf(F);
      if (m) for (let u = 0; u < 3; u++) {
        let S = m.extent[u] / 2;
        m.centre[u] - S < c[u] && (c[u] = m.centre[u] - S), m.centre[u] + S > l[u] && (l[u] = m.centre[u] + S);
      }
    }
    return Number.isFinite(c[0]) ? { min: c, max: l, centre: [0, 1, 2].map((E) => (c[E] + l[E]) / 2), size: [0, 1, 2].map((E) => l[E] - c[E]) } : null;
  }
  ["frame"](c) {
    this.gizmo.update(this.game.camera, c), this.presence && this.presence.update();
  }
  ["watch"](c) {
    return this.presence = c, this.overlay.add(c.root), c;
  }
  ["pointerDown"](c, l) {
    let F = this.gizmo.pick(this.game.camera, c, l);
    return F >= 0 && this.gizmo.begin(this.game.camera, c, l, F) ? "drag" : (this.select(this.pick(c, l)), this.selected ? "select" : "none");
  }
  ["pointerMove"](c, l) {
    if (this.gizmo.dragging) {
      let F = this.gizmo.move(this.game.camera, c, l);
      return F && this.transform(this.selected, F), true;
    }
    return this.gizmo.setHover(this.gizmo.pick(this.game.camera, c, l)), false;
  }
  ["pointerUp"]() {
    return this.sealHistory(), this.gizmo.end();
  }
  ["pick"](F, m) {
    let S = this.game.camera.inverseViewProjection, E = _.create(), A = _.create();
    co(E, F, m, -1, S), co(A, F, m, 1, S);
    let v = _.normalize(_.create(), _.sub(_.create(), A, E)), g = null, b = 1 / 0;
    for (let [O, M] of this.nodes) {
      let T = this.doc.get(O);
      if (T && (T.locked || T.hidden) || this.isolated && O !== this.isolated) continue;
      let s = Na(E, v, M);
      s !== null && s < b && (b = s, g = O);
    }
    return g;
  }
  ["undo"]() {
    let c = this.history.undo((l) => this._do(l));
    return c && this.dispatchEvent(new CustomEvent("history", { detail: { did: "undo", entry: c } })), c;
  }
  ["redo"]() {
    let c = this.history.redo((l) => this._do(l));
    return c && this.dispatchEvent(new CustomEvent("history", { detail: { did: "redo", entry: c } })), c;
  }
  ["sealHistory"]() {
    this.history.seal();
  }
  ["_do"](c) {
    let l = c.o ? c.o.id : c.id;
    this.history.record(c, l ? this.doc.get(l) : null);
    let F = c.o ? c.o.id : c.id;
    F && (c.k === D.MOVE || c.k === D.MATERIAL) && this.doc.claim(F, "me"), this.doc.apply(c, { local: true }), this.net && this.net.connected && this.net.sendEdit(c);
  }
  ["_sync"]({ op: c }) {
    switch (c.k) {
      case D.ADD:
      case D.MOVE:
      case D.MATERIAL:
        this._build(this.doc.get(c.o.id)), c.o.id === this.selected && !this.gizmo.dragging && this.gizmo.attach(this.doc.get(c.o.id));
        break;
      case D.REMOVE: {
        let l = this.nodes.get(c.id);
        if (l) {
          for (let F of l.allNodes()) this.game.unanimate(F);
          l.dispose(), this.nodes.delete(c.id);
        }
        this._queueCollision();
        break;
      }
    }
    this.dispatchEvent(new CustomEvent("changed", { detail: c }));
  }
  async ["_build"](c) {
    if (!c) return;
    let l = this.nodes.get(c.id);
    if (!l || l._kind !== c.kind || l._src !== c.src) {
      if (l && l.dispose(), l = new R(c.name || c.kind), l._kind = c.kind, l._src = c.src, this.nodes.set(c.id, l), this.root.add(l), c.kind === "model") try {
        let S = this._pending?.get(c.id), E = S ? await hs(S, {}) : await Ct(c.src, {});
        this._pending?.delete(c.id), l.add(E), ho(l, this.doc.get(c.id) || c), this.game.animate(E), this.dispatchEvent(new CustomEvent("loaded", { detail: { id: c.id, node: l, model: E } })), Rs(l, { idle: true }), l._bounds = null;
      } catch (h) {
        console.warn("Could not load " + c.src + ": " + h.message), l.mesh = B(0.5, 0.5, 0.5), l.material = new N({ colour: [0.9, 0.2, 0.2], roughness: 0.9 });
      }
      else l.mesh = c.kind === "stroke" ? lo(c) : ao(c.kind), l._strokeKey = c.kind === "stroke" ? ii(c) : null, l.material = new N();
    }
    l.name = c.name || c.kind;
    let F = be(c.position, 0), m = be(c.rotation, 0), u = be(c.scale, 1);
    if (l.visible = this._shows(c), _.set(l.position, ...F), X.fromEuler(l.rotation, m[0] * Ee, m[1] * Ee, m[2] * Ee), _.set(l.scale, ...u), l.markDirty(), c.kind !== "model" && l.material) {
      let A = Ot(c);
      l.material.colour = A.colour, l.material.roughness = A.roughness, l.material.metallic = A.metallic, l.material.emissive = Array.isArray(c.emissive) ? c.emissive : [0, 0, 0], l.material.alpha = c.opacity ?? 1, l.material.castShadow = c.castShadow !== false;
    }
    if (l.light = Ba(c), c.kind === "box" && c.texture) {
      let v = u + "|" + c.tile;
      if (l._tileKey !== v && (l.mesh = qe(u, c.tile || 1), l._tileKey = v), l._textureOf !== c.texture) {
        l._textureOf = c.texture;
        let g = l.material;
        sn(c.texture).then((b) => {
          l._textureOf === c.texture && (g.map = b, g._texture = null);
        }).catch((b) => console.warn(b.message));
      }
    } else l._tileKey && (l.mesh = ao(c.kind), l._tileKey = null, l._textureOf = null, l.material && (l.material.map = null, l.material._texture = null));
    c.kind === "stroke" && l._strokeKey !== ii(c) && (l.mesh = lo(c), l._strokeKey = ii(c)), c.kind === "model" && (ho(l, c), Oa(l, c), za(l, c)), this._queueCollision();
  }
  ["_rebuildAll"]() {
    for (let c of this.nodes.values()) c.dispose();
    this.nodes.clear();
    for (let l of this.doc.list()) this._build(l);
  }
  ["_queueCollision"]() {
    this._collisionQueued || (this._collisionQueued = true, queueMicrotask(() => {
      this._collisionQueued = false, this._rebuildCollision();
    }));
  }
  ["_rebuildCollision"]() {
    let c = this.game.collision;
    c.clear(), this.groundPlane !== false && c.addBox([0, -0.5, 0], [200, 1, 200]);
    let l = /* @__PURE__ */ new Set();
    for (let F of this.doc.list()) {
      if (F.solid === false) continue;
      if (F.kind === "box" && !(F.rotation || []).some((m) => m % 360 !== 0) || F.hidden) {
        let m = this._sizeOf(F);
        m && c.addBox(m.centre, m.extent);
        continue;
      }
      l.add(F.id), c.addBuilt(this._colliderOf(F));
    }
    if (this._triCache) {
      for (let u of this._triCache.keys()) l.has(u) || this._triCache.delete(u);
    }
  }
  ["_colliderOf"](F) {
    let m = this.nodes.get(F.id);
    if (!m) return null;
    let u = this._collidingParts(m);
    if (!u.length) return null;
    let S = 0;
    for (let O of u) S += O.mesh.indices ? O.mesh.indices.length : O.mesh.positions.length / 3;
    let E = /ladder/i.test((F.name || "") + " " + (F.src || "")), A = F.src + "|" + F.kind + "|" + F.position + "|" + F.rotation + "|" + F.scale + "|" + u.length + "|" + S + "|" + E;
    this._triCache ??= /* @__PURE__ */ new Map();
    let v = this._triCache.get(F.id);
    if (v && v.key === A) return v.built;
    let g = this._trianglesOf(F, u), b = g ? It.buildMesh(g, { id: F.id, climb: E }) : null;
    return this._triCache.set(F.id, { key: A, built: b }), b;
  }
  ["_collidingParts"](c) {
    let l = [], F = (m) => {
      if (!m.noCollide) {
        m.mesh && m.mesh.positions && m.mesh.positions.length && !m.skin && l.push(m);
        for (let u of m.children) F(u);
      }
    };
    return F(c), l;
  }
  ["_trianglesOf"](F, S = null) {
    let E = this.nodes.get(F.id);
    if (!E || (S ??= this._collidingParts(E), !S.length)) return null;
    let A = 0;
    for (let O of S) A += O.mesh.indices ? O.mesh.indices.length : O.mesh.positions.length / 3;
    let v = new Float32Array(A * 3), b = 0;
    for (let M of S) {
      let T = M.worldMatrix(), x = M.mesh.positions, y = M.mesh.indices, w = y ? y.length : x.length / 3;
      for (let q = 0; q < w; q++) {
        let L = (y ? y[q] : q) * 3, I = x[L], z = x[L + 1], K = x[L + 2];
        v[b++] = T[0] * I + T[4] * z + T[8] * K + T[12], v[b++] = T[1] * I + T[5] * z + T[9] * K + T[13], v[b++] = T[2] * I + T[6] * z + T[10] * K + T[14];
      }
    }
    return v;
  }
  ["_sizeOf"](F) {
    if (F.kind !== "model") {
      let v = be(F.scale, 1);
      return { centre: be(F.position, 0), extent: [Math.abs(v[0]) || 0.01, Math.abs(v[1]) || 0.01, Math.abs(v[2]) || 0.01] };
    }
    let m = this.nodes.get(F.id), u = m && uo(m);
    if (!u) return null;
    let S = m.worldMatrix(), E = [1 / 0, 1 / 0, 1 / 0], h = [-1 / 0, -1 / 0, -1 / 0], A = _.create();
    for (let g = 0; g < 8; g++) {
      _.transformMat4(A, [g & 1 ? u.max[0] : u.min[0], g & 2 ? u.max[1] : u.min[1], g & 4 ? u.max[2] : u.min[2]], S);
      for (let b = 0; b < 3; b++) A[b] < E[b] && (E[b] = A[b]), A[b] > h[b] && (h[b] = A[b]);
    }
    return Number.isFinite(E[0]) ? { centre: [(E[0] + h[0]) / 2, (E[1] + h[1]) / 2, (E[2] + h[2]) / 2], extent: [Math.max(h[0] - E[0], 0.01), Math.max(h[1] - E[1], 0.01), Math.max(h[2] - E[2], 0.01)] } : null;
  }
  ["_wireNet"](c) {
    c.addEventListener("edit", (l) => {
      let { op: F, from: m, fixed: u } = l.detail;
      m === c.id && !u || this.doc.apply(F, { local: false, from: m });
    }), c.addEventListener("scene", (l) => {
      this.doc.replaceAll(l.detail.objects);
    }), c.addEventListener("connected", () => {
      this.doc.size && c.sendScene(this.doc.list(), this.spawns && this.spawns.length ? this.spawns : null);
    });
  }
  ["save"]() {
    return JSON.stringify(this.doc.toJSON(), null, 2);
  }
  ["load"](c) {
    let l = typeof c == "string" ? JSON.parse(c) : c;
    this.doc.replaceAll(Array.isArray(l.objects) ? l.objects : []), this.net && this.net.connected && this.net.sendScene(this.doc.list());
  }
};
function be(c, l) {
  let F = [l, l, l];
  if (!Array.isArray(c)) return F;
  for (let m = 0; m < 3; m++) {
    let u = Number(c[m]);
    Number.isFinite(u) && (F[m] = u);
  }
  return F;
}
function ao(c) {
  switch (c) {
    case "sphere":
      return U(0.5, 28, 18);
    case "cylinder":
      return V(0.5, 1, 24);
    case "plane":
      return Yt(1, 1, 1);
    default:
      return B(1, 1, 1);
  }
}
function La(c) {
  return String(c).split("/").pop().replace(/\.(glb|gltf)$/i, "").slice(0, 48) || "model";
}
function co(c, l, F, m, u) {
  let S = [l, F, m, 1], E = [u[0] * S[0] + u[4] * S[1] + u[8] * S[2] + u[12], u[1] * S[0] + u[5] * S[1] + u[9] * S[2] + u[13], u[2] * S[0] + u[6] * S[1] + u[10] * S[2] + u[14], u[3] * S[0] + u[7] * S[1] + u[11] * S[2] + u[15]];
  return _.set(c, E[0] / E[3], E[1] / E[3], E[2] / E[3]);
}
function Na(F, m, S) {
  let E = uo(S);
  if (!E) return null;
  let A = P.invert(P.create(), S.worldMatrix());
  if (!A) return null;
  let v = _.transformMat4(_.create(), F, A), g = _.transformDir(_.create(), m, A), b = 0, O = 1e9;
  for (let M = 0; M < 3; M++) {
    if (Math.abs(g[M]) < 1e-9) {
      if (v[M] < E.min[M] || v[M] > E.max[M]) return null;
      continue;
    }
    let T = 1 / g[M], x = (E.min[M] - v[M]) * T, y = (E.max[M] - v[M]) * T;
    if (x > y) {
      let w = x;
      x = y, y = w;
    }
    if (x > b && (b = x), y < O && (O = y), b > O) return null;
  }
  return b;
}
function uo(F) {
  if (F._bounds) return F._bounds;
  let m = [1 / 0, 1 / 0, 1 / 0], u = [-1 / 0, -1 / 0, -1 / 0], S = F.worldMatrix(), E = P.invert(P.create(), S), A = _.create();
  for (let v of F.allNodes()) {
    if (!v.mesh) continue;
    let g = P.multiply(P.create(), E, v.worldMatrix()), b = v.mesh.positions;
    for (let O = 0; O < b.length; O += 3) {
      _.transformMat4(A, [b[O], b[O + 1], b[O + 2]], g);
      for (let M = 0; M < 3; M++) A[M] < m[M] && (m[M] = A[M]), A[M] > u[M] && (u[M] = A[M]);
    }
  }
  return Number.isFinite(m[0]) ? (F._bounds = { min: m, max: u }, F._bounds) : null;
}
var ii = (c) => c.width + "|" + JSON.stringify(c.points || []);
function lo(c) {
  return Ke(Array.isArray(c.points) && c.points.length ? c.points : [[0, 0, 0]], Math.max(25e-4, (c.width || 0.03) / 2), 8);
}
var Da = { 0: "walls", 1: "trim", 3: "accents" };
function oi(c) {
  return new N({ colour: c.colour.slice(), alpha: c.alpha, roughness: c.roughness, metallic: c.metallic, emissive: (c.emissive || [0, 0, 0]).slice(), map: c.map, doubleSided: c.doubleSided, castShadow: c.castShadow });
}
function Oa(c, l) {
  if (/#room$/.test(l.src || "")) {
    if (!c._paintParts) {
      let F = [];
      for (let m of [...c.allNodes()]) {
        let u = /:(\d+)$/.exec(m.name || ""), S = u && Da[u[1]];
        if (!(!S || !m.mesh || !m.material) && (m.material = oi(m.material), m._paintKey = S, m._paintBase = m.material.colour.slice(), F.push(m), S === "trim")) {
          let E = Ua(m);
          E && F.push(E);
        }
      }
      if (!F.length) return;
      c._paintParts = F;
    }
    for (let h of c._paintParts) h.material.colour = l.paint && l.paint[h._paintKey] ? l.paint[h._paintKey].slice() : h._paintBase.slice();
  }
}
function Ua(F) {
  let S = F.worldMatrix(), E = F.mesh.positions, A = F.mesh.indices;
  if (!A) return null;
  let b = (y) => [S[0] * E[y] + S[4] * E[y + 1] + S[8] * E[y + 2] + S[12], S[1] * E[y] + S[5] * E[y + 1] + S[9] * E[y + 2] + S[13], S[2] * E[y] + S[6] * E[y + 1] + S[10] * E[y + 2] + S[14]], O = [], M = [];
  for (let y = 0; y < A.length; y += 3) {
    let w = b(A[y] * 3), q = b(A[y + 1] * 3), L = b(A[y + 2] * 3), I = [q[0] - w[0], q[1] - w[1], q[2] - w[2]], z = [L[0] - w[0], L[1] - w[1], L[2] - w[2]], K = I[2] * z[0] - I[0] * z[2], H = Math.hypot(I[1] * z[2] - I[2] * z[1], K, I[0] * z[1] - I[1] * z[0]) || 1, d0 = (w[1] + q[1] + L[1]) / 3 > 2.5;
    (K / H < -0.7 && d0 ? M : O).push(A[y], A[y + 1], A[y + 2]);
  }
  if (!M.length) return null;
  let T = A.constructor;
  F.mesh = { ...F.mesh, indices: T.from(O) };
  let x = new R(F.name + ":ceiling");
  return x.mesh = { positions: F.mesh.positions, normals: F.mesh.normals, uvs: F.mesh.uvs, indices: T.from(M) }, x.material = oi(F.material), x._paintKey = "ceiling", x._paintBase = x.material.colour.slice(), F.parent.add(x), x;
}
function Ba(c) {
  let l = /^light(?::(\d+(?:\.\d+)?))?(?::(\d+(?:\.\d+)?))?$/.exec(c && c.tag || "");
  if (!l) return null;
  let F = Array.isArray(c.emissive) && c.emissive.some((u) => u > 0) ? c.emissive : c.colour || [1, 1, 1], m = Math.max(...F, 1e-3);
  return { colour: F.map((u) => u / m), range: Math.min(Math.max(Number(l[1]) || 7, 1), 30), intensity: Math.min(Math.max(l[2] === void 0 ? 6 : Number(l[2]), 0), 60) };
}
function za(F, m) {
  if (/#room$/.test(m.src || "")) return;
  let S = Array.isArray(m.tint) && m.tint.length === 3 ? m.tint : null;
  if (!S && !F._tinted) return;
  let E = [];
  for (let O of F.allNodes()) O.mesh && O.material && !O.mirror && E.push(O);
  if (!E.length) return;
  for (let M of E) M._tintBase || (M._tintBase = M.material);
  if (!S) {
    for (let T of E) T.material = T._tintBase;
    F._tinted = null;
    return;
  }
  let A = S.join(",");
  if (F._tinted === A && E.every((x) => x.material !== x._tintBase)) return;
  let v = (x) => 0.2126 * x[0] + 0.7152 * x[1] + 0.0722 * x[2], g = E.filter((x) => !x._tintBase.map), b = Math.max(1e-3, ...g.map((x) => v(x._tintBase.colour || [1, 1, 1])));
  for (let x of E) {
    let f = x._tintBase, y = oi(f);
    if (f.map) y.colour = S.slice();
    else {
      let w = Math.min(1, Math.max(0.35, v(f.colour || [1, 1, 1]) / b));
      y.colour = S.map((q) => q * w);
    }
    x.material = y;
  }
  F._tinted = A;
}
function ho(c, l) {
  let F = (m) => {
    m.material && (m.material.castShadow = l.castShadow !== false, l.opacity !== void 0 && (m.material.alpha = l.opacity));
    for (let u of m.children || []) F(u);
  };
  F(c);
}
var Ft = typeof navigator < "u" && /Mac|iPhone|iPad/.test(navigator.platform || navigator.userAgent || ""), Ga = Ft ? "\u2318" : "Ctrl", $a = Ft ? "\u21E7" : "Shift", Va = Ft ? "\u2325" : "Alt";
function fo(c) {
  if (!c) return null;
  let l = String(c).split("+").map((S) => S.trim()).filter(Boolean), F = l.pop() || "", m = { mod: l.some((S) => /^(mod|ctrl|cmd|meta)$/i.test(S)), shift: l.some((S) => /^shift$/i.test(S)), alt: l.some((S) => /^alt|option$/i.test(S)), code: Ha(F) }, u = [m.mod ? Ga : "", m.alt ? Va : "", m.shift ? $a : "", ja(F)].filter(Boolean).join(Ft ? "" : "+");
  return { ...m, shown: u };
}
function Ha(c) {
  return /^[a-z]$/i.test(c) ? "Key" + c.toUpperCase() : /^[0-9]$/.test(c) ? "Digit" + c : /^F([1-9]|1[0-2])$/.test(c) ? c : { Delete: "Delete", Backspace: "Backspace", Escape: "Escape", Space: "Space", Enter: "Enter", Tab: "Tab", "/": "Slash", ",": "Comma", "`": "Backquote", "=": "Equal", "-": "Minus", "[": "BracketLeft", "]": "BracketRight", ".": "Period", End: "End", Home: "Home", PageUp: "PageUp", PageDown: "PageDown", Left: "ArrowLeft", Right: "ArrowRight", Up: "ArrowUp", Down: "ArrowDown" }[c] || c;
}
function ja(c) {
  return { Delete: Ft ? "\u2326" : "Del", Backspace: "\u232B", Escape: "Esc", Space: "Space", Enter: "\u21A9", Tab: "\u21E5", End: "End", Home: "Home", ArrowLeft: "\u2190", ArrowRight: "\u2192", ArrowUp: "\u2191", ArrowDown: "\u2193" }[c] || c.toUpperCase();
}
function po(c, l) {
  if (!c) return false;
  let F = Ft ? l.metaKey : l.ctrlKey, m = Ft ? l.ctrlKey : l.metaKey;
  return c.code === l.code && !!c.mod == !!F && !m && !!c.shift == !!l.shiftKey && !!c.alt == !!l.altKey;
}
var ri = class extends EventTarget {
  constructor() {
    super(), this.all = /* @__PURE__ */ new Map(), this.order = [];
  }
  ["add"]({ id: F, label: m, menu: S = "", sub: E = "", group: A = 0, accel: v = "", when: g = null, run: b, checked: O = null, hint: M = "" }) {
    if (!F || typeof b != "function") throw new Error("a command needs an id and something to run");
    let T = { id: F, label: m, menu: S, group: A, hint: M, sub: E, accel: fo(v), when: g, run: b, checked: O };
    return this.all.set(F, T), this.order.push(F), T;
  }
  ["addAll"](c) {
    for (let l of c) this.add(l);
    return this;
  }
  ["get"](c) {
    return this.all.get(c);
  }
  ["enabled"](c) {
    let l = typeof c == "string" ? this.get(c) : c;
    if (!l) return false;
    try {
      return l.when ? !!l.when() : true;
    } catch {
      return false;
    }
  }
  ["run"](c) {
    let l = this.get(c);
    if (!l || !this.enabled(l)) return false;
    try {
      l.run();
    } catch (F) {
      return this.dispatchEvent(new CustomEvent("failed", { detail: { id: c, error: F } })), true;
    }
    return this.dispatchEvent(new CustomEvent("ran", { detail: { id: c } })), true;
  }
  ["menus"]() {
    let c = [];
    for (let l of this.order) {
      let F = this.all.get(l);
      if (!F.menu) continue;
      let m = c.find((u) => u.name === F.menu);
      m || c.push(m = { name: F.menu, items: [] }), m.items.push(F);
    }
    for (let u of c) u.items.sort((S, E) => S.group - E.group);
    return c;
  }
  ["handleKey"](c) {
    for (let l of this.order) {
      let F = this.all.get(l);
      if (!(!F.accel || !po(F.accel, c))) return c.preventDefault(), this.run(l), true;
    }
    return false;
  }
  ["search"](l) {
    let F = String(l || "").trim().toLowerCase(), m = [];
    for (let u of this.order) {
      let S = this.all.get(u), E = (S.menu + " " + S.sub + " " + S.label + " " + S.hint).toLowerCase();
      if (!F) {
        m.push([0, S]);
        continue;
      }
      if (E.indexOf(F) < 0) continue;
      let h = S.label.toLowerCase().indexOf(F), A = h === 0 ? 0 : h > 0 ? 1 : 2;
      m.push([A * 1e5 + Math.max(h, 0) * 1e3 + S.label.length, S]);
    }
    return m.sort((v, g) => v[0] - g[0]), m.map(([, v]) => v);
  }
}, ai = class {
  constructor(c, l) {
    this.host = c, this.commands = l, this.open = null, this.pop = document.createElement("div"), this.pop.className = "menupop", this.pop.hidden = true, document.body.appendChild(this.pop), this.titles = /* @__PURE__ */ new Map(), document.addEventListener("pointerdown", (F) => {
      this.pop.contains(F.target) || this.host.contains(F.target) || this._fly && this._fly.pop.contains(F.target) || this.close();
    }), window.addEventListener("blur", () => this.close()), document.addEventListener("keydown", (F) => {
      F.code === "Escape" && this.open && (this.close(), F.stopPropagation());
    }), this.build();
  }
  ["build"]() {
    this.host.textContent = "", this.titles.clear();
    for (let c of this.commands.menus()) {
      let l = document.createElement("button");
      l.type = "button", l.className = "menutitle", l.textContent = c.name, l.addEventListener("pointerdown", (F) => {
        F.preventDefault(), this.open === c.name ? this.close() : this.show(c.name, l);
      }), l.addEventListener("pointerenter", () => {
        this.open && this.open !== c.name && this.show(c.name, l);
      }), this.host.appendChild(l), this.titles.set(c.name, l);
    }
  }
  ["show"](c, l) {
    let F = this.commands.menus().find((S) => S.name === c);
    if (!F) return;
    this.open = c;
    for (let [S, E] of this.titles) E.classList.toggle("on", S === c);
    this.pop.textContent = "", this.closeFlyout(), mo(this.pop, F.items, (h) => this.item(h), (h, A, v) => this.flyout(h, A, v));
    let m = l.getBoundingClientRect();
    this.pop.hidden = false, this.pop.style.left = Math.round(m.left) + "px", this.pop.style.top = Math.round(m.bottom + 2) + "px";
    let u = this.pop.getBoundingClientRect();
    u.right > window.innerWidth - 8 && (this.pop.style.left = Math.max(8, window.innerWidth - u.width - 8) + "px");
  }
  ["item"](c) {
    let l = document.createElement("button");
    l.type = "button", l.className = "menuitem";
    let F = this.commands.enabled(c);
    l.disabled = !F;
    let m = document.createElement("i");
    m.className = "menutick";
    let u = c.checked ? !!go(c.checked) : null;
    m.textContent = u ? "\u2713" : "", l.appendChild(m);
    let S = document.createElement("span");
    S.className = "menulabel", S.textContent = c.label, l.appendChild(S);
    let E = document.createElement("span");
    return E.className = "menukey", E.textContent = c.accel ? c.accel.shown : "", l.appendChild(E), F && l.addEventListener("click", () => {
      this.close(), this.commands.run(c.id);
    }), l.addEventListener("pointerenter", () => {
      this._fly && !this._fly.pop.contains(l) && this._leaveSoon();
    }), l;
  }
  ["flyout"](c, l, F) {
    let m = () => {
      if (this._fly && this._fly.row === F) return;
      this.closeFlyout();
      let u = document.createElement("div");
      u.className = "menupop menufly", mo(u, l, (h) => this.item(h)), document.body.appendChild(u);
      let S = F.getBoundingClientRect();
      u.style.top = Math.round(S.top - 5) + "px", u.style.left = Math.round(S.right + 2) + "px";
      let E = u.getBoundingClientRect();
      E.right > window.innerWidth - 8 && (u.style.left = Math.round(S.left - E.width - 2) + "px"), E.bottom > window.innerHeight - 8 && (u.style.top = Math.max(8, Math.round(window.innerHeight - E.height - 8)) + "px"), F.classList.add("on"), u.addEventListener("pointerenter", () => clearTimeout(this._flyTimer)), u.addEventListener("pointerleave", () => this._leaveSoon()), this._fly = { pop: u, row: F };
    };
    F.addEventListener("pointerenter", () => {
      clearTimeout(this._flyTimer), m();
    }), F.addEventListener("pointerleave", () => this._leaveSoon()), F.addEventListener("click", m);
  }
  ["_leaveSoon"]() {
    clearTimeout(this._flyTimer), this._flyTimer = setTimeout(() => this.closeFlyout(), 220);
  }
  ["closeFlyout"]() {
    clearTimeout(this._flyTimer), this._fly && (this._fly.row.classList.remove("on"), this._fly.pop.remove(), this._fly = null);
  }
  ["close"]() {
    this.open = null, this.pop.hidden = true, this.closeFlyout();
    for (let c of this.titles.values()) c.classList.remove("on");
  }
};
function mo(l, F, m, u = null) {
  let S = F.length ? F[0].group : 0, E = /* @__PURE__ */ new Set();
  for (let h of F) {
    if (h.group !== S) {
      let A = document.createElement("div");
      A.className = "menurule", l.appendChild(A), S = h.group;
    }
    if (h.sub && u) {
      if (E.has(h.sub)) continue;
      E.add(h.sub);
      let v = F.filter((b) => b.sub === h.sub), g = document.createElement("button");
      g.type = "button", g.className = "menuitem menusub", g.appendChild(Object.assign(document.createElement("i"), { className: "menutick" })), g.appendChild(Object.assign(document.createElement("span"), { className: "menulabel", textContent: h.sub })), g.appendChild(Object.assign(document.createElement("span"), { className: "menukey", textContent: "\u203A" })), l.appendChild(g), u(h.sub, v, g);
      continue;
    }
    l.appendChild(m(h));
  }
}
function Xa(F, S, E, { align: A = "left" } = {}) {
  let O = document.createElement("div");
  O.className = "menupop", document.body.appendChild(O);
  let M = null, T = S.includes("-");
  for (let H of S) {
    if (H === "-") {
      let d6 = document.createElement("div");
      d6.className = "menurule", O.appendChild(d6);
      continue;
    }
    if (typeof H == "object" && H.note) {
      let d7 = document.createElement("div");
      d7.className = "menunote", d7.textContent = H.note, O.appendChild(d7);
      continue;
    }
    let d0 = F.get(typeof H == "string" ? H : H.id);
    if (!d0) continue;
    if (!T && M !== null && d0.group !== M) {
      let d8 = document.createElement("div");
      d8.className = "menurule", O.appendChild(d8);
    }
    M = d0.group;
    let d1 = document.createElement("button");
    d1.type = "button", d1.className = "menuitem";
    let d2 = F.enabled(d0);
    d1.disabled = !d2;
    let d3 = document.createElement("i");
    d3.className = "menutick", d3.textContent = d0.checked && go(d0.checked) ? "\u2713" : "", d1.appendChild(d3);
    let d4 = document.createElement("span");
    d4.className = "menulabel", d4.textContent = typeof H == "object" && H.label || d0.label, d1.appendChild(d4);
    let d5 = document.createElement("span");
    d5.className = "menukey", d5.textContent = d0.accel ? d0.accel.shown : "", d1.appendChild(d5), d2 && d1.addEventListener("click", () => {
      K(), F.run(d0.id);
    }), O.appendChild(d1);
  }
  let x = E.getBoundingClientRect ? E.getBoundingClientRect() : { left: E.x, right: E.x, top: E.y, bottom: E.y - 4 };
  O.style.top = Math.round(x.bottom + 4) + "px";
  let q = O.getBoundingClientRect(), L = A === "right" ? x.right - q.width : x.left;
  O.style.left = Math.round(Math.min(Math.max(8, L), window.innerWidth - q.width - 8)) + "px", x.bottom + 4 + q.height > window.innerHeight - 8 && (O.style.top = Math.max(8, Math.round(x.top - q.height - 4)) + "px");
  let I = (d9) => {
    O.contains(d9.target) || K();
  }, z = (d9) => {
    d9.code === "Escape" && (K(), d9.stopPropagation());
  };
  setTimeout(() => {
    document.addEventListener("pointerdown", I), document.addEventListener("keydown", z);
  }, 0);
  function K() {
    document.removeEventListener("pointerdown", I), document.removeEventListener("keydown", z), O.remove();
  }
  return K;
}
var ci = class {
  constructor(c) {
    this.commands = c, this.index = 0, this.shown = [], this.el = document.createElement("div"), this.el.className = "palette", this.el.hidden = true, this.input = document.createElement("input"), this.input.type = "text", this.input.placeholder = "What do you want to do?", this.input.spellcheck = false, this.input.setAttribute("aria-label", "Search commands"), this.list = document.createElement("div"), this.list.className = "palettelist", this.el.append(this.input, this.list), document.body.appendChild(this.el), this.input.addEventListener("input", () => this.refresh()), this.input.addEventListener("keydown", (l) => this.key(l)), this.el.addEventListener("pointerdown", (l) => l.stopPropagation()), document.addEventListener("pointerdown", (l) => {
      !this.el.hidden && !this.el.contains(l.target) && this.close();
    });
  }
  ["toggle"]() {
    this.el.hidden ? this.show() : this.close();
  }
  ["show"]() {
    this.el.hidden = false, this.input.value = "", this.refresh(), this.input.focus();
  }
  ["close"]() {
    this.el.hidden = true, this.input.blur();
  }
  ["refresh"]() {
    this.shown = this.commands.search(this.input.value), this.index = Math.max(0, this.shown.findIndex((c) => this.commands.enabled(c))), this.draw();
  }
  ["draw"]() {
    if (this.list.textContent = "", !this.shown.length) {
      let c = document.createElement("div");
      c.className = "paletteempty", c.textContent = "Nothing matches that.", this.list.appendChild(c);
      return;
    }
    this.shown.slice(0, 40).forEach((l, F) => {
      let m = document.createElement("button");
      m.type = "button";
      let u = this.commands.enabled(l);
      if (m.className = "paletterow" + (F === this.index ? " on" : "") + (u ? "" : " off"), m.disabled = !u, l.menu) {
        let h = document.createElement("span");
        h.className = "palettewhere", h.textContent = l.menu, m.appendChild(h);
      }
      let S = document.createElement("span");
      S.className = "palettelabel", S.textContent = l.label, m.appendChild(S);
      let E = document.createElement("span");
      E.className = "menukey", E.textContent = l.accel ? l.accel.shown : "", m.appendChild(E), u && m.addEventListener("click", () => {
        this.close(), this.commands.run(l.id);
      }), m.addEventListener("pointerenter", () => {
        this.index = F, this.mark();
      }), this.list.appendChild(m);
    });
  }
  ["mark"]() {
    [...this.list.children].forEach((c, l) => c.classList.toggle("on", l === this.index));
  }
  ["key"](c) {
    if (c.code === "Escape") {
      this.close(), c.stopPropagation();
      return;
    }
    if (c.code === "ArrowDown" || c.code === "ArrowUp") {
      let l = c.code === "ArrowDown" ? 1 : -1, F = Math.min(this.shown.length, 40);
      F && (this.index = (this.index + l + F) % F), this.mark(), this.list.children[this.index]?.scrollIntoView({ block: "nearest" }), c.preventDefault();
      return;
    }
    if (c.code === "Enter") {
      let m = this.shown[this.index];
      if (c.preventDefault(), !m || !this.commands.enabled(m)) return;
      this.close(), this.commands.run(m.id);
    }
  }
};
function go(c) {
  try {
    return c();
  } catch {
    return false;
  }
}
var hi = class extends EventTarget {
  constructor(c, { limit: l = 500 } = {}) {
    super(), this.host = c, this.limit = l, this.rows = [], this.filter = { log: true, warn: true, error: true }, this.counts = { log: 0, warn: 0, error: 0 }, this.collapse = true, this._pinned = true;
  }
  ["listen"](c = globalThis) {
    if (this._listening) return this;
    this._listening = true;
    let l = {};
    for (let F of ["log", "info", "warn", "error"]) l[F] = c.console[F]?.bind(c.console) || (() => {
    }), c.console[F] = (...m) => {
      l[F](...m), this.push(F === "info" ? "log" : F, m.map(li).join(" "));
    };
    return c.addEventListener?.("error", (m) => {
      this.push("error", m.message ? m.message + "  " + qa(m) : "Could not load " + li(m.target && (m.target.src || m.target.href)));
    }), c.addEventListener?.("unhandledrejection", (m) => {
      this.push("error", "Unhandled: " + li(m.reason && (m.reason.message || m.reason)));
    }), this;
  }
  ["push"](c, l) {
    let F = /* @__PURE__ */ new Date(), m = this.rows[this.rows.length - 1];
    if (this.collapse && m && m.level === c && m.message === l) {
      m.count++, m.at = F, this.counts[c]++, this.draw(), this.dispatchEvent(new CustomEvent("logged", { detail: { level: c, message: l } }));
      return;
    }
    this.rows.push({ level: c, message: String(l), at: F, count: 1 }), this.rows.length > this.limit && this.rows.shift(), this.counts[c] = (this.counts[c] || 0) + 1, this.draw(), this.dispatchEvent(new CustomEvent("logged", { detail: { level: c, message: l } }));
  }
  ["clear"]() {
    this.rows.length = 0, this.counts = { log: 0, warn: 0, error: 0 }, this.draw(), this.dispatchEvent(new CustomEvent("cleared"));
  }
  ["show"](c, l) {
    this.filter[c] = !!l, this.draw();
  }
  get ["tally"]() {
    return { ...this.counts };
  }
  ["draw"]() {
    if (!this.host) return;
    let c = this.host.scrollHeight - this.host.scrollTop - this.host.clientHeight < 40;
    this.host.textContent = "";
    let l = this.rows.filter((F) => this.filter[F.level]);
    if (!l.length) {
      let F = document.createElement("div");
      F.className = "empty", F.textContent = this.rows.length ? "Nothing of that kind." : "Nothing has happened yet.", this.host.appendChild(F);
      return;
    }
    for (let m of l) {
      let u = document.createElement("div");
      u.className = "logrow " + m.level;
      let S = document.createElement("span");
      if (S.className = "logtime", S.textContent = Wa(m.at), u.appendChild(S), m.count > 1) {
        let h = document.createElement("span");
        h.className = "logcount", h.textContent = String(m.count), u.appendChild(h);
      }
      let E = document.createElement("span");
      E.className = "logtext", E.textContent = m.message, u.appendChild(E), this.host.appendChild(u);
    }
    c && (this.host.scrollTop = this.host.scrollHeight);
  }
};
function Wa(c) {
  return String(c.getHours()).padStart(2, "0") + ":" + String(c.getMinutes()).padStart(2, "0") + ":" + String(c.getSeconds()).padStart(2, "0");
}
function qa(c) {
  return c.filename ? "(" + String(c.filename).split("/").pop() + ":" + (c.lineno || 0) + ")" : "";
}
function li(c) {
  if (typeof c == "string") return c;
  if (c instanceof Error) return c.name + ": " + c.message;
  if (c === null) return "null";
  if (c === void 0) return "undefined";
  if (typeof c == "object") try {
    let l = JSON.stringify(c);
    return l && l.length > 300 ? l.slice(0, 300) + "..." : l || String(c);
  } catch {
    return "[object]";
  }
  return String(c);
}
var vo = "rz.layout.v1", wo = { left: 170, right: 230, dock: 90 }, yo = { left: 520, right: 620, dock: 520 }, _o = (c, l, F) => Math.min(Math.max(c, l), F), fi = class extends EventTarget {
  constructor(c, l = {}) {
    super(), this.shell = c, this.sizes = { left: 236, right: 300, dock: 172, ...l, ...Ka() }, this.collapsed = { left: false, right: false, dock: false }, this.apply();
  }
  ["apply"]() {
    let { left: c, right: l, dock: F } = this.visible();
    this.shell.style.gridTemplateColumns = c + "px 1fr " + l + "px", this.shell.style.gridTemplateRows = "30px 38px 1fr " + F + "px 22px";
    for (let m of ["left", "right", "dock"]) this.shell.classList.toggle("no-" + m, this.collapsed[m]);
    this.dispatchEvent(new CustomEvent("changed", { detail: this.visible() }));
  }
  ["visible"]() {
    return { left: this.collapsed.left ? 0 : this.sizes.left, right: this.collapsed.right ? 0 : this.sizes.right, dock: this.collapsed.dock ? 0 : this.sizes.dock };
  }
  ["set"](c, l) {
    c in this.sizes && (this.sizes[c] = Math.round(_o(l, wo[c], yo[c])), this.apply(), ui(this.sizes));
  }
  ["toggle"](c, l) {
    c in this.collapsed && (this.collapsed[c] = l === void 0 ? !this.collapsed[c] : !!l, this.apply());
  }
  ["reset"]() {
    this.sizes = { left: 236, right: 300, dock: 172 }, this.collapsed = { left: false, right: false, dock: false }, this.apply(), ui(this.sizes);
  }
  ["handle"](c, l, F = 1) {
    c && (c.addEventListener("pointerdown", (m) => {
      m.preventDefault();
      let u = l === "dock" ? m.clientY : m.clientX, S = this.sizes[l];
      this.toggle(l, false), c.setPointerCapture(m.pointerId), c.classList.add("dragging"), document.body.classList.add("resizing");
      let E = (A) => {
        let v = l === "dock" ? A.clientY : A.clientX;
        this.set(l, S + (v - u) * F);
      }, h = (A) => {
        c.removeEventListener("pointermove", E), c.removeEventListener("pointerup", h), c.removeEventListener("pointercancel", h), c.hasPointerCapture?.(A.pointerId) && c.releasePointerCapture(A.pointerId), c.classList.remove("dragging"), document.body.classList.remove("resizing");
      };
      c.addEventListener("pointermove", E), c.addEventListener("pointerup", h), c.addEventListener("pointercancel", h);
    }), c.addEventListener("dblclick", () => {
      this.sizes[l] = { left: 236, right: 300, dock: 172 }[l], this.apply(), ui(this.sizes);
    }));
  }
};
function Ka() {
  try {
    let c = JSON.parse(localStorage.getItem(vo) || "{}"), l = {};
    for (let F of ["left", "right", "dock"]) {
      let m = Number(c[F]);
      Number.isFinite(m) && (l[F] = _o(m, wo[F], yo[F]));
    }
    return l;
  } catch {
    return {};
  }
}
function ui(c) {
  try {
    localStorage.setItem(vo, JSON.stringify(c));
  } catch {
  }
}
var pi = [{ name: "amber", hex: "#ffb020", rgb: [1, 0.69, 0.13] }, { name: "mint", hex: "#39d98a", rgb: [0.22, 0.85, 0.54] }, { name: "rose", hex: "#ff6b9d", rgb: [1, 0.42, 0.62] }, { name: "violet", hex: "#b388ff", rgb: [0.7, 0.53, 1] }, { name: "cyan", hex: "#4dd0e1", rgb: [0.3, 0.82, 0.88] }, { name: "coral", hex: "#ff8a5c", rgb: [1, 0.54, 0.36] }];
function mi(c) {
  let l = Math.abs(Number(c) || 0);
  return pi[l % pi.length];
}
var xo = 2600, gi = class extends EventTarget {
  constructor({ editor: c, net: l = null }) {
    if (super(), this.editor = c, this.net = l, this.touching = /* @__PURE__ */ new Map(), this.root = new R("presence"), this._cages = /* @__PURE__ */ new Map(), l) {
      l.addEventListener("edit", (F) => {
        let { op: m, from: u } = F.detail;
        if (!u || u === l.id) return;
        let S = m && (m.id || m.o && m.o.id);
        S && this.saw(u, S);
      }), l.addEventListener("left", (F) => this.gone(F.detail.id));
      for (let F of ["joined", "left", "connected"]) l.addEventListener(F, () => this.dispatchEvent(new CustomEvent("changed")));
    }
  }
  ["saw"](c, l) {
    let F = this.net && this.net.players.get(c);
    this.touching.set(l, { peer: c, name: F && F.name || "somebody", colour: mi(c), at: Date.now() }), this.dispatchEvent(new CustomEvent("changed"));
  }
  ["gone"](c) {
    for (let [l, F] of this.touching) F.peer === c && this.touching.delete(l);
    this.dispatchEvent(new CustomEvent("changed"));
  }
  ["on"](c) {
    let l = this.touching.get(c);
    return l ? Date.now() - l.at > xo ? (this.touching.delete(c), null) : l : null;
  }
  ["people"]() {
    return this.net ? [...this.net.players.values()].map((c) => ({ id: c.id, name: c.name, colour: mi(c.id), on: [...this.touching.entries()].filter(([, l]) => l.peer === c.id && Date.now() - l.at <= xo).map(([l]) => l) })) : [];
  }
  ["update"]() {
    let c = /* @__PURE__ */ new Set();
    for (let [l] of this.touching) {
      let F = this.on(l);
      if (!F) continue;
      let m = this.editor.doc.get(l);
      if (!m) continue;
      let u = this.editor._sizeOf(m);
      if (!u) continue;
      c.add(l);
      let S = [0, 1, 2].map((h) => Math.max(u.extent[h], 0.1) * 1.06), E = this._cages.get(l);
      (!E || S.some((A, v) => Math.abs(A - E.span[v]) > 0.02)) && (E && (this.root.remove(E), E.dispose?.()), E = new R("cage:" + l), E.mesh = Ja(S[0], S[1], S[2]), E.span = S, E.material = new N({ colour: [0, 0, 0], emissive: F.colour.rgb, roughness: 1, castShadow: false }), this.root.add(E), this._cages.set(l, E)), E.material.emissive = F.colour.rgb, E.setPosition(u.centre[0], u.centre[1], u.centre[2]);
    }
    for (let [h, A] of this._cages) c.has(h) || (A.dispose?.(), this.root.remove?.(A), this._cages.delete(h));
  }
};
function Ja(F, m, u) {
  let S = Math.min(Math.max(Math.min(F, m, u) * 0.035, 0.012), 0.06), E = F / 2, h = m / 2, A = u / 2, v = [];
  for (let g of [-h, h]) for (let b of [-A, A]) v.push(di(B(F, S, S), 0, g, b));
  for (let O of [-E, E]) for (let M of [-A, A]) v.push(di(B(S, m, S), O, 0, M));
  for (let T of [-E, E]) for (let x of [-h, h]) v.push(di(B(S, S, u), T, x, 0));
  return Pt(v);
}
function di(c, l, F, m) {
  let u = new Float32Array(c.positions);
  for (let S = 0; S < u.length; S += 3) u[S] += l, u[S + 1] += F, u[S + 2] += m;
  return { ...c, positions: u };
}
export {
  $r as A,
  Ls as B,
  Ns as C,
  rt as D,
  zs as E,
  qs as F,
  Kt as G,
  _e as H,
  to as I,
  vt as J,
  Xe as K,
  ni as L,
  ri as M,
  ai as N,
  Xa as O,
  ci as P,
  hi as Q,
  fi as R,
  gi as S,
  Ee as a,
  X as b,
  P as c,
  wi as d,
  R as e,
  B as f,
  Yt as g,
  U as h,
  V as i,
  bt as j,
  Z as k,
  Ke as l,
  W as m,
  Pt as n,
  ht as o,
  N as p,
  $t as q,
  is as r,
  lr as s,
  ds as t,
  ps as u,
  Nt as v,
  ks as w,
  G as x,
  D as y,
  pl as z
};
