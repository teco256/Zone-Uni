import { p as F } from "./c-USQKEFSE.js";
import * as m from "three";
import { Avatar as u } from "/js/modules/avatar.js";
var R = { skin: "light", shirtColor: "zoneblue", shirt: "tee", hat: "cap", face: "none", expression: "default", hair: "none", hairColor: "brown" }, E = null;
function C() {
  return E || (E = (async () => {
    let W = Object.create(u.prototype);
    Object.assign(W, { canvas: null, interactive: false, ready: false, disposed: false, t: 0 }), W.outfit = { ...R }, W.scene = new m.Scene(), W.root = new m.Group(), W.scene.add(W.root), W.groups = { head: new m.Group(), torso: new m.Group(), lhand: new m.Group(), rhand: new m.Group() };
    for (let S of Object.values(W.groups)) W.root.add(S);
    for (let h of ["hairSlot", "hatSlot", "faceSlot", "exprSlot", "chestSlot"]) W[h] = new m.Group();
    return W.frame = () => {
    }, W.resize = () => {
    }, await W.load("/models", "/img/logo.png"), W;
  })(), E.catch(() => {
    E = null;
  })), E;
}
var v = (W) => {
  let S = W ? W.getHex() : 16777215;
  return [(S >> 16 & 255) / 255, (S >> 8 & 255) / 255, (S & 255) / 255];
}, A = /* @__PURE__ */ new Map(), H = /* @__PURE__ */ new WeakMap(), G = 1;
function z(W) {
  let S = W.map && W.map.image ? W.map.image : null;
  S && !H.has(S) && H.set(S, G++);
  let h = W.side === m.DoubleSide, Z = !!(W.transparent && S), g = (W.color ? W.color.getHex() : "w") + "|" + (S ? H.get(S) : 0) + "|" + h + "|" + Z + "|" + W.opacity;
  return A.has(g) || A.set(g, new F({ colour: v(W.color), roughness: 0.8, map: S, doubleSided: h, alpha: Z ? Math.min(W.opacity ?? 1, 0.999) : W.transparent ? W.opacity ?? 1 : 1, alphaCutoff: Z ? 0.02 : 1e-3, castShadow: !Z })), A.get(g);
}
function P(W, S, Z, b) {
  let J = { p: [], n: [], u: [] }, O = (N) => ({ p: [W[N * 3], W[N * 3 + 1], W[N * 3 + 2]], n: [S[N * 3], S[N * 3 + 1], S[N * 3 + 2]], u: Z ? [Z[N * 2], Z[N * 2 + 1]] : [0, 0] }), M = (N, X, q) => ({ p: N.p.map((L, B) => L + (X.p[B] - L) * q), n: N.n.map((L, B) => L + (X.n[B] - L) * q), u: N.u.map((L, B) => L + (X.u[B] - L) * q) }), x = (N, X) => N.normal.x * X.p[0] + N.normal.y * X.p[1] + N.normal.z * X.p[2] + N.constant;
  for (let N = 0; N < W.length / 9; N++) {
    let X = [O(N * 3), O(N * 3 + 1), O(N * 3 + 2)];
    for (let q of b) {
      let L = [];
      for (let B = 0; B < X.length; B++) {
        let V = X[B], Y = X[(B + 1) % X.length], K = x(q, V), Q = x(q, Y);
        K >= 0 && L.push(V), K >= 0 != Q >= 0 && L.push(M(V, Y, K / (K - Q)));
      }
      if (X = L, X.length < 3) break;
    }
    for (let d0 = 1; d0 + 1 < X.length; d0++) for (let d1 of [X[0], X[d0], X[d0 + 1]]) J.p.push(...d1.p), J.n.push(...d1.n), J.u.push(...d1.u);
  }
  return J;
}
function $(W, S, h) {
  let Z = W.nodes[h];
  if (!Z) return [];
  W.root.updateMatrixWorld(true);
  let g = Z.matrixWorld.clone().invert(), b = new m.Box3().setFromObject(W.meshes[h]).getCenter(new m.Vector3()).applyMatrix4(g), e = [];
  for (let J of S) J.traverse((N) => {
    if (!N.isMesh || !N.visible || !N.geometry || !N.geometry.attributes.position) return;
    let X = Array.isArray(N.material) ? N.material[0] : N.material;
    if (!X || X.visible === false) return;
    let q = N.geometry.index ? N.geometry.toNonIndexed() : N.geometry.clone();
    q.applyMatrix4(new m.Matrix4().multiplyMatrices(g, N.matrixWorld)), q.attributes.normal || q.computeVertexNormals();
    let L = Array.from(q.attributes.position.array), B = Array.from(q.attributes.normal.array), V = q.attributes.uv ? Array.from(q.attributes.uv.array) : new Array(L.length / 3 * 2).fill(0);
    if (q.dispose(), X.clippingPlanes && X.clippingPlanes.length) {
      let d2 = X.clippingPlanes.map((d4) => d4.clone().applyMatrix4(g)), d3 = P(L, B, V, d2);
      if (L = d3.p, B = d3.n, V = d3.u, !L.length) return;
    }
    let Y = X.polygonOffset ? 15e-4 : 0, K = L.length / 3, Q = new Float32Array(L.length), d0 = new Float32Array(B.length);
    for (let d4 = 0; d4 < K; d4++) {
      let d5 = L[d4 * 3] + B[d4 * 3] * Y, d6 = L[d4 * 3 + 1] + B[d4 * 3 + 1] * Y, d7 = L[d4 * 3 + 2] + B[d4 * 3 + 2] * Y;
      d5 = 2 * b.x - d5, d7 = 2 * b.z - d7, Q.set([d5, d6, d7], d4 * 3), d0.set([-B[d4 * 3], B[d4 * 3 + 1], -B[d4 * 3 + 2]], d4 * 3);
    }
    let d1 = new Uint32Array(K);
    for (let d8 = 0; d8 < K; d8++) d1[d8] = d8;
    e.push({ mesh: { positions: Q, normals: d0, uvs: new Float32Array(V), indices: d1 }, material: z(X) });
  });
  return e;
}
var T = /* @__PURE__ */ new Map();
async function k(W) {
  let S = { ...R, ...W || {} }, h = JSON.stringify(S);
  if (T.has(h)) return T.get(h);
  let Z = await C();
  Z.outfit = { ...R }, Z.apply(S);
  let g = { skin: v(Z.meshes.head && Z.meshes.head.material.color), shirt: v(Z.meshes.torso && Z.meshes.torso.material.color), head: $(Z, [Z.hairSlot, Z.hatSlot, Z.faceSlot, Z.exprSlot], "head"), torso: $(Z, [Z.chestSlot], "torso") };
  return T.set(h, g), g;
}
async function U(W) {
  let S = await fetch("/api/game/outfits?names=" + encodeURIComponent(W.join(",")), { credentials: "same-origin", headers: { Accept: "application/json" } });
  return S.ok ? (await S.json()).outfits || {} : {};
}
function D({ game: W, net: S, myName: h = "" }) {
  let Z = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), J = (X) => X + "|" + JSON.stringify(b.get(X) || null), O = async (X) => {
    let q = X.filter((L) => !b.has(L));
    if (q.length) {
      let L = {};
      try {
        L = await U(q);
      } catch {
        L = {};
      }
      for (let B of q) b.set(B, L[B] || null);
    }
  }, M = (X) => W.dressSelf ? W.dressSelf(X) : W.setHandColour(X.skin);
  h && O([h]).then(() => k(b.get(h))).then(M).catch((X) => console.warn("[wardrobe] your own outfit is off:", X.message));
  let s = false, x = async () => {
    if (!s) {
      s = true;
      try {
        for (let L of [...Z.keys()]) W.remotes.has(L) || Z.delete(L);
        let X = [], q = [];
        for (let B of W.remotes.keys()) {
          let V = S.players.get(B)?.name;
          V && q.push([B, V]);
        }
        if (!q.length) return;
        await O([...new Set(q.map(([, Y]) => Y))]);
        for (let [Y, K] of q) Z.get(Y) !== J(K) && X.push([Y, K]);
        for (let [Q, d0] of X) {
          let d1 = await k(b.get(d0));
          W.remotes.has(Q) && (W.dressRemote(Q, d1), Z.set(Q, J(d0)));
        }
      } catch (d2) {
        console.warn("[wardrobe] could not dress somebody:", d2.message);
      } finally {
        s = false;
      }
    }
  }, f = setInterval(x, 1e3), N = setInterval(() => {
    b.clear(), x();
  }, 2e4);
  return x(), { stop: () => {
    clearInterval(f), clearInterval(N);
  }, tick: x, refreshMe: (X) => (h && b.set(h, X || null), k(X).then(M).catch(() => {
  })) };
}
export {
  R as a,
  k as b,
  D as c
};
