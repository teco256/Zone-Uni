import { t as c } from "./c-USQKEFSE.js";
function ht(l) {
  return async () => {
    try {
      let k = await fetch("/api/game/relay-ticket", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ room: l() }) });
      return k.ok && (await k.json()).ticket || null;
    } catch {
      return null;
    }
  };
}
function ct(l, k = "/engine-ws") {
  return l && l.relayUrl ? l.relayUrl : (location.protocol === "https:" ? "wss" : "ws") + "://" + location.host + (l && l.wsPath || k);
}
var a = (l, k, m) => {
  let u = document.createElement(l);
  return k && (u.className = k), m !== void 0 && (u.textContent = m), u;
}, V = new URL("img/rz-white-128.png", import.meta.url).href, S = 'fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"', Y = { home: '<path d="M12 2.6L1.8 11.4h3V21h5.4v-6.2h3.6V21h5.4v-9.6h3z"/>', rooms: '<rect x="2.5" y="2.5" width="8.6" height="8.6" rx="2.2"/><rect x="12.9" y="2.5" width="8.6" height="8.6" rx="2.2"/><rect x="2.5" y="12.9" width="8.6" height="8.6" rx="2.2"/><rect x="12.9" y="12.9" width="8.6" height="8.6" rx="2.2"/>', people: '<circle cx="8.6" cy="7.3" r="3.9"/><path d="M1.4 20.6c0-4.5 3.2-7.6 7.2-7.6s7.2 3.1 7.2 7.6z"/><circle cx="17.3" cy="8.3" r="3.1"/><path d="M15 13.5c.7-.3 1.5-.4 2.3-.4 3.2 0 5.5 2.6 5.5 6.5h-5.4c0-2.5-.9-4.6-2.4-6.1z"/>', chat: '<path fill-rule="evenodd" d="M5.2 3h13.6A2.7 2.7 0 0 1 21.5 5.7v9.2a2.7 2.7 0 0 1-2.7 2.7h-7L6.5 22v-4.4H5.2a2.7 2.7 0 0 1-2.7-2.7V5.7A2.7 2.7 0 0 1 5.2 3zM8 8.7a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 1 0 0-3.2zM12 8.7a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 1 0 0-3.2zM16 8.7a1.6 1.6 0 1 0 0 3.2 1.6 1.6 0 1 0 0-3.2z"/>', respawn: '<path d="M5.3 12.6a6.9 6.9 0 1 0 2-5.3" ' + S + ' stroke-width="3.6"/><path d="M2.6 3.2l.6 7.4 7.1-2.2z"/>', camera: '<path fill-rule="evenodd" d="M8.4 3.8h7.2l1.6 2.6H20a2.2 2.2 0 0 1 2.2 2.2v9.6a2.2 2.2 0 0 1-2.2 2.2H4a2.2 2.2 0 0 1-2.2-2.2V8.6A2.2 2.2 0 0 1 4 6.4h2.8zM12 8.8a4.6 4.6 0 1 0 0 9.2 4.6 4.6 0 1 0 0-9.2zM12 11.1a2.3 2.3 0 1 1 0 4.6 2.3 2.3 0 1 1 0-4.6z"/>', settings: '<circle cx="12" cy="12" r="5.6" ' + S + ' stroke-width="3.6"/><path d="M12 2.4v3.2M12 18.4v3.2M21.6 12h-3.2M5.6 12H2.4M18.8 5.2l-2.3 2.3M7.5 16.5l-2.3 2.3M18.8 18.8l-2.3-2.3M7.5 7.5L5.2 5.2" ' + S + ' stroke-width="3.4"/>', controls: '<path fill-rule="evenodd" d="M7.2 5.8h9.6a5.2 5.2 0 0 1 5.2 5.2v2a4.6 4.6 0 0 1-8.3 2.8l-.6-.8h-2.2l-.6.8A4.6 4.6 0 0 1 2 13v-2a5.2 5.2 0 0 1 5.2-5.2zM6.6 8.8v1.9H4.7v2.2h1.9v1.9h2.2v-1.9h1.9v-2.2H8.8V8.8zM16.4 8.6a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 1 0 0-2.6zM18.8 11.2a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 1 0 0-2.6z"/>', store: '<path fill-rule="evenodd" d="M4.2 3h15.6l1.7 5.4a3.2 3.2 0 0 1-2.2 3.9V21H4.7v-8.7a3.2 3.2 0 0 1-2.2-3.9zM9.6 14.4V21h4.8v-6.6z"/>', outfit: '<path d="M8.6 2.8L3 5.6 1.4 10.4l3.5 1.4 1-2V21h12.2V9.8l1 2 3.5-1.4L21 5.6l-5.6-2.8c-.5 1.7-1.9 2.8-3.4 2.8S9.1 4.5 8.6 2.8z"/>', invite: '<circle cx="9" cy="7.4" r="3.9"/><path d="M1.6 20.6c0-4.5 3.3-7.5 7.4-7.5s7.4 3 7.4 7.5z"/><path d="M18.6 7v7M15.1 10.5h7" ' + S + ' stroke-width="3"/>', close: '<path d="M6 6l12 12M18 6L6 18" ' + S + ' stroke-width="3.6"/>', back: '<path d="M14.5 5.5L8 12l6.5 6.5" ' + S + ' stroke-width="3.4"/>', up: '<path d="M12 5l9.5 13H2.5z"/>', down: '<path d="M12 19L2.5 6h19z"/>', send: '<path d="M2.2 10.6L21.6 3l-5 18.2-5.1-5.8-4.6 3.4.8-5.9z"/>', arrow: '<path d="M4.5 12h14M13 6l6 6-6 6" ' + S + ' stroke-width="3.2"/>', dorms: '<path fill-rule="evenodd" d="M6.2 2.5h11.6A1.7 1.7 0 0 1 19.5 4.2V20h2v2H2.5v-2h2V4.2a1.7 1.7 0 0 1 1.7-1.7zM15.2 11a1.3 1.3 0 1 0 0 2.6 1.3 1.3 0 1 0 0-2.6z"/>' }, _ = (l) => '<svg viewBox="0 0 24 24" aria-hidden="true">' + (Y[l] || "") + "</svg>", Z = [{ id: "home", label: "Home", icon: "home", side: "pages" }, { id: "rooms", label: "Rooms", icon: "rooms", side: "pages" }, { id: "people", label: "People", icon: "people", side: "pages" }, { id: "chat", label: "Chat", icon: "chat", side: "pages" }, { id: "settings", label: "Settings", icon: "settings", side: "pages" }, { id: "respawn", label: "Respawn", icon: "respawn", side: "acts" }, { id: "camera", label: "Photo", icon: "camera", side: "acts" }], J = [["W A S D", "Move"], ["Space", "Jump"], ["Shift", "Sprint"], ["F", "Left hand"], ["G", "Right hand"], ["Click", "Grab"], ["Enter", "Chat"], ["C", "First or third person"], ["Scroll", "Zoom in third person"], ["M", "Mute or unmute your mic"], ["E", "Pick up or drop a ball"], ["Hold click", "Throw what you are holding"], ["X", "Watch"], ["Esc", "Free mouse"]], Q = { auto: "Auto", 60: "60", 120: "120", 144: "144", 240: "240", max: "Max" }, tt = [["auto", "Auto"], ["ultra", "Ultra"], ["high", "High"], ["medium", "Medium"], ["low", "Low"], ["potato", "Potato"]], et = { auto: "Picks for this device and steps down by itself if frames drop.", ultra: "Soft wide shadows, sky reflections, rim light, smooth edges, full resolution.", high: "Soft shadows, sky reflections on glossy things, smooth edges.", medium: "Soft shadows and light edge smoothing.", low: "Hard shadows, no smoothing. For older laptops.", potato: "No shadows, simple light, lower resolution. For anything that struggles." };
function N(k, m, { rest: E = 4, x: v = 6, y: g = 7, edge: T = 2.6 } = {}) {
  if (globalThis.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return;
  let y = false, w = 0, L = 0, p = 0, B = T / 2;
  k.addEventListener("pointermove", (d0) => {
    w = d0.clientX / innerWidth - 0.5, L = d0.clientY / innerHeight - 0.5, !y && (y = true, requestAnimationFrame(() => {
      y = false, m.style.transform = "rotateX(" + (E - L * v).toFixed(2) + "deg) rotateY(" + (w * g).toFixed(2) + "deg)";
      let d1 = Math.round(-w * T / B);
      d1 !== p && (p = d1, m.style.setProperty("--sx", (p * B).toFixed(2) + "px"));
    }));
  });
}
var O = /* @__PURE__ */ new Map(), F = /* @__PURE__ */ new Set(), H = /* @__PURE__ */ new Set(), D = null, R = null;
function ut(l) {
  D = typeof l == "function" ? l : null;
}
async function ft(l) {
  let k = await fetch("/api/game/avatars?names=" + encodeURIComponent(l.join(",")), { credentials: "same-origin", headers: { Accept: "application/json" } });
  return k.ok ? (await k.json()).avatars || {} : {};
}
function W(l, k) {
  if (l.querySelector(".rz-pic")) return;
  let m = new Image();
  m.className = "rz-pic", m.alt = "", m.draggable = false, m.decoding = "async", m.addEventListener("load", () => l.classList.add("has-pic")), m.addEventListener("error", () => m.remove()), m.src = k, l.appendChild(m);
}
async function st() {
  R = null;
  let l = [...H];
  H.clear();
  let k = {};
  try {
    k = await D(l) || {};
  } catch {
    k = {};
  }
  for (let m of l) O.set(m, typeof k[m] == "string" && k[m] ? k[m] : null);
  for (let u of [...F]) {
    let E = O.get(u.dataset.face);
    E !== void 0 && (F.delete(u), E && u.isConnected && W(u, E));
  }
}
function x(l, k) {
  let m = String(k || "?").trim();
  l.textContent = m.charAt(0).toUpperCase() || "?", l.style.background = M(m), l.classList.add("rz-face"), l.classList.remove("has-pic");
  let u = O.get(m);
  return u ? (W(l, u), l) : (u === null || !D || !m || (l.dataset.face = m, F.add(l), H.add(m), R || (R = setTimeout(st, 40))), l);
}
var q = 3;
function M(l) {
  let k = ["#2d6cff", "#39d98a", "#ffb020", "#ff6b9d", "#b388ff", "#4dd0e1", "#ff8a5c"], m = 0;
  for (let u of String(l || "?")) m = m * 31 + u.charCodeAt(0) >>> 0;
  return k[m % k.length];
}
function it(l, k) {
  if (k === "reczone") return ["#2d6cff", "#06123a"];
  let m = [["#3b82f6", "#0a1a48"], ["#6d5cff", "#160f45"], ["#06b6d4", "#03283a"], ["#8b5cf6", "#1d0d45"], ["#0ea5e9", "#04203d"], ["#d946ef", "#33093f"]], u = 7;
  for (let E of String(l || "?")) u = u * 33 + E.charCodeAt(0) >>> 0;
  return m[u % m.length];
}
var j = class extends EventTarget {
  constructor({ mount: k, me: m = "You", room: E = () => "", players: h = () => [], rooms: v = null, invite: T = null, onRespawn: y = null, onCamera: w = null, pages: L = [], customize: B = null } = {}) {
    super(), this.me = m, this.roomOf = E, this.playersOf = h, this.roomsOf = v, this.inviteOf = T, this.onRespawn = y, this.onCamera = w, this.extraPages = L.filter((d3) => d3 && d3.id && typeof d3.draw == "function"), this.hud = null, this.enabled = true, this.open = false, this.page = "home", this._rooms = null, this.root = a("div", "wt"), this.root.hidden = true, this.root.innerHTML = '\n      <div class="wt-menu" role="dialog" aria-label="Watch">\n        <header class="wt-bar">\n          <img class="wt-logo" alt="" draggable="false">\n          <div class="wt-brand">RECZONE</div>\n          <div class="wt-avatar"></div>\n          <div class="wt-who">\n            <div class="wt-me"></div>\n            <div class="wt-where"></div>\n          </div>\n          <div class="wt-time"></div>\n          <button type="button" class="wt-invite">' + _("invite") + '<span>Invite</span></button>\n          <button type="button" class="wt-x" data-tile="close" aria-label="Close">' + _("close") + '</button>\n        </header>\n        <aside class="wt-wing wt-wing-left" aria-label="Who is here">\n          <div class="wt-crowdcount"></div>\n          <div class="wt-crowd"></div>\n          <button type="button" class="wt-crowdadd" aria-label="Invite">' + _("invite") + '</button>\n        </aside>\n        <section class="wt-screen"><div class="wt-body"></div></section>\n        <nav class="wt-wing wt-rail" aria-label="Scroll">\n          <button type="button" class="wt-railbtn wt-up" aria-label="Scroll up">' + _("up") + '</button>\n          <div class="wt-track"><i class="wt-thumb"></i></div>\n          <button type="button" class="wt-railbtn wt-down" aria-label="Scroll down">' + _("down") + '</button>\n        </nav>\n        <footer class="wt-dock wt-dock-l"></footer>\n        <footer class="wt-dock wt-dock-c"></footer>\n        <footer class="wt-dock wt-dock-r"></footer>\n      </div>', (k || document.body).appendChild(this.root), this.menu = this.root.querySelector(".wt-menu"), this.body = this.root.querySelector(".wt-body"), this.root.querySelector(".wt-logo").src = V;
    let d0 = this.root.querySelector(".wt-me");
    d0.textContent = m;
    let d1 = String(m || "").length;
    d0.classList.toggle("is-long", d1 > 14 && d1 <= 19), d0.classList.toggle("is-longer", d1 > 19);
    let d2 = this.root.querySelector(".wt-avatar");
    x(d2, m), this._buildDock(), this._buildRail(), this.root.querySelector(".wt-invite").addEventListener("click", () => this.invite()), this.customize = typeof B == "function" ? B : null, this.root.querySelector(".wt-crowdadd").addEventListener("click", () => this.invite());
    for (let d3 of this.root.querySelectorAll(".wt-bar [data-tile]")) d3.addEventListener("click", () => this._tile(d3.dataset.tile));
    this.root.addEventListener("pointerdown", (d4) => {
      d4.target === this.root && this.toggle(false);
    }), N(this.root, this.menu, { rest: 5, x: 6, y: 7, edge: 2.6 }), window.addEventListener("keydown", (d4) => {
      /^(INPUT|TEXTAREA|SELECT)$/.test(d4.target.tagName) || !this.enabled && !this.open || d4.ctrlKey || d4.metaKey || d4.altKey || (d4.code === "KeyX" ? (d4.preventDefault(), this.toggle()) : d4.code === "Escape" && this.open && (d4.preventDefault(), this.toggle(false)));
    }), this.show("home");
  }
  ["attachVoice"](l) {
    return !l || !l.supported ? this : (this.voice = l, l.addEventListener("change", () => {
      if (!this.open) return;
      for (let v of this.body.querySelectorAll(".wt-person[data-id]")) {
        let g = l.stateOf(Number(v.dataset.id));
        v.classList.toggle("is-speaking", g.speaking), v.classList.toggle("is-vmuted", g.muted), v.classList.toggle("is-blocked", g.blocked);
        let T = v.querySelector(".wt-vmute");
        T && T.setAttribute("aria-pressed", String(g.blocked));
      }
      let k = this.body.querySelector(".wt-person.is-me");
      k && k.classList.toggle("is-speaking", !!l.speaking);
      let m = this.body.querySelector(".wt-voicestatus");
      m && (m.textContent = G(l));
      let E = this.body.querySelector('[data-pref="mic"]');
      E && E.classList.toggle("is-on", !!l.micTrack);
      let h = this.body.querySelector(".wt-micsettings");
      h && (h.hidden = !K(l));
    }), this);
  }
  ["attach"](l) {
    this.hud = l, l.addEventListener("line", () => {
      this.open && this.page === "chat" && this._appendChat(), this.open && this.page === "home" && this._drawLatest(), this._dockBadges();
    }), this._dockBadges();
  }
  ["toggle"](l) {
    return this.open = l === void 0 ? !this.open : !!l, this.open || this._leavePage(), this.root.hidden = !this.open, this.open && (document.pointerLockElement && document.exitPointerLock(), this._rooms = null, this.show("home"), this._fitDock()), this.dispatchEvent(new CustomEvent(this.open ? "opened" : "closed")), this;
  }
  ["show"](l) {
    this._leavePage(), this.page = l === "here" ? "home" : l;
    let k = this.roomOf() || "RECZONE", m = this.playersOf().length + 1;
    this.root.querySelector(".wt-where").textContent = k + "  \xB7  " + (m === 1 ? "just you" : m + " here"), this.root.querySelector(".wt-time").textContent = (/* @__PURE__ */ new Date()).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }), this.body.textContent = "", this.body.className = "wt-body wt-page-" + this.page;
    for (let h of this.root.querySelectorAll(".wt-app")) h.classList.toggle("is-on", h.dataset.tile === this.page);
    this._drawCrowd();
    let u = this.extraPages.find((v) => v.id === this.page);
    u && u.visible && !u.visible() && (this.page = "home", u = null);
    let E = u ? () => {
      this._title(u.title || u.label), u.draw(this.body, this);
    } : { home: () => this._home(), rooms: () => this._roomsPage(), people: () => this._people(), chat: () => this._chat(), controls: () => this._controls(), settings: () => this._settings() }[this.page];
    return E && E(), this.body.scrollTop = 0, this._dockBadges(), requestAnimationFrame(() => this._railSync()), this;
  }
  ["_leavePage"]() {
    let l = this.extraPages.find((k) => k.id === this.page);
    if (l && typeof l.leave == "function") try {
      l.leave(this);
    } catch {
    }
  }
  async ["invite"]() {
    let l = this.inviteOf && await this.inviteOf() || { text: location.href, note: "Link copied" }, k = this.root.querySelector(".wt-invite"), m = k.querySelector("span"), u = false;
    try {
      await navigator.clipboard.writeText(l.text), u = true;
    } catch {
      u = false;
    }
    return m.textContent = u ? l.note || "Copied" : l.text, k.classList.add("is-done"), clearTimeout(this._inviteTimer), this._inviteTimer = setTimeout(() => {
      m.textContent = "Invite", k.classList.remove("is-done");
    }, u ? 1800 : 6e3), u;
  }
  ["_buildDock"]() {
    let k = { respawn: this.root.querySelector(".wt-dock-l"), camera: this.root.querySelector(".wt-dock-r") }, m = this.root.querySelector(".wt-dock-c"), u = [...Z];
    for (let E of this.extraPages) {
      if (E.dock === false) continue;
      let h = u.findIndex((T) => T.id === (E.after || "rooms")), v = { id: E.id, label: E.label, icon: E.icon || "rooms", side: "pages" }, g = h < 0 ? u.length : h + 1;
      for (; g < u.length && u[g].after === (E.after || "rooms"); ) g++;
      v.after = E.after || "rooms", u.splice(g, 0, v);
    }
    for (let T of u) {
      if (T.id === "respawn" && !this.onRespawn || T.id === "camera" && !this.onCamera) continue;
      let f = a("button", "wt-app wt-app-" + T.id);
      f.type = "button", f.dataset.tile = T.id, f.innerHTML = '<span class="wt-appface">' + _(T.icon) + '<span class="wt-applabel">' + T.label + "</span></span>", f.addEventListener("click", () => this._tile(T.id)), (k[T.id] || m).appendChild(f);
    }
    window.addEventListener("resize", () => this._fitDock());
  }
  ["_fitDock"]() {
    let k = this.root.querySelector(".wt-dock-c");
    if (!k || this.root.hidden) return;
    k.style.setProperty("--fit", "1");
    let m = getComputedStyle(k);
    if (!m.display.includes("flex")) return;
    let E = (parseFloat(m.paddingLeft) || 0) + (parseFloat(m.paddingRight) || 0), h = parseFloat(m.columnGap) || 0, v = [...k.children], g = v.reduce((y, w) => y + w.offsetWidth, 0) + h * Math.max(0, v.length - 1), T = k.clientWidth - E - h * Math.max(0, v.length - 1);
    if (T <= 0 || g <= 0) return;
    let f = Math.min(1, T / (g - h * Math.max(0, v.length - 1)));
    k.style.setProperty("--fit", f.toFixed(3));
  }
  ["_drawCrowd"]() {
    let l = [this.me, ...this.playersOf()], k = this.root.querySelector(".wt-crowdcount");
    k.innerHTML = "", k.append(String(l.length), a("small", "", "HERE"));
    let m = this.root.querySelector(".wt-crowd");
    m.textContent = "";
    let u = l.slice(0, 5);
    for (let E of u) {
      let h = x(a("button", "wt-crowdface"), E);
      h.type = "button", h.title = E, h.addEventListener("click", () => this.show("people")), m.appendChild(h);
    }
    l.length > u.length && m.appendChild(a("span", "wt-crowdmore", "+" + (l.length - u.length)));
  }
  ["_dockBadges"]() {
    let l = (k, m) => {
      let u = this.root.querySelector('.wt-app[data-tile="' + k + '"]');
      if (!u) return;
      let E = u.querySelector(".wt-dockbadge");
      if (!m) {
        E?.remove();
        return;
      }
      E || (E = a("b", "wt-dockbadge"), u.appendChild(E)), E.textContent = String(m);
    };
    l("people", this.playersOf().length + 1);
    for (let k of this.extraPages) k.badge && l(k.id, k.badge() || 0);
    this.open && this.page === "chat" && this.hud?.markRead(), l("chat", this.hud ? this.hud.unread : 0);
  }
  ["_buildRail"]() {
    let l = () => Math.max(80, this.body.clientHeight * 0.7);
    this.root.querySelector(".wt-up").addEventListener("click", () => this.body.scrollBy({ top: -l(), behavior: "smooth" })), this.root.querySelector(".wt-down").addEventListener("click", () => this.body.scrollBy({ top: l(), behavior: "smooth" })), this.body.addEventListener("scroll", () => this._railSync(), { passive: true });
    let k = this.root.querySelector(".wt-track");
    k.addEventListener("pointerdown", (m) => {
      let u = k.getBoundingClientRect(), E = (h) => {
        let v = Math.min(Math.max((h.clientY - u.top) / u.height, 0), 1);
        this.body.scrollTop = v * (this.body.scrollHeight - this.body.clientHeight);
      };
      E(m), k.setPointerCapture(m.pointerId), k.addEventListener("pointermove", E), k.addEventListener("pointerup", () => k.removeEventListener("pointermove", E), { once: true });
    }), window.addEventListener("resize", () => this._railSync());
  }
  ["_railSync"]() {
    let k = this.root.querySelector(".wt-rail"), m = this.root.querySelector(".wt-thumb"), { scrollTop: E, scrollHeight: h, clientHeight: v } = this.body, g = h - v;
    k.classList.toggle("is-idle", g <= 2);
    let T = g <= 2 ? 1 : Math.max(v / h, 0.16), f = g <= 2 ? 0 : E / g;
    m.style.height = (T * 100).toFixed(1) + "%", m.style.top = (f * (1 - T) * 100).toFixed(1) + "%", this.root.querySelector(".wt-up").disabled = g <= 2 || E <= 1, this.root.querySelector(".wt-down").disabled = g <= 2 || E >= g - 1;
  }
  ["refreshBadges"]() {
    this._dockBadges();
  }
  ["_tile"](l) {
    if (l === "respawn") {
      this.onRespawn?.(), this.toggle(false);
      return;
    }
    if (l === "camera") {
      this.toggle(false), setTimeout(() => this.onCamera?.(), 60);
      return;
    }
    if (l === "close") {
      this.toggle(false);
      return;
    }
    this.show(l);
  }
  ["_title"](l, k = null) {
    let m = a("div", "wt-title");
    if (m.appendChild(a("h3", "", l)), k) {
      let u = a("button", "wt-more");
      u.type = "button", u.innerHTML = "<span>" + k.label + "</span>" + _("arrow"), u.addEventListener("click", k.run), m.appendChild(u);
    }
    return this.body.appendChild(m), m;
  }
  async ["_loadRooms"]() {
    if (this._rooms) return this._rooms;
    let l = this.roomOf() || "RECZONE", k = [];
    try {
      k = this.roomsOf ? await this.roomsOf() || [] : [];
    } catch {
      k = [];
    }
    if (!k.some((m) => m.here)) {
      let m = this.playersOf().length;
      k.unshift({ id: "here", name: l, sub: m ? m + 1 + " people in here" : "Just you in here", here: true });
    }
    return this._rooms = k, k;
  }
  ["_card"](k) {
    let [m, u] = it(k.name, k.id), E = a("button", "wt-card" + (k.here ? " is-here" : ""));
    E.type = "button", E.dataset.room = k.id || k.name, E.style.setProperty("--card-a", m), E.style.setProperty("--card-b", u);
    let h = a("span", "wt-cardart" + (k.picture ? " has-pic" : ""));
    if (k.picture) {
      let g = a("img", "wt-cardpic");
      g.src = k.picture, g.alt = "", g.draggable = false, h.appendChild(g);
    } else {
      let T = a("img", "wt-cardmark");
      T.src = V, T.alt = "", T.draggable = false, h.appendChild(T);
    }
    k.here && h.appendChild(a("span", "wt-cardhere", "You are here")), k.people && h.appendChild(a("span", "wt-cardpeople", k.people + " in"));
    let v = a("span", "wt-cardstrip");
    return v.append(a("b", "wt-cardname", k.name), a("small", "wt-cardsub", k.sub || "")), E.append(h, v), E.addEventListener("click", () => {
      k.here || !k.go || (this.toggle(false), k.go());
    }), E;
  }
  ["_home"]() {
    this._title("Featured rooms", { label: "More rooms", run: () => this.show("rooms") });
    let k = a("div", "wt-cards wt-cards-featured");
    for (let f = 0; f < q; f++) k.appendChild(a("span", "wt-card is-loading"));
    this.body.appendChild(k), this._loadRooms().then((y) => {
      if (this.page !== "home") return;
      k.textContent = "";
      let w = y.slice(0, q);
      for (let L of w) k.appendChild(this._card(L));
      for (let p = w.length; p < q; p++) k.appendChild(a("span", "wt-card is-empty"));
      this._railSync();
    });
    let m = a("div", "wt-strip"), E = a("button", "wt-tilebig wt-tile-people");
    E.type = "button", E.dataset.go = "people";
    let h = [this.me, ...this.playersOf()], v = a("span", "wt-faces");
    for (let y of h.slice(0, 5)) v.appendChild(x(a("span", "wt-face"), y));
    let g = a("span", "wt-tiletext");
    g.append(a("b", "", h.length === 1 ? "Just you here" : h.length + " people here"), a("small", "", h.length === 1 ? "Invite somebody in" : h.slice(1, 4).join(", "))), E.append(v, g), E.addEventListener("click", () => this.show("people"));
    let T = a("button", "wt-tilebig wt-tile-latest");
    T.type = "button", T.dataset.go = "chat", T.addEventListener("click", () => this.show("chat")), m.append(E, T), this.body.appendChild(m), this._drawLatest();
  }
  ["_drawLatest"]() {
    let l = this.body.querySelector(".wt-tile-latest");
    if (!l) return;
    l.textContent = "";
    let k = a("span", "wt-latesticon");
    k.innerHTML = _("chat");
    let m = a("span", "wt-tiletext"), u = this.hud ? [...this.hud.log].reverse().find((E) => E.kind === "chat") : null;
    if (u) {
      let E = a("b", "", u.from);
      E.style.color = M(u.from), m.append(E, a("small", "", u.text));
    } else m.append(a("b", "", "Chat"), a("small", "", this.hud ? "Nothing said yet. Say hi" : "Chat is off here"));
    l.append(k, m);
  }
  ["_roomsPage"]() {
    let l = this._title("Rooms"), k = a("div", "wt-cards wt-cards-all");
    for (let m = 0; m < q; m++) k.appendChild(a("span", "wt-card is-loading"));
    this.body.appendChild(k), this._loadRooms().then((u) => {
      if (this.page === "rooms") {
        l.querySelector("h3").textContent = "Rooms  \xB7  " + u.length, k.textContent = "";
        for (let E of u) k.appendChild(this._card(E));
        this._railSync();
      }
    });
  }
  ["_people"]() {
    let k = this.playersOf(), m = this._title("People here  \xB7  " + (k.length + 1)), E = a("button", "wt-pill wt-pill-invite");
    E.type = "button", E.innerHTML = _("invite") + "<span>Invite</span>", E.addEventListener("click", () => this.invite()), m.appendChild(E);
    let h = this.extraPages.find((y) => y.id === "staff");
    if (h && (!h.visible || h.visible())) {
      let y = a("button", "wt-pill wt-pill-staff");
      y.type = "button", y.innerHTML = _("settings") + "<span>Staff panel</span>", y.addEventListener("click", () => this.show("staff")), m.insertBefore(y, E);
    }
    let v = a("div", "wt-list"), g = this.voice, T = (w) => g ? [...g.net.players.values()].find((L) => L.name === w)?.id : void 0, f = (L, B) => {
      let d0 = a("div", "wt-person" + (B ? " is-me" : "")), d1 = x(a("span", "wt-mini"), L);
      d0.append(d1, a("span", "wt-name", L)), B && d0.appendChild(a("span", "wt-tag", "You"));
      let d2 = B ? void 0 : T(L);
      if (g && d2 !== void 0) {
        let d3 = g.stateOf(d2);
        d0.dataset.id = String(d2), d0.classList.toggle("is-speaking", d3.speaking), d0.classList.toggle("is-vmuted", d3.muted), d0.classList.toggle("is-blocked", d3.blocked), d0.appendChild(a("i", "wt-vstate"));
        let d4 = document.createElement("input");
        d4.type = "range", d4.className = "wt-vvol", Object.assign(d4, { min: "0", max: "2", step: "0.05", value: String(d3.volume) }), d4.title = L + "'s volume, for you", d4.setAttribute("aria-label", d4.title), d4.addEventListener("input", () => g.setPersonVolume(d2, Number(d4.value)));
        let d5 = a("button", "wt-vmute");
        d5.type = "button", d5.title = "Mute " + L + " for you", d5.setAttribute("aria-label", d5.title), d5.setAttribute("aria-pressed", String(d3.blocked)), d5.addEventListener("click", () => g.setPersonMuted(d2, !g.stateOf(d2).blocked)), d0.append(d4, d5);
      }
      if (B && this.customize) {
        let d6 = a("button", "wt-pill wt-look", "Change look");
        d6.type = "button", d6.addEventListener("click", () => this.customize()), d0.appendChild(d6);
      }
      v.appendChild(d0);
    };
    f(this.me, true);
    for (let w of k) f(w, false);
    this.body.appendChild(v), k.length || this.body.appendChild(a("div", "wt-empty", "Nobody else here yet. Invite copies a way in."));
  }
  ["_chat"]() {
    if (this._title("Chat"), !this.hud || !this.hud.allowChat) {
      this.body.appendChild(a("div", "wt-empty", "Chat is turned off in this room."));
      return;
    }
    let l = a("div", "wt-chatlog");
    this.body.appendChild(l), this._chatShown = 0, this._appendChat();
    let k = a("form", "wt-chatform"), m = a("input", "wt-chatinput");
    m.type = "text", m.maxLength = 200, m.placeholder = "Say something to the room", m.autocomplete = "off", m.spellcheck = false;
    let u = a("button", "wt-send");
    u.type = "submit", u.innerHTML = _("send") + "<span>Send</span>", k.append(m, u), k.addEventListener("submit", (E) => {
      E.preventDefault();
      let h = m.value.trim();
      h && (this.hud.send(h), m.value = "", m.focus());
    }), m.addEventListener("keydown", (E) => {
      E.code === "Escape" && (E.preventDefault(), E.stopPropagation(), m.blur());
    }), this.body.appendChild(k), this.hud.markRead(), setTimeout(() => m.focus(), 30);
  }
  ["_appendChat"]() {
    let l = this.body.querySelector(".wt-chatlog");
    if (!l || !this.hud) return;
    let k = this.hud.log;
    !k.length && !l.children.length && l.appendChild(a("div", "wt-chatempty", "Nothing said yet. Be the first.")), this._chatShown > k.length && (this._chatShown = 0);
    let m = l.scrollHeight - l.scrollTop - l.clientHeight < 40;
    for (let u of k.slice(this._chatShown)) {
      l.querySelector(".wt-chatempty")?.remove();
      let E = a("div", "wt-chatline wt-k-" + u.kind);
      if (u.from) {
        let h = a("b", "wt-chatfrom", u.from);
        h.style.color = M(u.from), E.appendChild(h);
      }
      E.appendChild(a("span", "", u.text)), l.appendChild(E);
    }
    this._chatShown = k.length, m && (l.scrollTop = l.scrollHeight), this.hud.markRead(), this._dockBadges();
  }
  ["_controls"]() {
    let l = this._title("Controls"), k = a("button", "wt-pill");
    k.type = "button", k.innerHTML = _("back") + "<span>Settings</span>", k.addEventListener("click", () => this.show("settings")), l.appendChild(k);
    let m = a("div", "wt-keys");
    for (let [u, E] of J) {
      let h = a("div", "wt-key");
      h.append(a("kbd", "", u), a("span", "", E)), m.appendChild(h);
    }
    this.body.appendChild(m);
  }
  ["_settings"]() {
    let h = this._title("Settings"), T = a("button", "wt-pill");
    T.type = "button", T.dataset.tile = "controls", T.innerHTML = _("controls") + "<span>Controls</span>", T.addEventListener("click", () => this.show("controls")), h.appendChild(T);
    let L = globalThis.rzGame, B = a("div", "wt-settings");
    this.body.appendChild(B);
    let d0 = (d7) => B.appendChild(a("div", "wt-group", d7)), d1 = this.extraPages.find((d7) => d7.id === "staff");
    if (d1 && d1.visible && d1.visible()) {
      d0("Staff");
      let d7 = a("div", "wt-field wt-field-wide wt-staffentry"), d8 = a("div", "wt-fieldtop"), d9 = globalThis.rzNet, dd = d9 && Array.isArray(d9.staffPerms) ? d9.staffPerms.map((dc) => ({ panel: "staff panel", rpg: "RPG", hammer: "ban hammer" })[dc] || dc).join("  \xB7  ") : "";
      d8.append(a("span", "", "Staff tools"), a("b", "wt-val", dd));
      let dC = a("button", "wt-chip is-on wt-staffopen");
      dC.type = "button", dC.innerHTML = _("settings") + "<span>Open staff panel</span>", dC.addEventListener("click", () => this.show("staff")), d7.append(d8, dC), B.appendChild(d7);
    }
    d0("View");
    let d2 = (dc, dl, dF, dk, dm, du, dj) => {
      let dW = a("label", "wt-field"), dS = a("div", "wt-fieldtop"), dE = a("b", "wt-val", dj(dm));
      dS.append(a("span", "", dc), dE);
      let dh = document.createElement("input");
      dh.type = "range", Object.assign(dh, { min: dl, max: dF, step: dk, value: String(dm) }), dh.addEventListener("input", () => {
        du(Number(dh.value)), dE.textContent = dj(Number(dh.value));
      }), dW.append(dS, dh), B.appendChild(dW);
    };
    if (L && typeof L.setView == "function") {
      let dc = a("div", "wt-field wt-field-wide"), dl = a("div", "wt-fieldtop");
      dl.append(a("span", "", "Camera"), a("b", "wt-val", "C switches  \xB7  scroll zooms"));
      let dF = a("div", "wt-chips");
      for (let [dk, dm] of [["first", "First person"], ["third", "Third person"]]) {
        let du = a("button", "wt-chip" + (L.view === dk ? " is-on" : ""), dm);
        du.type = "button", du.dataset.view = dk, du.addEventListener("click", () => {
          L.setView(dk), this.show("settings");
        }), dF.appendChild(du);
      }
      dc.append(dl, dF), B.appendChild(dc), L.view === "third" && d2("Camera distance", 1.4, 7, 0.1, L.thirdDistance, (dj) => L.setThirdDistance(dj), (dj) => dj.toFixed(1) + " m");
    }
    d2("Look speed", 0.4, 2.5, 0.1, this._sensitivity(), (dj) => this._sensitivity(dj), (dj) => dj.toFixed(1) + "x"), d2("Field of view", 50, 110, 1, L ? Math.round(L.camera.fov) : 60, (dj) => globalThis.rzGame?.setFov(dj), (dj) => Math.round(dj) + "\xB0"), d0("Graphics");
    let d3 = a("div", "wt-field wt-field-wide"), d4 = L ? L.quality.describe() : null, d5 = a("div", "wt-fieldtop");
    d5.append(a("span", "", "Graphics"), a("b", "wt-val", d4 ? d4.fps + " fps  \xB7  " + d4.label + "  \xB7  " + (L.backend === "webgpu" ? "WebGPU" : "WebGL") : ""));
    let d6 = a("div", "wt-chips");
    for (let [dj, dW] of tt) {
      let dS = a("button", "wt-chip" + (L && L.quality.mode === dj ? " is-on" : ""), dW);
      dS.type = "button", dS.dataset.quality = dj, dS.addEventListener("click", () => {
        globalThis.rzGame?.setQuality(dj), this.show("settings");
      }), d6.appendChild(dS);
    }
    if (d3.append(d5, d6), L && d3.appendChild(a("div", "wt-note", et[L.quality.mode] || "")), B.appendChild(d3), L && L.pacer) {
      let dE = L.pacer.describe(), dh = a("div", "wt-field wt-field-wide"), dA = a("div", "wt-fieldtop"), dv = L.quality.describe(), dZ = dE.measuring ? "measuring" : dE.cap ? "capped at " + dE.cap : dE.unlocked ? "no cap" : "screen rate";
      dA.append(a("span", "", "Frame rate"), a("b", "wt-val", dv.fps + " fps  \xB7  " + dZ));
      let dg = a("div", "wt-chips");
      for (let de of ["auto", "60", "120", "144", "240", "max"]) {
        let dJ = a("button", "wt-chip" + (dE.choice === de ? " is-on" : ""), Q[de]);
        dJ.type = "button", dJ.dataset.fps = de, dJ.addEventListener("click", () => {
          globalThis.rzGame?.setFrameRate(de), this.show("settings");
        }), dg.appendChild(dJ);
      }
      dh.append(dA, dg);
      let db = globalThis.reczoneDesktop;
      if (db && typeof db.setFpsUnlocked == "function") {
        let dO = a("div", "wt-toggles wt-fpsunlock"), dM = a("button", "wt-toggle" + (dE.unlocked ? " is-on" : ""));
        dM.type = "button", dM.dataset.pref = "fps-unlock", dM.innerHTML = "<i></i><span>Unlock past the screen's rate</span>";
        let dT = a("button", "wt-pill wt-restart", "Restart to apply");
        dT.type = "button", dT.hidden = true, dT.addEventListener("click", () => db.relaunch?.()), dM.addEventListener("click", async () => {
          let dD = !dM.classList.contains("is-on");
          dM.classList.toggle("is-on", dD);
          let ds = await db.setFpsUnlocked(dD).catch(() => null);
          dT.hidden = !(ds && ds.restart);
        }), dO.append(dM, dT), dh.appendChild(dO), db.info?.().then((dD) => {
          dD && dD.fpsUnlockable === false && dO.remove();
        }).catch(() => {
        });
      } else dE.unlocked || dh.appendChild(a("div", "wt-note", "Above the screen's own rate needs the latest RECZONE client."));
      B.appendChild(dh);
    }
    if (this.voice && (d0("Voice"), this._voiceSettings(B, d2)), this.hud) {
      d0("On screen");
      let dD = a("div", "wt-field wt-field-wide wt-toggles");
      for (let [dG, dR] of [["tags", "Name tags"], ["bubbles", "Chat over heads"], ["feed", "Chat on screen"]]) {
        let dx = a("button", "wt-toggle" + (this.hud.prefs[dG] ? " is-on" : ""));
        dx.type = "button", dx.dataset.pref = dG, dx.innerHTML = "<i></i><span>" + dR + "</span>", dx.addEventListener("click", () => {
          this.hud.setPref(dG, !this.hud.prefs[dG]), dx.classList.toggle("is-on", !!this.hud.prefs[dG]);
        }), dD.appendChild(dx);
      }
      let ds = a("button", "wt-toggle" + (P("rz.rawmouse") === "1" ? " is-on" : ""));
      ds.type = "button", ds.dataset.pref = "rawmouse", ds.innerHTML = "<i></i><span>Raw mouse input</span>", ds.title = "No pointer acceleration. Turn off again if a touchpad stops turning the camera.", ds.addEventListener("click", () => {
        let df = !ds.classList.contains("is-on");
        z("rz.rawmouse", df ? "1" : "0"), ds.classList.toggle("is-on", df);
      }), dD.appendChild(ds), B.appendChild(dD);
    }
  }
  ["_voiceSettings"](k, m) {
    let E = this.voice, h = a("div", "wt-field wt-field-wide wt-voice"), v = a("div", "wt-fieldtop");
    v.append(a("span", "", "Voice chat"), a("b", "wt-val wt-voicestatus", G(E))), h.appendChild(v);
    let g = a("div", "wt-toggles"), T = (B, d0, d1, d2) => {
      let d3 = a("button", "wt-toggle" + (d1 ? " is-on" : ""));
      return d3.type = "button", d3.dataset.pref = B, d3.innerHTML = "<i></i><span>" + d0 + "</span>", d3.addEventListener("click", () => {
        d2(!d3.classList.contains("is-on")), d3.classList.toggle("is-on");
      }), g.appendChild(d3), d3;
    };
    T("mic", "Microphone", !!E.micTrack, (B) => B ? E.enableMic() : E.disableMic()), T("ptt", "Push to talk (hold " + nt(E.settings.pttKey) + ")", E.settings.ptt, (B) => E.setPushToTalk(B)), T("spatial", "Hear people by distance", E.settings.spatial, (B) => E.setSpatial(B)), h.appendChild(g);
    let y = globalThis.reczoneDesktop;
    if (y && typeof y.openMicSettings == "function") {
      let B = a("button", "wt-pill wt-micsettings", "Open microphone settings");
      B.type = "button", B.hidden = !K(E), B.addEventListener("click", () => {
        y.openMicSettings();
      }), h.appendChild(B);
    }
    let w = a("div", "wt-pickers"), L = (d0, d1, d2, d3) => {
      let d4 = a("label", "wt-pick");
      d4.appendChild(a("span", "", d0));
      let d5 = document.createElement("select"), d6 = document.createElement("option");
      d6.value = "", d6.textContent = "System default", d5.appendChild(d6);
      for (let d7 of d1) {
        let d8 = document.createElement("option");
        d8.value = d7.id, d8.textContent = d7.label, d5.appendChild(d8);
      }
      d5.value = d1.some((d9) => d9.id === d2) ? d2 : "", d5.addEventListener("change", () => d3(d5.value)), d4.appendChild(d5), w.appendChild(d4);
    };
    E.devices().then(({ inputs: d0, outputs: d1 }) => {
      h.isConnected && (d0.length && L("Microphone", d0, E.settings.input, (d2) => E.setInput(d2)), d1.length && L("Speaker", d1, E.settings.output, (d2) => E.setOutput(d2)));
    }), h.appendChild(w), k.appendChild(h), m("Voice volume", 0, 1, 0.05, E.settings.volume, (d0) => E.setVolume(d0), (d0) => Math.round(d0 * 100) + "%");
  }
  ["_sensitivity"](l) {
    let k = globalThis.rzGame, m = 22e-4;
    if (l === void 0) {
      let u = Number(P("rz.sens"));
      return u > 0 ? u : 1;
    }
    return z("rz.sens", String(l)), k && (k.player.o.lookSensitivity = m * l), l;
  }
};
function K(l) {
  return !l.micTrack && /blocked/i.test(l.error || "");
}
function G(l) {
  if (l.state === "unavailable") return l.error || "Voice chat is not available here";
  if (l.net.noVoice) return "Off while you are muted";
  if (l.state === "asking") return "Waiting for the microphone";
  if (l.error && !l.micTrack) return l.error;
  let k = [...l.peers.values()].filter((u) => u.connected).length, m = k ? k + " connected" : "nobody else in voice";
  return l.micTrack ? l.muted ? "Muted  \xB7  " + m : (l.settings.ptt ? "Push to talk" : "Mic on") + "  \xB7  " + m : "Listening  \xB7  " + m;
}
function nt(l) {
  let k = String(l || "");
  return /^Key[A-Z]$/.test(k) ? k.slice(3) : k;
}
function P(l) {
  try {
    return localStorage.getItem(l);
  } catch {
    return null;
  }
}
function z(l, k) {
  try {
    localStorage.setItem(l, k);
  } catch {
  }
}
var b = (l, k, m) => {
  let u = document.createElement(l);
  return k && (u.className = k), m !== void 0 && (u.textContent = m), u;
}, A = 28, at = 9e3, ot = 6500, I = 150, rt = 3e3, dt = 8, U = ["tags", "bubbles", "feed"], X = class extends EventTarget {
  constructor({ game: k, net: m, canvas: E, watch: h, roomName: v = () => "", allowChat: g = true, startCard: T = true, mount: y = null } = {}) {
    super(), this.active = true, this.game = k, this.net = m, this.canvas = E, this.watch = h, this.roomName = v, this.allowChat = g, this.tags = /* @__PURE__ */ new Map(), this.talking = /* @__PURE__ */ new Map(), this._sayKey = 0, this.log = [], this.unread = 0, this.prefs = {};
    for (let w of U) this.prefs[w] = P("rz.hud." + w) !== "0";
    this.root = b("div", y ? "rz-hud in-view" : "rz-hud"), (y || document.body).appendChild(this.root), this._applyPrefs(), T ? this._buildStart() : this.start = null, this._buildCrosshair(), this._buildBubble(), this._buildFeed(), g && this._buildChat(), this.tagLayer = b("div", "hud-tags"), this.root.appendChild(this.tagLayer), document.addEventListener("pointerlockchange", () => this._locked()), document.addEventListener("mousedown", (L) => {
      !this.active || this.loading || document.pointerLockElement === this.canvas || this.watch?.open || this.chat && !this.chat.hidden || this.start && this.start.style.display !== "none" || L.target.closest && L.target.closest("button, a, input, textarea, select, label, [contenteditable], .wt-root") || (this.entered = true, c(this.canvas));
    }, true), h?.addEventListener("opened", () => this._locked()), h?.addEventListener("closed", () => this._locked());
    for (let L of ["connected", "joined", "left", "disconnected"]) m.addEventListener(L, () => this.redraw());
    this.names = /* @__PURE__ */ new Map(), this._leaving = /* @__PURE__ */ new Map(), m.addEventListener("joined", (B) => {
      let { id: d0, name: d1 } = B.detail;
      this.names.set(d0, d1);
      let d2 = this._leaving.get(d1);
      if (d2) {
        clearTimeout(d2), this._leaving.delete(d1);
        return;
      }
      [...this.names.entries()].some(([d3, d4]) => d3 !== d0 && d4 === d1) || this.say(d1 + " joined", "join");
    }), m.addEventListener("left", (p) => {
      let B = this.names.get(p.detail.id) || p.detail.name || "Somebody";
      this.names.delete(p.detail.id), this._dropTag(p.detail.id), ![...this.names.values()].includes(B) && (clearTimeout(this._leaving.get(B)), this._leaving.set(B, setTimeout(() => {
        this._leaving.delete(B), this.say(B + " left", "leave");
      }, rt)));
    }), m.addEventListener("chat", (B) => {
      let { id: d0, name: d1, text: d2 } = B.detail;
      if (this.say(d2, "chat", d1), d0 && d0 !== this.net.id) {
        let d3 = performance.now(), d4 = (this.talking.get(d0) || []).filter((d5) => d5.until > d3).slice(-1);
        d4.push({ text: d2, until: d3 + ot, key: ++this._sayKey }), this.talking.set(d0, d4);
      }
    }), m.addEventListener("refused", (p) => this.say(p.detail.why, "warn"));
    for (let p of ["who", "hud"]) {
      let B = document.getElementById(p);
      B && B.classList.add("hud-legacy");
    }
    this._tick = this._tick.bind(this), k.afterDraw ? k.afterDraw(this._tick) : requestAnimationFrame(this._loop = () => {
      requestAnimationFrame(this._loop), this._tick();
    }), this.redraw(), this._locked(), h?.attach?.(this);
  }
  ["setPref"](l, k) {
    U.includes(l) && (this.prefs[l] = !!k, z("rz.hud." + l, k ? "1" : "0"), this._applyPrefs());
  }
  ["_applyPrefs"]() {
    for (let l of U) this.root.classList.toggle("no-" + l, !this.prefs[l]);
  }
  ["_buildStart"]() {
    this.start = document.getElementById("click") || b("div"), this.start.id = "click", this.start.className = "hud-start", this.start.textContent = "";
    let l = b("div", "hud-startcard");
    l.innerHTML = '\n      <div class="hud-kicker">RECZONE</div>\n      <h1 class="hud-room"></h1>\n      <div class="hud-here"></div>\n      <div class="hud-load" hidden><i></i><span></span></div>\n      <button type="button" class="hud-play">Play</button>\n      <div class="hud-menu">\n        <button type="button" data-go="rooms">Rooms</button>\n        <button type="button" data-go="dorms">Dorms</button>\n        <button type="button" data-go="avatar">Avatar</button>\n        <button type="button" data-go="settings">Settings</button>\n      </div>\n      <div class="hud-keys">\n        <span><kbd>WASD</kbd> Move</span><span><kbd>Space</kbd> Jump</span>\n        <span><kbd>X</kbd> Watch</span>' + (this.allowChat ? "<span><kbd>Enter</kbd> Chat</span>" : "") + "\n      </div>", this.start.appendChild(l), this.start.parentElement || document.body.appendChild(this.start);
    for (let k of l.querySelectorAll(".hud-menu [data-go]")) k.addEventListener("click", (m) => {
      m.stopPropagation(), this.watch && (this.watch.toggle(true), this.watch.show(k.dataset.go));
    });
    this.start.addEventListener("click", () => {
      this.loading || this.enter();
    }), N(this.start, l, { rest: 4, x: 8, y: 9, edge: 3 });
  }
  ["enter"]() {
    this.entered = true, c(this.canvas), this.dispatchEvent(new CustomEvent("play")), this._locked(), clearTimeout(this._lockHint), this._lockHint = setTimeout(() => {
      let l = document.pointerLockElement !== this.canvas, k = !!this.watch?.open || this.chat && !this.chat.hidden;
      this.entered && l && !k && this.say("Click anywhere to look around", "info");
    }, 1500);
  }
  ["setLoading"](l, k = "") {
    if (this.loading = l < 1, !this.start) return;
    let m = this.start.querySelector(".hud-load"), u = this.start.querySelector(".hud-play");
    m.hidden = !this.loading, m.querySelector("i").style.width = Math.round(Math.min(1, Math.max(0, l)) * 100) + "%", m.querySelector("span").textContent = k, u.disabled = this.loading, u.textContent = this.loading ? "Loading\u2026" : "Play", this.start.classList.toggle("is-loading", this.loading);
  }
  ["_buildCrosshair"]() {
    this.xhair = b("div", "hud-xhair"), this.root.appendChild(this.xhair);
  }
  ["_buildBubble"]() {
    this.bubble = b("div", "hud-bubble"), this.root.appendChild(this.bubble);
  }
  ["_buildFeed"]() {
    this.feed = b("div", "hud-feed"), this.root.appendChild(this.feed);
  }
  ["_buildChat"]() {
    this.chat = b("form", "hud-chat"), this.chat.hidden = true;
    let l = b("input");
    l.type = "text", l.maxLength = 200, l.placeholder = "Say something", l.autocomplete = "off", l.spellcheck = false;
    let k = b("button", "hud-chatsend", "Send");
    k.type = "submit", this.chat.append(b("span", "hud-chatlabel", "Chat"), l, k), this.root.appendChild(this.chat), this.chatInput = l, this.hint = b("button", "hud-chathint"), this.hint.type = "button", this.hint.innerHTML = '<kbd>Enter</kbd><span>Chat</span><b class="hud-unread" hidden></b>', this.hint.addEventListener("click", () => this.openChat()), this.root.appendChild(this.hint), window.addEventListener("keydown", (m) => {
      this.active && (m.code !== "Enter" && m.code !== "KeyT" || m.ctrlKey || m.metaKey || m.altKey || this.chat.hidden !== false && (this.watch?.open || /^(INPUT|TEXTAREA|SELECT)$/.test(m.target.tagName) || m.target.isContentEditable || (m.preventDefault(), this.openChat())));
    }), l.addEventListener("keydown", (m) => {
      m.code === "Escape" && (m.preventDefault(), this.closeChat(false));
    }), this.chat.addEventListener("submit", (m) => {
      m.preventDefault();
      let u = l.value.trim();
      u && this.send(u), this.closeChat(true);
    });
  }
  ["attachVoice"](l) {
    if (!l || !l.supported) return this;
    this.voice = l, this.root.classList.add("has-voice");
    let k = b("div", "hud-dockrow");
    this.hint && k.appendChild(this.hint);
    let m = b("button", "hud-chathint hud-mic");
    m.type = "button", m.innerHTML = '<i class="hud-micicon"></i><span class="hud-miclabel">Mic off</span>', m.addEventListener("click", (E) => {
      E.stopPropagation(), l.toggle();
    }), k.appendChild(m), this.root.appendChild(k), this.mic = m, this._voiceMarks = /* @__PURE__ */ new Map();
    let u = () => {
      this._voiceMarks.clear();
      for (let g of this.net.players.keys()) {
        let T = l.stateOf(g);
        this._voiceMarks.set(g, (T.speaking ? 1 : 0) | (T.muted ? 2 : 0));
      }
      let E = m.querySelector(".hud-miclabel"), h = "Mic off", v = "off";
      l.state === "unavailable" ? (h = "No voice", v = "error") : l.state === "asking" ? (h = "Allow mic", v = "asking") : l.micTrack && l.muted ? (h = "Muted", v = "muted") : l.micTrack && l.settings.ptt ? (h = l.pttHeld ? "Talking" : "Hold " + lt(l.settings.pttKey), v = l.pttHeld ? "live" : "ptt") : l.micTrack ? (h = "Mic on", v = "live") : l.state === "error" && (h = "Mic off", v = "error"), E.textContent !== h && (E.textContent = h), m.dataset.state = v, m.classList.toggle("is-speaking", !!l.speaking), m.title = l.error || (v === "off" ? "Turn your microphone on (M)" : v === "muted" ? "Unmute (M)" : "Mute (M)");
    };
    return l.addEventListener("change", u), l.addEventListener("problem", (E) => this.say(E.detail.message, "warn")), u(), window.addEventListener("keydown", (E) => {
      !this.active || E.code !== "KeyM" || E.repeat || E.ctrlKey || E.metaKey || E.altKey || this.watch?.open || this.chat && this.chat.hidden === false || /^(INPUT|TEXTAREA|SELECT)$/.test(E.target.tagName) || E.target.isContentEditable || l.toggle();
    }), this;
  }
  ["flash"](l, k = "") {
    this.flashEl || (this.flashEl = b("div", "hud-flash"), this.flashEl.append(b("b", "hud-flashtitle"), b("span", "hud-flashsub")), this.root.appendChild(this.flashEl));
    let m = this.flashEl;
    m.querySelector(".hud-flashtitle").textContent = l, m.querySelector(".hud-flashsub").textContent = k, m.classList.remove("is-on"), m.offsetWidth, m.classList.add("is-on"), clearTimeout(this._flashTimer), this._flashTimer = setTimeout(() => m.classList.remove("is-on"), 2600);
  }
  ["send"](l) {
    let k = String(l || "").trim().slice(0, 200);
    return k ? this.net.connected ? (this.net.say(k), true) : (this.say("Not connected right now, so that was not sent.", "warn"), false) : false;
  }
  ["markRead"]() {
    this.unread && (this.unread = 0, this._drawUnread());
  }
  ["_drawUnread"]() {
    let l = this.hint?.querySelector(".hud-unread");
    l && (l.hidden = !this.unread, l.textContent = this.unread > 9 ? "9+" : String(this.unread));
  }
  ["openChat"]() {
    this.chat && (this._wasLocked = document.pointerLockElement === this.canvas, this._wasLocked && document.exitPointerLock(), this.chat.hidden = false, this.root.classList.add("is-chatting"), this.chatInput.value = "", this.chatInput.focus(), this.markRead());
  }
  ["closeChat"](l) {
    !this.chat || this.chat.hidden || (this.chat.hidden = true, this.root.classList.remove("is-chatting"), this.chatInput.blur(), (l || this._wasLocked) && c(this.canvas));
  }
  ["say"](l, k = "info", m = "") {
    let u = b("div", "hud-line hud-k-" + k);
    if (m) {
      let h = b("b", "hud-from", m);
      h.style.color = M(m), u.appendChild(h);
    }
    for (u.appendChild(b("span", "", l)), this.feed.appendChild(u); this.feed.children.length > dt; ) this.feed.firstElementChild.remove();
    setTimeout(() => u.classList.add("is-old"), at), this.log.push({ kind: k, from: m, text: String(l), at: Date.now() }), this.log.length > I && this.log.splice(0, this.log.length - I);
    let E = this.chat && !this.chat.hidden || this.watch?.open && this.watch.page === "chat";
    return k === "chat" && !E && m !== this.net.name && this.unread++, this._drawUnread(), this.dispatchEvent(new CustomEvent("line", { detail: this.log[this.log.length - 1] })), u;
  }
  ["redraw"]() {
    let k = [...this.net.players.values()];
    for (let v of k) this.names.set(v.id, v.name);
    let m = k.filter((g, T) => g.name !== this.net.name && k.findIndex((f) => f.name === g.name) === T), u = this.roomName() || this.net.room || "RECZONE", E = m.length + 1;
    this.start && (this.start.querySelector(".hud-room").textContent = u, this.start.querySelector(".hud-here").textContent = E === 1 ? "Just you so far" : E + " people here"), this.bubble.textContent = "";
    let h = b("div", "hud-stack");
    for (let g of [this.net.name, ...m.map((T) => T.name)].slice(0, 5)) {
      let T = x(b("span", "hud-dot"), g);
      T.title = g, h.appendChild(T);
    }
    this.bubble.append(h, b("b", "hud-count", String(E))), this.bubble.classList.toggle("is-alone", E === 1);
  }
  ["setActive"](l) {
    return this.active = !!l, this.root.hidden = !this.active, this.active || this.closeChat(false), this.watch && (this.watch.enabled = this.active), this._locked(), this;
  }
  ["_locked"]() {
    let l = document.pointerLockElement === this.canvas;
    l ? this._hadLock = true : this._hadLock && (this._hadLock = false, this.entered = false);
    let k = this.chat && !this.chat.hidden, m = !!this.watch?.open, u = this.active && !!this.start && !l && !m && !k && !this.entered;
    this.start && (this.start.style.display = u ? "flex" : "none"), this.root.classList.toggle("is-locked", l), this.root.classList.toggle("is-waiting", u), this.game.hold?.("watch", this.active && m), this.game.easeOff?.("start", u, 2);
  }
  ["_tick"]() {
    if (!this.active) return;
    let h = this.game.camera, d0 = h.viewProjection, d1 = this.canvas.clientWidth, d2 = this.canvas.clientHeight;
    if (!d0 || !d1) return;
    let d3 = h.position;
    for (let [d4, d5] of this.game.remotes) {
      let d6 = this.net.players.get(d4);
      if (!d6 || !d5.head) continue;
      let d7 = this.tags.get(d4);
      if (!d7) {
        d7 = b("div", "hud-tag"), d7.appendChild(b("div", "hud-says"));
        let dh = b("div", "hud-plate");
        dh.append(b("span", "hud-tagdot"), b("span", "hud-tagname"), b("span", "hud-tagvoice")), d7.appendChild(dh), this.tagLayer.appendChild(d7), this.tags.set(d4, d7);
      }
      d7.dataset.name !== d6.name && (d7.dataset.name = d6.name, d7.querySelector(".hud-tagname").textContent = d6.name);
      let d8 = this.tagTint && this.tagTint(d4) || M(d6.name);
      d7.dataset.who !== d8 && (d7.dataset.who = d8, d7.style.setProperty("--who", d8)), this._drawWords(d4, d7);
      let d9 = this._voiceMarks && this._voiceMarks.get(d4) || 0;
      d7._mark !== d9 && (d7._mark = d9, d7.classList.toggle("is-speaking", (d9 & 1) !== 0), d7.classList.toggle("is-muted", (d9 & 2) !== 0));
      let dd = d5.head.worldPosition();
      dd[1] += 0.42;
      let dC = d0[0] * dd[0] + d0[4] * dd[1] + d0[8] * dd[2] + d0[12], dc = d0[1] * dd[0] + d0[5] * dd[1] + d0[9] * dd[2] + d0[13], dl = d0[2] * dd[0] + d0[6] * dd[1] + d0[10] * dd[2] + d0[14], dF = d0[3] * dd[0] + d0[7] * dd[1] + d0[11] * dd[2] + d0[15], dk = Math.hypot(dd[0] - d3[0], dd[1] - d3[1], dd[2] - d3[2]);
      if (dF <= 0.05 || dk > A) {
        d7.style.opacity = "0";
        continue;
      }
      let dm = dC / dF, du = dc / dF;
      if (Math.abs(dm) > 1.15 || Math.abs(du) > 1.15 || dl / dF > 1) {
        d7.style.opacity = "0";
        continue;
      }
      let dj = (dm * 0.5 + 0.5) * d1, dW = (1 - (du * 0.5 + 0.5)) * d2, dS = Math.max(0.62, Math.min(1, 6 / Math.max(dk, 0.1))), dE = dk > A * 0.7 ? 1 - (dk - A * 0.7) / (A * 0.3) : 1;
      d7.style.transform = "translate(" + dj.toFixed(1) + "px, " + dW.toFixed(1) + "px) translate(-50%, -100%) scale(" + dS.toFixed(3) + ")", d7.style.opacity = String(Math.max(0, dE).toFixed(2));
    }
    for (let dA of this.tags.keys()) this.game.remotes.has(dA) || this._dropTag(dA);
  }
  ["_drawWords"](k, m) {
    let E = m.firstChild, h = this.talking.get(k);
    if (!h && !E.dataset.shown) return;
    let v = performance.now(), g = (h || []).filter((f) => f.until > v);
    g.length || this.talking.delete(k);
    let T = g.map((f) => String(f.key)).join(",");
    if (E.dataset.shown !== T) {
      E.dataset.shown = T;
      let f = new Map([...E.children].map((y) => [y.dataset.key, y]));
      E.textContent = "", g.forEach((y, w) => {
        let L = f.get(String(y.key)) || b("div", "hud-say", y.text);
        L.dataset.key = String(y.key), L.classList.toggle("is-older", w < g.length - 1), E.appendChild(L);
      });
    }
    for (let y of E.children) {
      let w = g.find((L) => String(L.key) === y.dataset.key);
      y.classList.toggle("is-going", !!w && w.until - v < 450);
    }
    m.classList.toggle("is-talking", g.length > 0);
  }
  ["_dropTag"](l) {
    let k = this.tags.get(l);
    k && k.remove(), this.tags.delete(l), this.talking.delete(l);
  }
};
function bt(l, k = "reczone") {
  return new Promise((m) => {
    l.render(), l.canvas.toBlob((u) => {
      if (!u) return m(false);
      let E = document.createElement("a");
      E.href = URL.createObjectURL(u);
      let v = (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace(/[T:]/g, "-");
      E.download = k + "-" + v + ".png", E.click(), setTimeout(() => URL.revokeObjectURL(E.href), 3e4), m(true);
    }, "image/png");
  });
}
function lt(l) {
  let k = String(l || "");
  return /^Key[A-Z]$/.test(k) ? k.slice(3) : /^Digit\d$/.test(k) ? k.slice(5) : { Backquote: "`", CapsLock: "Caps", AltLeft: "Alt", ControlLeft: "Ctrl", Space: "Space" }[k] || k;
}
export {
  ht as a,
  ct as b,
  ut as c,
  ft as d,
  j as e,
  X as f,
  bt as g
};
