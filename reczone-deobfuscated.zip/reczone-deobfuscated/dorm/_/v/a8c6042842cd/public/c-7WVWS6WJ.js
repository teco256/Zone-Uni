import { x as l } from "./c-USQKEFSE.js";
var b = "/api/dorms", d = (k, m, u) => {
  let E = document.createElement(k);
  return m && (E.className = m), u !== void 0 && (E.textContent = u), E;
};
async function w(k, m) {
  let u = await fetch(k, { credentials: "same-origin", headers: { Accept: "application/json", ...m && m.headers }, ...m }), E = await u.json().catch(() => ({}));
  if (!u.ok) throw Object.assign(new Error(E.error || E.message || "HTTP " + u.status), { body: E });
  return E;
}
var q = class extends EventTarget {
  constructor({ mount: k, room: m = null, show: u = null } = {}) {
    super(), this.room = m, this.mine = null, this.open = false, this.waiting = [], this.show = u, this._knockPoll = null, this.root = d("div", u ? "rzd rzd-inline" : "rzd"), this.root.innerHTML = (u ? "" : '\n      <button class="rzd-tab" type="button">\n        <span class="rzd-tab-label">Dorms</span>\n        <span class="rzd-badge" hidden>0</span>\n      </button>') + '\n      <div class="rzd-body" hidden>\n        <div class="rzd-head">\n          <strong class="rzd-title">Dorms</strong>\n          <button class="rzd-close" type="button" aria-label="Close">&times;</button>\n        </div>\n        <div class="rzd-scroll">\n          <section class="rzd-sect rzd-knocks" hidden>\n            <h4>At your door</h4>\n            <div class="rzd-knock-list"></div>\n          </section>\n          <section class="rzd-sect">\n            <h4>Yours</h4>\n            <div class="rzd-mine"></div>\n          </section>\n          <section class="rzd-sect">\n            <h4>Go somewhere</h4>\n            <form class="rzd-codeform">\n              <input class="rzd-code" maxlength="6" placeholder="Dorm code" autocomplete="off">\n              <button class="rzd-go" type="submit">Find</button>\n            </form>\n            <div class="rzd-others"></div>\n          </section>\n        </div>\n        <p class="rzd-note"></p>\n      </div>', k && k.appendChild(this.root), this.tab = this.root.querySelector(".rzd-tab"), this.badge = this.root.querySelector(".rzd-badge"), this.panel = this.root.querySelector(".rzd-body"), this.note = this.panel.querySelector(".rzd-note"), this.tab?.addEventListener("click", () => this.toggle()), this.panel.querySelector(".rzd-close").addEventListener("click", () => this.toggle(false)), this.panel.querySelector(".rzd-codeform").addEventListener("submit", (E) => {
      E.preventDefault(), this._byCode(this.panel.querySelector(".rzd-code").value);
    }), this.refresh(), this._knockPoll = setInterval(() => this._refreshKnocks(), 5e3);
  }
  ["stop"]() {
    this._knockPoll && clearInterval(this._knockPoll), this._knockPoll = null;
  }
  ["toggle"](k) {
    this.open = k === void 0 ? !this.open : !!k, this.show ? this.show(this.open) : this.panel.hidden = !this.open, this.open && this.refresh(), this.dispatchEvent(new CustomEvent(this.open ? "opened" : "closed"));
  }
  ["drawInto"](k) {
    this.panel.hidden = false, k.appendChild(this.panel), this.refresh();
  }
  ["say"](k, m = "") {
    this.note.textContent = k || "", this.note.className = "rzd-note " + m;
  }
  async ["refresh"]() {
    try {
      let [k, m] = await Promise.all([w(b + "/me"), w(b)]);
      this.mine = k, this._drawMine(k), this._drawKnocks(k.waiting || []), this._drawOthers(m.dorms || []), this.note.classList.contains("is-bad") && this.say("");
    } catch (u) {
      console.warn("[dorms] could not refresh:", u), this.say(u.message === "Failed to fetch" ? "Cannot reach RECZONE right now." : "Sign in to use dorms.", "is-bad");
    }
  }
  async ["_refreshKnocks"]() {
    try {
      let { waiting: k } = await w(b + "/knocks");
      this._drawKnocks(k || []);
    } catch {
    }
  }
  ["_drawMine"](m) {
    let u = this.panel.querySelector(".rzd-mine");
    u.innerHTML = "";
    let E = this.room && this.room === m.room, v = d("div", "rzd-row");
    v.appendChild(d("span", "rzd-name", m.name));
    let g = d("button", E ? "rzd-btn rzd-here" : "rzd-btn rzd-btn-go", E ? "You are here" : "Go home");
    g.disabled = E, g.addEventListener("click", () => this._enter(m.room, m.name)), v.appendChild(g), u.appendChild(v);
    let J = d("div", "rzd-code-line");
    J.appendChild(d("span", "", "Code ")), J.appendChild(d("strong", "", m.code)), u.appendChild(J);
    let T = d("div", "rzd-door");
    for (let [x, f, y] of [["open", "Open", "anyone can walk in"], ["knock", "Knock", "they ask, you decide"], ["closed", "Closed", "nobody but you"]]) {
      let N = d("button", "rzd-pill" + (m.policy === x ? " is-on" : ""), f);
      N.title = y, N.type = "button", N.addEventListener("click", () => this._setPolicy(x)), T.appendChild(N);
    }
    if (u.appendChild(T), m.guests && m.guests.length) {
      let V = d("div", "rzd-guests");
      V.appendChild(d("span", "rzd-sub", "Let in"));
      for (let z of m.guests) {
        let d0 = d("div", "rzd-row");
        d0.appendChild(d("span", "rzd-name", z.username));
        let d1 = d("button", "rzd-btn rzd-btn-quiet", "Show out");
        d1.addEventListener("click", () => this._showOut(z.id)), d0.appendChild(d1), V.appendChild(d0);
      }
      u.appendChild(V);
    }
  }
  async ["_setPolicy"](k) {
    try {
      await w(b + "/me", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ policy: k }) }), this.say(k === "open" ? "Your door is open." : k === "closed" ? "Your door is closed." : "People will have to knock."), this.refresh();
    } catch (m) {
      this.say(m.message, "is-bad");
    }
  }
  async ["_showOut"](k) {
    try {
      await w(b + "/me", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ showOut: k }) }), this.refresh();
    } catch (m) {
      this.say(m.message, "is-bad");
    }
  }
  ["_drawKnocks"](k) {
    let m = this.panel.querySelector(".rzd-knocks"), u = this.panel.querySelector(".rzd-knock-list");
    m.hidden = !k.length, this.badge && (this.badge.hidden = !k.length, this.badge.textContent = String(k.length)), this.tab?.classList.toggle("is-knocking", k.length > 0);
    let E = new Set(this.waiting.map((g) => g.id)), v = k.filter((g) => !E.has(g.id));
    this.waiting = k, this.dispatchEvent(new CustomEvent("knocks", { detail: { waiting: k, fresh: v } })), u.innerHTML = "";
    for (let g of k) {
      let J = d("div", "rzd-row");
      J.appendChild(d("span", "rzd-name", g.username + " is at your door"));
      let T = d("button", "rzd-btn rzd-btn-go", "Let in");
      T.addEventListener("click", () => this._answer(g.id, true, g.username));
      let x = d("button", "rzd-btn rzd-btn-quiet", "Not now");
      x.addEventListener("click", () => this._answer(g.id, false, g.username)), J.appendChild(T), J.appendChild(x), u.appendChild(J);
    }
  }
  async ["_answer"](k, m, u) {
    try {
      let E = await w(b + "/knocks/" + k, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ letIn: m }) });
      this.say(m ? u + " can come in." : u + " was told not now."), this._drawKnocks(E.waiting || []);
    } catch (h) {
      this.say(h.message, "is-bad");
    }
  }
  ["_drawOthers"](k) {
    let m = this.panel.querySelector(".rzd-others");
    if (m.innerHTML = "", !k.length) {
      m.appendChild(d("p", "rzd-empty", "Nobody else has opened theirs yet."));
      return;
    }
    for (let u of k) m.appendChild(this._otherRow(u));
  }
  ["_otherRow"](k) {
    let m = d("div", "rzd-row");
    if (m.appendChild(d("span", "rzd-name", "" + k.username)), k.policy === "open" || k.knock === "let-in") {
      let u = d("button", "rzd-btn rzd-btn-go", "Go in");
      u.addEventListener("click", () => this._enter(k.room, k.username + "'s dorm")), m.appendChild(u);
    } else {
      if (k.knock === "waiting") {
        let E = d("button", "rzd-btn", "Waiting");
        E.disabled = true, m.appendChild(E);
      } else {
        let h = d("button", "rzd-btn", k.knock === "refused" ? "Ask again" : "Knock");
        h.addEventListener("click", () => this._knock(k, h)), m.appendChild(h);
      }
    }
    return m;
  }
  async ["_knock"](k, m) {
    m.disabled = true;
    try {
      let u = await w(b + "/" + k.id + "/knock", { method: "POST" });
      this.say(u.message || "Knocked."), u.state === "let-in" ? this._enter(k.room, k.username + "'s dorm") : m.textContent = "Waiting";
    } catch (E) {
      this.say(E.body && E.body.message ? E.body.message : E.message, "is-bad"), m.disabled = false;
    }
  }
  async ["_byCode"](k) {
    let m = String(k || "").trim().toUpperCase();
    if (m.length !== 6) return this.say("A dorm code is six characters.", "is-bad");
    try {
      let u = await w(b + "/by-code/" + encodeURIComponent(m));
      if (u.mayEnter) return this._enter(u.room, u.name);
      let E = await w(b + "/" + u.owner.id + "/knock", { method: "POST" });
      this.say(E.message || "Knocked."), this.refresh();
    } catch (h) {
      this.say(h.body && h.body.message ? h.body.message : "No dorm with that code.", "is-bad");
    }
  }
  ["_enter"](k, m) {
    (this.open || this.show) && this.toggle(false), this.dispatchEvent(new CustomEvent("enter", { detail: { room: k, label: m } }));
  }
}, D = { paintball: new URL("img/room-paintball.jpg", import.meta.url).href, dorm: new URL("img/room-dorm.jpg", import.meta.url).href };
async function nt({ current: k = null, enter: m = null, knock: u = null } = {}) {
  let E = [{ id: "reczone", name: "RECZONE", sub: "The main room", here: k === "reczone", go: () => location.assign("/game") }];
  try {
    let J = await w("/api/game/rooms");
    for (let T of J.rooms || []) E.push({ id: T.id, name: T.name, sub: T.sub, here: k === T.id, picture: D[T.id] || null, go: () => location.assign(T.href) });
  } catch {
  }
  let v = null, g = [];
  try {
    let [x, f] = await Promise.all([w(b + "/me"), w(b)]);
    v = x, g = f.dorms || [];
  } catch {
    return E;
  }
  E.push({ id: v.room, name: "Your dorm", sub: "Code " + v.code, here: k === v.room, picture: D.dorm, go: () => m ? m(v.room, v.name) : location.assign("/dorm") });
  for (let y of g) {
    let N = y.username + "'s dorm", p = y.policy === "open" || y.knock === "let-in";
    E.push({ id: y.room, name: N, sub: p ? "Open" : y.knock === "waiting" ? "Waiting at the door" : "Knock first", here: k === y.room, picture: D.dorm, go: () => p ? m ? m(y.room, N) : location.assign("/dorm/" + y.id) : u ? u(y) : location.assign("/dorm") });
  }
  return E;
}
function ot({ canReport: k = () => false } = {}) {
  return { id: "dorms", label: "Dorms", icon: "dorms", title: "Dorms", draw: (m, u) => {
    if (u.dorms?.drawInto(m), k()) {
      let E = document.createElement("button");
      E.type = "button", E.className = "wt-pill rp-open", E.textContent = "Report this dorm", E.addEventListener("click", () => u.show("report")), m.appendChild(E);
    }
  }, badge: function() {
    return this.watch?.dorms ? this.watch.dorms.waiting.length : 0;
  } };
}
function rt(k, m = null) {
  let u = new q({ room: m, show: (E) => {
    E ? (k.open || k.toggle(true), k.show("dorms")) : k.open && k.toggle(false);
  } });
  k.dorms = u;
  for (let E of k.extraPages || []) E.id === "dorms" && (E.watch = k);
  return k.addEventListener("closed", () => {
    u.open = false;
  }), u.addEventListener("knocks", () => k.refreshBadges()), u;
}
function at(k, m, u) {
  k.addEventListener("knocks", (E) => {
    for (let h of E.detail.fresh) u.say(h.username + " is at your door. Press X, then Dorms", "warn");
  });
}
var B = (k, m) => {
  let u = document.createElement("div");
  return u.className = "wt-empty lk-loading", u.textContent = m, k.appendChild(u), u;
};
function lt(k = {}) {
  let m = null, u = () => m ||= import("./c-42X3NNAW.js"), E = (v, g, J, T, x) => ({ id: v, label: g, icon: J, title: T, after: v === "avatar" ? "chat" : "avatar", draw: (f, y) => {
    let N = B(f, "Loading\u2026");
    u().then((V) => {
      y.page !== v || !N.isConnected || (N.remove(), V[x](f, y, k));
    }).catch((V) => {
      N.textContent = "This could not load. Close the watch and try again.", console.warn("[locker]", V.message);
    });
  }, leave: () => {
    m && m.then((f) => f.leave(v)).catch(() => {
    });
  } });
  return [E("avatar", "Avatar", "outfit", "Avatar", "drawAvatar"), E("store", "Store", "store", "Store", "drawStore")];
}
function ut({ game: k, net: m, tools: u, hud: E = null }) {
  let h = (v) => {
    E && E.say && E.say(v, "info");
  };
  window.addEventListener("keydown", (v) => {
    if (!(v.code !== "KeyG" || v.repeat || v.ctrlKey || v.metaKey || v.altKey) && !/^(INPUT|TEXTAREA|SELECT)$/.test(v.target && v.target.tagName) && document.pointerLockElement === k.canvas) {
      if (k.player.wielding === l.duck) {
        k.player.wielding = 0;
        return;
      }
      if (!m.og) {
        h("The OG Duck is in the Store.");
        return;
      }
      if (!u.mayHoldDuck()) {
        h(m.room === "PAINTBALL" ? "Ducks stay out of the arena." : "This game server needs an update before ducks can come out.");
        return;
      }
      k.player.wielding = l.duck, h("Your OG Duck #" + m.og + ". G puts it away.");
    }
  }), window.addEventListener("rz:og-duck", (v) => {
    let g = v.detail && v.detail.number;
    !g || m.og === g || (m.disconnect(), setTimeout(() => m.connect(), 400));
  });
}
var A = null, P = /* @__PURE__ */ new Set();
function M() {
  return !A && typeof AudioContext < "u" && (A = new AudioContext(), A.addEventListener("statechange", () => {
    A.state === "running" && G();
  })), A;
}
function G() {
  for (let k of [...P]) {
    P.delete(k);
    try {
      k();
    } catch {
    }
  }
}
function Q() {
  let k = M();
  k && k.state === "suspended" && k.resume().catch(() => {
  }), k && k.state === "running" && G();
}
if (typeof window < "u") {
  for (let o of ["pointerdown", "keydown", "touchstart"]) window.addEventListener(o, Q, { capture: true });
}
function O(k) {
  let m = M();
  if (m && m.state === "running") return k();
  P.add(k), m && typeof navigator < "u" && navigator.userActivation && navigator.userActivation.hasBeenActive && m.resume().catch(() => {
  });
}
function K(k, m = () => {
}, u = () => true) {
  O(() => {
    u() && k.play().then(m).catch((E) => {
      E && E.name === "NotAllowedError" && P.add(() => K(k, m, u));
    });
  });
}
var $ = { get(k, m) {
  try {
    let u = localStorage.getItem(k);
    return u === null ? m : u;
  } catch {
    return m;
  }
}, set(k, m) {
  try {
    localStorage.setItem(k, String(m));
  } catch {
  }
} };
function tt(k, m, u = Date.now() / 1e3) {
  let E = (k || []).filter((g) => g && g.duration > 1), h = E.reduce((g, J) => g + J.duration, 0);
  if (!h) return null;
  let v = ((u - (m || 0)) % h + h) % h;
  for (let g = 0; g < E.length; g++) {
    if (v < E[g].duration) return { song: E[g], index: g, offset: v, left: E[g].duration - v };
    v -= E[g].duration;
  }
  return { song: E[0], index: 0, offset: 0, left: E[0].duration };
}
var U = class extends EventTarget {
  constructor(k = "/api/music") {
    super(), this.url = k, this.radio = [], this.menu = null, this.epoch = 0, this.loaded = false, this._blobs = /* @__PURE__ */ new Map();
  }
  async ["load"]() {
    try {
      let k = await fetch(this.url, { credentials: "same-origin", headers: { Accept: "application/json" } });
      if (k.ok) {
        let m = await k.json();
        this.radio = Array.isArray(m.radio) ? m.radio : [], this.menu = m.menu || null, this.epoch = Number(m.epoch) || 0;
      }
    } catch {
    }
    return this.loaded = true, this.dispatchEvent(new CustomEvent("loaded")), this;
  }
  ["fileFor"](k) {
    if (!this.wholeFiles) return Promise.resolve(k.url);
    let m = this._blobs.get(k.url);
    if (!m) for (m = fetch(k.url, { credentials: "same-origin" }).then((u) => u.ok ? u.blob() : Promise.reject(new Error("HTTP " + u.status))).then((u) => URL.createObjectURL(u)), m.catch(() => this._blobs.delete(k.url)), this._blobs.set(k.url, m); this._blobs.size > 2; ) {
      let [u, E] = this._blobs.entries().next().value;
      this._blobs.delete(u), E.then((h) => URL.revokeObjectURL(h)).catch(() => {
      });
    }
    return m;
  }
  ["streamFailed"](k) {
    return this.wholeFiles || !k || !k.error ? false : (this.wholeFiles = true, true);
  }
}, L = class {
  constructor({ positional: k = false } = {}) {
    this.el = new Audio(), this.el.preload = "auto", this.positional = k, this.gain = null, this.panner = null;
  }
  ["_wire"]() {
    if (this.gain) return true;
    let k = M();
    if (!k) return false;
    let m = k.createMediaElementSource(this.el);
    return this.gain = k.createGain(), this.gain.gain.value = 0, this.positional ? (this.panner = k.createPanner(), this.panner.panningModel = "HRTF", this.panner.distanceModel = "inverse", this.panner.refDistance = 1.6, this.panner.maxDistance = 30, this.panner.rolloffFactor = 1.1, m.connect(this.gain).connect(this.panner).connect(k.destination)) : m.connect(this.gain).connect(k.destination), true;
  }
  ["level"](k, m = 0.25) {
    if (!this._wire()) return;
    let u = M();
    this.gain.gain.cancelScheduledValues(u.currentTime), this.gain.gain.setTargetAtTime(Math.max(0, k), u.currentTime, m / 3);
  }
  ["at"](k) {
    if (!this.panner) return;
    let m = this.panner;
    m.positionX ? (m.positionX.value = k[0], m.positionY.value = k[1], m.positionZ.value = k[2]) : m.setPosition(k[0], k[1], k[2]);
  }
};
function et(k) {
  let m = M();
  if (!m || !k) return;
  let u = m.listener, E = k.position, h = k.forward();
  u.positionX ? (u.positionX.value = E[0], u.positionY.value = E[1], u.positionZ.value = E[2], u.forwardX.value = h[0], u.forwardY.value = h[1], u.forwardZ.value = h[2], u.upX.value = 0, u.upY.value = 1, u.upZ.value = 0) : (u.setPosition(E[0], E[1], E[2]), u.setOrientation(h[0], h[1], h[2], 0, 1, 0));
}
var Y = class extends EventTarget {
  constructor({ game: k, library: m, model: u, clock: E = () => Date.now() }) {
    super(), this.game = k, this.library = m, this.model = u, this.clock = E, this.voice = new L({ positional: true }), this.state = this.defaults(true), this.readOnly = false, this.owner = "", this.locked = null, this.on = true, this.current = null, this.playing = false, this.begun = false, this._loading = null, this._resuming = false, u.setVolume(this.volume), this.voice.el.addEventListener("ended", () => {
      this.playing = false;
    }), this.voice.el.addEventListener("error", () => {
      this.library.streamFailed(this.voice.el) && (this.current = null, this._loading = null);
    });
  }
  ["defaults"](k = true) {
    return { mode: "live", songId: null, startedAt: 0, loop: false, paused: false, at: 0, volume: k ? Math.min(100, Math.max(0, Number($.get("rz.radio.volume", 60)) || 0)) : 60, v: 0 };
  }
  get ["volume"]() {
    return this.state.volume;
  }
  get ["mode"]() {
    return this.state.mode;
  }
  get ["loop"]() {
    return this.state.loop;
  }
  get ["paused"]() {
    return this.state.paused;
  }
  ["songs"]() {
    return (this.library.radio || []).filter((k) => k && k.duration > 1);
  }
  ["where"](k = this.clock()) {
    let m = this.songs();
    if (!m.length) return null;
    let u = this.state;
    if (u.mode === "live") return tt(m, this.library.epoch, k / 1e3);
    let E = m.findIndex((T) => T.id === u.songId);
    E < 0 && (E = 0);
    let v = m[E];
    if (u.paused) {
      let T = Math.min(u.at, v.duration);
      return { song: v, index: E, offset: T, left: v.duration - T };
    }
    let g = Math.max(0, (k - u.startedAt) / 1e3);
    if (u.loop) return g %= v.duration, { song: v, index: E, offset: g, left: v.duration - g };
    let J = m.reduce((x, f) => x + f.duration, 0);
    g %= J;
    for (let x = 0; x < m.length; x++) {
      let f = (E + x) % m.length;
      if (g < m[f].duration) return { song: m[f], index: f, offset: g, left: m[f].duration - g };
      g -= m[f].duration;
    }
    return { song: v, index: E, offset: 0, left: v.duration };
  }
  ["song"]() {
    let k = this.where();
    return k && k.song;
  }
  ["progress"]() {
    let k = this.where();
    if (!k) return { at: 0, length: 0 };
    let m = this.voice.el;
    return this.current === k.song && m.src && !m.paused ? { at: m.currentTime || 0, length: k.song.duration } : { at: k.offset, length: k.song.duration };
  }
  ["_may"]() {
    return this.locked ? (this._say("The radio is locked while the RecZone Alert plays."), false) : this.readOnly ? (this._say("This is " + (this.owner || "the owner") + "'s radio. It plays what they play."), false) : true;
  }
  ["_say"](k) {
    this.dispatchEvent(new CustomEvent("refused", { detail: k }));
  }
  ["_changed"]() {
    this.dispatchEvent(new CustomEvent("changed"));
  }
  ["_set"](k) {
    this.state = { ...this.state, ...k, v: (this.state.v || 0) + 1 }, this.dispatchEvent(new CustomEvent("local", { detail: this.state })), this._changed();
  }
  ["follow"](k, { mine: m = false, owner: u = "" } = {}) {
    let E = this.readOnly !== !m || this.owner !== u;
    if (this.readOnly = !m, this.owner = u, k) {
      let h = this.state;
      this.state = { ...this.state, ...k }, E = E || ["mode", "songId", "startedAt", "loop", "paused", "at", "volume"].some((v) => h[v] !== this.state[v]), this.model.setVolume(this.volume), this._level(), h.volume !== this.volume && this.dispatchEvent(new CustomEvent("volume"));
    }
    E && this._changed();
  }
  ["setVolume"](k) {
    if (!this._may()) return;
    let m = Math.round(Math.min(100, Math.max(0, Number(k) || 0)));
    m !== this.volume && ($.set("rz.radio.volume", m), this._set({ volume: m }), this.model.setVolume(m), this._level(), this.dispatchEvent(new CustomEvent("volume")));
  }
  ["_level"]() {
    if (!this.voice.gain) return;
    let k = this.on && !this.locked ? (this.volume / 100) ** 2 : 0;
    this.voice.level(k * 1.2);
  }
  ["begin"]() {
    this.begun = true;
  }
  ["setOn"](k) {
    this.on = !!k, this.on ? this._level() : (this.voice.level(0, 0.4), setTimeout(() => {
      this.on || this.voice.el.pause();
    }, 600));
  }
  ["lock"](k) {
    let m = !!this.locked;
    this.locked = k || null, !!this.locked !== m && (this.locked && (this.voice.level(0, 0.15), this.voice.el.pause(), this.playing = false), this._level(), this._changed());
  }
  ["pause"]() {
    if (this.paused || !this._may()) return;
    let k = this.where();
    this.mode === "mine" && k ? this._set({ paused: true, songId: k.song.id, at: k.offset }) : this._set({ paused: true });
  }
  ["resume"]() {
    !this.paused || !this._may() || (this.begun = true, this.mode === "mine" ? this._set({ paused: false, startedAt: this.clock() - this.state.at * 1e3 }) : this._set({ paused: false }));
  }
  ["togglePause"]() {
    this.paused ? this.resume() : this.pause();
  }
  ["pick"](k) {
    let m = this.songs();
    if (!m.length || !this._may()) return;
    let u = m[(k % m.length + m.length) % m.length];
    this.begun = true, this._set({ mode: "mine", songId: u.id, startedAt: this.clock(), paused: false, at: 0 });
  }
  ["_at"]() {
    let k = this.where();
    return k ? k.index : 0;
  }
  ["next"]() {
    this.pick(this._at() + 1);
  }
  ["previous"]() {
    let k = this.where();
    k && k.offset > 3 ? this.pick(k.index) : this.pick(this._at() - 1);
  }
  ["setLoop"](k) {
    if (!this._may()) return;
    let m = this.where();
    if (!m) return;
    let u = this.paused ? { at: m.offset } : { startedAt: this.clock() - m.offset * 1e3 };
    this._set({ mode: "mine", loop: !!k, songId: m.song.id, ...u });
  }
  ["goLive"]() {
    this._may() && this._set({ mode: "live", loop: false, paused: false });
  }
  ["update"](k) {
    let m = this.where(), u = m && m.song, E = this.locked ? "ALERT" : u ? this.paused ? "PAUSED" : this.mode === "live" ? "LIVE" : this.loop ? "LOOP" : "PICKED" : "";
    if (this.locked) {
      let J = this.locked;
      this.model.show({ title: (J.label || "RecZone Alert").toUpperCase(), artist: J.from || "RecZone Management Team", tag: E });
    } else this.model.show(u ? { title: u.title, artist: u.artist, tag: E } : { note: this.library.loaded ? "No songs yet" : "Tuning in\u2026" });
    let v = false;
    if (this.model.root.parent && this.game.camera) {
      let T = this.model.root.worldMatrix(), x = this.game.camera.position;
      v = Math.hypot(T[12] - x[0], T[13] - x[1], T[14] - x[2]) < 6;
    }
    if (this.model.draw(k, (this.playing || !!this.locked) && this.on && (this.volume > 0 || !!this.locked), v), this.model.root.parent) {
      let f = this.model.root.worldMatrix();
      this.voice.at([f[12], f[13] + 0.2, f[14]]);
    }
    et(this.game.camera);
    let g = this.voice.el;
    if (!u || !this.on || !this.begun || this.paused || this.locked) {
      g.paused || g.pause(), this.playing = false;
      return;
    }
    if (!this.current || this.current.url !== u.url) {
      this._start(u);
      return;
    }
    if (g.loop = this.loop && this.mode === "mine", !this._loading) {
      if (g.paused && g.src && !this._resuming) {
        this._resuming = true, g.currentTime = m.offset, K(g, () => {
          this._resuming = false, this.playing = true, this._level(), this._changed();
        }, () => !this.paused && !this.locked), setTimeout(() => {
          this._resuming = false;
        }, 2e3);
        return;
      }
      this.playing && !g.paused && Math.abs(g.currentTime - m.offset) > 0.75 && m.left > 1.5 && m.offset > 0.5 && (g.currentTime = m.offset);
    }
  }
  ["_start"](k) {
    this._loading !== k.url && (this._loading = k.url, this.current = k, this.playing = false, this.dispatchEvent(new CustomEvent("song", { detail: k })), this._changed(), this.library.fileFor(k).then((m) => {
      if (this.current !== k) return;
      let u = this.voice.el;
      u.src = m, u.loop = this.loop && this.mode === "mine", O(() => {
        if (this.current !== k || this.paused || this.locked) return;
        let E = () => {
          let v = this.where();
          return v && v.song.url === k.url ? v.offset : 0;
        };
        this.voice._wire(), u.currentTime = E();
        let h = () => u.play().then(() => {
          this.playing = true, this._level(), this._changed();
          let v = E();
          Math.abs(u.currentTime - v) > 0.3 && (u.currentTime = v);
        }).catch((v) => {
          v && v.name === "NotAllowedError" && P.add(() => {
            this.current === k && !this.paused && !this.locked && (u.currentTime = E(), h());
          });
        });
        h();
      });
    }).catch((m) => console.warn("[radio] could not load a song:", m.message)).finally(() => {
      this._loading === k.url && (this._loading = null);
    }));
  }
}, H = class {
  constructor({ library: k, hud: m }) {
    this.library = k, this.hud = m, this.voice = new L(), this.voice.el.loop = true, this.voice.el.addEventListener("error", () => {
      k.streamFailed(this.voice.el) && this.start();
    }), this.muted = $.get("rz.menu.music", "on") === "off", this.done = false, this.button = this._button(), k.addEventListener("loaded", () => this.start()), k.loaded && this.start(), m.addEventListener("play", () => this.stop());
  }
  ["_button"]() {
    if (typeof document > "u" || !this.hud.start) return null;
    let k = this.hud.start.querySelector(".hud-startcard");
    if (!k) return null;
    let m = document.createElement("button");
    return m.type = "button", m.className = "hud-music", m.hidden = true, m.addEventListener("click", (u) => {
      u.stopPropagation(), this.muted = !this.muted, $.set("rz.menu.music", this.muted ? "off" : "on"), this._paint(), this.muted ? this.voice.level(0, 0.3) : (this.start(), this.voice.level(0.55, 0.6));
    }), k.appendChild(m), m;
  }
  ["_paint"]() {
    if (!this.button) return;
    let k = this.library.menu;
    this.button.hidden = !k || this.done, this.button.classList.toggle("is-off", this.muted), this.button.textContent = this.muted ? "\u266A Music off" : "\u266A " + (k ? k.title : ""), this.button.title = this.muted ? "Turn the menu music on" : "Turn the menu music off";
  }
  ["start"]() {
    let k = this.library.menu;
    this._paint(), !(!k || this.done || this.muted) && this.library.fileFor(k).then((m) => {
      this.done || (this.voice.el.src !== new URL(m, location.href).href && (this.voice.el.src = m), this.voice._wire(), K(this.voice.el, () => this.voice.level(0.55, 1.2), () => !this.done && !this.muted));
    }).catch(() => {
    });
  }
  ["stop"]() {
    this.done = true, this._paint(), this.voice.level(0, 0.9), setTimeout(() => {
      let k = this.voice.el;
      k.pause(), k.removeAttribute("src"), k.load();
    }, 1200);
  }
}, R = { intro: 7, outro: 3 }, S = (k) => 440 * 2 ** ((k - 69) / 12);
function st(k) {
  let m = k.sampleRate, u = (z) => k.createBuffer(1, Math.ceil(z * m), m), E = (d0, d1, d2, d3 = 0.9, d4 = 0.2) => {
    let d5 = S(d2), d6 = [[1, 1, 1], [2, 0.42, 1.6], [3.01, 0.22, 2.5], [4.2, 0.1, 3.6]], d7 = Math.floor(d1 * m), d8 = Math.floor(d3 * m);
    for (let d9 = 0; d9 < d8 && d7 + d9 < d0.length; d9++) {
      let dd = d9 / m, dC = 0;
      for (let [dc, dl, dF] of d6) dC += dl * Math.sin(2 * Math.PI * d5 * dc * dd) * Math.exp(-dd * 3.1 * dF);
      d0[d7 + d9] += d4 * Math.min(1, dd / 4e-3) * dC;
    }
  }, g = (d0, d1, d2, d3 = 0.36, d4 = 0.32) => {
    let d5 = S(d2), d6 = 0, d7 = Math.floor(d1 * m), d8 = Math.floor(d3 * m);
    for (let d9 = 0; d9 < d8 && d7 + d9 < d0.length; d9++) {
      let dd = d9 / m;
      d6 += 2 * Math.PI * d5 * (1 + 0.7 * Math.exp(-dd * 32)) / m, d0[d7 + d9] += d4 * Math.min(1, dd / 3e-3) * Math.exp(-dd * 7.5) * Math.sin(d6);
    }
  }, J = (d0, d1, d2, d3, d4, d5) => {
    let d6 = 0, d7 = Math.floor(d1 * m), d8 = Math.floor(d4 * m);
    for (let d9 = 0; d9 < d8 && d7 + d9 < d0.length; d9++) {
      let dd = d9 / m, dC = dd / d4, dc = S(d2) * (S(d3) / S(d2)) ** dC * (1 + 0.025 * Math.sin(2 * Math.PI * 7 * dd));
      d6 += 2 * Math.PI * dc / m, d0[d7 + d9] += d5 * Math.sin(Math.PI * dC) ** 0.6 * (Math.sin(d6) + 0.3 * Math.sin(d6 * 2));
    }
  }, T = (d0, d1, d2, d3, d4) => {
    let d5 = Math.floor(d1 * m), d6 = Math.floor(d3 * m);
    for (let d7 = 0; d7 < d6 && d5 + d7 < d0.length; d7++) {
      let d8 = d7 / m, d9 = Math.min(1, d8 / 0.25) * Math.min(1, (d3 - d8) / 0.9), dd = 0;
      for (let dC of d2) dd += Math.sin(2 * Math.PI * S(dC) * d8 + Math.sin(2 * Math.PI * 4.5 * d8) * 0.6);
      d0[d5 + d7] += d4 * d9 * dd;
    }
  }, x = (z) => {
    let d0 = 0;
    for (let d3 = 0; d3 < z.length; d3++) d0 = Math.max(d0, Math.abs(z[d3]));
    let d1 = d0 > 0.85 ? 0.85 / d0 : 1, d2 = Math.floor(0.05 * m);
    for (let d4 = 0; d4 < z.length; d4++) {
      let d5 = Math.min(1, (z.length - 1 - d4) / d2);
      z[d4] *= d1 * d5;
    }
  }, f = u(R.intro), y = f.getChannelData(0);
  J(y, 0, 43, 79, 1.2, 0.16), [72, 76, 79, 84, 81, 79, 76, 79].forEach((z, d0) => E(y, 1.25 + d0 * 0.28, z, 0.8, 0.17)), [48, 43, 45, 43].forEach((z, d0) => g(y, 1.25 + d0 * 0.56, z)), E(y, 3.55, 86, 0.3, 0.12), E(y, 3.69, 88, 0.3, 0.12);
  for (let z of [72, 76, 79, 84, 88]) E(y, 3.85, z, 2.9, 0.11);
  g(y, 3.85, 36, 0.6, 0.38), T(y, 3.85, [60, 67], 3, 0.045), [96, 100, 103, 108].forEach((d0, d1) => E(y, 4.2 + d1 * 0.22, d0, 0.5, 0.05)), x(y);
  let N = u(R.outro), V = N.getChannelData(0);
  return E(V, 0.08, 79, 1, 0.2), E(V, 0.5, 76, 1, 0.2), E(V, 0.92, 84, 1.9, 0.2), g(V, 0.92, 48, 0.5, 0.3), x(V), { intro: f, outro: N };
}
var F = /* @__PURE__ */ new WeakMap();
function it(k) {
  return F.has(k) || F.set(k, st(k)), F.get(k);
}
var W = { dorm: 2500, room: 4e3 }, I = class {
  constructor({ positional: k, clock: m }) {
    this.positional = k, this.clock = m, this.voice = new L({ positional: k }), this.id = null, this.sources = [], this.out = null, this.panner = null, this.clipStarted = false;
  }
  ["_wire"]() {
    return this.out ? true : !M() || !this.voice._wire() ? false : (this.out = this.voice.gain, true);
  }
  ["sync"](k, m, u = null) {
    if (!k) {
      this.stop();
      return;
    }
    if (u && this.voice.at(u), this.id === k.id) {
      this._clip(k, m);
      return;
    }
    this.stop(), this.id = k.id, O(async () => {
      if (this.id !== k.id || !this._wire()) return;
      let E = M(), { intro: v, outro: g } = it(E);
      if (this.id !== k.id) return;
      this.voice.level((k.volume / 100) ** 2 * 1.3, 0.05);
      let J = (this.clock() - k.startedAt) / 1e3, T = (y) => E.currentTime + Math.max(0, y - J), x = (y, N) => {
        let V = N + y.duration;
        if (J >= V) return;
        let z = E.createBufferSource();
        z.buffer = y, z.connect(this.out), z.start(T(N), Math.max(0, J - N)), this.sources.push(z);
      };
      x(v, 0);
      let f = k.clip ? k.clip.duration : 4;
      x(g, (k.intro ?? R.intro) + f), k.clip && (this.voice.el.src = k.clip.url, this.voice.el.preload = "auto"), this.clipStarted = false;
    });
  }
  ["_clip"](k, m) {
    if (!k.clip || !this.out) return;
    let u = (m - k.startedAt) / 1e3 - (k.intro ?? R.intro), E = this.voice.el;
    if (u < -0.05 || u > k.clip.duration) {
      !E.paused && u > k.clip.duration && E.pause();
      return;
    }
    if (!this.clipStarted) {
      this.clipStarted = true, E.currentTime = Math.max(0, u), E.play().catch(() => {
        this.clipStarted = false;
      });
      return;
    }
    !E.paused && Math.abs(E.currentTime - u) > 0.6 && (E.currentTime = u);
  }
  ["stop"]() {
    if (!this.id) return;
    this.id = null;
    for (let m of this.sources) try {
      m.stop();
    } catch {
    }
    this.sources = [];
    let k = this.voice.el;
    k.pause(), k.removeAttribute("src"), k.load(), this.voice.gain && this.voice.level(0, 0.05);
  }
}, Z = class {
  constructor() {
    this.node = null, this.id = null;
  }
  ["show"](k) {
    if (typeof document > "u") return;
    if (!k) {
      this.node && (this.node.hidden = true), this.id = null;
      return;
    }
    if (this.node || (this.node = document.createElement("div"), this.node.className = "rza-banner", this.node.setAttribute("role", "alert"), this.node.innerHTML = '<b class="rza-head"><i class="rza-star"></i><span>RECZONE ALERT</span></b><div class="rza-crawl"><span class="rza-text"></span></div>', document.body.appendChild(this.node)), this.node.hidden = false, this.id === k.id) return;
    this.id = k.id;
    let m = k.label || "Announcement", u = k.from || "RecZone Management Team", E = /^[aeiou]/i.test(m) ? "an" : "a", v = k.scope === "everyone" ? "everyone in RecZone" : "every radio in RecZone", g = ["Heads up, RecZone! The " + u + " has " + E + " " + m + " for " + v + ".", k.message, k.clip && k.clip.title ? "Now playing: " + k.clip.title : "", "Thanks for playing!"].filter(Boolean).join("   \u2726   ");
    this.node.querySelector(".rza-head span").textContent = k.kind === "test" ? "RECZONE TEST" : "RECZONE ALERT";
    let J = this.node.querySelector(".rza-text");
    J.textContent = g + "     " + g + "     ", J.style.animationDuration = Math.max(14, g.length * 0.3) + "s";
  }
}, X = class extends EventTarget {
  constructor({ net: k, player: m = null, radioModel: u = null, url: E = "/api/radio" }) {
    super(), this.net = k, this.player = m, this.radioModel = u, this.url = E, this.offset = 0, this._best = 1 / 0, this.takeover = null, this.dorm = null, this._timer = 0, this._pushTimer = 0, this._pushing = null, this._lastPushed = 0, this._stopped = false, this._asked = 0, this._changedSince = 0, this.atRadio = new I({ positional: true, clock: () => this.now() }), this.everywhere = new I({ positional: false, clock: () => this.now() }), this.banner = new Z(), m && (m.clock = () => this.now(), m.addEventListener("local", () => {
      this._changedSince = Date.now(), this._queuePush();
    })), k && k.addEventListener && k.addEventListener("connected", () => {
      this.dorm = null, this.ask();
    });
  }
  ["now"]() {
    return Date.now() + this.offset;
  }
  ["start"]() {
    return this._stopped = false, this.ask(), this;
  }
  ["stop"]() {
    this._stopped = true, clearTimeout(this._timer);
  }
  ["_room"]() {
    return this.net && this.net.room || "";
  }
  async ["ask"]() {
    if (clearTimeout(this._timer), this._stopped) return;
    let k = this._room(), m = Date.now();
    this._asked = m;
    try {
      let u = await fetch(this.url + "?room=" + encodeURIComponent(k), { credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store" });
      if (u.ok) {
        let E = Date.now(), h = await u.json(), v = E - m;
        Number.isFinite(h.now) && (v <= this._best * 1.5 || v < 120) && (this._best = Math.min(this._best * 1.02, v), this.offset = h.now - (m + E) / 2), this._take(h, k);
      }
    } catch {
    }
    this._stopped || (this._timer = setTimeout(() => this.ask(), /^DORM-/i.test(this._room()) ? W.dorm : W.room));
  }
  ["_take"](k, m) {
    let u = k.takeover && k.takeover.endsAt > this.now() ? k.takeover : null;
    if ((u && u.id) !== (this.takeover && this.takeover.id) && (this.takeover = u, this.dispatchEvent(new CustomEvent("takeover", { detail: u }))), !this.player || m !== this._room()) return;
    let E = k.dorm || null;
    if (!E) {
      this.player.follow(null, { mine: true }), this.dorm = null;
      return;
    }
    let h = !this.dorm || this.dorm.owner !== E.owner;
    if (this.dorm = E, !E.mine) {
      this.player.follow(E.state || this.player.defaults(false), { mine: false, owner: E.ownerName });
      return;
    }
    this._pushing || this._pushTimer || Date.now() - this._lastPushed < 4e3 || this._changedSince > this._asked ? this.player.follow(null, { mine: true }) : E.state && (h || E.state.v > (this.player.state.v || 0)) ? this.player.follow(E.state, { mine: true }) : !E.state && h ? this.player.follow(this.player.defaults(true), { mine: true }) : this.player.follow(null, { mine: true }), !E.state && h && this._queuePush();
  }
  ["_queuePush"]() {
    this.dorm && !this.dorm.mine || (clearTimeout(this._pushTimer), this._pushTimer = setTimeout(() => {
      this._pushTimer = 0, this._push();
    }, 300));
  }
  async ["_push"]() {
    if (!this.player) return;
    let k = { ...this.player.state };
    this._pushing = k;
    try {
      let m = await fetch(this.url + "/dorm", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ state: k }) });
      if (m.ok) {
        let u = await m.json();
        u.state && this.player.state === k ? this.player.state = { ...this.player.state, v: u.state.v } : u.state && (this.player.state.v = Math.max(this.player.state.v || 0, u.state.v));
      }
    } catch {
    }
    this._lastPushed = Date.now(), this._pushing = null;
  }
  ["update"]() {
    let k = this.now(), m = this.takeover;
    m && k > m.endsAt && (this.takeover = m = null, this.dispatchEvent(new CustomEvent("takeover", { detail: null })));
    let u = m && k >= m.startedAt - 200 ? m : null, E = this.player && this.radioModel && this.radioModel.root.visible && this.player.on ? this.player : null, h = !this.player || this.player.begun;
    if (u && u.scope === "everyone") this.everywhere.sync(h ? u : null, k), this.atRadio.sync(null, k);
    else {
      if (u && E) {
        let v = this.radioModel.root.worldMatrix();
        this.atRadio.sync(h ? u : null, k, [v[12], v[13] + 0.2, v[14]]), this.everywhere.sync(null, k);
      } else this.atRadio.sync(null, k), this.everywhere.sync(null, k);
    }
    this.player && this.player.lock(u && (u.scope === "everyone" || E) ? u : null), this.banner.show(u && h && (u.scope === "everyone" || E) ? u : null);
  }
  async ["clips"]() {
    let k = await fetch(this.url + "/clips", { credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store" });
    return k.ok ? k.json() : null;
  }
  async ["startTakeover"]({ clipId: k, message: m, volume: u, scope: E, kind: h }) {
    let v = await (await fetch(this.url + "/takeover", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ clipId: k, message: m, volume: u, scope: E, kind: h }) })).json().catch(() => ({ ok: false, message: "The website did not answer." }));
    return v.ok && this.ask(), v;
  }
  async ["stopTakeover"]() {
    let k = await fetch(this.url + "/takeover/stop", { method: "POST", credentials: "same-origin" });
    return this.ask(), k.ok;
  }
};
export {
  nt as a,
  ot as b,
  rt as c,
  at as d,
  lt as e,
  ut as f,
  U as g,
  Y as h,
  H as i,
  X as j
};
