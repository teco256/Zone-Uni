import { a as c, b as l, c as F, d as k, e as m, f as u, g as S, i as h, j as A } from "./c-7WVWS6WJ.js";
import { a as v, b as Z } from "./c-ZGTNTUL7.js";
import { a as g, b, c as J, d as O, e as M, f as T, g as D } from "./c-H3C27IZN.js";
import { B as s, C as G, E as x, F as f, L as y, c as N, d as o, e as r, g as X, h as a, i as P, m as L, p, q as i, r as B, s as V, v as n, w as z, x as Y } from "./c-USQKEFSE.js";
var ct = { zenith: [6e-3, 0.01, 0.035], horizon: [0.025, 0.035, 0.085], ground: [8e-3, 0.01, 0.02], sun: [0.2, 0.25, 0.4], elevation: 42, azimuth: 120, size: 28e-4, stars: 1, dark: 1 }, Ct = [{ at: 0, ...ct }, { at: 0.5, ...ct }, { at: 0.53, ...ct, sun: [0, 0, 0] }, { at: 0.535, ...ct, zenith: [0.01, 0.015, 0.05], horizon: [0.06, 0.05, 0.1], sun: [0, 0, 0], elevation: -6, azimuth: 70, size: 6e-3, stars: 0.8 }, { at: 0.58, zenith: [0.06, 0.08, 0.2], horizon: [0.62, 0.38, 0.3], ground: [0.06, 0.05, 0.06], sun: [0.9, 0.55, 0.35], elevation: 2, azimuth: 70, size: 8e-3, stars: 0.1, dark: 0.55 }, { at: 0.62, zenith: [0.17, 0.34, 0.72], horizon: [0.76, 0.78, 0.86], ground: [0.13, 0.13, 0.15], sun: [1, 0.88, 0.72], elevation: 20, azimuth: 100, size: 5e-3, stars: 0, dark: 0.15 }, { at: 0.7, zenith: [0.2, 0.4, 0.78], horizon: [0.72, 0.83, 0.94], ground: [0.16, 0.17, 0.2], sun: [1, 0.96, 0.88], elevation: 55, azimuth: 160, size: 4e-3, stars: 0, dark: 0 }, { at: 0.82, zenith: [0.2, 0.4, 0.78], horizon: [0.72, 0.83, 0.94], ground: [0.16, 0.17, 0.2], sun: [1, 0.95, 0.85], elevation: 48, azimuth: 215, size: 4e-3, stars: 0, dark: 0 }, { at: 0.88, zenith: [0.14, 0.16, 0.34], horizon: [0.95, 0.52, 0.26], ground: [0.1, 0.08, 0.07], sun: [1, 0.65, 0.35], elevation: 3, azimuth: 250, size: 8e-3, stars: 0, dark: 0.45 }, { at: 0.92, zenith: [0.035, 0.04, 0.12], horizon: [0.24, 0.12, 0.2], ground: [0.03, 0.025, 0.04], sun: [0.18, 0.08, 0.06], elevation: -3, azimuth: 255, size: 8e-3, stars: 0.45, dark: 0.85 }, { at: 0.935, zenith: [0.012, 0.016, 0.05], horizon: [0.05, 0.04, 0.09], ground: [0.01, 0.01, 0.02], sun: [0, 0, 0], elevation: -6, azimuth: 255, size: 6e-3, stars: 0.85, dark: 0.95 }, { at: 0.94, ...ct, sun: [0, 0, 0] }, { at: 0.97, ...ct }, { at: 1, ...ct }], nt = (U, H, d0) => U + (H - U) * d0, Pt = (U, H, d0) => [nt(U[0], H[0], d0), nt(U[1], H[1], d0), nt(U[2], H[2], d0)], cn = (U) => U * U * (3 - 2 * U);
function ln(U) {
  let H = (U % 1 + 1) % 1, d0 = 0;
  for (; d0 < Ct.length - 2 && Ct[d0 + 1].at <= H; ) d0++;
  let d1 = Ct[d0], d2 = Ct[d0 + 1], d3 = cn(d2.at > d1.at ? (H - d1.at) / (d2.at - d1.at) : 0);
  return { zenith: Pt(d1.zenith, d2.zenith, d3), horizon: Pt(d1.horizon, d2.horizon, d3), ground: Pt(d1.ground, d2.ground, d3), sunColour: Pt(d1.sun, d2.sun, d3), sunElevation: nt(d1.elevation, d2.elevation, d3), sunAzimuth: nt(d1.azimuth, d2.azimuth, d3), sunSize: nt(d1.size, d2.size, d3), stars: nt(d1.stars, d2.stars, d3), dark: nt(d1.dark, d2.dark, d3) };
}
function dn(U, H) {
  return (U % H + H) % H / H;
}
var Nt = class {
  constructor(U, { length: H = 1800, offset: d0 = 0, lamps: d1 = [0.45, 1], ambient: d2 = 1 } = {}) {
    this.ambient = d2, this.game = U, this.length = H, this.offset = d0, this.lamps = d1, this.fixed = null, this.now = null, this._last = -1 / 0, U.sky instanceof i || (U.sky = new i());
  }
  ["phase"]() {
    return this.fixed !== null && this.fixed !== void 0 ? (this.fixed % 1 + 1) % 1 : dn(Date.now() / 1e3 + this.offset * this.length, this.length);
  }
  ["update"](U = false) {
    let H = performance.now();
    if (!U && H - this._last < 1e3) return this.now;
    this._last = H;
    let d0 = ln(this.phase()), d1 = this.game.sky;
    return d1.zenith = d0.zenith, d1.horizon = d0.horizon, d1.ground = d0.ground, d1.sunColour = d0.sunColour, d1.sunElevation = d0.sunElevation, d1.sunAzimuth = d0.sunAzimuth, d1.sunSize = d0.sunSize, d1.stars = d0.stars, d1.ambient = this.ambient, this.game.renderer && (this.game.renderer.lightScale = nt(this.lamps[0], this.lamps[1], d0.dark)), this.now = d0, d0;
  }
}, un = /* @__PURE__ */ new Set(["box", "cylinder", "sphere", "plane", "stroke"]);
function pn(U, H) {
  let d0 = H.material;
  return JSON.stringify([U.colour, U.roughness, U.metallic, U.emissive || 0, U.opacity ?? 1, U.castShadow !== false, U.texture || "", d0 && d0.doubleSided ? 1 : 0]);
}
function Fe({ scene: U, world: d0, cell: d1 = 18, min: d2 = 2 }) {
  let d3 = /* @__PURE__ */ new Map();
  for (let d7 of d0.doc.list()) {
    if (!un.has(d7.kind) || d7.hidden) continue;
    let d8 = d0.nodes.get(d7.id);
    if (!d8 || !d8.mesh || !d8.material || !d8.visible || d8.light || d8.skin || !d8.mesh.positions || !d8.mesh.indices) continue;
    let d9 = d8.worldMatrix(), dd = pn(d7, d8) + "|" + Math.floor(d9[12] / d1) + "," + Math.floor(d9[14] / d1), dC = d3.get(dd);
    dC || d3.set(dd, dC = []), dC.push(d8);
  }
  let d4 = new r("static batches");
  d4.unpickable = true;
  let d5 = [], d6 = o.create();
  for (let dc of d3.values()) {
    if (dc.length < d2) continue;
    let dl = 0, dF = 0;
    for (let dh of dc) dl += dh.mesh.positions.length / 3, dF += dh.mesh.indices.length;
    let dk = new Float32Array(dl * 3), dm = new Float32Array(dl * 3), du = new Float32Array(dl * 2), dj = dl > 65535 ? new Uint32Array(dF) : new Uint16Array(dF), dW = 0, dS = 0;
    for (let dA of dc) {
      let dv = dA.worldMatrix();
      N.normalFromMat4(d6, dv);
      let dZ = dA.mesh.positions, dg = dA.mesh.normals, db = dA.mesh.uvs, dJ = dA.mesh.indices, dO = dZ.length / 3;
      for (let dM = 0; dM < dO; dM++) {
        let dT = dZ[dM * 3], dD = dZ[dM * 3 + 1], ds = dZ[dM * 3 + 2];
        if (dk[(dW + dM) * 3] = dv[0] * dT + dv[4] * dD + dv[8] * ds + dv[12], dk[(dW + dM) * 3 + 1] = dv[1] * dT + dv[5] * dD + dv[9] * ds + dv[13], dk[(dW + dM) * 3 + 2] = dv[2] * dT + dv[6] * dD + dv[10] * ds + dv[14], dg) {
          let dG = dg[dM * 3], dR = dg[dM * 3 + 1], dx = dg[dM * 3 + 2], df = d6[0] * dG + d6[3] * dR + d6[6] * dx, dy = d6[1] * dG + d6[4] * dR + d6[7] * dx, dN = d6[2] * dG + d6[5] * dR + d6[8] * dx, dr = Math.hypot(df, dy, dN) || 1;
          dm[(dW + dM) * 3] = df / dr, dm[(dW + dM) * 3 + 1] = dy / dr, dm[(dW + dM) * 3 + 2] = dN / dr;
        }
        db && (du[(dW + dM) * 2] = db[dM * 2], du[(dW + dM) * 2 + 1] = db[dM * 2 + 1]);
      }
      for (let dX = 0; dX < dJ.length; dX++) dj[dS + dX] = dJ[dX] + dW;
      dW += dO, dS += dJ.length;
    }
    let dE = new r("static batch");
    dE.mesh = { positions: dk, normals: dm, uvs: du, indices: dj }, dE.material = dc[0].material, d4.add(dE);
    for (let da of dc) da.batched = true;
    d5.push(...dc);
  }
  return U.add(d4), { root: d4, pieces: d5.length, draws: d4.children.length, undo() {
    for (let dP of d5) dP.batched = false;
    d4.parent && (d4.parent.remove ? d4.parent.remove(d4) : d4.dispose());
  } };
}
function Ue({ game: U, world: H, watch: d0 = null, hud: d1 = null }) {
  let d2 = [], d3 = () => {
    d2 = H.doc.list().filter((dC) => /^portal:/.test(dC.tag || "")).map((dC) => ({ go: dC.tag.slice(7), min: dC.position.map((dc, dl) => dc - Math.abs(dC.scale[dl]) / 2), max: dC.position.map((dc, dl) => dc + Math.abs(dC.scale[dl]) / 2) }));
  };
  H.doc.addEventListener("reset", () => setTimeout(d3, 0)), d3();
  let d4 = (dC) => {
    d1 && typeof d1.say == "function" && d1.say(dC, "info");
  }, d5 = () => {
    let dC = U.player.position, dc = Math.hypot(dC[0], dC[2]) || 1;
    dC[0] -= dC[0] / dc * 2.2, dC[2] -= dC[2] / dc * 2.2, U.player.velocity[0] = U.player.velocity[2] = 0;
  }, d6 = (dC, dc) => {
    if (d4("Going to " + dc), typeof document < "u") {
      let dl = document.createElement("div");
      dl.className = "portal-veil", dl.innerHTML = "<b>" + dc + "</b>", document.body.appendChild(dl), requestAnimationFrame(() => dl.classList.add("is-on"));
    }
    setTimeout(() => location.assign(dC), 450);
  }, d7 = (dC) => {
    d5(), d0 && (d0.toggle(true), d0.show(dC));
  };
  async function d8(dC) {
    switch (dC) {
      case "arena": {
        let dc = false;
        try {
          let dl = await fetch("/api/game/rooms", { credentials: "same-origin", headers: { Accept: "application/json" } });
          dc = ((dl.ok ? await dl.json() : {}).rooms || []).some((dF) => dF.id === "paintball");
        } catch {
          dc = false;
        }
        dc ? d6("/game/paintball", "RZ LaserTag") : (d5(), d4("RZ LaserTag is invite only for now."));
        return;
      }
      case "dorms":
        d6("/dorm", "your dorm");
        return;
      case "create":
        d6("/dorm?build=1", "your dorm, to build");
        return;
      case "games":
      case "rooms":
        d7("rooms");
        return;
      case "shop":
        d7("store");
        return;
      case "quests":
        d5(), d4("Quests are coming soon.");
        return;
      default:
        d5();
    }
  }
  let d9 = null, dd = 0;
  return U.addUpdater((dC) => {
    if (dd = Math.max(0, dd - dC), !d2.length) return;
    let dc = U.player.position, dl = [dc[0], dc[1] + 0.9, dc[2]], dF = d2.find((dk) => dl[0] >= dk.min[0] && dl[0] <= dk.max[0] && dl[1] >= dk.min[1] && dl[1] <= dk.max[1] && dl[2] >= dk.min[2] && dl[2] <= dk.max[2]) || null;
    dF !== d9 && (d9 = dF, !(!dF || dd > 0) && (dd = 1.5, d8(dF.go)));
  }), { get portals() {
    return d2;
  }, go: d8 };
}
function Ie(U) {
  let H = U.map((d3) => [d3[0], d3[1]]).sort((d3, d4) => d3[0] - d4[0] || d3[1] - d4[1]);
  if (H.length < 3) return H;
  let d0 = (d3, d4, d5) => (d4[0] - d3[0]) * (d5[1] - d3[1]) - (d4[1] - d3[1]) * (d5[0] - d3[0]), d1 = [], d2 = [];
  for (let d3 of H) {
    for (; d1.length >= 2 && d0(d1[d1.length - 2], d1[d1.length - 1], d3) <= 1e-9; ) d1.pop();
    d1.push(d3);
  }
  for (let d4 = H.length - 1; d4 >= 0; d4--) {
    let d5 = H[d4];
    for (; d2.length >= 2 && d0(d2[d2.length - 2], d2[d2.length - 1], d5) <= 1e-9; ) d2.pop();
    d2.push(d5);
  }
  return d1.slice(0, -1).concat(d2.slice(0, -1));
}
function hn(U, H) {
  let d0 = [H[0] - U.origin[0], H[1] - U.origin[1], H[2] - U.origin[2]];
  return [d0[0] * U.u[0] + d0[1] * U.u[1] + d0[2] * U.u[2], d0[0] * U.v[0] + d0[1] * U.v[1] + d0[2] * U.v[2], d0[0] * U.w[0] + d0[1] * U.w[1] + d0[2] * U.w[2]];
}
function fn(U) {
  let H = [], d0 = U.outline;
  for (let d1 = 0; d1 < d0.length; d1++) {
    let d2 = d0[d1], d3 = d0[(d1 + 1) % d0.length], d4 = [d3[0] - d2[0], d3[1] - d2[1]];
    H.push((d5) => d4[0] * (d5[1] - d2[1]) - d4[1] * (d5[0] - d2[0]));
  }
  return H.push((d5) => d5[2] - U.depth[0]), H.push((d5) => U.depth[1] - d5[2]), H;
}
var Bt = (U, H, d0) => U.map((d1, d2) => d1 + (H[d2] - d1) * d0);
function mn(U, H, d0) {
  let d1 = Bt(U.n, H.n, d0), d2 = Math.hypot(d1[0], d1[1], d1[2]) || 1;
  return { p: Bt(U.p, H.p, d0), n: [d1[0] / d2, d1[1] / d2, d1[2] / d2], uv: Bt(U.uv, H.uv, d0), c: Bt(U.c, H.c, d0) };
}
function gn(U, H) {
  let d0 = [], d1 = [];
  for (let d2 = 0; d2 < U.length; d2++) {
    let d3 = U[d2], d4 = U[(d2 + 1) % U.length], d5 = H(d3.c), d6 = H(d4.c);
    if (d5 >= 0 ? d1.push(d3) : d0.push(d3), d5 >= 0 != d6 >= 0) {
      let d7 = d5 / (d5 - d6), d8 = mn(d3, d4, d7);
      d1.push(d8), d0.push(d8);
    }
  }
  return { outside: d0, inside: d1 };
}
function Vt(U) {
  let H = 0;
  for (let d0 = 1; d0 + 1 < U.length; d0++) {
    let d1 = U[0].c, d2 = U[d0].c, d3 = U[d0 + 1].c, d4 = [d2[0] - d1[0], d2[1] - d1[1], d2[2] - d1[2]], d5 = [d3[0] - d1[0], d3[1] - d1[1], d3[2] - d1[2]];
    H += Math.hypot(d4[1] * d5[2] - d4[2] * d5[1], d4[2] * d5[0] - d4[0] * d5[2], d4[0] * d5[1] - d4[1] * d5[0]) / 2;
  }
  return H;
}
var je = (U, H, d0, d1) => [U[0] * H + U[4] * d0 + U[8] * d1 + U[12], U[1] * H + U[5] * d0 + U[9] * d1 + U[13], U[2] * H + U[6] * d0 + U[10] * d1 + U[14]];
function De(U, d0, d1) {
  let d2 = U.positions, d3 = U.normals, d4 = U.uvs, d5 = U.indices || Array.from({ length: d2.length / 3 }, (dW, dS) => dS), d6 = new Array(d2.length / 3);
  for (let dW = 0; dW < d6.length; dW++) d6[dW] = hn(d1, je(d0, d2[dW * 3], d2[dW * 3 + 1], d2[dW * 3 + 2]));
  let d7 = [1 / 0, 1 / 0, -1 / 0, -1 / 0];
  for (let dS of d1.outline) d7[0] = Math.min(d7[0], dS[0]), d7[1] = Math.min(d7[1], dS[1]), d7[2] = Math.max(d7[2], dS[0]), d7[3] = Math.max(d7[3], dS[1]);
  let d8 = fn(d1), d9 = [], dd = { p: [], n: [], uv: [], idx: [] }, dC = d2.length / 3, dc = 0, dl = (dE) => ({ p: [d2[dE * 3], d2[dE * 3 + 1], d2[dE * 3 + 2]], n: d3 ? [d3[dE * 3], d3[dE * 3 + 1], d3[dE * 3 + 2]] : [0, 1, 0], uv: d4 ? [d4[dE * 2], d4[dE * 2 + 1]] : [0, 0], c: d6[dE] }), dF = (dE) => {
    if (dE.length < 3 || Vt(dE) < 1e-7) return;
    let dh = dC;
    for (let dA of dE) dd.p.push(...dA.p), dd.n.push(...dA.n), dd.uv.push(...dA.uv), dC++;
    for (let dv = 1; dv + 1 < dE.length; dv++) dd.idx.push(dh, dh + dv, dh + dv + 1);
  };
  for (let dE = 0; dE + 2 < d5.length; dE += 3) {
    let dh = d6[d5[dE]], dA = d6[d5[dE + 1]], dv = d6[d5[dE + 2]];
    if (Math.max(dh[0], dA[0], dv[0]) <= d7[0] || Math.min(dh[0], dA[0], dv[0]) >= d7[2] || Math.max(dh[1], dA[1], dv[1]) <= d7[1] || Math.min(dh[1], dA[1], dv[1]) >= d7[3] || Math.max(dh[2], dA[2], dv[2]) <= d1.depth[0] || Math.min(dh[2], dA[2], dv[2]) >= d1.depth[1]) {
      d9.push(d5[dE], d5[dE + 1], d5[dE + 2]);
      continue;
    }
    let dZ = [dl(d5[dE]), dl(d5[dE + 1]), dl(d5[dE + 2])], dg = [];
    for (let db of d8) {
      let { outside: dJ, inside: dO } = gn(dZ, db);
      if (dJ.length >= 3 && dg.push(dJ), dZ = dO, dZ.length < 3) break;
    }
    if (dZ.length < 3 && dg.length === 1 && dg[0].length === 3 && Vt(dg[0]) >= Vt([dl(d5[dE]), dl(d5[dE + 1]), dl(d5[dE + 2])]) - 1e-9) {
      d9.push(d5[dE], d5[dE + 1], d5[dE + 2]);
      continue;
    }
    dc++;
    for (let dM of dg) dF(dM);
  }
  if (!dc) return { mesh: U, cut: 0 };
  let dk = d2.length / 3 + dd.p.length / 3, dm = new Float32Array(dk * 3);
  dm.set(d2), dm.set(dd.p, d2.length);
  let du = new Float32Array(dk * 3);
  d3 && du.set(d3), du.set(dd.n, d2.length);
  let dj = new Float32Array(dk * 2);
  return d4 && dj.set(d4), dj.set(dd.uv, d2.length / 3 * 2), { mesh: { positions: dm, normals: du, uvs: dj, indices: d9.concat(dd.idx) }, cut: dc };
}
function Wt(U, H, d0) {
  let d1 = U.positions, d2 = U.indices || Array.from({ length: d1.length / 3 }, (d6, d7) => d7), d3 = [], d4 = [];
  for (let d6 = 0; d6 + 2 < d2.length; d6 += 3) {
    let d7 = [0, 1, 2].map((dl) => je(H, d1[d2[d6 + dl] * 3], d1[d2[d6 + dl] * 3 + 1], d1[d2[d6 + dl] * 3 + 2])), d8 = [d7[1][0] - d7[0][0], d7[1][1] - d7[0][1], d7[1][2] - d7[0][2]], d9 = [d7[2][0] - d7[0][0], d7[2][1] - d7[0][1], d7[2][2] - d7[0][2]], dd = [d8[1] * d9[2] - d8[2] * d9[1], d8[2] * d9[0] - d8[0] * d9[2], d8[0] * d9[1] - d8[1] * d9[0]], dC = Math.hypot(dd[0], dd[1], dd[2]), dc = dC ? [dd[0] / dC, dd[1] / dC, dd[2] / dC] : [0, 0, 0];
    (d0(d7, dc, dC / 2) ? d3 : d4).push(d2[d6], d2[d6 + 1], d2[d6 + 2]);
  }
  let d5 = (dl) => dl.length ? { positions: U.positions, normals: U.normals, uvs: U.uvs, indices: dl } : null;
  return { picked: d5(d3), rest: d5(d4) };
}
function qe(U, H = 0.01) {
  let d0 = U.map((d6, d7) => d7), d1 = (d6) => {
    for (; d0[d6] !== d6; ) d0[d6] = d0[d0[d6]], d6 = d0[d6];
    return d6;
  }, d2 = H * 4, d3 = /* @__PURE__ */ new Map(), d4 = (d6) => d6.map((d7) => Math.round(d7 / d2)).join(",");
  U.forEach((d6, d7) => {
    for (let d8 of d6) {
      let d9 = d4(d8);
      d3.has(d9) ? d0[d1(d7)] = d1(d3.get(d9)) : d3.set(d9, d7);
    }
  });
  let d5 = /* @__PURE__ */ new Map();
  return U.forEach((d6, d7) => {
    let d8 = d1(d7);
    d5.has(d8) || d5.set(d8, []), d5.get(d8).push(d7);
  }), [...d5.values()];
}
var yn = /^Architecture__(Blue|Cream|Wall|Wood|Baseboard)$/, bn = /^Portal_(\w+)_Membrane$/, wn = { Props__Court_Paint_Blue: 4e-3, Props__Court_Lines: 8e-3, Outdoor__Patio_Stone: 3e-3 }, vn = /^Basketball_(\d+|Loose)$/, xn = 0.6, Mn = 1, kn = 0.06, ft = { piece: "Architecture__Steel", within: [18.88, 19.02], top: 9.2, out: 21.95 - 19 }, Sn = new p({ colour: [0.74, 0.8, 0.86], roughness: 0.06, metallic: 0.2 }), vt = (U, H, d0, d1) => [U[0] * H + U[4] * d0 + U[8] * d1 + U[12], U[1] * H + U[5] * d0 + U[9] * d1 + U[13], U[2] * H + U[6] * d0 + U[10] * d1 + U[14]], xt = (U) => U.children.filter((H) => H.mesh && H.mesh.positions && H.mesh.positions.length);
function Tn(U) {
  let H = [];
  for (let d0 of xt(U)) {
    let d1 = d0.worldMatrix(), d2 = d0.mesh.positions;
    for (let d3 = 0; d3 < d2.length; d3 += 3) H.push(vt(d1, d2[d3], d2[d3 + 1], d2[d3 + 2]));
  }
  return H;
}
function An(U) {
  let H = Tn(U);
  if (H.length < 3) return null;
  let d0 = [0, 1, 2].map((dd) => H.reduce((dC, dc) => dC + dc[dd], 0) / H.length), d1 = null, d2 = 0;
  for (let dd of xt(U)) {
    let dC = dd.worldMatrix(), dc = dd.mesh.positions, dl = dd.mesh.indices;
    for (let dF = 0; dl && dF + 2 < dl.length; dF += 3) {
      let dk = [0, 1, 2].map((dS) => vt(dC, dc[dl[dF + dS] * 3], dc[dl[dF + dS] * 3 + 1], dc[dl[dF + dS] * 3 + 2])), dm = dk[1].map((dS, dE) => dS - dk[0][dE]), du = dk[2].map((dS, dE) => dS - dk[0][dE]), dj = [dm[1] * du[2] - dm[2] * du[1], dm[2] * du[0] - dm[0] * du[2], dm[0] * du[1] - dm[1] * du[0]], dW = Math.hypot(dj[0], dj[1], dj[2]);
      dW > d2 && (d2 = dW, d1 = dj);
    }
  }
  if (!d1) return null;
  d1 = [d1[0], 0, d1[2]];
  let d3 = Math.hypot(d1[0], d1[2]);
  if (d3 < 1e-6) return null;
  d1 = [d1[0] / d3, 0, d1[2] / d3], d1[0] * -d0[0] + d1[2] * -d0[2] < 0 && (d1 = [-d1[0], 0, -d1[2]]);
  let d4 = [d1[2], 0, -d1[0]], d5 = [0, 1, 0], d6 = H.map((dS) => {
    let dE = [dS[0] - d0[0], dS[1] - d0[1], dS[2] - d0[2]];
    return [dE[0] * d4[0] + dE[2] * d4[2], dE[1], dE[0] * d1[0] + dE[2] * d1[2]];
  }), d7 = Math.min(...d6.map((dS) => dS[1])), d8 = Ie(d6.map((dS) => [dS[0], Math.max(dS[1], d7 + kn)])), d9 = [Math.min(...d6.map((dS) => dS[2])) - Mn, Math.max(...d6.map((dS) => dS[2])) + xn];
  return { origin: d0, u: d4, v: d5, w: d1, outline: d8, depth: d9 };
}
function zn(U, H) {
  let d0 = U.parent ? U.parent.worldMatrix() : N.create(), d1 = N.invert(N.create(), d0);
  d1 && (U.position[0] += d1[4] * H, U.position[1] += d1[5] * H, U.position[2] += d1[6] * H, U.markDirty());
}
function Ge(U, H) {
  let d0 = /* @__PURE__ */ new Map(), d1 = [], d2 = [], d3 = [], d4 = [];
  for (let d5 of H) {
    let d6 = d0.get(d5);
    d6 === void 0 && (d6 = d0.size, d0.set(d5, d6), d1.push(U.positions[d5 * 3], U.positions[d5 * 3 + 1], U.positions[d5 * 3 + 2]), d2.push(U.normals[d5 * 3], U.normals[d5 * 3 + 1], U.normals[d5 * 3 + 2]), d3.push(U.uvs ? U.uvs[d5 * 2] : 0, U.uvs ? U.uvs[d5 * 2 + 1] : 0)), d4.push(d6);
  }
  return { positions: new Float32Array(d1), normals: new Float32Array(d2), uvs: new Float32Array(d3), indices: d4 };
}
function Ln(U) {
  let H = [];
  for (let d0 of xt(U)) {
    let d1 = d0.worldMatrix(), { picked: d2, rest: d3 } = Wt(d0.mesh, d1, (d6, d7, d8) => {
      if (d8 < 0.4 || Math.abs(d7[1]) > 0.2) return false;
      let d9 = [(d6[0][0] + d6[1][0] + d6[2][0]) / 3, (d6[0][2] + d6[1][2] + d6[2][2]) / 3], dd = Math.hypot(d9[0], d9[1]) || 1;
      return (d7[0] * -d9[0] + d7[2] * -d9[1]) / dd > 0.6;
    });
    if (!d2) continue;
    let d4 = d2.indices, d5 = [];
    for (let d6 = 0; d6 < d4.length; d6 += 3) d5.push([0, 1, 2].map((d7) => vt(d1, d0.mesh.positions[d4[d6 + d7] * 3], d0.mesh.positions[d4[d6 + d7] * 3 + 1], d0.mesh.positions[d4[d6 + d7] * 3 + 2])));
    for (let d7 of qe(d5, 0.02)) {
      let d8 = [];
      for (let dd of d7) d8.push(d4[dd * 3], d4[dd * 3 + 1], d4[dd * 3 + 2]);
      let d9 = new r("mirror glass:" + H.length);
      d9.mesh = Ge(d0.mesh, d8), d9.material = Sn, d9.mirror = true, d9.position.set(d0.position), d9.rotation.set(d0.rotation), d9.scale.set(d0.scale), d9.markDirty(), d0.parent.add(d9), H.push(d9);
    }
    d0.mesh = d3 || { positions: new Float32Array(0), normals: new Float32Array(0), uvs: new Float32Array(0), indices: [] };
  }
  return H;
}
function En(U) {
  let H = U.get(ft.piece);
  if (!H) return 0;
  let d0 = 0;
  for (let d1 of xt(H)) {
    let d2 = d1.worldMatrix(), d3 = (d9) => {
      let dd = Math.hypot(d9[0], d9[2]);
      return dd >= ft.within[0] && dd <= ft.within[1] && d9[1] >= -0.05 && d9[1] <= ft.top;
    }, { picked: d4 } = Wt(d1.mesh, d2, (d9) => d9.every(d3));
    if (!d4) continue;
    let d5 = Ge(d1.mesh, d4.indices), d6 = N.invert(N.create(), d2);
    if (!d6) continue;
    let d7 = d5.positions;
    for (let d9 = 0; d9 < d7.length; d9 += 3) {
      let dd = vt(d2, d7[d9], d7[d9 + 1], d7[d9 + 2]), dC = Math.hypot(dd[0], dd[2]) || 1;
      dd[0] += dd[0] / dC * ft.out, dd[2] += dd[2] / dC * ft.out;
      let dc = vt(d6, dd[0], dd[1], dd[2]);
      d7[d9] = dc[0], d7[d9 + 1] = dc[1], d7[d9 + 2] = dc[2];
    }
    let d8 = new r("stair rail:outer");
    d8.mesh = d5, d8.material = d1.material, d8.position.set(d1.position), d8.rotation.set(d1.rotation), d8.scale.set(d1.scale), d8.markDirty(), d1.parent.add(d8), d0 += d5.indices.length / 3;
  }
  return d0;
}
function _n(U) {
  let H = /* @__PURE__ */ new Map();
  for (let d3 of U.allNodes()) d3.name && !H.has(d3.name) && H.set(d3.name, d3);
  let d0 = { doorways: [], lifted: [], balls: 0, mirrors: 0, stairRail: 0 }, d1 = [...H.values()].filter((d4) => yn.test(d4.name));
  for (let [d4, d5] of H) {
    let d6 = bn.exec(d4);
    if (!d6) continue;
    let d7 = An(d5);
    if (!d7) continue;
    let d8 = 0;
    for (let d9 of d1) for (let dd of xt(d9)) {
      let dC = De(dd.mesh, dd.worldMatrix(), d7);
      dC.cut && (dd.mesh = dC.mesh, d8 += dC.cut);
    }
    d0.doorways.push({ portal: d6[1].toLowerCase(), cut: d8 });
  }
  for (let [dc, dl] of Object.entries(wn)) {
    let dF = H.get(dc);
    dF && (zn(dF, dl), d0.lifted.push(dc));
  }
  for (let [dk, dm] of H) vn.test(dk) && (dm.visible = false, dm.noCollide = true, d0.balls++);
  d0.stairRail = En(H);
  let d2 = H.get("Props__Mirror");
  return d2 && (d0.mirrors = Ln(d2).length), d0;
}
function Ve({ game: U, world: H, id: d0 = "rc_model" }) {
  let d1 = null, d2 = { report: null }, d3 = (d4) => !d4 || d4 === d1 ? false : (d1 = d4, d2.report = _n(d4), d2.report.mirrors && (U.mirrorSelf = true), true);
  return typeof H.addEventListener == "function" && H.addEventListener("loaded", (d4) => {
    d4.detail && d4.detail.id === d0 && d3(d4.detail.model);
  }), U.addUpdater(() => {
    let d4 = H.nodes.get(d0), d5 = d4 && d4.children.find((d6) => d6.children.length);
    d3(d5) && typeof H._queueCollision == "function" && H._queueCollision();
  }), d2;
}
var W = { blue: { name: "Blue", colour: [0.16, 0.52, 1], glow: [0.2, 1.1, 2.6], css: "#2e86ff" }, black: { name: "Black", colour: [0.56, 0.22, 1], glow: [1.15, 0.32, 2.6], css: "#a46bff" } }, R = { health: 100, damage: 34, regenDelay: 5, regenPerSecond: 25, respawnSeconds: 4, protectSeconds: 2.5, energy: 100, shotCost: 14, energyPerSecond: 34, energyWait: 0.45, overheatSeconds: 1.6, cooldown: 0.2, range: 80, countdownSeconds: 10, matchSeconds: 300, scoreLimit: 30, endSeconds: 14, maxTeam: 8, maxBots: 8, tagPoints: 100, hitPoints: 10, winPoints: 150 };
function Ht(U, H) {
  U.energy === void 0 && (U.energy = R.energy);
  let d0 = Math.max(U.at ?? H, (U.lastShot ?? -1e9) + R.energyWait);
  return H > d0 && (U.energy = Math.min(R.energy, U.energy + (H - d0) * R.energyPerSecond)), U.at = H, U;
}
function We(U, H) {
  return Ht(U, H), (U.lockedUntil ?? 0) > H || H - (U.lastShot ?? -1e9) < R.cooldown - 0.02 ? false : (U.energy ?? R.energy) < R.shotCost ? (U.lockedUntil = H + R.overheatSeconds, false) : (U.energy -= R.shotCost, U.lastShot = H, U.at = H, U.energy < R.shotCost && (U.lockedUntil = H + R.overheatSeconds), true);
}
var He = (U, H) => H > 0 ? Math.round(U / H * 100) : 0, w = (U, H, d0) => {
  let d1 = document.createElement(U);
  return H && (d1.className = H), d0 !== void 0 && (d1.textContent = d0), d1;
}, Cn = (U) => {
  let H = Math.max(0, Math.ceil(U / 1e3));
  return Math.floor(H / 60) + ":" + String(H % 60).padStart(2, "0");
}, mt = () => performance.now(), Yt = class {
  constructor() {
    this.ctx = null, this.volume = 0.55;
  }
  ["_ctx"]() {
    if (this.ctx) return this.ctx;
    let U = globalThis.AudioContext || globalThis.webkitAudioContext;
    if (!U) return null;
    try {
      this.ctx = new U();
    } catch {
      this.ctx = null;
    }
    return this.ctx;
  }
  ["wake"]() {
    let U = this._ctx();
    U && U.state === "suspended" && U.resume().catch(() => {
    });
  }
  ["_tone"]({ type: U = "sine", from: H = 440, to: d0 = H, time: d1 = 0.15, gain: d2 = 0.3, delay: d3 = 0, pan: d4 = 0 }) {
    let d5 = this._ctx();
    if (!d5 || d5.state !== "running") return;
    let d6 = d5.currentTime + d3, d7 = d5.createOscillator(), d8 = d5.createGain();
    d7.type = U, d7.frequency.setValueAtTime(H, d6), d7.frequency.exponentialRampToValueAtTime(Math.max(20, d0), d6 + d1), d8.gain.setValueAtTime(1e-4, d6), d8.gain.exponentialRampToValueAtTime(d2 * this.volume, d6 + 8e-3), d8.gain.exponentialRampToValueAtTime(1e-4, d6 + d1);
    let d9 = d8;
    if (d5.createStereoPanner) {
      let dd = d5.createStereoPanner();
      dd.pan.value = Math.max(-1, Math.min(1, d4)), d8.connect(dd), d9 = dd;
    }
    d7.connect(d8), d9.connect(d5.destination), d7.start(d6), d7.stop(d6 + d1 + 0.02);
  }
  ["_noise"]({ time: U = 0.12, gain: H = 0.2, delay: d0 = 0, freq: d1 = 2400 }) {
    let d2 = this._ctx();
    if (!d2 || d2.state !== "running") return;
    let d3 = d2.currentTime + d0, d4 = Math.floor(d2.sampleRate * U), d5 = d2.createBuffer(1, d4, d2.sampleRate), d6 = d5.getChannelData(0);
    for (let dd = 0; dd < d4; dd++) d6[dd] = (Math.random() * 2 - 1) * (1 - dd / d4);
    let d7 = d2.createBufferSource(), d8 = d2.createBiquadFilter(), d9 = d2.createGain();
    d7.buffer = d5, d8.type = "bandpass", d8.frequency.value = d1, d8.Q.value = 1.2, d9.gain.setValueAtTime(H * this.volume, d3), d9.gain.exponentialRampToValueAtTime(1e-4, d3 + U), d7.connect(d8), d8.connect(d9), d9.connect(d2.destination), d7.start(d3);
  }
  ["pew"](U = 1, H = 0) {
    this._tone({ type: "square", from: 1700, to: 240, time: 0.13, gain: 0.16 * U, pan: H }), this._tone({ type: "sine", from: 2600, to: 900, time: 0.07, gain: 0.1 * U, pan: H });
  }
  ["hit"]() {
    this._tone({ type: "triangle", from: 1400, to: 1900, time: 0.06, gain: 0.22 }), this._tone({ type: "sine", from: 2200, time: 0.05, gain: 0.12, delay: 0.05 });
  }
  ["hurt"]() {
    this._noise({ time: 0.16, gain: 0.35, freq: 900 }), this._tone({ type: "sawtooth", from: 300, to: 120, time: 0.18, gain: 0.18 });
  }
  ["tagged"]() {
    [520, 390, 260].forEach((U, H) => this._tone({ type: "square", from: U, to: U * 0.9, time: 0.16, gain: 0.16, delay: H * 0.13 }));
  }
  ["scored"]() {
    [660, 880, 1320].forEach((U, H) => this._tone({ type: "triangle", from: U, time: 0.12, gain: 0.2, delay: H * 0.07 }));
  }
  ["beep"](U = false) {
    this._tone({ type: "sine", from: U ? 1320 : 880, time: U ? 0.4 : 0.14, gain: 0.25 });
  }
  ["empty"]() {
    this._tone({ type: "square", from: 180, to: 120, time: 0.12, gain: 0.12 });
  }
  ["win"]() {
    [523, 659, 784, 1047].forEach((U, H) => this._tone({ type: "triangle", from: U, time: 0.28, gain: 0.22, delay: H * 0.14 }));
  }
  ["lose"]() {
    [392, 330, 262].forEach((U, H) => this._tone({ type: "triangle", from: U, time: 0.32, gain: 0.2, delay: H * 0.18 }));
  }
}, gt = [0, 1, 0];
function Pn(U) {
  let H = Math.max(-1, Math.min(1, U[1]));
  if (H > 0.99999) return [0, 0, 0, 1];
  if (H < -0.99999) return [1, 0, 0, 0];
  let d0 = [gt[1] * U[2] - gt[2] * U[1], gt[2] * U[0] - gt[0] * U[2], gt[0] * U[1] - gt[1] * U[0]], d1 = Math.hypot(...d0), d2 = Math.acos(H) / 2, d3 = Math.sin(d2) / d1;
  return [d0[0] * d3, d0[1] * d3, d0[2] * d3, Math.cos(d2)];
}
var Nn = P(0.5, 1, 10), Bn = P(0.5, 1, 6), Ye = a(0.5, 14, 10), $n = L(0.31, 0.03, 32, 8), On = a(0.5, 8, 6);
function Rn(U, H) {
  if (typeof document > "u") return null;
  let d0 = document.createElement("canvas");
  d0.width = 1024, d0.height = 146;
  let d1 = new p({ colour: [1, 1, 1], map: d0, emissive: [1.5, 1.5, 1.5], roughness: 0.3, castShadow: false });
  d1.glowMap = true, d1.mapVersion = 0;
  let d2 = [], d3 = () => {
    for (let d5 of d2.splice(0)) d5.dispose();
    for (let d6 of U.doc.list()) {
      if (!/^scoreboard:/.test(d6.tag || "")) continue;
      let d7 = d6.position[0] < 0 ? 1 : -1, d8 = new r("lasertag scoreboard");
      d8.setPosition(d6.position[0] + d7 * 0.035, d6.position[1], d6.position[2]), d8.setEuler(0, d7 * Math.PI / 2, 0);
      let d9 = new r("lasertag scoreboard tilt");
      d9.setEuler(Math.PI / 2, 0, 0), d8.add(d9);
      let dd = new r("lasertag scoreboard face");
      dd.mesh = X(Math.abs(d6.scale[2]) - 0.1, Math.abs(d6.scale[1]) - 0.06), dd.material = d1, dd.setEuler(0, Math.PI, 0), d9.add(dd), H.scene.add(d8), d2.push(d8);
    }
  };
  U.doc.addEventListener("reset", () => setTimeout(d3, 0)), d3();
  let d4 = "";
  return (d5, d6, d7) => {
    let d8 = d5.blue + "|" + d5.black + "|" + d6 + "|" + d7;
    if (d8 === d4 || !d2.length) return;
    d4 = d8;
    let d9 = d0.getContext("2d");
    d9.save(), d9.setTransform(-1, 0, 0, 1, d0.width, 0), d9.fillStyle = "#05070f", d9.fillRect(0, 0, d0.width, d0.height), d9.textBaseline = "middle", d9.font = "900 92px Inter, system-ui, sans-serif", d9.textAlign = "left", d9.fillStyle = W.blue.css, d9.fillText("BLUE " + d5.blue, 34, 78), d9.textAlign = "right", d9.fillStyle = W.black.css, d9.fillText(d5.black + " BLACK", d0.width - 34, 78), d9.textAlign = "center", d9.fillStyle = "#eef2ff", d9.font = "800 70px Inter, system-ui, sans-serif", d9.fillText(d6, d0.width / 2, 70), d9.font = "700 22px Inter, system-ui, sans-serif", d9.fillStyle = "rgba(238,242,255,.7)", d9.fillText(d7, d0.width / 2, 124), d9.restore(), d1.mapVersion++;
  };
}
function Ze({ game: U, net: d0, hud: d1 = null, tools: d2, world: d3 = null }) {
  let d4 = new Yt(), d5 = /* @__PURE__ */ new Map(), d6 = { team: null, alive: true, hp: R.health, blaster: { energy: R.energy }, protectUntil: 0, deadAt: null }, d7 = "waiting", d8 = 0, d9 = { blue: 0, black: 0 }, dd = R.scoreLimit, dC = null, dc = false, dl = false, dF = -1, dk = null, dm = [], du = /* @__PURE__ */ new Map(), dj = d3 ? Rn(d3, U) : null, dW = () => !!(d0.connected && (d0.features || []).includes("lasertag")), dS = (C8) => (C8 === d0.id ? d6.team : (d5.get(C8) || {}).team) || null, dE = (C8) => (W[C8] || W.blue).colour, dh = (C8) => C8 === d0.id ? "You" : (d5.get(C8) || {}).name || (d0.players.get(C8) || {}).name || "Somebody";
  d2.blasterTeamOf = (C8) => dE(C8 === "mine" ? d6.team : dS(C8)), d1 && (d1.tagTint = (C8) => {
    let C9 = dS(C8);
    return C9 ? W[C9].css : null;
  });
  let dA = w("div", "lt-root");
  dA.hidden = true;
  let dv = w("div", "lt-top"), dZ = w("div", "lt-teambox lt-blue"), dg = w("b", "", "0");
  dZ.append(w("span", "", "BLUE"), dg);
  let db = w("div", "lt-mid"), dJ = w("b", "lt-timer", "0:00"), dO = w("span", "lt-phase", "");
  db.append(dJ, dO);
  let dM = w("div", "lt-teambox lt-black"), dT = w("b", "", "0");
  dM.append(w("span", "", "BLACK"), dT), dv.append(dZ, db, dM);
  let dD = w("div", "lt-status"), ds = w("div", "lt-myteam", ""), dG = w("div", "lt-bar lt-hp"), dR = w("i"), dx = w("span", "", "100");
  dG.append(w("em", "", "Health"), dR, dx);
  let df = w("div", "lt-bar lt-energy"), dy = w("i"), dN = w("span", "", "100");
  df.append(w("em", "", "Energy"), dy, dN), dD.append(ds, dG, df);
  let dr = w("div", "lt-feed"), dX = w("div", "lt-banner"), da = w("b"), dP = w("span");
  dX.append(da, dP), dX.hidden = true;
  let dw = w("div", "lt-hitmark"), dq = w("div", "lt-hurt"), dL = w("div", "lt-board");
  dL.hidden = true;
  let dp = w("div", "lt-notice");
  dp.hidden = true, dA.append(dq, dv, dD, dr, dX, dw, dL, dp), document.body.appendChild(dA);
  let di = (C8, C9 = "", Cd = 0, CC = "") => {
    da.textContent = C8, dP.textContent = C9, dX.className = "lt-banner " + CC, dX.hidden = false, clearTimeout(dX._t), Cd && (dX._t = setTimeout(() => {
      dX.hidden = true;
    }, Cd));
  };
  function dB(C8, C9, Cd) {
    let CC = w("div", "lt-feedrow"), Cc = w("b", "", dh(C8));
    Cc.style.color = W[Cd].css;
    let Cl = w("b", "", dh(C9)), CF = dS(C9);
    for (CF && (Cl.style.color = W[CF].css), CC.append(Cc, w("span", "", " tagged "), Cl), (C8 === d0.id || C9 === d0.id) && CC.classList.add("is-me"), dr.prepend(CC); dr.children.length > 5; ) dr.lastChild.remove();
    setTimeout(() => CC.classList.add("is-old"), 6e3), setTimeout(() => CC.remove(), 7e3);
  }
  function dV(C8 = null) {
    dL.textContent = "";
    let C9 = w("div", "lt-boardhead");
    if (C8) {
      let Ck = C8.winner === "draw" ? null : C8.winner, Cm = Ck && Ck === d6.team;
      C9.append(w("b", "lt-result " + (Ck ? "lt-" + Ck : ""), Ck ? Cm ? "Victory" : d6.team ? "Defeat" : W[Ck].name + " wins" : "Draw"));
    } else C9.append(w("b", "", "Scoreboard"));
    let Cd = w("div", "lt-boardscore"), CC = w("span", "lt-blue", String((C8 || {}).score ? C8.score.blue : d9.blue)), Cc = w("span", "lt-black", String((C8 || {}).score ? C8.score.black : d9.black));
    Cd.append(CC, w("i", "", ":"), Cc), C9.append(Cd), dL.append(C9);
    let Cl = C8 ? C8.players : [...d5.entries()].map(([Cu, Cj]) => ({ id: Cu, ...Cj })), CF = w("div", "lt-cols");
    for (let Cu of ["blue", "black"]) {
      let Cj = w("div", "lt-col lt-" + Cu);
      Cj.append(w("div", "lt-colhead", "" + W[Cu].name));
      let CW = w("table", "lt-table"), CS = w("tr");
      for (let CE of ["", "Tags", "Tagged", "Acc", "Score"]) CS.append(w("th", "", CE));
      CW.append(CS);
      for (let Ch of Cl.filter((CA) => CA.team === Cu).sort((CA, Cv) => Cv.score - CA.score || Cv.tags - CA.tags)) {
        let CA = w("tr", Ch.id === d0.id ? "is-me" : ""), Cv = w("td", "lt-name", "" + Ch.name + (Ch.bot, ""));
        Ch.bot && Cv.append(w("em", "lt-bot", "BOT")), C8 && C8.mvp === Ch.id && Cv.append(w("em", "lt-mvp", "MVP")), CA.append(Cv, w("td", "", String(Ch.tags || 0)), w("td", "", String(Ch.deaths || 0)), w("td", "", He(Ch.hits || 0, Ch.shots || 0) + "%"), w("td", "", String(Ch.score || 0))), CW.append(CA);
      }
      Cj.append(CW), CF.append(Cj);
    }
    if (dL.append(CF), C8) {
      let CZ = w("div", "lt-boardfoot");
      CZ.append(w("span", "lt-next", ""), Object.assign(w("a", "", "Leaderboards"), { href: "/lasertag", target: "_blank" })), dL.append(CZ);
    }
  }
  function dI(C8, C9, Cd, CC) {
    if (C8 === d0.id) {
      d6.team = C9, ds.textContent = "You are " + W[C9].name, ds.style.setProperty("--team", W[C9].css), dA.dataset.team = C9;
      let CF = d2.blasters.get("mine");
      CF && CF.setTeam(dE(C9));
    }
    let Cc = d5.get(C8) || { alive: true, hp: R.health, tags: 0, deaths: 0, shots: 0, hits: 0, score: 0 };
    Object.assign(Cc, { team: C9, bot: !!Cd, name: CC || Cc.name || dh(C8) }), d5.set(C8, Cc);
    let Cl = d2.blasters.get(C8);
    Cl && Cl.setTeam(dE(C9));
  }
  d0.addEventListener("lt", (C8) => {
    let C9 = C8.detail;
    switch (C9.k) {
      case "match": {
        let Cd = d7;
        d7 = C9.phase, d8 = mt() + (C9.left || 0), d9 = C9.score || d9, dd = C9.limit || dd;
        for (let [CC, Cc] of Object.entries(C9.players || {})) {
          let Cl = Number(CC);
          dI(Cl, Cc.team, Cc.bot, Cc.name), Object.assign(d5.get(Cl), Cc);
        }
        for (let CF of [...d5.keys()]) String(CF) in (C9.players || {}) || d5.delete(CF);
        C9.you && dI(d0.id, C9.you, false, "You"), d7 === "playing" && Cd !== "playing" && (di("GO!", "First to " + dd + " tags", 1400, "is-go"), d4.beep(true), dL.hidden = true, dC = null), d7 === "countdown" && Cd === "ended" && (dL.hidden = true, dC = null), d7 === "ended" && C9.result && (dC = C9.result, dV(dC), dL.hidden = false);
        break;
      }
      case "team":
        dI(C9.id, C9.team, C9.bot, C9.name), C9.id === d0.id && C9.moved && d1 && d1.say("Moved to " + W[C9.team].name + " to keep the teams even.", "info");
        break;
      case "gone":
        d5.delete(C9.id);
        break;
      case "shot":
        if (C9.by !== d0.id ? C1(C9.by, C9.o, C9.e, C9.hit) : C9.hit && (dw.classList.remove("is-on"), dw.offsetWidth, dw.classList.add("is-on"), d4.hit()), C9.hit) {
          let Ck = d5.get(C9.by);
          Ck && (Ck.hits = (Ck.hits || 0) + 1), C9.hit !== d0.id && C3(C9.e, dE(dS(C9.by)), 0.35);
        }
        {
          let Cm = d5.get(C9.by);
          Cm && d7 === "playing" && (Cm.shots = (Cm.shots || 0) + 1);
        }
        break;
      case "hp": {
        let Cu = d5.get(C9.id);
        if (Cu && (Cu.hp = C9.hp), C9.id === d0.id) {
          let Cj = C9.hp < d6.hp;
          d6.hp = C9.hp, Cj && C9.by && (dq.classList.remove("is-on"), dq.offsetWidth, dq.classList.add("is-on"), d4.hurt());
        }
        break;
      }
      case "tag": {
        d9 = C9.score || d9;
        let CW = d5.get(C9.victim), CS = d5.get(C9.by);
        CW && (CW.alive = false, CW.deaths = (CW.deaths || 0) + 1), CS && (CS.tags = (CS.tags || 0) + 1, CS.score = (CS.score || 0) + R.tagPoints), dB(C9.by, C9.victim, C9.team);
        let CE = C0(C9.victim);
        CE && C3([CE[0], CE[1] + 1.1, CE[2]], dE(dS(C9.victim)), 1.1), C9.victim === d0.id ? (d6.alive = false, d6.hp = 0, d6.deadAt = U.player.position.slice(), dc = false, di("Tagged out", "by " + C9.byName + ". Back in " + (C9.respawn || R.respawnSeconds), 0, "is-out"), d4.tagged()) : C9.by === d0.id && (di("Tagged " + C9.victimName, "+100", 1100, "is-score"), d4.scored());
        break;
      }
      case "spawn": {
        let Ch = d5.get(C9.id);
        Ch && (Ch.alive = true, Ch.hp = R.health), C9.id === d0.id && (d6.alive = true, d6.hp = R.health, d6.deadAt = null, d6.blaster = { energy: R.energy }, d6.protectUntil = mt() + (C9.protect || R.protectSeconds) * 1e3, dk = { p: C9.p, y: C9.y }, !dX.classList.contains("is-go") && d7 !== "countdown" && (dX.hidden = true));
        break;
      }
      case "energy":
        d6.blaster.energy = C9.e, C9.lock && (d6.blaster.lockedUntil = mt() / 1e3 + C9.lock);
        break;
      case "end": {
        dC = C9.result, d9 = dC.score || d9, dV(dC), dL.hidden = false, dX.hidden = true, dC.winner !== "draw" && dC.winner === d6.team ? d4.win() : dC.winner !== "draw" && d4.lose();
        break;
      }
    }
  }), d0.addEventListener("left", (C8) => {
    d5.delete(C8.detail.id), C5(C8.detail.id);
  }), d0.addEventListener("disconnected", () => {
    dc = false;
  });
  let dz = () => document.pointerLockElement === U.canvas, dY = () => dW() && d6.alive && U.player.wielding === Y.blaster && !dk;
  function dU() {
    if (U.view !== "third") return Array.from(U.camera.position);
    let C8 = U.player.position;
    return [C8[0], C8[1] + 1.55, C8[2]];
  }
  function dK() {
    if (!dY()) return;
    let C8 = mt() / 1e3;
    if (!We(d6.blaster, C8)) {
      !dl && (d6.blaster.lockedUntil || 0) > C8 && (d4.empty(), dl = true);
      return;
    }
    dl = false;
    let C9 = dU(), Cd = Array.from(U.camera.forward()), CC = {}, Cc = new Set(U._cameraSkip ? U._cameraSkip() : []);
    for (let Cj of dm) Cc.add(Cj.node);
    let Cl = n(U.scene, C9, Cd, R.range, Cc, CC), CF = Cl === null ? R.range : Cl, Ck = [C9[0] + Cd[0] * CF, C9[1] + Cd[1] * CF, C9[2] + Cd[2] * CF], Cm = d2.blasters.get("mine"), Cu = Cm && Cm.muzzle ? Array.from(Cm.muzzle.worldPosition()) : [C9[0], C9[1] - 0.2, C9[2]];
    C2(Cu, Ck, dE(d6.team), true), Cl !== null && C3(Ck, dE(d6.team), 0.22), d4.pew(1, 0), d0.sendLaserTag({ k: "fire", o: C9.map((CW) => Math.round(CW * 1e3) / 1e3), d: Cd.map((CW) => Math.round(CW * 1e4) / 1e4), ...dQ(C9, Cd) });
  }
  let dH = mt();
  function dQ(C8, C9) {
    let Cd = null, CC = 0.35;
    for (let [Cl, CF] of U.remotes) {
      if (!CF.root || !CF.buffer || dS(Cl) === d6.team) continue;
      let Ck = CF.root.worldPosition(), Cm = [Ck[0] - C8[0], Ck[1] + 1.1 - C8[1], Ck[2] - C8[2]], Cu = Math.hypot(Cm[0], Cm[1], Cm[2]) || 1, Cj = Math.acos(Math.max(-1, Math.min(1, (Cm[0] * C9[0] + Cm[1] * C9[1] + Cm[2] * C9[2]) / Cu)));
      Cj < CC && (CC = Cj, Cd = CF);
    }
    if (!Cd || typeof d0.serverTimeOf != "function") return {};
    let Cc = d0.serverTimeOf(dH - Cd.buffer.delay);
    return Cc === null ? {} : { at: Math.round(Cc) };
  }
  function C0(C8) {
    if (C8 === d0.id) return U.player.position;
    let C9 = U.remotes.get(C8);
    return C9 && C9.root ? Array.from(C9.root.worldPosition()) : null;
  }
  function C1(C8, C9, Cd, CC) {
    let Cc = d2.blasters.get(C8), Cl = Cc && Cc.muzzle ? Array.from(Cc.muzzle.worldPosition()) : C9, CF = dS(C8);
    C2(Cl, Cd, dE(CF), false), CC || C3(Cd, dE(CF), 0.18);
    let Ck = U.camera.position, Cm = Math.hypot(Cl[0] - Ck[0], Cl[1] - Ck[1], Cl[2] - Ck[2]), Cu = U.player.yaw, Cj = [Math.cos(Cu), -Math.sin(Cu)], CW = Cl[0] - Ck[0], CS = Cl[2] - Ck[2], CE = Cm > 0.1 ? (CW * Cj[0] + CS * Cj[1]) / Cm : 0;
    d4.pew(Math.max(0.08, 1 - Cm / 45) * 0.7, CE);
  }
  function C2(C8, C9, Cd, CC) {
    let Cc = [C9[0] - C8[0], C9[1] - C8[1], C9[2] - C8[2]], Cl = Math.hypot(Cc[0], Cc[1], Cc[2]);
    if (Cl < 0.05) return;
    let CF = Cc.map((CS) => CS / Cl), Ck = new r("laser"), Cm = new p({ colour: Cd, emissive: Cd.map((CS) => CS * 3.2 + 0.1), roughness: 1, opacity: 0.55, castShadow: false });
    Ck.mesh = Nn, Ck.material = Cm, Ck.setPosition((C8[0] + C9[0]) / 2, (C8[1] + C9[1]) / 2, (C8[2] + C9[2]) / 2), Ck.setRotation(Pn(CF));
    let Cu = new r("laser core");
    Cu.mesh = Bn, Cu.material = new p({ colour: [1, 1, 1], emissive: [3, 3, 3], roughness: 1, castShadow: false }), Ck.add(Cu), Ck.noMirror = true;
    let Cj = CC ? 0.022 : 0.03;
    Ck.setScale(Cj, Cl, Cj), Cu.setScale(0.35, 1, 0.35), U.scene.add(Ck);
    let CW = new r("muzzle flash");
    CW.mesh = Ye, CW.material = new p({ colour: Cd, emissive: Cd.map((CS) => CS * 4 + 0.6), roughness: 1, opacity: 0.8, castShadow: false }), CW.setPosition(C8[0], C8[1], C8[2]), CW.setScale(0.07), U.scene.add(CW), dm.push({ node: Ck, t: 0, life: 0.14, update: (CS, CE) => {
      let Ch = 1 - CS / CE;
      return Ck.setScale(Cj * (0.6 + Ch * 0.6), Cl, Cj * (0.6 + Ch * 0.6)), Cm.opacity = 0.55 * Ch, CS < CE;
    } }), dm.push({ node: CW, t: 0, life: 0.07, update: (CS, CE) => (CW.setScale(0.07 + CS * 1.2), CS < CE) });
  }
  function C3(C8, C9, Cd) {
    let CC = new r("laser hit"), Cc = new p({ colour: C9, emissive: C9.map((Cl) => Cl * 3.5 + 0.4), roughness: 1, opacity: 0.85, castShadow: false });
    CC.mesh = Ye, CC.material = Cc, CC.setPosition(C8[0], C8[1], C8[2]), CC.setScale(Cd * 0.3), CC.noMirror = true, U.scene.add(CC), dm.push({ node: CC, t: 0, life: 0.22 + Cd * 0.2, update: (Cl, CF) => {
      let Ck = Cl / CF;
      return CC.setScale(Cd * (0.3 + Ck)), Cc.opacity = 0.85 * (1 - Ck), Cl < CF;
    } });
  }
  function C4(C8, C9, Cd) {
    let CC = du.get(C8);
    if (CC && (CC.root !== C9 || CC.team !== Cd) && (C5(C8), CC = null), CC || !C9 || !Cd) return CC;
    let Cc = dE(Cd), Cl = new r("team band");
    Cl.mesh = $n, Cl.material = new p({ colour: Cc, emissive: Cc.map((Ck) => Ck * 2.2 + 0.05), roughness: 0.4, castShadow: false }), Cl.setPosition(0, 1.12, 0), C9.add(Cl);
    let CF = new r("team mark");
    return CF.mesh = On, CF.material = Cl.material, CF.setPosition(0, 2.12, 0), CF.setScale(0.09, 0.14, 0.09), C9.add(CF), CC = { node: Cl, mark: CF, root: C9, team: Cd }, du.set(C8, CC), CC;
  }
  function C5(C8) {
    let C9 = du.get(C8);
    C9 && (C9.node.dispose(), C9.mark.dispose(), du.delete(C8));
  }
  let C6 = -1, C7 = -1;
  return U.addUpdater((C8) => {
    let C9 = dW();
    if (dA.hidden = !C9, !C9) {
      d0.connected && !(d0.features || []).includes("lasertag") && dp.hidden && (dp.textContent = "This game server does not run RZ LaserTag yet: it needs updating. You can look round the arena.", dp.hidden = false);
      return;
    }
    dp.hidden = true;
    let Cd = mt();
    dH = Cd, !U.player.wielding && d6.alive && (U.player.wielding = Y.blaster), !d6.alive && U.player.wielding === Y.blaster && (U.player.wielding = 0);
    let CC = d2.blasters.get("mine");
    if (CC && (CC.team !== dE(d6.team) && d6.team && CC.setTeam(dE(d6.team)), Ht(d6.blaster, Cd / 1e3), CC.setEnergy(d6.blaster.energy / R.energy)), dk) {
      let [Cm, Cu, Cj] = dk.p, CW = U.player;
      CW.position[0] = Cm, CW.position[1] = Cu + 0.05, CW.position[2] = Cj, CW.velocity[0] = CW.velocity[1] = CW.velocity[2] = 0, CW.yaw = dk.y, CW.pitch = 0, U.collision.groundAt(Cm, Cj, Cu + 1, 3) !== null && (dk = null);
    }
    if (!d6.alive && d6.deadAt) {
      let CS = U.player;
      CS.position[0] = d6.deadAt[0], CS.position[2] = d6.deadAt[2], CS.velocity[0] = CS.velocity[2] = 0;
    }
    dc && dz() && dK();
    let Cc = Math.max(0, d8 - Cd);
    if (dJ.textContent = d7 === "waiting" ? "" : Cn(Cc), dO.textContent = d7 === "countdown" ? "Get ready" : d7 === "ended" ? "Next match" : d7 === "playing" ? "First to " + dd : "Waiting", dg.textContent = String(d9.blue), dT.textContent = String(d9.black), dj && dj(d9, dJ.textContent, dO.textContent.toUpperCase()), d7 === "countdown") {
      let CE = Math.ceil(Cc / 1e3);
      CE <= 5 && CE !== dF && CE > 0 && (dF = CE, d4.beep(false)), di(CE > 0 ? String(CE) : "GO!", CE > 0 ? "The match is about to start" : "", 0, "is-count");
    } else dF = -1;
    if (d7 === "ended" && dC && !dL.hidden) {
      let Ch = dL.querySelector(".lt-next");
      Ch && (Ch.textContent = "Next match in " + Math.ceil(Cc / 1e3));
    }
    if (!d6.alive && d7 === "playing") {
      let CA = Math.max(0, R.respawnSeconds - (Cd - (d6._outAt || (d6._outAt = Cd))) / 1e3);
      dP.textContent = dP.textContent.replace(/Back in .*$/, "Back in " + Math.ceil(CA));
    } else d6._outAt = 0;
    let Cl = Math.round(d6.hp);
    Cl !== C6 && (C6 = Cl, dR.style.width = Cl + "%", dx.textContent = String(Cl), dG.classList.toggle("is-low", Cl <= 34));
    let CF = Math.round(d6.blaster.energy);
    CF !== C7 && (C7 = CF, dy.style.width = CF + "%", dN.textContent = String(CF)), df.classList.toggle("is-hot", (d6.blaster.lockedUntil || 0) > Cd / 1e3), dD.classList.toggle("is-safe", d6.protectUntil > Cd);
    for (let [Cv, CZ] of U.remotes) {
      let Cg = C4(Cv, CZ.root, dS(Cv));
      if (Cg) {
        let Cb = d5.get(Cv), CJ = Cb && Cb.alive === false;
        Cg.node.visible = Cg.mark.visible = !CJ;
      }
    }
    for (let CO of [...du.keys()]) CO !== "mine" && !U.remotes.has(CO) && C5(CO);
    let Ck = U._self && U._self.ready ? U._self.avatar.root : null;
    !C4("mine", U.view === "third" ? Ck : null, d6.team) && du.has("mine") && U.view !== "third" && C5("mine");
    for (let CM of [...dm]) CM.t += C8, CM.update(CM.t, CM.life) === false && (CM.node.dispose(), dm.splice(dm.indexOf(CM), 1));
  }), U.canvas.addEventListener("mousedown", (C8) => {
    d4.wake(), !(C8.button !== 0 || !dz() || !dW()) && U.player.wielding === Y.blaster && (dc = true, dK());
  }), window.addEventListener("mouseup", (C8) => {
    C8.button === 0 && (dc = false);
  }), window.addEventListener("keydown", (C8) => {
    d4.wake(), !(C8.code !== "Tab" || !dW()) && (C8.preventDefault(), !(d7 === "ended" && dC) && (dV(), dL.hidden = false));
  }), window.addEventListener("keyup", (C8) => {
    C8.code !== "Tab" || !dW() || d7 === "ended" && dC || (dL.hidden = true);
  }), { get team() {
    return d6.team;
  }, get phase() {
    return d7;
  }, get score() {
    return { ...d9 };
  }, get me() {
    return d6;
  }, players: d5, fire: dK, sounds: d4 };
}
var Mt = null;
J(O), V(new URL(".", import.meta.url).pathname);
var I = globalThis.RZ || {}, Ke = document.getElementById("view"), st = { el: document.getElementById("boot"), bar: document.getElementById("bootBar"), what: document.getElementById("bootWhat"), step(U, H) {
  this.bar && (this.bar.style.width = U + "%"), H && this.what && (this.what.textContent = H);
}, stuck(U) {
  this.step(100, U), this.el && this.el.classList.add("is-stuck");
}, done() {
  this.step(100, "ready"), setTimeout(() => this.el && this.el.classList.add("gone"), 240), setTimeout(() => this.el && this.el.remove(), 760);
} };
st.step(12, "starting the engine");
var E = new z(Ke, { sky: "day", fov: 60, gpu: await B() });
E.showHands();
if (I.room === "PAINTBALL") {
  let t = new Nt(E, { length: 1800, ambient: 0.62, lamps: [0.7, 1] }), e = new URLSearchParams(location.search).get("phase");
  t.fixed = e !== null && e !== "" && Number.isFinite(Number(e)) ? Number(e) : 0.25, t.update(true), E.addUpdater(() => t.update()), globalThis.rzDayNight = t;
}
st.step(34, "connecting");
var j = new s({ url: b(I), name: I.me && I.me.name || "Guest", room: I.room || "RECZONE", ticket: I.relayUrl ? g(() => j.room) : I.ticketUrl ? async () => {
  let U = await fetch(I.ticketUrl, { method: "POST", credentials: "same-origin", headers: { Accept: "application/json" } });
  return U.ok && (await U.json()).ticket || null;
} : null }), K = new y(E, { net: j });
K.groundPlane = false, j.source(() => E.player.snapshot()), j.addEventListener("state", (U) => E.applySnapshot(U.detail.id, U.detail.state, U.detail.time)), j.addEventListener("left", (U) => E.removeRemote(U.detail.id)), j.connect();
var Zt = [], ot = null;
E.addUpdater(() => {
  let U = E.player;
  if (ot) {
    if (E.collision.groundAt(ot[0], ot[2], ot[1] + 1, 3) === null) {
      U.position[0] = ot[0], U.position[1] = ot[1], U.position[2] = ot[2], U.velocity[0] = U.velocity[1] = U.velocity[2] = 0;
      return;
    }
    ot = null;
  }
  U.position[1] < -60 && Ot();
});
function Ot() {
  let U = Zt.filter((d1) => /spawn/i.test(d1.name || "") && !/drag/i.test(d1.name || ""));
  if (Mt && Mt.team) {
    let d1 = U.filter((d2) => new RegExp(Mt.team, "i").test(d2.name || ""));
    d1.length && (U = d1);
  }
  let H = U.length ? U : Zt;
  if (!H.length) return E.spawn(0, 1, 6);
  let d0 = H[Math.floor(Math.random() * H.length)].position;
  if (E.spawn(d0[0], d0[1] + 0.2, d0[2]), ot = [d0[0], d0[1] + 0.2, d0[2]], I.room === "PAINTBALL") {
    let d2 = [Math.sign(d0[0]) * 26.7, (Math.sign(d0[2]) || 1) * 4.6];
    E.player.yaw = Math.atan2(-(d2[0] - d0[0]), -(d2[1] - d0[2])), E.player.pitch = 0;
  } else K.doc.get("rc_model") && (E.player.yaw = Math.atan2(d0[0], d0[2]), E.player.pitch = 0.08);
  return E;
}
async function Fn() {
  st.step(56, "loading the build");
  let U;
  try {
    U = await fetch(I.buildUrl || "/api/game/build", { credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store" });
  } catch {
    return st.stuck("Could not reach RECZONE");
  }
  if (U.status === 403) {
    let d0 = await U.json().catch(() => ({}));
    return st.stuck(d0.message || "You cannot open this build");
  }
  if (!U.ok) return st.stuck("There is no build to load");
  let { scene: H } = await U.json();
  if (!H || !Array.isArray(H.objects) || !H.objects.length) return st.stuck("That build is empty");
  st.step(78, "placing " + H.objects.length + " things"), K.doc.replaceAll(H.objects), Array.isArray(H.spawns) && H.spawns.length && (Zt = H.spawns), Ot(), st.done();
}
var $t = null;
function Un() {
  $t && $t.undo(), $t = Fe({ scene: E.scene, world: K }), globalThis.rzBaked = $t;
}
K.doc.addEventListener("reset", () => setTimeout(Un, 0));
var Qe = null, kt = new f({ game: E, net: j, respawn: () => Ot() }), lt = new M({ mount: document.body, me: I.me && I.me.name || "You", room: () => I.roomName || "RECZONE", players: () => [...new Set([...j.players.values()].map((U) => U.name))].filter((U) => U !== j.name), onRespawn: Ot, onCamera: () => D(E, "reczone"), rooms: () => c({ current: I.room === "PAINTBALL" ? "paintball" : "reczone", knock: () => yt.toggle(true) }), invite: () => ({ text: I.room === "PAINTBALL" ? location.origin + "/game/paintball" : location.origin + "/game", note: "Link copied" }), pages: [l(), ...m({ me: I.me, onSaved: (U) => Qe?.refreshMe(U) }), Z({ net: j, tools: kt, site: true })], customize: () => lt.show("avatar") }), yt = F(lt, null);
yt.addEventListener("enter", (U) => {
  let H = /^DORM-(\d+)$/.exec(String(U.detail.room || "").toUpperCase()), d0 = yt.mine && yt.mine.room === U.detail.room;
  location.assign(!H || d0 ? "/dorm" : "/dorm/" + H[1]);
});
var Q = new T({ game: E, net: j, canvas: Ke, watch: lt, roomName: () => I.roomName || "RECZONE" });
globalThis.rzHud = Q;
var Je = new S();
Je.load(), new h({ library: Je, hud: Q }), kt.hud = Q, u({ game: E, net: j, tools: kt, hud: Q });
var Xe = new x({ game: E, net: j, hud: Q }).connect();
v({ pickups: Xe, world: K, game: E }), globalThis.rzPickups = Xe, globalThis.rzStaff = kt, I.room === "PAINTBALL" && (Mt = Ze({ game: E, net: j, hud: Q, tools: kt, world: K })), globalThis.rzLaserTag = Mt, globalThis.rzPortals = Ue({ game: E, world: K, watch: lt, hud: Q }), globalThis.rzRecCenter = Ve({ game: E, world: K });
var Kt = new G({ net: j, game: E });
Q.attachVoice(Kt), lt.attachVoice(Kt), globalThis.rzVoice = Kt, k(yt, lt, Q), globalThis.rzDorms = yt, setInterval(async () => {
  try {
    let U = await fetch(I.buildUrl || "/api/game/build", { credentials: "same-origin", headers: { Accept: "application/json" }, cache: "no-store" });
    if (U.status !== 403) return;
    let H = await U.json().catch(() => ({}));
    j.disconnect(), E.stop(), document.body.innerHTML = '<div style="min-height:100vh;display:grid;place-items:center;text-align:center;font:14px/1.6 Inter,system-ui,sans-serif;color:#f2f3f5;background:#000;padding:24px"><div><h1 style="font-size:1.2rem;margin:0 0 10px">You were taken out of the build</h1><p style="color:rgba(242,243,245,.58);margin:0 0 18px">' + In(H.message || "") + '</p><a href="/dorm" style="color:#f2f3f5">Back to your dorm</a></div></div>';
  } catch {
  }
}, 3e4);
var In = (U) => String(U).replace(/[&<>]/g, (H) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[H]);
globalThis.rzGame = E, globalThis.rzNet = j, globalThis.rzWorld = K, globalThis.rzWatch = lt, Fn();
var tn = new A({ net: j }).start();
E.addUpdater(() => tn.update()), globalThis.rzRadioSync = tn, import("./c-32QMBSR3.js").then((U) => {
  Qe = U.dressPlayers({ game: E, net: j, myName: I.me && I.me.name || "" });
}).catch((U) => console.warn("[wardrobe] outfits are off:", U.message)), E.start(), Q.redraw();
