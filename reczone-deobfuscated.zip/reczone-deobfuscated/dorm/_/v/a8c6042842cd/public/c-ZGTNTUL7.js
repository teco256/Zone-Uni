import { D as c, b as k, c as m, e as u, h as S, i as h, m as v, p as g, v as b, x as e } from "./c-USQKEFSE.js";
var y = { radius: 0.4, floor: 0.105, height: 0.42, balls: 5, ring: 0.235 }, $ = (M, s = {}) => new g({ colour: M, roughness: 0.5, ...s }), E = (M, x, f = [0, 0, 0], o = null) => {
  let r = new u("part");
  return r.mesh = M, r.material = x, r.setPosition(f[0], f[1], f[2]), o && r.setEuler(o[0], o[1], o[2]), r;
}, B = null;
function W() {
  if (B) return B;
  let M = y.radius;
  return B = { wire: $([0.11, 0.13, 0.18], { roughness: 0.35, metallic: 0.6 }), blue: $([0.12, 0.38, 0.92], { roughness: 0.3, metallic: 0.35 }), white: $([0.94, 0.95, 0.97], { roughness: 0.4 }), rubber: $([0.06, 0.06, 0.07], { roughness: 0.9 }), floor: $([0.16, 0.18, 0.24], { roughness: 0.6, metallic: 0.3 }), bar: h(8e-3, y.height - 0.08, 6), rimTop: v(M, 0.017, 48, 10), rimMid: v(M, 8e-3, 48, 6), rimLow: v(M, 0.012, 48, 8), disc: h(M, 0.025, 40), grate: v(M * 0.55, 6e-3, 32, 6), leg: h(0.014, 0.09, 10), foot: S(0.022, 12, 8) }, B;
}
function q(M = null) {
  let f = W(), o = y.radius, r = new u("ball basket");
  r.add(E(f.disc, f.floor, [0, y.floor - 0.0125, 0])), r.add(E(f.grate, f.wire, [0, y.floor, 0]));
  for (let L = 0; L < 3; L++) {
    let i = L / 3 * Math.PI * 2 + Math.PI / 6, I = Math.cos(i) * o * 0.82, U = Math.sin(i) * o * 0.82;
    r.add(E(f.leg, f.wire, [I, 0.05, U])), r.add(E(f.foot, f.rubber, [I, 0.018, U]));
  }
  let a = 22, P = y.floor - 0.01;
  for (let d0 = 0; d0 < a; d0++) {
    let d1 = d0 / a * Math.PI * 2;
    r.add(E(f.bar, f.wire, [Math.cos(d1) * o, P + (y.height - 0.08) / 2, Math.sin(d1) * o]));
  }
  let w = [E(f.rimLow, f.blue, [0, P, 0]), E(f.rimTop, f.blue, [0, y.height - 0.01, 0])];
  for (let d2 of w) r.add(d2);
  return r.add(E(f.rimMid, f.white, [0, P + (y.height - P) * 0.55, 0])), r.setColour = (d3) => {
    let d4 = Array.isArray(d3) && d3.length === 3 ? $(d3.slice(), { roughness: 0.3, metallic: 0.35 }) : f.blue;
    for (let d5 of w) d5.material = d4;
    r.colour = d4 === f.blue ? null : d3.slice();
  }, M && r.setColour(M), r.rings = w, r;
}
function F(M, x = y.balls) {
  let f = [];
  for (let o = 0; o < x; o++) {
    let r = o / x * Math.PI * 2;
    f.push([Math.cos(r) * y.ring, y.floor + M + 4e-3, Math.sin(r) * y.ring]);
  }
  return f;
}
var j = Math.PI / 180, K = 0.12;
function X(M) {
  let s = k.fromEuler(k.create(), (M.rotation[0] || 0) * j, (M.rotation[1] || 0) * j, (M.rotation[2] || 0) * j);
  return m.fromRotationTranslationScale(m.create(), s, M.position, M.scale);
}
var R = { centre: [-0.0375, 0.020215, 0.01745], radius: 29e-4, tube: 25e-5, out: [0, -1, 0] }, V = (M, s, x = 1) => [M[0] * s[0] + M[4] * s[1] + M[8] * s[2] + M[12] * x, M[1] * s[0] + M[5] * s[1] + M[9] * s[2] + M[13] * x, M[2] * s[0] + M[6] * s[1] + M[10] * s[2] + M[14] * x];
function lt({ pickups: M, world: f, game: o }) {
  let r = "", a = null, P = () => {
    a && (a.dispose(), a = null);
  }, w = () => {
    M.clear(), P();
  }, L = (d2) => d2.tag === "hoop" || /#basketball%20hoop$/.test(d2.src || ""), i = () => {
    let d2 = f.doc.list();
    if (!d2.length) {
      r && w(), r = "";
      return;
    }
    let d3 = d2.filter((dc) => L(dc) || dc.tag === "basketball" || dc.tag === "basket").map((dc) => dc.id + "@" + dc.position.map((dl) => dl.toFixed(2)) + "/" + (dc.rotation[1] || 0).toFixed(0)).join(",") || "-";
    if (d3 === r) return;
    let d4 = [];
    for (let dc of d2) if (dc.tag === "hoop") d4.push({ centre: dc.position.slice(), radius: Math.max(0.15, Math.abs(dc.scale[0]) / 2), tube: 0.025, out: null, node: f.nodes.get(dc.id) });
    else {
      if (/#basketball%20hoop$/.test(dc.src || "")) {
        let dl = X(dc), dF = Math.hypot(dl[0], dl[1], dl[2]), dk = V(dl, R.out, 0), dm = Math.hypot(dk[0], dk[2]) || 1;
        d4.push({ centre: V(dl, R.centre), radius: R.radius * dF, tube: Math.max(0.015, R.tube * dF), out: [dk[0] / dm, 0, dk[2] / dm] });
      }
    }
    for (let du of d4) du.node && (du.node.visible = false);
    let d5 = d2.filter((dj) => dj.tag === "basketball");
    if (r = d3, w(), !d4.length && !d5.length) return;
    for (let dj of d4) M.addHoop(dj);
    if (d5.length) {
      for (let dW of d5) {
        let dS = f.nodes.get(dW.id);
        dS && (dS.visible = false), M.addBall("ball-" + dW.id, dW.position.slice());
      }
      return;
    }
    let d6, d7, d8 = d2.find((dE) => dE.tag === "basket");
    if (d8) {
      let dE = f.nodes.get(d8.id);
      dE && (dE.visible = false), d6 = d8.position.slice(), d7 = (d8.rotation[1] || 0) * j;
    } else {
      let dh = d4[0], dA = dh.out || [0, 0, 1];
      d6 = [dh.centre[0] + dA[0] * K, dh.centre[1], dh.centre[2] + dA[2] * K], d7 = Math.atan2(dA[0], dA[2]);
    }
    let d9 = Z(o, [d6[0], d6[1] + 0.5, d6[2]], M);
    a = q(I().basket), a.setPosition(d6[0], d9, d6[2]), a.setEuler(0, d7, 0), o.scene.add(a);
    let dd = Math.cos(d7), dC = Math.sin(d7);
    F(c).forEach((dv, dZ) => {
      let dg = d6[0] + dv[0] * dd + dv[2] * dC, db = d6[2] - dv[0] * dC + dv[2] * dd, de = M.restHeight(dg, db, d9 + y.height) ?? d9 + dv[1];
      M.addBall("ball-" + (dZ + 1), [dg, de, db]);
    });
  }, I = () => {
    let d2 = f.doc.list().find(L), d3 = d2 && d2.paint || {};
    return { hoop: d2, basket: d3.basket || null, balls: d3.balls || null };
  }, U = () => {
    let d2 = I();
    a && a.setColour && JSON.stringify(a.colour || null) !== JSON.stringify(d2.basket) && a.setColour(d2.basket), JSON.stringify(M.ballColour || null) !== JSON.stringify(d2.balls) && M.setBallColour(d2.balls);
  };
  f.doc.addEventListener("reset", () => {
    r = "", setTimeout(() => {
      i(), U();
    }, 0);
  }), f.doc.addEventListener("changed", () => setTimeout(() => {
    i(), U();
  }, 0)), i(), U();
  let d0 = 0, d1 = setInterval(() => {
    if (++d0 > 20) return clearInterval(d1);
    if (a) {
      let d2 = a.position, d3 = Z(o, [d2[0], d2[1] + 0.5, d2[2]], M, a), d4 = d3 - d2[1];
      if (Math.abs(d4) > 2e-3) {
        a.setPosition(d2[0], d3, d2[2]);
        for (let d5 of M.balls.values()) {
          if (d5.owner || d5.held || !d5.asleep) continue;
          let d6 = M.restHeight(d5.home[0], d5.home[2], d3 + y.height);
          d5.home[1] = d6 ?? d5.home[1] + d4, d5.p = d5.home.slice();
        }
      }
    }
    if (!a) for (let d7 of M.balls.values()) {
      if (d7.owner || d7.held || !d7.asleep) continue;
      let d8 = M.restHeight(d7.home[0], d7.home[2], d7.home[1] + 0.6) ?? Q(o, [d7.home[0], d7.home[1] + 0.6, d7.home[2]], M) + c + 2e-3;
      Math.abs(d8 - d7.home[1]) > 2e-3 && (d7.home[1] = d8, d7.p = d7.home.slice());
    }
  }, 1e3);
  return { refresh: i, get basket() {
    return a;
  }, size: y, gear: I };
}
function Z(M, x, f, o = null) {
  let r = new Set(M._cameraSkip ? M._cameraSkip() : []);
  for (let P of f.balls.values()) r.add(P.node);
  o && r.add(o);
  let a = b(M.scene, x, [0, -1, 0], 20, r);
  return a != null ? x[1] - a : Q(M, x, f, o);
}
function Q(M, x, f, o = null) {
  let r = new Set(M._cameraSkip ? M._cameraSkip() : []);
  for (let L of f.balls.values()) r.add(L.node);
  o && r.add(o);
  let a = b(M.scene, x, [0, -1, 0], 20, r), P = M.collision.raycast(x, [0, -1, 0], 20, { ignoreInside: true }), w = Math.min(a ?? 1 / 0, P ? P.distance : 1 / 0);
  return Number.isFinite(w) ? x[1] - w : 0;
}
var l = (M, x, f) => {
  let o = document.createElement(M);
  return x && (o.className = x), f !== void 0 && (o.textContent = f), o;
};
function Y({ goTo: M, watch: f }) {
  let o = l("div", "wt-field wt-field-wide sp-visit"), r = l("div", "wt-fieldtop");
  r.append(l("span", "", "Go to a dorm"), l("b", "wt-val", "logged, 10 minutes"));
  let a = l("form", "sp-visitform"), P = l("input");
  P.type = "text", P.maxLength = 6, P.placeholder = "Dorm code", P.autocomplete = "off", P.spellcheck = false, P.addEventListener("input", () => {
    P.value = P.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
  });
  let w = l("button", "wt-chip", "Go");
  w.type = "submit";
  let L = l("div", "sp-said");
  a.append(P, w);
  let i = async (d0) => {
    L.textContent = "Going\u2026";
    try {
      let d1 = await fetch("/api/dorms/staff-visit", { method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ code: d0 }) }), d2 = await d1.json().catch(() => ({}));
      if (!d1.ok || !d2.ok) {
        L.textContent = d2.message || "Could not go there.";
        return;
      }
      L.textContent = "", f.toggle(false), M(d2.room, d2.name);
    } catch {
      L.textContent = "The site did not answer.";
    }
  };
  a.addEventListener("submit", (d0) => {
    d0.preventDefault(), P.value.length === 6 ? i(P.value) : L.textContent = "A dorm code is six letters and numbers.";
  });
  let I = l("div", "sp-reports"), U = () => {
    I.textContent = "", fetch("/api/dorm-reports", { credentials: "same-origin", headers: { Accept: "application/json" } }).then((d0) => d0.ok ? d0.json() : Promise.reject(new Error("HTTP " + d0.status))).then((d0) => {
      let d1 = d0.reports || [];
      I.appendChild(l("div", "sp-reporthead", d1.length ? "Reported dorms (" + d1.length + ")" : "No reported dorms waiting."));
      for (let d2 of d1) {
        let d3 = l("div", "sp-report"), d4 = l("div", "sp-reportwhat");
        d4.append(l("b", "", d2.code + " \xB7 " + d2.owner + "'s dorm"), l("span", "", "" + d2.reason + (d2.details ? ": " + d2.details : "")), l("small", "", "reported by " + d2.reporter));
        let d5 = l("button", "wt-chip", "Go there"), d6 = l("button", "wt-chip", "Done");
        d5.type = d6.type = "button", d5.addEventListener("click", () => i(d2.code)), d6.addEventListener("click", async () => {
          d6.disabled = true, await fetch("/api/dorm-reports/" + d2.id + "/resolve", { method: "POST", credentials: "same-origin" }).catch(() => {
          }), U();
        }), d3.append(d4, d5, d6), I.appendChild(d3);
      }
    }).catch(() => {
      I.appendChild(l("div", "sp-reporthead", "Reported dorms: the site did not answer."));
    });
  };
  return U(), o.append(r, a, L, I), o;
}
function pt({ net: M, tools: x, site: f = true, goTo: o = null }) {
  return { id: "staff", label: "Staff", title: "Staff panel", dock: false, visible: () => !!M.staff, draw(a, P) {
    let w = (d7) => typeof M.canStaff == "function" ? M.canStaff(d7) : !!M.staff, L = l("div", "st-note", "Bans, mutes and warnings happen on the website. Nothing here punishes anyone: the RPG sends people back to spawn and the ban hammer is for show (each hit is logged on the website and you get their details there).");
    a.appendChild(L);
    let U = l("div", "wt-field wt-field-wide sp-tools"), d0 = l("div", "wt-fieldtop"), d1 = ["1 hands", w("rpg") && "2 RPG", w("hammer") && "3 ban hammer"].filter(Boolean).join("  \xB7  ");
    d0.append(l("span", "", "In your hand"), l("b", "wt-val", d1));
    let d2 = l("div", "wt-chips"), d3 = [[e.none, "Hands", true], [e.rpg, "RPG", w("rpg")], [e.hammer, "Ban hammer", w("hammer")]];
    for (let [d7, d8, d9] of d3) {
      if (!d9) continue;
      let dd = l("button", "wt-chip" + ((x.game.player.wielding | 0) === d7 ? " is-on" : ""), d8);
      dd.type = "button", dd.dataset.tool = String(d7), dd.addEventListener("click", () => {
        x.equip(d7);
        for (let dC of d2.children) dC.classList.toggle("is-on", dC === dd);
      }), d2.appendChild(dd);
    }
    if (U.append(d0, d2), (w("rpg") || w("hammer")) && a.appendChild(U), !w("panel")) {
      a.appendChild(l("div", "wt-empty", "The list of who is here and their UUIDs has not been given to you. An EDR can give it on the website."));
      return;
    }
    f && o && a.appendChild(Y({ goTo: o, watch: P }));
    let d4 = l("div", "sp-list");
    a.appendChild(d4);
    let d5 = [...M.players.values()].filter((dC, dc, dl) => dl.findIndex((dF) => dF.name === dC.name) === dc && dC.id !== M.id);
    if (!d5.length) {
      d4.appendChild(l("div", "wt-empty", "Nobody else is here."));
      return;
    }
    let d6 = /* @__PURE__ */ new Map();
    for (let dC of d5) {
      let dc = l("div", "sp-row");
      dc.dataset.id = String(dC.id);
      let dl = l("div", "sp-who");
      dl.append(l("b", "sp-name", dC.name), l("span", "sp-rank", ""));
      let dF = l("code", "sp-uuid", f ? "UUID: asking the site\u2026" : "UUID: only on rec.zone");
      dl.appendChild(dF);
      let dk = l("div", "sp-actions"), dm = l("button", "wt-pill sp-copy", "Copy UUID");
      dm.type = "button", dm.disabled = true, dm.addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(dm.dataset.uuid || ""), dm.textContent = "Copied";
        } catch {
          dm.textContent = "Could not copy";
        }
        setTimeout(() => {
          dm.textContent = "Copy UUID";
        }, 1500);
      });
      let du = l("button", "wt-pill sp-back", "Send to spawn");
      du.type = "button", du.addEventListener("click", () => {
        x.sendBack(dC.id), du.textContent = "Sent", setTimeout(() => {
          du.textContent = "Send to spawn";
        }, 1500);
      }), dk.append(dm), w("rpg") && dk.append(du), dc.append(dl, dk), d4.appendChild(dc), d6.set(dC.name.toLowerCase(), { uuid: dF, copy: dm, rank: dl.querySelector(".sp-rank") });
    }
    f && fetch("/api/game/staff/players?names=" + encodeURIComponent(d5.map((dj) => dj.name).join(",")), { credentials: "same-origin", headers: { Accept: "application/json" } }).then((dj) => dj.ok ? dj.json() : Promise.reject(new Error("HTTP " + dj.status))).then((dj) => {
      for (let dW of dj.players || []) {
        let dS = d6.get(String(dW.username).toLowerCase());
        dS && (dS.uuid.textContent = "UUID: " + dW.uuid, dS.copy.dataset.uuid = dW.uuid, dS.copy.disabled = false, dS.rank.textContent = dW.role && dW.role !== "user" ? dW.role : "");
      }
      for (let dE of d6.values()) dE.copy.disabled && (dE.uuid.textContent = "UUID: no account found");
    }).catch((dj) => {
      for (let dW of d6.values()) dW.uuid.textContent = "UUID: the site did not answer (" + dj.message + ")";
    });
  } };
}
export {
  lt as a,
  pt as b
};
